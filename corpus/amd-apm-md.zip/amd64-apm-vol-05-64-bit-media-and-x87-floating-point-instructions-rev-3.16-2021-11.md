# AMD

# AMD64 Technology

# AMD64 Architecture Programmer’s Manual Volume 5: 64-Bit Media and x87 Floating-Point Instructions

<table>
  <thead>
    <tr>
        <th>Publication No.</th>
        <th>Revision</th>
        <th>Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>26569</td>
        <td>3.16</td>
        <td>November 2021</td>
    </tr>
  </tbody>
</table>

Advanced Micro Devices logo [AMD Confidential - Distribution with NDA]

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

© 2002–2021 Advanced Micro Devices, Inc. All rights reserved.

The information contained herein is for informational purposes only, and is subject to change without notice. While every precaution has been taken in the preparation of this document, it may contain technical inaccuracies, omissions and typographical errors, and AMD is under no obligation to update or otherwise correct this information. Advanced Micro Devices, Inc. makes no representations or warranties with respect to the accuracy or completeness of the contents of this document, and assumes no liability of any kind, including the implied warranties of noninfringement, merchantability or fitness for particular purposes, with respect to the operation or use of AMD hardware, software or other products described herein. No license, including implied or arising by estoppel, to any intellectual property rights is granted by this document. Terms and limitations applicable to the purchase or use of AMD's products are as set forth in a signed agreement between the parties or in AMD's Standard Terms and Conditions of Sale.

## Trademarks

AMD, the AMD Arrow logo, AMD Athlon, and AMD Opteron, and combinations thereof, and 3DNow! are trademarks, and AMD-K6 is a registered trademark of Advanced Micro Devices, Inc. Other product names used in this publication are for identification purposes only and may be trademarks of their respective companies.

Reverse engineering or disassembly is prohibited.

MMX is a trademark and Pentium is a registered trademark of Intel Corporation.

## Dolby Laboratories, Inc.

Manufactured under license from Dolby Laboratories.

## Rovi Corporation

This device is protected by U.S. patents and other intellectual property rights. The use of Rovi Corporation's copy protection technology in the device must be authorized by Rovi Corporation and is intended for home and other limited pay-per-view uses only, unless otherwise authorized in writing by Rovi Corporation.

USE OF THIS PRODUCT IN ANY MANNER THAT COMPLIES WITH THE MPEG ACTUAL OR DE FACTO VIDEO AND/OR AUDIO STANDARDS IS EXPRESSLY PROHIBITED WITHOUT ALL NECESSARY LICENSES UNDER APPLICABLE PATENTS. SUCH LICENSES MAY BE ACQUIRED FROM VARIOUS THIRD PARTIES INCLUDING, BUT NOT LIMITED TO, IN THE MPEG PATENT PORTFOLIO, WHICH LICENSE IS AVAILABLE FROM MPEG LA,

[AMD Confidential - Distribution with NDA]

AMD

26569—Rev. 3.16—November 2021 AMD64 Technology

# Contents

**Contents** iii
**Figures** ix
**Tables** xi
**Revision History** xiii
**Preface** xv
About This Book xv
Audience xv
Organization xv
Conventions and Definitions xvi
Related Documents xxviii
**1 64-Bit Media Instruction Reference** 1
CVTPD2PI 3
CVTPI2PD 6
CVTPI2PS 8
CVTPS2PI 10
CVTTPD2PI 12
CVTTPS2PI 15
EMMS 17
FEMMS 18
FRSTOR 20
FSAVE
(FNSAVE) 22
FXRSTOR 24
FXSAVE 26
MASKMOVQ 28
MOVD 31
MOVDQ2Q 34
MOVNTQ 36
MOVQ 38
MOVQ2DQ 40
PACKSSDW 42
PACKSSWB 44
PACKUSWB 46
PADDB 48
PADDD 50
PADDQ 52
PADDSB 54
PADDSW 56
PADDUSB 58
PADDUSW 60
PADDW 62

Contents [AMD Confidential - Distribution with NDA] <page_number>iii</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

PAND . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 64
PANDN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 66
PAVGB . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 68
PAVGUSB . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 70
PAVGW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 72
PCMPEQB . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 74
PCMPEQD . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 76
PCMPEQW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 78
PCMPGTB . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 80
PCMPGTD . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 82
PCMPGTW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 84
PEXTRW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 86
PF2ID . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 88
PF2IW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 90
PFACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 92
PFADD . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 94
PFCMPEQ . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 96
PFCMPGE . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 98
PFCMPGT . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 101
PFMAX . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 103
PFMIN . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 105
PFMUL . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 107
PFNACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 109
PFPNACC . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 112
PFRCP . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 115
PFRCPIT1 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 118
PFRCPIT2 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 121
PFRSQIT1 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 124
PFRSQRT . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 127
PFSUB . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 130
PFSUBR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 132
PI2FD . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 134
PI2FW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 136
PINSRW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 138
PMADDWD . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 140
PMAXSW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 142
PMAXUB . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 144
PMINSW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 146
PMINUB . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 148
PMOVMSKB . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 150
PMULHRW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 152
PMULHUW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 154
PMULHW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 156
PMULLW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 158
PMULUDQ . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 160
POR . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 162
PSADBW . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 164

<page_number>iv</page_number>

[AMD Confidential - Distribution with NDA]

Contents

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

PSHUFW ................................................................. 166
PSLLD .................................................................. 169
PSLLQ .................................................................. 171
PSLLW .................................................................. 173
PSRAD .................................................................. 175
PSRAW .................................................................. 177
PSRLD .................................................................. 179
PSRLQ .................................................................. 181
PSRLW .................................................................. 183
PSUBB .................................................................. 185
PSUBD .................................................................. 187
PSUBQ .................................................................. 189
PSUBSB ................................................................. 191
PSUBSW ................................................................. 193
PSUBUSB ................................................................ 195
PSUBUSW ................................................................ 197
PSUBW .................................................................. 199
PSWAPD ................................................................. 201
PUNPCKHBW ............................................................. 203
PUNPCKHDQ ............................................................. 205
PUNPCKHWD ............................................................. 207
PUNPCKLBW ............................................................. 209
PUNPCKLDQ ............................................................. 211
PUNPCKLWD ............................................................. 213
PXOR ................................................................... 215

# 2 x87 Floating-Point Instruction Reference ................................. 217

F2XM1 .................................................................. 218
FABS ................................................................... 220
FADD
FADDP
FIADD .................................................................. 222
FBLD ................................................................... 225
FBSTP .................................................................. 227
FCHS ................................................................... 229
FCLEX
(FNCLEX) ............................................................... 230
FCMOVcc ................................................................ 232
FCOM
FCOMP
FCOMPP ................................................................. 234
FCOMI
FCOMIP ................................................................. 237
FCOS ................................................................... 239
FDECSTP ................................................................ 241
FDIV
FDIVP
FIDIV .................................................................. 243

**Contents**

<mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>v</page_number>

AMD logo

# AMD64 Technology 26569—Rev. 3.16—November 2021

FDIVR
FDIVRP
FIDIVR ................................................................................................................................... 246
FFREE .................................................................................................................................... 249
FICOM
FICOMP ................................................................................................................................. 250
FILD ....................................................................................................................................... 252
FINCSTP ................................................................................................................................ 254
FINIT
FNINIT ................................................................................................................................... 256
FIST
FISTP ..................................................................................................................................... 258
FISTTP ................................................................................................................................... 261
FLD ........................................................................................................................................ 263
FLD1 ...................................................................................................................................... 265
FLDCW .................................................................................................................................. 266
FLDENV ................................................................................................................................. 268
FLDL2E .................................................................................................................................. 270
FLDL2T .................................................................................................................................. 271
FLDLG2 ................................................................................................................................. 272
FLDLN2 ................................................................................................................................. 273
FLDPI ..................................................................................................................................... 274
FLDZ ...................................................................................................................................... 275
FMUL
FMULP
FIMUL .................................................................................................................................... 276
FNOP ...................................................................................................................................... 279
FPATAN ................................................................................................................................. 280
FPREM ................................................................................................................................... 282
FPREM1 ................................................................................................................................. 284
FPTAN ................................................................................................................................... 286
FRNDINT ............................................................................................................................... 288
FRSTOR ................................................................................................................................. 290
FSAVE
FNSAVE ................................................................................................................................. 292
FSCALE ................................................................................................................................. 294
FSIN ....................................................................................................................................... 296
FSINCOS ................................................................................................................................ 298
FSQRT ................................................................................................................................... 300
FST
FSTP ...................................................................................................................................... 302
FSTCW
(FNSTCW) ............................................................................................................................. 304
FSTENV
(FNSTENV) ............................................................................................................................ 306
FSTSW
(FNSTSW) ............................................................................................................................. 308

<page_number>vi</page_number> [AMD Confidential - Distribution with NDA] **Contents**

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

FSUB
FSUBP
FISUB ................................................................................................................................................. 310

FSUBR
FSUBRP
FISUBR ............................................................................................................................................... 313

FTST ................................................................................................................................................... 316

FUCOM
FUCOMP
FUCOMPP .......................................................................................................................................... 317

FUCOMI
FUCOMIP ........................................................................................................................................... 319

FWAIT
(WAIT) ................................................................................................................................................ 321

FXAM ................................................................................................................................................. 322

FXCH .................................................................................................................................................. 324

FXTRACT ........................................................................................................................................... 325

FYL2X ................................................................................................................................................ 327

FYL2XP1 ............................................................................................................................................ 329

**Appendix A Recommended Substitutions for 3DNow!™ Instructions ................................... 333**

**Index ................................................................................................................................................. 335**

Contents

[AMD Confidential - Distribution with NDA]

<page_number>vii</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<page_number>viii</page_number>

[AMD Confidential - Distribution with NDA]

Contents

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Figures

Figure 1-1. Diagram Conventions for 64-Bit Media Instructions .................................... 1

Figures [AMD Confidential - Distribution with NDA] <page_number>ix</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<page_number>x</page_number>

[AMD Confidential - Distribution with NDA]

Figures

AMD

26569—Rev. 3.16—November 2021 AMD64 Technology

# Tables

Table 1-1. Immediate-Byte Operand Encoding for 64-Bit PEXTRW 86
Table 1-2. Numeric Range for PF2ID Results 89
Table 1-3. Numeric Range for PF2IW Results 91
Table 1-4. Numeric Range for PFACC Results 93
Table 1-5. Numeric Range for the PFADD Results 95
Table 1-6. Numeric Range for the PFCMPEQ Instruction 97
Table 1-7. Numeric Range for the PFCMPGE Instruction 99
Table 1-8. Numeric Range for the PFCMPGT Instruction 102
Table 1-9. Numeric Range for the PFMAX Instruction 104
Table 1-10. Numeric Range for the PFMIN Instruction 106
Table 1-11. Numeric Range for the PFMUL Instruction 108
Table 1-12. Numeric Range of PFNACC Results 110
Table 1-13. Numeric Range of PFPNACC Result (Low Result) 113
Table 1-14. Numeric Range of PFPNACC Result (High Result) 113
Table 1-15. Numeric Range for the PFRCP Result 116
Table 1-16. Numeric Range for the PFRCP Result 128
Table 1-17. Numeric Range for the PFSUB Results 131
Table 1-18. Numeric Range for the PFSUBR Results 133
Table 1-19. Immediate-Byte Operand Encoding for 64-Bit PINSRW 138
Table 1-20. Immediate-Byte Operand Encoding for PSHUFW 167
Table 2-1. Storing Numbers as Integers 258
Table 2-2. Storing Numbers as Integers 261
Table 2-3. Computing Arctangent of Numbers 280

Tables

[AMD Confidential - Distribution with NDA]

<page_number>xi</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<page_number>xii</page_number>

[AMD Confidential - Distribution with NDA]

Tables

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Revision History

<table>
  <thead>
    <tr>
        <th>Date</th>
        <th>Revision</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>November 2021</td>
        <td>3.16</td>
        <td>Added Alignment Check, #AC to FXRSTOR and FXSAVE and<br/>additional details of alignment check behavior.</td>
    </tr>
    <tr>
        <td>May 2018</td>
        <td>3.15</td>
        <td>Added clarification to CVTPI2PS.<br/>Corrected PSHUFW detail.</td>
    </tr>
    <tr>
        <td>September 2016</td>
        <td>3.14</td>
        <td>Modified Exceptions for Floating-Point Load under x87 Floating-<br/>Point Exception Generated, #MF.</td>
    </tr>
    <tr>
        <td>May 2013</td>
        <td>3.13</td>
        <td>Corrected CPUID function and feature bit called out in text for<br/>FXSAVE/FXRSTOR optimization. Made other corrections and<br/>clarifications related to the specification of feature bits.</td>
    </tr>
    <tr>
        <td>March 2012</td>
        <td>3.12</td>
        <td>Clarified exception and trap behavior for MASKMOVQ</td>
    </tr>
    <tr>
        <td>December 2009</td>
        <td>3.11</td>
        <td>Revised FCOM, FCOMP, FCOMPP and FCOMI, FCOMIP<br/>instruction pages.<br/>Corrected exception tables for FPREM and FPREM1.</td>
    </tr>
    <tr>
        <td>April 2009</td>
        <td>3.10</td>
        <td>Revised FCOM, FCOMP, FCOMPP description. Corrected<br/>FISTTP exception table.</td>
    </tr>
    <tr>
        <td>September 2007</td>
        <td>3.09</td>
        <td>Added minor clarifications and corrected typographical and<br/>formatting errors.</td>
    </tr>
    <tr>
        <td>July 2007</td>
        <td>3.08</td>
        <td>Added misaligned access support to applicable instructions.<br/>Deprecated 3DNow!™ instructions. Added Appendix<br/>A, "Recommended Substitutions for 3DNow!™ Instructions," on<br/>page 333.<br/>Added minor clarifications and corrected typographical and<br/>formatting errors.</td>
    </tr>
    <tr>
        <td>September 2006</td>
        <td>3.07</td>
        <td>Added minor clarifications and corrected typographical and<br/>formatting errors.</td>
    </tr>
    <tr>
        <td>December 2005</td>
        <td>3.06</td>
        <td>Added minor clarifications and corrected typographical and<br/>formatting errors.</td>
    </tr>
  </tbody>
</table>

Revision History <mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>xiii</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
        <th>Date</th>
        <th>Revision</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>December 2004</td>
        <td>3.05</td>
        <td>Added FISTTP instruction (SSE3). Updated CPUID information in exception tables. Corrected several typographical and formatting errors.</td>
    </tr>
    <tr>
        <td>September 2003</td>
        <td>3.04</td>
        <td>Clarified x87 condition codes for FPREM and FPREM1 instructions. Corrected tables of numeric ranges for results of PF2ID and PF2IW instructions.</td>
    </tr>
    <tr>
        <td>April 2003</td>
        <td>3.03</td>
        <td>Corrected numerous typos and stylistic errors. Corrected description of FYL2XP1 instruction. Clarified the description of the FXRSTOR instruction.</td>
    </tr>
  </tbody>
</table>

<page_number>xiv</page_number>

[AMD Confidential - Distribution with NDA] **Revision History**

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

# Preface

## About This Book

This book is part of a multivolume work entitled the *AMD64 Architecture Programmer’s Manual*. This table lists each volume and its order number.

<table>
  <thead>
    <tr>
        <th>Title</th>
        <th>Order No.</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Volume 1: Application Programming</td>
        <td>24592</td>
    </tr>
    <tr>
        <td>Volume 2: System Programming</td>
        <td>24593</td>
    </tr>
    <tr>
        <td>Volume 3: General-Purpose and System Instructions</td>
        <td>24594</td>
    </tr>
    <tr>
        <td>Volume 4: 128-Bit and 256-Bit Media Instructions</td>
        <td>26568</td>
    </tr>
    <tr>
        <td>Volume 5: 64-Bit Media and x87 Floating-Point Instructions</td>
        <td>26569</td>
    </tr>
  </tbody>
</table>

## Audience

This volume (Volume 5) is intended for all programmers writing application or system software for a processor that implements the AMD64 processor architecture.

## Organization

Volumes 3, 4, and 5 describe the AMD64 instruction set in detail. Together, they cover each instruction’s mnemonic syntax, opcodes, functions, affected flags, and possible exceptions.

The AMD64 instruction set is divided into five subsets:

* General-purpose instructions

* System instructions

* 128-bit and 256-bit media instructions (Streaming SIMD Extensions – SSE)

* 64-bit media instructions (MMX™)

* x87 floating-point instructions

A number of instructions belong to—and are described identically in—multiple instruction subsets.

This volume describes the 64-bit media and x87 floating-point instructions. The index at the end cross-references topics within this volume. For other topics relating to the AMD64 architecture, and for information on instructions in other subsets, see the tables of contents and indexes of the other volumes.

Preface [AMD Confidential - Distribution with NDA] <page_number>xv</page_number>

AMD64 Technology 26569—Rev. 3.16—November 2021

AMD logo



# Conventions and Definitions

The following section **Notational Conventions** describes notational conventions used in this volume and in the remaining volumes of this *AMD64 Architecture Programmer’s Manual*. This is followed by a **Definitions** section which lists a number of terms used in the manual along with their technical definitions. Finally, the **Registers** section lists the registers which are a part of the application programming model.

## Notational Conventions

#GP(0)

An instruction exception—in this example, a general-protection exception with error code of 0.

1011b

A binary value—in this example, a 4-bit value.

F0EA_0B02h

A hexadecimal value. Underscore characters may be inserted to improve readability.

128

Numbers without an alpha suffix are decimal unless the context indicates otherwise.

7:4

A bit range, from bit 7 to 4, inclusive. The high-order bit is shown first. Commas may be inserted to indicate gaps.

CPUID FnXXXX_XXXX_RRR[*FieldName*]

Support for optional features or the value of an implementation-specific parameter of a processor can be discovered by executing the CPUID instruction on that processor. To obtain this value, software must execute the CPUID instruction with the function code XXXX_XXXXh in EAX and then examine the field *FieldName* returned in register *RRR*. If the “_*RRR*” notation is followed by “_*xYYY*”, register ECX must be set to the value *YYYh* before executing CPUID. When *FieldName* is not given, the entire contents of register *RRR* contains the desired value. When determining optional feature support, if the bit identified by *FieldName* is set to a one, the feature is supported on that processor.

CR0–CR4

A register range, from register CR0 through CR4, inclusive, with the low-order register first.

CR0[PE], CR0.PE

Notation for referring to a field within a register—in this case, the PE field of the CR0 register.

CR0[PE] = 1, CR0.PE = 1

The PE field of the CR0 register is set (contains the value 1).

<page_number>xvi</page_number> [AMD Confidential - Distribution with NDA] Preface

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

EFER[LME] = 0, EFER.LME = 0

The LME field of the EFER register is cleared (contains a value of 0).

DS:SI

A far pointer or logical address. The real address or segment descriptor specified by the segment register (DS in this example) is combined with the offset contained in the second register (SI in this example) to form a real or virtual address.

RFLAGS[13:12]

A field within a register identified by its bit range. In this example, corresponding to the IOPL field.

# Definitions

Many of the following definitions assume an in-depth knowledge of the legacy x86 architecture. See “Related Documents” on page xxviii for descriptions of the legacy x86 architecture.

## 128-bit media instructions

Instructions that operate on the various 128-bit vector data types. Supported within both the legacy *SSE* and *extended SSE* instruction sets.

## 256-bit media instructions

Instructions that operate on the various 256-bit vector data types. Supported within the *extended SSE* instruction set.

## 64-bit media instructions

Instructions that operate on the 64-bit vector data types. These are primarily a combination of MMX and 3DNow!™ instruction sets and their extensions, with some additional instructions from the *SSE1* and *SSE2* instruction sets.

## 16-bit mode

Legacy mode or compatibility mode in which a 16-bit address size is active. See *legacy mode* and *compatibility mode*.

## 32-bit mode

Legacy mode or compatibility mode in which a 32-bit address size is active. See *legacy mode* and *compatibility mode*.

## 64-bit mode

A submode of *long mode*. In 64-bit mode, the default address size is 64 bits and new features, such as register extensions, are supported for system and application software.

## absolute

Said of a displacement that references the base of a code segment rather than an instruction pointer. Contrast with *relative*.

Preface [AMD Confidential - Distribution with NDA] <page_number>xvii</page_number>

AMD logo

**AMD64 Technology** **26569—Rev. 3.16—November 2021**

AES

Advance Encryption Standard (AES) algorithm acceleration instructions; part of *Streaming SIMD Extensions (SSE)*.

ASID

Address space identifier.

AVX

Extension of the SSE instruction set supporting 256-bit vector (packed) operands. See *Streaming SIMD Extensions*.

biased exponent

The sum of a floating-point value’s exponent and a constant bias for a particular floating-point data type. The bias makes the range of the biased exponent always positive, which allows reciprocation without overflow.

byte

Eight bits.

clear

To write a bit value of 0. Compare *set*.

compatibility mode

A submode of *long mode*. In compatibility mode, the default address size is 32 bits, and legacy 16-bit and 32-bit applications run without modification.

commit

To irreversibly write, in program order, an instruction’s result to software-visible storage, such as a register (including flags), the data cache, an internal write buffer, or memory.

CPL

Current privilege level.

direct

Referencing a memory location whose address is included in the instruction’s syntax as an immediate operand. The address may be an absolute or relative address. Compare *indirect*.

dirty data

Data held in the processor’s caches or internal buffers that is more recent than the copy held in main memory.

displacement

A signed value that is added to the base of a segment (absolute addressing) or an instruction pointer (relative addressing). Same as *offset*.

<page_number>xviii</page_number>

[AMD Confidential - Distribution with NDA]

Preface

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

doubleword

Two words, or four bytes, or 32 bits.

double quadword

Eight words, or 16 bytes, or 128 bits. Also called *octword*.

effective address size

The address size for the current instruction after accounting for the default address size and any address-size override prefix.

effective operand size

The operand size for the current instruction after accounting for the default operand size and any operand-size override prefix.

element

See *vector*.

exception

An abnormal condition that occurs as the result of executing an instruction. The processor’s response to an exception depends on the type of the exception. For all exceptions except SSE floating-point exceptions and x87 floating-point exceptions, control is transferred to the handler (or service routine) for that exception, as defined by the exception’s vector. For floating-point exceptions defined by the IEEE 754 standard, there are both masked and unmasked responses. When unmasked, the exception handler is called, and when masked, a default response is provided instead of calling the handler.

extended SSE

Enhanced set of SIMD instructions supporting 256-bit vector data types and allowing the specification of up to four operands. A subset of the *Streaming SIMD Extensions (SSE)*. Includes the *AVX*, *FMA*, *FMA4*, and *XOP* instructions. Compare *legacy SSE*.

flush

An often ambiguous term meaning (1) writeback, if modified, and invalidate, as in “flush the cache line,” or (2) invalidate, as in “flush the pipeline,” or (3) change a value, as in “flush to zero.”

FMA4

Fused Multiply Add, four operand. Part of the *extended SSE* instruction set.

FMA

Fused Multiply Add. Part of the *extended SSE* instruction set.

GDT

Global descriptor table.

Preface [AMD Confidential - Distribution with NDA] <page_number>xix</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

GIF

Global interrupt flag.

IDT

Interrupt descriptor table.

IGN

Ignored. Value written is ignored by hardware. Value returned on a read is indeterminate. See reserved.

indirect

Referencing a memory location whose address is in a register or other memory location. The address may be an absolute or relative address. Compare direct.

IRB

The virtual-8086 mode interrupt-redirection bitmap.

IST

The long-mode interrupt-stack table.

IVT

The real-address mode interrupt-vector table.

LDT

Local descriptor table.

legacy x86

The legacy x86 architecture. See “Related Documents” on page xxviii for descriptions of the legacy x86 architecture.

legacy mode

An operating mode of the AMD64 architecture in which existing 16-bit and 32-bit applications and operating systems run without modification. A processor implementation of the AMD64 architecture can run in either long mode or legacy mode. Legacy mode has three submodes, real mode, protected mode, and virtual-8086 mode.

legacy SSE

A subset of the Streaming SIMD Extensions (SSE) composed of the SSE1, SSE2, SSE3, SSSE3, SSE4.1, SSE4.2, and SSE4A instruction sets. Compare extended SSE.

long mode

An operating mode unique to the AMD64 architecture. A processor implementation of the AMD64 architecture can run in either long mode or legacy mode. Long mode has two submodes, 64-bit mode and compatibility mode.

<page_number>xx</page_number>

[AMD Confidential - Distribution with NDA]

Preface

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

lsb

    Least-significant bit.

LSB

    Least-significant byte.

main memory

    Physical memory, such as RAM and ROM (but not cache memory) that is installed in a particular computer system.

mask

    (1) A control bit that prevents the occurrence of a floating-point exception from invoking an exception-handling routine. (2) A field of bits used for a control purpose.

MBZ

    Must be zero. If software attempts to set an MBZ bit to 1, a general-protection exception (#GP) occurs. See *reserved*.

memory

    Unless otherwise specified, *main memory*.

msb

    Most-significant bit.

MSB

    Most-significant byte.

multimedia instructions

    Those instructions that operate simultaneously on multiple elements within a vector data type. Comprises the 256-bit media instructions, 128-bit media instructions, and 64-bit media instructions.

octword

    Same as *double quadword*.

offset

    Same as *displacement*.

overflow

    The condition in which a floating-point number is larger in magnitude than the largest, finite, positive or negative number that can be represented in the data-type format being used.

packed

    See *vector*.

Preface [AMD Confidential - Distribution with NDA] <page_number>xxi</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

PAE

Physical-address extensions.

physical memory

Actual memory, consisting of *main memory* and cache.

probe

A check for an address in a processor’s caches or internal buffers. *External probes* originate outside the processor, and *internal probes* originate within the processor.

protected mode

A submode of *legacy mode*.

quadword

Four words, or eight bytes, or 64 bits.

RAZ

Read as zero. Value returned on a read is always zero (0) regardless of what was previously written. (See *reserved*)

real-address mode

See *real mode*.

real mode

A short name for *real-address mode*, a submode of *legacy mode*.

relative

Referencing with a displacement (also called offset) from an instruction pointer rather than the base of a code segment. Contrast with *absolute*.

reserved

Fields marked as reserved may be used at some future time.

To preserve compatibility with future processors, reserved fields require special handling when read or written by software. Software must not depend on the state of a reserved field (unless qualified as RAZ), nor upon the ability of such fields to return a previously written state.

If a field is marked reserved without qualification, software must not change the state of that field; it must reload that field with the same value returned from a prior read.

Reserved fields may be qualified as IGN, MBZ, RAZ, or SBZ (see definitions).

REX

An instruction encoding prefix that specifies a 64-bit operand size and provides access to additional registers.

RIP-relative addressing

Addressing relative to the 64-bit RIP instruction pointer.

<page_number>xxii</page_number>

[AMD Confidential - Distribution with NDA]

Preface

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

SBZ

Should be zero. An attempt by software to set an SBZ bit to 1 results in undefined behavior. See *reserved*.

scalar

An atomic value existing independently of any specification of location, direction, etc., as opposed to *vectors*.

set

To write a bit value of 1. Compare *clear*.

SIB

A byte following an instruction opcode that specifies address calculation based on scale (S), index (I), and base (B).

SIMD

Single instruction, multiple data. See *vector*.

Streaming SIMD Extensions (SSE)

Instructions that operate on scalar or vector (packed) integer and floating point numbers. The SSE instruction set comprises the *legacy SSE* and *extended SSE* instruction sets.

SSE1

Original SSE instruction set. Includes instructions that operate on vector operands in both the MMX and the XMM registers.

SSE2

Extensions to the SSE instruction set.

SSE3

Further extensions to the SSE instruction set.

SSSE3

Further extensions to the SSE instruction set.

SSE4.1

Further extensions to the SSE instruction set.

SSE4.2

Further extensions to the SSE instruction set.

SSE4A

A minor extension to the SSE instruction set adding the instructions EXTRQ, INSERTQ, MOVNTSS, and MOVNTSD.

Preface

[AMD Confidential - Distribution with NDA]

<page_number>xxiii</page_number>

AMD logo

# AMD64 Technology 26569—Rev. 3.16—November 2021

sticky bit

A bit that is set or cleared by hardware and that remains in that state until explicitly changed by software.

TOP

The x87 top-of-stack pointer.

TSS

Task-state segment.

underflow

The condition in which a floating-point number is smaller in magnitude than the smallest nonzero, positive or negative number that can be represented in the data-type format being used.

vector

(1) A set of integer or floating-point values, called *elements*, that are packed into a single operand. Most of the media instructions support vectors as operands. Vectors are also called *packed* or *SIMD* (single-instruction multiple-data) operands.

(2) An index into an interrupt descriptor table (IDT), used to access exception handlers. Compare *exception*.

VEX

An instruction encoding escape prefix that opens a new extended instruction encoding space, specifies a 64-bit operand size, and provides access to additional registers. See *XOP prefix*.

virtual-8086 mode

A submode of *legacy mode*.

VMCB

Virtual machine control block.

VMM

Virtual machine monitor.

word

Two bytes, or 16 bits.

XOP instructions

Part of the extended SSE instruction set using the XOP prefix. See *Streaming SIMD Extensions*.

XOP prefix

Extended instruction identifier prefix, used by XOP instructions allowing the specification of up to four operands and 128 or 256-bit operand widths.

<page_number>xxiv</page_number>

[AMD Confidential - Distribution with NDA]

Preface

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

# Registers

In the following list of registers, the names are used to refer either to a given register or to the contents of that register:

AH–DH

- The high 8-bit AH, BH, CH, and DH registers. Compare *AL–DL*.

AL–DL

- The low 8-bit AL, BL, CL, and DL registers. Compare *AH–DH*.

AL–r15B

- The low 8-bit AL, BL, CL, DL, SIL, DIL, BPL, SPL, and R8B–R15B registers, available in 64-bit mode.

BP

- Base pointer register.

CR*n*

- Control register number *n*.

CS

- Code segment register.

eAX–eSP

- The 16-bit AX, BX, CX, DX, DI, SI, BP, and SP registers or the 32-bit EAX, EBX, ECX, EDX, EDI, ESI, EBP, and ESP registers. Compare *rAX–rSP*.

EBP

- Extended base pointer register.

EFER

- Extended features enable register.

eFLAGS

- 16-bit or 32-bit flags register. Compare *rFLAGS*.

EFLAGS

- 32-bit (extended) flags register.

eIP

- 16-bit or 32-bit instruction-pointer register. Compare *rIP*.

EIP

- 32-bit (extended) instruction-pointer register.

Preface [AMD Confidential - Distribution with NDA] <page_number>xxv</page_number>

AMD logo

# AMD64 Technology 26569—Rev. 3.16—November 2021

FLAGS

16-bit flags register.

GDTR

Global descriptor table register.

GPRs

General-purpose registers. For the 16-bit data size, these are AX, BX, CX, DX, DI, SI, BP, and SP. For the 32-bit data size, these are EAX, EBX, ECX, EDX, EDI, ESI, EBP, and ESP. For the 64-bit data size, these include RAX, RBX, RCX, RDX, RDI, RSI, RBP, RSP, and R8–R15.

IDTR

Interrupt descriptor table register.

IP

16-bit instruction-pointer register.

LDTR

Local descriptor table register.

MSR

Model-specific register.

r8–r15

The 8-bit R8B–R15B registers, or the 16-bit R8W–R15W registers, or the 32-bit R8D–R15D registers, or the 64-bit R8–R15 registers.

rAX–rSP

The 16-bit AX, BX, CX, DX, DI, SI, BP, and SP registers, or the 32-bit EAX, EBX, ECX, EDX, EDI, ESI, EBP, and ESP registers, or the 64-bit RAX, RBX, RCX, RDX, RDI, RSI, RBP, and RSP registers. Replace the placeholder r with nothing for 16-bit size, “E” for 32-bit size, or “R” for 64-bit size.

RAX

64-bit version of the EAX register.

RBP

64-bit version of the EBP register.

RBX

64-bit version of the EBX register.

RCX

64-bit version of the ECX register.

<page_number>xxvi</page_number>

[AMD Confidential - Distribution with NDA]

Preface

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

RDI

64-bit version of the EDI register.

RDX

64-bit version of the EDX register.

rFLAGS

16-bit, 32-bit, or 64-bit flags register. Compare *RFLAGS*.

RFLAGS

64-bit flags register. Compare *rFLAGS*.

rIP

16-bit, 32-bit, or 64-bit instruction-pointer register. Compare *RIP*.

RIP

64-bit instruction-pointer register.

RSI

64-bit version of the ESI register.

RSP

64-bit version of the ESP register.

SP

Stack pointer register.

SS

Stack segment register.

TPR

Task priority register (CR8), a new register introduced in the AMD64 architecture to speed interrupt management.

TR

Task register.

## Endian Order

The x86 and AMD64 architectures address memory using little-endian byte-ordering. Multibyte values are stored with their least-significant byte at the lowest byte address, and they are illustrated with their least significant byte at the right side. Strings are illustrated in reverse order, because the addresses of their bytes increase from right to left.

Preface [AMD Confidential - Distribution with NDA] <page_number>xxvii</page_number>

AMD logo

# AMD64 Technology 26569—Rev. 3.16—November 2021

## Related Documents

* Peter Abel, *IBM PC Assembly Language and Programming*, Prentice-Hall, Englewood Cliffs, NJ, 1995.

* Rakesh Agarwal, *80x86 Architecture & Programming: Volume II*, Prentice-Hall, Englewood Cliffs, NJ, 1991.

* AMD, *AMD-K6™ MMX™ Enhanced Processor Multimedia Technology*, Sunnyvale, CA, 2000.

* AMD, *3DNow!™ Technology Manual*, Sunnyvale, CA, 2000.

* AMD, *AMD Extensions to the 3DNow!™ and MMX™ Instruction Sets*, Sunnyvale, CA, 2000.

* Don Anderson and Tom Shanley, *Pentium Processor System Architecture*, Addison-Wesley, New York, 1995.

* Nabajyoti Barkakati and Randall Hyde, *Microsoft Macro Assembler Bible*, Sams, Carmel, Indiana, 1992.

* Barry B. Brey, *8086/8088, 80286, 80386, and 80486 Assembly Language Programming*, Macmillan Publishing Co., New York, 1994.

* Barry B. Brey, *Programming the 80286, 80386, 80486, and Pentium Based Personal Computer*, Prentice-Hall, Englewood Cliffs, NJ, 1995.

* Ralf Brown and Jim Kyle, *PC Interrupts*, Addison-Wesley, New York, 1994.

* Penn Brumm and Don Brumm, *80386/80486 Assembly Language Programming*, Windcrest McGraw-Hill, 1993.

* Geoff Chappell, *DOS Internals*, Addison-Wesley, New York, 1994.

* Chips and Technologies, Inc. *Super386 DX Programmer’s Reference Manual*, Chips and Technologies, Inc., San Jose, 1992.

* John Crawford and Patrick Gelsinger, *Programming the 80386*, Sybex, San Francisco, 1987.

* Cyrix Corporation, *5x86 Processor BIOS Writer's Guide*, Cyrix Corporation, Richardson, TX, 1995.

* Cyrix Corporation, *M1 Processor Data Book*, Cyrix Corporation, Richardson, TX, 1996.

* Cyrix Corporation, *MX Processor MMX Extension Opcode Table*, Cyrix Corporation, Richardson, TX, 1996.

* Cyrix Corporation, *MX Processor Data Book*, Cyrix Corporation, Richardson, TX, 1997.

* Ray Duncan, *Extending DOS: A Programmer's Guide to Protected-Mode DOS*, Addison Wesley, NY, 1991.

* William B. Giles, *Assembly Language Programming for the Intel 80xxx Family*, Macmillan, New York, 1991.

* Frank van Gilluwe, *The Undocumented PC*, Addison-Wesley, New York, 1994.

* John L. Hennessy and David A. Patterson, *Computer Architecture*, Morgan Kaufmann Publishers, San Mateo, CA, 1996.

* Thom Hogan, *The Programmer’s PC Sourcebook*, Microsoft Press, Redmond, WA, 1991.

<page_number>xxviii</page_number>

[AMD Confidential - Distribution with NDA]

Preface

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

* Hal Katircioglu, *Inside the 486, Pentium, and Pentium Pro*, Peer-to-Peer Communications, Menlo Park, CA, 1997.

* IBM Corporation, *486SLC Microprocessor Data Sheet*, IBM Corporation, Essex Junction, VT, 1993.

* IBM Corporation, *486SLC2 Microprocessor Data Sheet*, IBM Corporation, Essex Junction, VT, 1993.

* IBM Corporation, *80486DX2 Processor Floating Point Instructions*, IBM Corporation, Essex Junction, VT, 1995.

* IBM Corporation, *80486DX2 Processor BIOS Writer's Guide*, IBM Corporation, Essex Junction, VT, 1995.

* IBM Corporation, *Blue Lightning 486DX2 Data Book*, IBM Corporation, Essex Junction, VT, 1994.

* Institute of Electrical and Electronics Engineers, *IEEE Standard for Binary Floating-Point Arithmetic*, ANSI/IEEE Std 754-1985.

* Institute of Electrical and Electronics Engineers, *IEEE Standard for Radix-Independent Floating-Point Arithmetic*, ANSI/IEEE Std 854-1987.

* Muhammad Ali Mazidi and Janice Gillispie Mazidi, *80X86 IBM PC and Compatible Computers*, Prentice-Hall, Englewood Cliffs, NJ, 1997.

* Hans-Peter Messmer, *The Indispensable Pentium Book*, Addison-Wesley, New York, 1995.

* Karen Miller, *An Assembly Language Introduction to Computer Architecture: Using the Intel Pentium*, Oxford University Press, New York, 1999.

* Stephen Morse, Eric Isaacson, and Douglas Albert, *The 80386/387 Architecture*, John Wiley & Sons, New York, 1987.

* NexGen Inc., *Nx586 Processor Data Book*, NexGen Inc., Milpitas, CA, 1993.

* NexGen Inc., *Nx686 Processor Data Book*, NexGen Inc., Milpitas, CA, 1994.

* Bipin Patwardhan, *Introduction to the Streaming SIMD Extensions in the Pentium III*, www.x86.org/articles/sse_pt1/simd1.htm, June, 2000.

* Peter Norton, Peter Aitken, and Richard Wilton, *PC Programmer’s Bible*, Microsoft Press, Redmond, WA, 1993.

* *PharLap 386|ASM Reference Manual*, Pharlap, Cambridge MA, 1993.

* *PharLap TNT DOS-Extender Reference Manual*, Pharlap, Cambridge MA, 1995.

* Sen-Cuo Ro and Sheau-Chuen Her, *i386/i486 Advanced Programming*, Van Nostrand Reinhold, New York, 1993.

* Jeffrey P. Royer, *Introduction to Protected Mode Programming*, course materials for an onsite class, 1992.

* Tom Shanley, *Protected Mode System Architecture*, Addison Wesley, NY, 1996.

* SGS-Thomson Corporation, *80486DX Processor SMM Programming Manual*, SGS-Thomson Corporation, 1995.

Preface

[AMD Confidential - Distribution with NDA]

<page_number>xxix</page_number>

AMD logo

# AMD64 Technology 26569—Rev. 3.16—November 2021

* Walter A. Triebel, *The 80386DX Microprocessor*, Prentice-Hall, Englewood Cliffs, NJ, 1992.

* John Wharton, *The Complete x86*, MicroDesign Resources, Sebastopol, California, 1994.

* Web sites and newsgroups:

    - www.amd.com

    - news.comp.arch

    - news.comp.lang.asm.x86

    - news.intel.microprocessors

    - news.microsoft

xxx

[AMD Confidential - Distribution with NDA]

Preface

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# 1 64-Bit Media Instruction Reference

This chapter describes the function, mnemonic syntax, opcodes, affected flags, and possible exceptions generated by the 64-bit media instructions. These instructions operate on data located in the 64-bit MMX registers. Most of the instructions operate in parallel on sets of packed elements called vectors, although some operate on scalars. The instructions define both integer and floating-point operations, and include the legacy MMX™ instructions, the 3DNow!™ instructions, and the AMD extensions to the MMX and 3DNow! instruction sets.

Each instruction that performs a vector (packed) operation is illustrated with a diagram. Figure 1-1 on page 1 shows the conventions used in these diagrams. The particular diagram shows the PSLLW (packed shift left logical words) instruction.

Arrowheads going *to* a source operand indicate the writing of the result. In this case, the result is written to the first source operand, which is also the destination operand.

Diagram showing conventions for 64-bit media instructions, specifically the PSLLW instruction, with callouts for operands, operations, and ellipses.

Arrowheads coming *from* a source operand indicate that the source operand provides a *control function*. In this case, the second source operand specifies the **number** of bits to shift, and the first source operand specifies the **data** to be shifted.

Ellipses indicate that the operation is repeated for each element of the source vectors. In this case, there are 4 elements in each source vector, so the operation is performed 4 times, in parallel.

Figure 1-1. Diagram Conventions for 64-Bit Media Instructions

Gray areas in diagrams indicate unmodified operand bits.


1

64-Bit Media [AMD Confidential - Distribution with NDA] 1
Instruction Reference

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

Like the 128-bit media instructions, many of the 64-bit instructions independently and simultaneously perform a single operation on multiple elements of a vector and are thus classified as *single-instruction, multiple-data* (SIMD) instructions. A few 64-bit media instructions convert operands in MMX registers to operands in GPR, XMM, or x87 registers (or vice versa), or save or restore MMX state, or reset x87state.

Hardware support of the MMX instruction set and specific optional extensions can be determined by testing specific bits of the value returned in EDX by the CPUID instruction. If a specific bit is set in the return value, the feature is supported on the processor. The following lists the CPUID function numbers and feature bits indicating support for these features:

* MMX Instructions, indicated by EDX[23] returned by CPUID function 0000_0001h and function 8000_0001h.

* AMD Extensions to MMX Instructions, indicated by EDX[22] of CPUID function 8000_0001h.

* SSE1, indicated by EDX[25] of CPUID function 0000_0001h.

* SSE2, indicated by EDX[26] of CPUID function 0000_0001h.

* AMD 3DNow! Instructions, indicated by EDX[31] of CPUID function 8000_0001h.

* AMD Extensions to 3DNow! Instructions, indicated by EDX[30] of CPUID function 8000_0001h.

* FXSAVE and FXRSTOR, indicated by EDX[24] of CPUID function 0000_0001h and function 8000_0001h.

The 64-bit media instructions can be used in legacy mode or long mode. Their use in long mode is available if the following CPUID function return bit is set:

* Long Mode, indicated by EDX[29] of CPUID function 8000_0001h.

For more information on using the CPUID instruction, see the instruction description in Volume 3.

Compilation of 64-bit media programs for execution in 64-bit mode offers four primary advantages: access to the eight extended, 64-bit general-purpose registers (for a register set consisting of GPR0–GPR15), access to the eight extended XMM registers (for a register set consisting of XMM0–XMM15), access to the 64-bit virtual address space, and access to the RIP-relative addressing mode.

For further information, see:

* “64-Bit Media Programming” in Volume 1.

* “Summary of Registers and Data Types” in Volume 3.

* “Notation” in Volume 3.

* “Instruction Prefixes” in Volume 3.

<page_number>2</page_number>

[AMD Confidential - Distribution with NDA] **64-Bit Media Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# CVTPD2PI Convert Packed Double-Precision Floating-Point to Packed Doubleword Integers

Converts two packed double-precision floating-point values in an XMM register or a 128-bit memory location to two packed 32-bit signed integer values and writes the converted values in an MMX register.

If the result of the conversion is an inexact value, the value is rounded as specified by the rounding control bits (RC) in the MXCSR register. If the floating-point value is a NaN, infinity, or if the result of the conversion is larger than the maximum signed doubleword (–2<sup>31</sup> to +2<sup>31</sup> – 1), the instruction returns the 32-bit indefinite integer value (8000_0000h) when the invalid-operation exception (IE) is masked.

The CVTPD2PI instruction is an SSE2 instruction. Support for this instruction set is indicated by CPUID Fn0000_0001_EDX[SSE2] = 1. Support for misaligned 16-byte memory accesses is indicated by CPUID Fn8000_0001_ECX[MisAlignSse] = 1.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CVTPD2PI mmx, xmm2/mem128</td>
        <td>66 0F 2D /r</td>
        <td>Converts packed double-precision floating-point values in an XMM register or 128-bit memory location to packed doubleword integers values in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two 64-bit double-precision floating-point values from a 128-bit xmm/mem128 source to two 32-bit doubleword integers in a 64-bit mmx destination register.

## Related Instructions

CVTDQ2PD, CVTPD2DQ, CVTPI2PD, CVTSD2SI, CVTSI2SD, CVTTPD2DQ, CVTTPD2PI, CVTTSD2SI

## rFLAGS Affected

None

**64-Bit Media**
**Instruction Reference**
**CVTPD2PI**
[AMD Confidential - Distribution with NDA]
<page_number>

3
</page_number>

AMD logo

**AMD64 Technology**

**26569—Rev. 3.16—November 2021**

## MXCSR Flags Affected

<table>
  <thead>
    <tr>
        <th>MM</th>
        <th>FZ</th>
        <th colspan="2">RC</th>
        <th>PM</th>
        <th>UM</th>
        <th>OM</th>
        <th>ZM</th>
        <th>DM</th>
        <th>IM</th>
        <th>DAZ</th>
        <th>PE</th>
        <th>UE</th>
        <th>OE</th>
        <th>ZE</th>
        <th>DE</th>
        <th>IE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
    </tr>
    <tr>
        <td>17</td>
        <td>15</td>
        <td>14</td>
        <td>13</td>
        <td>12</td>
        <td>11</td>
        <td>10</td>
        <td>9</td>
        <td>8</td>
        <td>7</td>
        <td>6</td>
        <td>5</td>
        <td>4</td>
        <td>3</td>
        <td>2</td>
        <td>1</td>
        <td>0</td>
    </tr>
  </tbody>
</table>

**Note:** A flag that can be set to one or zero is M (modified). Unaffected flags are blank.

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="4">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The operating-system FXSAVE/FXRSTOR support bit (OSFXSR) of CR4 was cleared to 0.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>There was an unmasked SIMD floating-point exception while CR4.OSXMMEXCPT was cleared to 0.<br/>See SIMD Floating-Point Exceptions, below, for details.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The memory operand was not aligned on a 16-byte boundary while MXCSR.MM = 0.</td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled with MXCSR.MM = 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An exception is pending due to an x87 floating-point instruction.</td>
    </tr>
    <tr>
        <td>SIMD Floating-Point Exception, #XF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>There was an unmasked SIMD floating-point exception while CR4.OSXMMEXCPT was set to 1.<br/>See SIMD Floating-Point Exceptions, below, for details.</td>
    </tr>
  </tbody>
</table>

<page_number>4</page_number>

**CVTPD2PI**
[AMD Confidential - Distribution with NDA]

**64-Bit Media Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td colspan="5">SIMD Floating-Point Exceptions</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN 
value, or ±infinity.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was too large to fit in the 
destination format.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the 
destination format.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
**CVTPD2PI**
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>5</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# CVTPI2PD Convert Packed Doubleword Integers to Packed Double-Precision Floating-Point

Converts two packed 32-bit signed integer values in an MMX register or a 64-bit memory location to two double-precision floating-point values and writes the converted values in an XMM register.

The CVTPI2PD instruction is an SSE2 instruction. Support for this instruction set is indicated by CPUID Fn0000_0001_EDX[SSE2] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CVTPI2PD xmm, mmx/mem64</td>
        <td>66 0F 2A /r</td>
        <td>Converts two packed doubleword integer values in an MMX register or 64-bit memory location to two packed double-precision floating-point values in the destination XMM register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two 32-bit integers from an mmx/mem64 register to two 64-bit double-precision floating-point values in an xmm register.

## Related Instructions

CVTDQ2PD, CVTPD2DQ, CVTPD2PI, CVTSD2SI, CVTSI2SD, CVTTPD2DQ, CVTTPD2PI, CVTTSD2SI

## rFLAGS Affected

None

## MXCSR Flags Affected

None

<page_number>

6
</page_number>

[AMD Confidential - Distribution with NDA] CVTPI2PD 64-Bit Media Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The operating-system FXSAVE/FXRSTOR support bit (OSFXSR) of CR4 was cleared to 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

CVTPI2PD
[AMD Confidential - Distribution with NDA]

<page_number>7</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# CVTPI2PS Convert Packed Doubleword Integers to Packed Single-Precision Floating-Point

Converts two packed 32-bit signed integer values in an MMX register or a 64-bit memory location to two single-precision floating-point values and writes the converted values in the low-order 64 bits of an XMM register. The high-order 64 bits of the XMM register are not modified. If the result of the conversion is an inexact value, the value is rounded as specified by the rounding control bits (RC) in the MXCSR register.

The CVTPI2PS instruction is an SSE1 instruction. Support for this instruction set is indicated by CPUID Fn0000_0001_EDX[SSE] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CVTPI2PS xmm, mmx/mem64</td>
        <td>0F 2A /r</td>
        <td>Converts packed doubleword integer values in an MMX register or 64-bit memory location to single-precision floating-point values in the destination XMM register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two 32-bit integers from an MMX register or 64-bit memory location to two single-precision floating-point values in the low 64 bits of an XMM register.

## Related Instructions

CVTDQ2PS, CVTPS2DQ, CVTPS2PI, CVTSI2SS, CVTSS2SI, CVTTPS2DQ, CVTTPS2PI, CVTTSS2SI

## rFLAGS Affected

None

<page_number>8</page_number>CVTPI2PS <mark>[AMD Confidential - Distribution with NDA]</mark> 64-Bit Media Instruction Reference

26569—Rev. 3.16—November 2021 AMD

AMD64 Technology

## MXCSR Flags Affected

<table>
  <thead>
    <tr>
        <th>MM</th>
        <th>FZ</th>
        <th colspan="2">RC</th>
        <th>PM</th>
        <th>UM</th>
        <th>OM</th>
        <th>ZM</th>
        <th>DM</th>
        <th>IM</th>
        <th>DAZ</th>
        <th>PE</th>
        <th>UE</th>
        <th>OE</th>
        <th>ZE</th>
        <th>DE</th>
        <th colspan="2">IE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>17</td>
        <td>15</td>
        <td>14</td>
        <td>13</td>
        <td>12</td>
        <td>11</td>
        <td>10</td>
        <td>9</td>
        <td>8</td>
        <td>7</td>
        <td>6</td>
        <td>5</td>
        <td>4</td>
        <td>3</td>
        <td>2</td>
        <td>1</td>
        <td>0</td>
        <td></td>
    </tr>
  </tbody>
</table>

**Note:** A flag that can be set to one or zero is M (modified). Unaffected flags are blank.

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The SSE1 instructions are not supported, as 
indicated by CPUID Fn0000_0001_EDX[SSE] = 0.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
      <td>Invalid opcode, #UD</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The operating-system FXSAVE/FXRSTOR support 
bit (OSFXSR) of CR4 was cleared to 0.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>There was an unmasked SIMD floating-point 
exception while CR4.OSXMMEXCPT was cleared to 
0. See SIMD Floating-Point Exceptions, below, for 
details.</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit 
or was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, #GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>A page fault resulted from the execution of the 
instruction.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, #MF</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>An unmasked x87 floating-point exception was 
pending.</td>
    </tr>
    <tr>
      <td>Alignment check, #AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>SIMD Floating-Point 
Exception, #XF</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>There was an unmasked SIMD floating-point 
exception while CR4.OSXMMEXCPT was set to 1.
See SIMD Floating-Point Exceptions, below, for 
details.</td>
    </tr>
    <tr>
      <td colspan="5">SIMD Floating-Point Exceptions</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the 
destination format.</td>
    </tr>
  </tbody>
</table>

64-Bit Media Instruction Reference CVTPI2PS [AMD Confidential - Distribution with NDA]

<page_number>9</page_number>

AMDA

AMD64 Technology

26569—Rev. 3.16—November 2021

# CVTPS2PI Convert Packed Single-Precision Floating-Point to Packed Doubleword Integers

Converts two packed single-precision floating-point values in the low-order 64 bits of an XMM register or a 64-bit memory location to two packed 32-bit signed integers and writes the converted values in an MMX register.

If the result of the conversion is an inexact value, the value is rounded as specified by the rounding control bits (RC) in the MXCSR register. If the floating-point value is a NaN, infinity, or if the result of the conversion is larger than the maximum signed doubleword (–2<sup>31</sup> to +2<sup>31</sup> – 1), the instruction returns the 32-bit indefinite integer value (8000_0000h) when the invalid-operation exception (IE) is masked.

The CVTPS2PI instruction is an SSE1 instruction. Support for this instruction set is indicated by CPUID Fn0000_0001_EDX[SSE] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CVTPS2PI mmx, xmm/mem64</td>
        <td>0F 2D /r</td>
        <td>Converts packed single-precision floating-point values in an XMM register or 64-bit memory location to packed doubleword integers in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two 32-bit single-precision floating-point values from the low 64 bits of an XMM register or memory location into two 32-bit signed integers in an MMX register.

## Related Instructions

CVTDQ2PS, CVTPI2PS, CVTPS2DQ, CVTSI2SS, CVTSS2SI, CVTTPS2DQ, CVTTPS2PI, CVTTSS2SI

## rFLAGS Affected

None

<page_number>10</page_number>

CVTPS2PI
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# MXCSR Flags Affected

<table>
  <thead>
    <tr>
        <th>MM</th>
        <th>FZ</th>
        <th colspan="2">RC</th>
        <th>PM</th>
        <th>UM</th>
        <th>OM</th>
        <th>ZM</th>
        <th>DM</th>
        <th>IM</th>
        <th>DAZ</th>
        <th>PE</th>
        <th>UE</th>
        <th>OE</th>
        <th>ZE</th>
        <th>DE</th>
        <th colspan="2">IE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
    </tr>
    <tr>
        <td>17</td>
        <td>15</td>
        <td>14</td>
        <td>13</td>
        <td>12</td>
        <td>11</td>
        <td>10</td>
        <td>9</td>
        <td>8</td>
        <td>7</td>
        <td>6</td>
        <td>5</td>
        <td>4</td>
        <td>3</td>
        <td>2</td>
        <td>1</td>
        <td>0</td>
        <td></td>
    </tr>
    <tr>
        <td colspan="18"><strong>Note:</strong> A flag that can be set to one or zero is M (modified). Unaffected flags are blank.</td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th>8086Protected</th>
      <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The SSE1 instructions are not supported, as 
indicated by CPUID Fn0000_0001_EDX[SSE] = 0.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
      <td>Invalid opcode, #UD</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The operating-system FXSAVE/FXRSTOR support 
bit (OSFXSR) of CR4 was cleared to 0.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>There was an unmasked SIMD floating-point 
exception while CR4.OSXMMEXCPT was cleared to 
0.
See SIMD Floating-Point Exceptions, below, for 
details.</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment 
limit or was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, #GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>A page fault resulted from the execution of the 
instruction.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, #MF</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>An unmasked x87 floating-point exception was 
pending.</td>
    </tr>
    <tr>
      <td>Alignment check, #AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed 
while alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>SIMD Floating-Point 
Exception, #XF</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>There was an unmasked SIMD floating-point 
exception while CR4.OSXMMEXCPT was set to 1.
See SIMD Floating-Point Exceptions, below, for 
details.</td>
    </tr>
    <tr>
      <td colspan="5">SIMD Floating-Point Exceptions</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN 
value, or ±infinity.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was too large to fit in the 
destination format.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the 
destination format.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

CVTPS2PI
[AMD Confidential - Distribution with NDA]

<page_number>11</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# CVTTPD2PI Convert Packed Double-Precision Floating-Point to Packed Doubleword Integers, Truncated

Converts two packed double-precision floating-point values in an XMM register or a 128-bit memory location to two packed 32-bit signed integer values and writes the converted values in an MMX register.

If the result of the conversion is an inexact value, the value is truncated (rounded toward zero). If the floating-point value is a NaN, infinity, or if the result of the conversion is larger than the maximum signed doubleword (–2<sup>31</sup> to +2<sup>31</sup> – 1), the instruction returns the 32-bit indefinite integer value (8000_0000h) when the invalid-operation exception (IE) is masked.

The CVTTPD2PI instruction is an SSE2 instruction. Support for this instruction set is indicated by CPUID Fn0000_0001_EDX[SSE2] = 1. Support for misaligned 16-byte memory accesses is indicated by CPUID Fn8000_0001_ECX[MisAlignSse] = 1.

See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CVTTPD2PI mmx, xmm/mem128</td>
        <td>66 0F 2C /r</td>
        <td>Converts packed double-precision floating-point values in an XMM register or 128-bit memory location to packed doubleword integer values in the destination MMX register. Inexact results are truncated.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two 64-bit double-precision floating-point values from a 128-bit XMM register or memory location to two 32-bit doubleword integers in a 64-bit MMX register.

## Related Instructions

CVTDQ2PD, CVTPD2DQ, CVTPD2PI, CVTPI2PD, CVTSD2SI, CVTSI2SD, CVTTPD2DQ, CVTTSD2SI

## rFLAGS Affected

None

<page_number>

12
</page_number>

CVTTPD2PI
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# MXCSR Flags Affected

<table>
  <tbody>
    <tr>
        <td>MM</td>
        <td>FZ</td>
        <td colspan="2">RC</td>
        <td>PM</td>
        <td>UM</td>
        <td>OM</td>
        <td>ZM</td>
        <td>DM</td>
        <td>IM</td>
        <td>DAZ</td>
        <td>PE</td>
        <td>UE</td>
        <td>OE</td>
        <td>ZE</td>
        <td>DE</td>
        <td>IE</td>
    </tr>
    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
    </tr>
    <tr>
        <td>17</td>
        <td>15</td>
        <td>14</td>
        <td>13</td>
        <td>12</td>
        <td>11</td>
        <td>10</td>
        <td>9</td>
        <td>8</td>
        <td>7</td>
        <td>6</td>
        <td>5</td>
        <td>4</td>
        <td>3</td>
        <td>2</td>
        <td>1</td>
        <td>0</td>
    </tr>
  </tbody>
</table>

**Note:** A flag that can be set to one or zero is M (modified). Unaffected flags are blank.

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="4">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The operating-system FXSAVE/FXRSTOR support bit (OSFXSR) of CR4 was cleared to 0.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>There was an unmasked SIMD floating-point exception while CR4.OSXMMEXCPT was cleared to 0.<br/>See SIMD Floating-Point Exceptions, below, for details.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The memory operand was not aligned on a 16-byte boundary while MXCSR.MM = 0.</td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled with MXCSR.MM = 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An exception is pending due to an x87 floating-point instruction.</td>
    </tr>
    <tr>
        <td>SIMD Floating-Point Exception, #XF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>There was an unmasked SIMD floating-point exception while CR4.OSXMMEXCPT was set to 1.<br/>See SIMD Floating-Point Exceptions, below, for details.</td>
    </tr>
  </tbody>
</table>

64-Bit Media

CVTTPD2PI

<page_number>13</page_number>

[AMD Confidential - Distribution with NDA]

Instruction Reference

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td colspan="5">SIMD Floating-Point Exceptions</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN 
value, or ±infinity.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was too large to fit in the 
destination format.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the 
destination format.</td>
    </tr>
  </tbody>
</table>

<page_number>14</page_number> CVTTPD2PI [AMD Confidential - Distribution with NDA] 64-Bit Media Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# CVTTPS2PI Convert Packed Single-Precision Floating-Point to Packed Doubleword Integers, Truncated

Converts two packed single-precision floating-point values in the low-order 64 bits of an XMM register or a 64-bit memory location to two packed 32-bit signed integer values and writes the converted values in an MMX register.

If the result of the conversion is an inexact value, the value is truncated (rounded toward zero). If the floating-point value is a NaN, infinity, or if the result of the conversion is larger than the maximum signed doubleword (–2<sup>31</sup> to +2<sup>31</sup> – 1), the instruction returns the 32-bit indefinite integer value (8000_0000h) when the invalid-operation exception (IE) is masked.

The CVTTPS2PI instruction is an SSE1 instruction. Support for this instruction set is indicated by CPUID Fn0000_0001_EDX[SSE] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CVTTPS2PI mmx, xmm/mem64</td>
        <td>0F 2C /r</td>
        <td>Converts packed single-precision floating-point values in an XMM register or 64-bit memory location to doubleword integer values in the destination MMX register. Inexact results are truncated.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph xmm_mem64 [xmm/mem64]
        direction LR
        xmm_high[127 ... 64]
        xmm_low_high[63 ... 32]
        xmm_low_low[31 ... 0]
    end

    subgraph mmx [mmx]
        direction LR
        mmx_high[63 ... 32]
        mmx_low[31 ... 0]
    end

    xmm_low_high -- convert --> mmx_high
    xmm_low_low -- convert --> mmx_low
```

## Related Instructions

CVTDQ2PS, CVTPI2PS, CVTPS2DQ, CVTPS2PI, CVTSI2SS, CVTSS2SI, CVTTPS2DQ, CVTTSS2SI

## rFLAGS Affected

None

64-Bit Media [AMD Confidential - Distribution with NDA] CVTTPS2PI
Instruction Reference

<page_number>15</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# MXCSR Flags Affected

<table>
  <tbody>
    <tr>
        <td>MM</td>
        <td>FZ</td>
        <td colspan="2">RC</td>
        <td>PM</td>
        <td>UM</td>
        <td>OM</td>
        <td>ZM</td>
        <td>DM</td>
        <td>IM</td>
        <td>DAZ</td>
        <td>PE</td>
        <td>UE</td>
        <td>OE</td>
        <td>ZE</td>
        <td>DE</td>
        <td>IE</td>
    </tr>
    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>M</td>
    </tr>
    <tr>
        <td>17</td>
        <td>15</td>
        <td>14</td>
        <td>13</td>
        <td>12</td>
        <td>11</td>
        <td>10</td>
        <td>9</td>
        <td>8</td>
        <td>7</td>
        <td>6</td>
        <td>5</td>
        <td>4</td>
        <td>3</td>
        <td>2</td>
        <td>1</td>
        <td>0</td>
    </tr>
  </tbody>
</table>

Note: A flag that can be set to one or zero is M (modified). Unaffected flags are blank.

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The SSE1 instructions are not supported, as indicated 
by CPUID Fn0000_0001_EDX[SSE] = 0.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
      <td>Invalid opcode, #UD</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The operating-system FXSAVE/FXRSTOR support bit 
(OSFXSR) of CR4 was cleared to 0.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>There was an unmasked SIMD floating-point 
exception while CR4.OSXMMEXCPT was cleared to 
0.
See SIMD Floating-Point Exceptions, below, for 
details.</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit 
or was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, #GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>A page fault resulted from the execution of the 
instruction.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, #MF</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>An unmasked x87 floating-point exception was 
pending.</td>
    </tr>
    <tr>
      <td>Alignment check, #AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>SIMD Floating-Point 
Exception, #XF</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>There was an unmasked SIMD floating-point 
exception while CR4.OSXMMEXCPT was set to 1.
See SIMD Floating-Point Exceptions, below, for 
details.</td>
    </tr>
    <tr>
      <td colspan="5">SIMD Floating-Point Exceptions</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN 
value, or ±infinity.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was too large to fit in the 
destination format.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the 
destination format.</td>
    </tr>
  </tbody>
</table>

16 CVTTPS2PI 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# EMMS Exit Multimedia State

Clears the MMX state by setting the state of the x87 stack registers to *empty* (tag-bit encoding of all 1s for all MMX registers) indicating that the contents of the registers are available for a new procedure, such as an x87 floating-point procedure. This setting of the tag bits is referred to as “clearing the MMX state”.

Because the MMX registers and tag word are shared with the x87 floating-point instructions, software should execute an EMMS instruction to clear the MMX state before executing code that includes x87 floating-point instructions.

The functions of the EMMS and FEMMS instructions are identical.

For details about the setting of x87 tag bits, see “Media and x87 Processor State” in Volume 2.

The EMMS instruction is an MMX™ instruction. Support for the MMX instruction subset is indicated by CPUID Fn0000_0001_EDX[MMX] = 1 or CPUID Fn8000_0001_EDX[MMX] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EMMS</td>
        <td>0F 77</td>
        <td>Clears the MMX state.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FEMMS (a 3DNow! instruction)

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

64-Bit Media Instruction Reference [AMD Confidential EMMS Distribution with NDA]

<page_number>17</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FEMMS Fast Exit Multimedia State

Clears the MMX state by setting the state of the x87 stack registers to *empty* (tag-bit encoding of all 1s for all MMX registers) indicating that the contents of the registers are available for a new procedure, such as an x87 floating-point procedure. This setting of the tag bits is referred to as “clearing the MMX state”.

Because the MMX registers and tag word are shared with the x87 floating-point instructions, software should execute an EMMS or FEMMS instruction to clear the MMX state before executing code that includes x87 floating-point instructions.

The functions of the FEMMS and EMMS instructions are identical. The FEMMS instruction is supported for backward-compatibility with certain AMD processors. Software that must be both compatible with both AMD and non-AMD processors should use the EMMS instruction.

FEMMS is a 3DNow! instruction. Support for this instruction subset is indicated by CPUID Fn8000_0001_EDX[3DNow] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

For details about the setting of x87 tag bits, see “Media and x87 Processor State” in Volume 2.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

EMMS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FEMMS</td>
        <td>0F 0E</td>
        <td>Clears MMX state.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

EMMS

## rFLAGS Affected

None

<page_number>18</page_number>

[AMD Confidential — Distribution with NDA] **FEMMS** **64-Bit Media**
**Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **FEMMS**
[AMD Confidential — Distribution with NDA]
Instruction Reference
<page_number>19</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# FRSTOR Floating-Point Restore x87 and MMX™ State

Restores the complete x87 state from memory starting at the specified address, as stored by a previous call to FNSAVE. The x87 state occupies 94 or 108 bytes of memory depending on whether the processor is operating in real or protected mode and whether the operand-size attribute is 16-bit or 32-bit. Because the MMX registers are mapped onto the low 64 bits of the x87 floating-point registers, this operation also restores the MMX state.

If FRSTOR results in set exception flags in the loaded x87 status word register, and these exceptions are unmasked in the x87 control word register, a floating-point exception occurs when the next floating-point instruction is executed (except for the no-wait floating-point instructions).

To avoid generating exceptions when loading a new environment, use the FCLEX or FNCLEX instruction to clear the exception flags in the x87 status word before storing that environment.

For details about the memory image restored by FRSTOR, see “Media and x87 Processor State” in Volume 2.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FRSTOR mem94/108env</td>
        <td>DD /4</td>
        <td>Load the x87 state from mem94/108env.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSAVE, FNSAVE, FXSAVE, FXRSTOR

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C1</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C3</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
  </tbody>
</table>

Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.

<page_number>

20
</page_number>

FRSTOR 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

64-Bit Media FRSTOR 21
[AMD Confidential - Distribution with NDA]
Instruction Reference
<page_number>21</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FSAVE (FNSAVE) Floating-Point Save x87 and MMX™ State

Stores the complete x87 state to memory starting at the specified address and reinitializes the x87 state. The x87 state requires 94 or 108 bytes of memory, depending upon whether the processor is operating in real or protected mode and whether the operand-size attribute is 16-bit or 32-bit. Because the MMX registers are mapped onto the low 64 bits of the x87 floating-point registers, this operation also saves the MMX state. For details about the memory image saved by FNSAVE, see “Media and x87 Processor State” in Volume 2.

The FNSAVE instruction does not wait for pending unmasked x87 floating-point exceptions to be processed. Processor interrupts should be disabled before using this instruction.

Assemblers usually provide an FSAVE macro that expands into the instruction sequence:

```
    WAIT                 ; Opcode 9B
    FNSAVE destination   ; Opcode DD /6
```

The WAIT (9Bh) instruction checks for pending x87 exceptions and calls an exception handler, if necessary. The FNSAVE instruction then stores the x87 state to the specified destination.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FNSAVE mem94/108env</td>
        <td>DD /6</td>
        <td>Copy the x87 state to mem94/108env without checking for pending floating-point exceptions, then reinitialize the x87 state.</td>
    </tr>
    <tr>
        <td>FSAVE mem94/108env</td>
        <td>9B DD /6</td>
        <td>Copy the x87 state to mem94/108env after checking for pending floating-point exceptions, then reinitialize the x87 state.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FRSTOR, FXSAVE, FXRSTOR

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>0</td>
        <td> </td>
    </tr>
  </tbody>
</table>

<page_number>

22
</page_number>

FSAVE (FNSAVE) [AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

FSAVE (FNSAVE)
<mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>23</page_number>

AMD64 Technology

26569—Rev. 3.16—November 2021

# FXRSTOR Restore XMM, MMX™, and x87 State

Restores the XMM, MMX, and x87 state from a 16-byte aligned area in memory pointed to by the source operand. The data loaded from memory is the state information previously saved using the FXSAVE instruction. Restoring data with FXRSTOR that had been previously saved with an FSAVE (rather than FXSAVE) instruction results in an incorrect restoration. If the source pointer is not 16-byte aligned, execution may be inhibited either by an #AC exception at CPL=3 if alignment checking is enabled, otherwise by a #GP(0) exception.

If FXRSTOR results in set exception flags in the loaded x87 status word register, and these exceptions are unmasked in the x87 control word register, a floating-point exception occurs when the next floating-point instruction is executed (except for the no-wait floating-point instructions).

If the restored MXCSR register contains a set bit in an exception status flag, and the corresponding exception mask bit is cleared (indicating an unmasked exception), loading the MXCSR register does not cause a SIMD floating-point exception (#XF).

FXRSTOR does not restore the x87 error pointers (last instruction pointer, last data pointer, and last opcode), except when FXRSTOR sets FSW.ES=1 after recomputing it from the error mask bits in FCW and error status bits in FSW.

The architecture supports two 512-bit memory formats for FXRSTOR, a 64-bit format that loads XMM0-XMM15, and a 32-bit legacy format that loads only XMM0-XMM7. If FXRSTOR is executed in 64-bit mode, the 64-bit format is used, otherwise the 32-bit format is used. When the 64-bit format is used, if the operand-size is 64-bit, FXRSTOR loads the x87 pointer registers as offset64, otherwise it loads them as sel:offset32. For details about the memory format used by FXRSTOR, see "Saving Media and x87 Processor State" in Volume 2.

If the fast-FXSAVE/FXRSTOR (FFXSR) feature is enabled in EFER, FXRSTOR does not restore the XMM registers (XMM0-XMM15) when executed in 64-bit mode at CPL 0. MXCSR is restored whether fast-FXSAVE/FXRSTOR is enabled or not.

Support for the fast-FXSAVE/FXRSTOR feature is indicated by CPUID Fn8000_0001_EDX[FFXSR] = 1.

If the operating-system FXSAVE/FXRSTOR support bit (OSFXSR) of CR4 is cleared to 0, the saved image of XMM0–XMM15 and MXCSR is not loaded into the processor. A general-protection exception occurs if the FXRSTOR instruction attempts to load non-zero values into reserved MXCSR bits. Software can use MXCSR_MASK to determine which bits of MXCSR are reserved. For details on the MXCSR_MASK, see “SSE, MMX, and x87 Programming” in Volume 2.

Support for this instruction is implementation-specific. CPUID Fn8000_0001_EDX[FXSR] = 1 or CPUID Fn0000_0001_EDX[FXSR] = 1 indicates support for the FXSAVE and FXRSTOR instructions. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<page_number>24</page_number>

FXRSTOR 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FXRSTOR mem512env</td>
        <td>0F AE /1</td>
        <td>Restores XMM, MMX™, and x87 state from 512-byte memory location.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FWAIT, FXSAVE

## rFLAGS Affected

None

## MXCSR Flags Affected

<table>
  <thead>
    <tr>
        <th>MM</th>
        <th>FZ</th>
        <th colspan="2">RC</th>
        <th>PM</th>
        <th>UM</th>
        <th>OM</th>
        <th>ZM</th>
        <th>DM</th>
        <th>IM</th>
        <th>DAZ</th>
        <th>PE</th>
        <th>UE</th>
        <th>OE</th>
        <th>ZE</th>
        <th>DE</th>
        <th>IE</th>
    </tr>
    <tr>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
        <th>M</th>
    </tr>
    <tr>
        <th>17</th>
        <th>15</th>
        <th>14</th>
        <th>13</th>
        <th>12</th>
        <th>11</th>
        <th>10</th>
        <th>9</th>
        <th>8</th>
        <th>7</th>
        <th>6</th>
        <th>5</th>
        <th>4</th>
        <th>3</th>
        <th>2</th>
        <th>1</th>
        <th>0</th>
    </tr>
  </thead>
</table>

Note: A flag that can be set to one or zero is M (modified). Unaffected flags are blank. Shaded fields are reserved.

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The FXSAVE/FXRSTOR instructions are not supported, as indicated by EDX[FXSR] = 0, returned by CPUID Fn0000_0001 or CPUID Fn8000_0001.</td>
    </tr>
    <tr>
        <td rowspan="2">Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit, or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="4">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The memory operand was not aligned on a 16-byte boundary. At CPL=3 (including virtual 8086 mode), this will be overridden by a #AC exception if alignment checking is enabled.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>Ones were written to the reserved bits in MXCSR.</td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment Check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media

FXRSTOR
[AMD Confidential - Distribution with NDA]

Instruction Reference

<page_number>25</page_number>

AMD64 Technology 26569—Rev. 3.16—November 2021

AMD logo



# FXSAVE Save XMM, MMX, and x87 State

Saves the XMM, MMX, and x87 state to a 16-byte aligned area in memory pointed to by the source operand. If the destination pointer is not 16-byte aligned, execution may be inhibited by an #AC exception at CPL=3 if alignment checking is enabled, otherwise by a #GP(0) exception.

Unlike FSAVE and FNSAVE, FXSAVE does not alter the x87 tag bits. The contents of the saved MMX/x87 data registers are retained, thus indicating that the registers may be valid (or whatever other value the x87 tag bits indicated prior to the save). To invalidate the contents of the MMX/x87 data registers after FXSAVE, software must execute an FINIT instruction. Also, FXSAVE (like FNSAVE) does not check for pending unmasked x87 floating-point exceptions. An FWAIT instruction can be used for this purpose.

FXSAVE does not save the x87 pointer registers (last instruction pointer, last data pointer, and last opcode), except in the relatively rare cases in which the exception-summary (ES) bit in the x87 status word is set to 1, indicating that an unmasked x87 exception has occurred.

The architecture supports two 512-bit memory formats for FXSAVE, a 64-bit format that saves XMM0-XMM15, and a 32-bit legacy format that saves only XMM0-XMM7. If FXSAVE is executed in 64-bit mode, the 64-bit format is used, otherwise the 32-bit format is used. When the 64-bit format is used, if the operand-size is 64-bit, FXSAVE saves the x87 pointer registers as *offset64*, otherwise it saves them as *sel:offset32*. For more details about the memory format used by FXSAVE, see “Saving Media and x87 Execution Unit State” in Volume 2.

If the fast-FXSAVE/FXRSTOR (FFXSR) feature is enabled in EFER, FXSAVE does not save the XMM registers (XMM0-XMM15) when executed in 64-bit mode at CPL 0. MXCSR is saved whether fast-FXSAVE/FXRSTOR is enabled or not.

Support for the fast-FXSAVE/FXRSTOR feature is indicated by CPUID Fn8000_0001_EDX[FFXSR] = 1.

If the operating-system FXSAVE/FXRSTOR support bit (OSFXSR) of CR4 is cleared to 0, FXSAVE does not save the image of XMM0–XMM15 or MXCSR. For details about the CR4.OSFXSR bit, see “FXSAVE/FXRSTOR Support (OSFXSR) Bit” in Volume 2.

Support for this instruction is implementation-specific. CPUID Fn8000_0001_EDX[FXSR] = 1 or CPUID Fn0000_0001_EDX[FXSR] = 1 indicates support for the FXSAVE and FXRSTOR instructions. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FXSAVE mem512env</td>
        <td>0F AE /0</td>
        <td>Saves XMM, MMX, and x87 state to 512-byte memory location.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FINIT, FNSAVE, FRSTOR, FSAVE, FXRSTOR, LDMXCSR, STMXCSR

<page_number>26</page_number> FXSAVE 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# rFLAGS Affected

None

# MXCSR Flags Affected

None

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The FXSAVE/FXRSTOR instructions are not supported, as indicated by EDX[FXSR] = 0, returned by CPUID Fn0000_0001 or CPUID Fn8000_0001.</td>
    </tr>
    <tr>
        <td rowspan="2">Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit, or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="4">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The memory operand was not aligned on a 16-byte boundary. At CPL=3 (including virtual 8086 mode), this will be overridden by an #AC exception if alignment checking is enabled.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>The destination operand was in a non-writable segment.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment Check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media**
**FXSAVE**
**Instruction Reference**
[AMD Confidential - Distribution with NDA]

<page_number>27</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# MASKMOVQ Masked Move Quadword

Stores bytes from the first source operand, as selected by the second source operand, to a memory location specified in the DS:rDI registers (except that DS is ignored in 64-bit mode). The first source operand is an MMX register, and the second source operand is another MMX register. The most-significant bit (msb) of each byte in the second source operand specifies the store (1 = store, 0 = no store) of the corresponding byte of the first source operand.

Exception and trap behavior for the elements not selected for storage to memory are implementation dependent. For instance, a given implementation may signal a data breakpoint or a page fault for bytes that are zero-masked and not actually written.

MASKMOVQ implicitly uses weakly-ordered, write-combining buffering for the data, as described in “Buffering and Combining Memory Writes” in Volume 2. If the stored data is shared by multiple processors, this instruction should be used together with a fence instruction in order to ensure data coherency (refer to “Cache and TLB Management” in Volume 2).

The MASKMOVQ instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. Support for AMD extensions to the MMX instruction subset is indicated by CPUID Fn8000_0001_EDX[MmxExt] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MASKMOVQ mmx1, mmx2</td>
        <td>0F F7 /r</td>
        <td>Store bytes from an MMX register, selected by the most-significant bit of the corresponding byte in another MMX register, to DS:rDI.</td>
    </tr>
  </tbody>
</table>

<page_number>28</page_number>

[AMD Confidential - Distribution with NDA] **MASKMOVQ** **64-Bit Media Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

Diagram showing MASKMOVQ operation between mmx1 and mmx2 registers and memory

# Related Instructions

MASKMOVDQU

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The operating-system FXSAVE/FXRSTOR support bit (OSFXSR) of CR4 was cleared to 0.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media** **MASKMOVQ** <page_number>29</page_number>
[AMD Confidential - Distribution with NDA]
**Instruction Reference**

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>30</page_number>

[AMD Confidential - Distribution with NDA] **MASKMOVQ** **64-Bit Media Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# MOVD Move Doubleword or Quadword

Moves a 32-bit or 64-bit value in one of the following ways:

* from a 32-bit or 64-bit general-purpose register or memory location to the low-order 32 or 64 bits of an XMM register, with zero-extension to 128 bits

* from the low-order 32 or 64 bits of an XMM to a 32-bit or 64-bit general-purpose register or memory location

* from a 32-bit or 64-bit general-purpose register or memory location to the low-order 32 bits (with zero-extension to 64 bits) or the full 64 bits of an MMX register

* from the low-order 32 or the full 64 bits of an MMX register to a 32-bit or 64-bit general-purpose register or memory location.

The MOVD instruction is a member of both the MMX and the SSE2 instruction sets. The presence of this instruction set is indicated by EDX[MMX] = 1 returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See "CPUID" in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MOVD mmx, reg/mem32</td>
        <td>0F 6E /r</td>
        <td>Move 32-bit value from a general-purpose register or 32-bit memory location to an MMX register.</td>
    </tr>
    <tr>
        <td>MOVD mmx, reg/mem64</td>
        <td>0F 6E /r</td>
        <td>Move 64-bit value from a general-purpose register or 64-bit memory location to an MMX register.</td>
    </tr>
    <tr>
        <td>MOVD reg/mem32, mmx</td>
        <td>0F 7E /r</td>
        <td>Move 32-bit value from an MMX register to a 32-bit general-purpose register or memory location.</td>
    </tr>
    <tr>
        <td>MOVD reg/mem64, mmx</td>
        <td>0F 7E /r</td>
        <td>Move 64-bit value from an MMX register to a 64-bit general-purpose register or memory location.</td>
    </tr>
  </tbody>
</table>

The following diagrams illustrate the operation of the MOVD instruction.

64-Bit Media
Instruction Reference

[AMD Confidential MOVD Distribution with NDA]

<page_number>31</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

All operations are "copy"

```mermaid
graph TD
    subgraph "xmm to reg/mem32"
        xmm1["xmm127 [ 0 ] 32 31 [ ] 0"]
        rm32_1["reg/mem3231 [ ] 0"]
        xmm1 -- "bits 31:0" --> rm32_1
    end

    subgraph "xmm to reg/mem64 (with REX prefix)"
        xmm2["xmm127 [ 0 ] 64 63 [ ] 0"]
        rm64_1["reg/mem6463 [ ] 0"]
        xmm2 -- "bits 63:0" --> rm64_1
    end

    subgraph "reg/mem32 to xmm"
        rm32_2["reg/mem3231 [ ] 0"]
        xmm3["xmm127 [ (zeroed) ] 32 31 [ ] 0"]
        rm32_2 -- "bits 31:0" --> xmm3
    end

    subgraph "reg/mem64 to xmm (with REX prefix)"
        rm64_2["reg/mem6463 [ ] 0"]
        xmm4["xmm127 [ (zeroed) ] 64 63 [ ] 0"]
        rm64_2 -- "bits 63:0" --> xmm4
    end

    subgraph "mmx to reg/mem32"
        mmx1["mmx63 [ 0 ] 32 31 [ ] 0"]
        rm32_3["reg/mem3231 [ ] 0"]
        mmx1 -- "bits 31:0" --> rm32_3
    end

    subgraph "mmx to reg/mem64 (with REX prefix)"
        mmx2["mmx63 [ ] 0"]
        rm64_3["reg/mem6463 [ ] 0"]
        mmx2 -- "bits 63:0" --> rm64_3
    end

    subgraph "reg/mem32 to mmx"
        rm32_4["reg/mem3231 [ ] 0"]
        mmx3["mmx63 [ (zeroed) ] 32 31 [ ] 0"]
        rm32_4 -- "bits 31:0" --> mmx3
    end

    subgraph "reg/mem64 to mmx (with REX prefix)"
        rm64_4["reg/mem6463 [ ] 0"]
        mmx4["mmx63 [ ] 0"]
        rm64_4 -- "bits 63:0" --> mmx4
    end
```

<page_number>32</page_number>

[AMD Confidential MOVD Distribution with NDA]

**64-Bit Media Instruction Reference**
movd.eps

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## Related Instructions

MOVDQA, MOVDQU, MOVDQ2Q, MOVQ, MOVQ2DQ

## rFLAGS Affected

None

## MXCSR Flags Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="4">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0 returned by CPUID function 0000_0001h or 8000_0001h.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The instruction used XMM registers while CR4.OSFXSR=0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>The destination operand was in a non-writable segment.</td>
        <td></td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

[AMD Confidential MOVD Distribution with NDA]

<page_number>33</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# MOVDQ2Q Move Quadword to Quadword

Moves the low-order 64-bit value in an XMM register to a 64-bit MMX register.

The MOVDQ2Q instruction is an SSE2 instruction. Support for this instruction subset is indicated by CPUID Fn0000_0001_EDX[SSE2] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MOVDQ2Q mmx, xmm</td>
        <td>F2 0F D6 /r</td>
        <td>Moves low-order 64-bit value from an XMM register to the destination MMX register.</td>
    </tr>
  </tbody>
</table>
<table>
  <thead>
    <tr>
        <th>Register</th>
        <th>Bits</th>
        <th>Operation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>xmm</td>
        <td>127-64</td>
        <td>(Not used)</td>
    </tr>
    <tr>
        <td>xmm</td>
        <td>63-0</td>
        <td>copy to mmx</td>
    </tr>
    <tr>
        <td>mmx</td>
        <td>63-0</td>
        <td>destination</td>
    </tr>
  </tbody>
</table>

movdq2q.eps

## Related Instructions

MOVD, MOVDQA, MOVDQU, MOVQ, MOVQ2DQ

## rFLAGS Affected

None

## MXCSR Flags Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
  </tbody>
</table>

<page_number>

34
</page_number>

**MOVDQ2Q**
[AMD Confidential - Distribution with NDA]
**64-Bit Media Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The destination operand was in non-writable segment.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media Instruction Reference** **MOVDQ2Q** [AMD Confidential - Distribution with NDA] <page_number>35</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# MOVNTQ Move Non-Temporal Quadword

Stores a 64-bit MMX register value into a 64-bit memory location. This instruction indicates to the processor that the data is non-temporal, and is unlikely to be used again soon. The processor treats the store as a write-combining (WC) memory write, which minimizes cache pollution. The exact method by which cache pollution is minimized depends on the hardware implementation of the instruction. For further information, see “Memory Optimization” in Volume 1.

MOVNTQ is weakly-ordered with respect to other instructions that operate on memory. Software should use an SFENCE instruction to force strong memory ordering of MOVNTQ with respect to other stores.

MOVNTQ implicitly uses weakly-ordered, write-combining buffering for the data, as described in “Buffering and Combining Memory Writes” in Volume 2. For data that is shared by multiple processors, this instruction should be used together with a fence instruction in order to ensure data coherency (refer to “Cache and TLB Management” in Volume 2).

The MOVNTQ instruction is a member of both the AMD MMX extensions and the SSE1 instruction sets. Support for the SSE1 instruction subset is indicated by CPUID Fn0000_0001_EDX[SSE] = 1. Support for AMD’s extensions to the MMX instruction subset is indicated by CPUID Fn8000_0001_EDX[MmxExt] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MOVNTQ mem64, mmx</td>
        <td>0F E7 /r</td>
        <td>Stores a 64-bit MMX register value into a 64-bit memory location, minimizing cache pollution.</td>
    </tr>
  </tbody>
</table>

Diagram showing the copy operation from a 64-bit MMX register to a 64-bit memory location (mem64). Both are labeled with bits 63 to 0.

## Related Instructions

MOVNTDQ, MOVNTI, MOVNTPD, MOVNTPS

<page_number>

36
</page_number>

MOVNTQ 64-Bit Media [AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>The destination operand was in a non-writable segment.</td>
        <td></td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **MOVNTQ** <page_number>37</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# MOVQ Move Quadword

Moves a 64-bit value:

* from an MMX register or 64-bit memory location to another MMX register, or

* from an MMX register to another MMX register or 64-bit memory location.

The MOVQ instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MOVQ mmx1, mmx2/mem64</td>
        <td>0F 6F /r</td>
        <td>Moves 64-bit value from an MMX register or memory location to an MMX register.</td>
    </tr>
    <tr>
        <td>MOVQ mmx1/mem64, mmx2</td>
        <td>0F 7F /r</td>
        <td>Moves 64-bit value from an MMX register to an MMX register or memory location.</td>
    </tr>
  </tbody>
</table>

Diagram showing MOVQ operation: copying 64-bit value from mmx2/mem64 to mmx1

Diagram showing MOVQ operation: copying 64-bit value from mmx2 to mmx1/mem64

## Related Instructions

MOVD, MOVDQA, MOVDQU, MOVDQ2Q, MOVQ2DQ

## rFLAGS Affected

None

<page_number>38</page_number>

MOVQ 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeds the stack segment limit or is non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>The destination operand was in a non-writable segment.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential MOVQ Distribution with NDA] 39
Instruction Reference
<page_number>39</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# MOVQ2DQ Move Quadword to Quadword

Moves a 64-bit value from an MMX register to the low-order 64 bits of an XMM register, with zero-extension to 128 bits.

The MOVQ2DQ instruction is an SSE2 instruction. Support for this instruction subset is indicated by CPUID Fn0000_0001_EDX[SSE2] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MOVQ2DQ xmm, mmx</td>
        <td>F3 0F D6 /r</td>
        <td>Moves 64-bit value from an MMX register to an XMM register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the movement of 64 bits from an MMX register to the low-order 64 bits of an XMM register, with the high-order 64 bits of the XMM register being zeroed.

## Related Instructions

MOVD, MOVDQA, MOVDQU, MOVDQ2Q, MOVQ

## rFLAGS Affected

None

## MXCSR Flags Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The operating-system FXSAVE/FXRSTOR support bit (OSFXSR) of CR4 was cleared to 0.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
  </tbody>
</table>

<page_number>

40
</page_number>

MOVQ2DQ

64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

64-Bit Media MOVQ2DQ 41
Instruction Reference
[AMD Confidential - Distribution with NDA]
<page_number>41</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# PACKSSDW Pack with Saturation Signed Doubleword to Word

Converts each 32-bit signed integer in the first and second source operands to a 16-bit signed integer and packs the converted values into words in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

Converted values from the first source operand are packed into the low-order words of the destination, and the converted values from the second source operand are packed into the high-order words of the destination.

For each packed value in the destination, if the value is larger than the largest signed 16-bit integer, it is saturated to 7FFFh, and if the value is smaller than the smallest signed 16-bit integer, it is saturated to 8000h.

The PACKSSDW instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PACKSSDW mmx1, mmx2/mem64</td>
        <td>0F 6B /r</td>
        <td>Packs 32-bit signed integers in an MMX register and another MMX register or 64-bit memory location into 16-bit signed integers in an MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the packing of two 64-bit operands (mmx1 and mmx2/mem64) containing 32-bit signed integers into a single 64-bit destination register containing four 16-bit signed integers.

## Related Instructions

PACKSSWB, PACKUSWB

<page_number>42</page_number>

PACKSSDW 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# rFLAGS Affected

None

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PACKSSDW**
Instruction Reference <mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>43</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PACKSSWB Pack with Saturation Signed Word to Byte

Converts each 16-bit signed integer in the first and second source operands to an 8-bit signed integer and packs the converted values into bytes in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

Converted values from the first source operand are packed into the low-order bytes of the destination, and the converted values from the second source operand are packed into the high-order bytes of the destination.

For each packed value in the destination, if the value is larger than the largest signed 8-bit integer, it is saturated to 7Fh, and if the value is smaller than the smallest signed 8-bit integer, it is saturated to 80h.

The PACKSSWB instruction is an MMX instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PACKSSWB mmx1, mmx2/mem64</td>
        <td>0F 63 /r</td>
        <td>Packs 16-bit signed integers in an MMX register and another MMX register or 64-bit memory location into 8-bit signed integers in an MMX register.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph mmx1
        m1_1[63:48]
        m1_2[47:32]
        m1_3[31:16]
        m1_4[15:0]
    end
    subgraph mmx2_mem64["mmx2/mem64"]
        m2_1[63:48]
        m2_2[47:32]
        m2_3[31:16]
        m2_4[15:0]
    end
    subgraph destination["mmx1 (destination)"]
        d1[63:56]
        d2[55:48]
        d3[47:40]
        d4[39:32]
        d5[31:24]
        d6[23:16]
        d7[15:8]
        d8[7:0]
    end

    m1_1 -- convert --> d4
    m1_2 -- convert --> d3
    m1_3 -- convert --> d2
    m1_4 -- convert --> d1
    
    m2_1 -- convert --> d8
    m2_2 -- convert --> d7
    m2_3 -- convert --> d6
    m2_4 -- convert --> d5
```

## Related Instructions

PACKSSDW, PACKUSWB

## rFLAGS Affected

None

<page_number>

44
</page_number>

PACKSSWB
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual 8086</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PACKSSWB**
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>45</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PACKUSWB Pack with Saturation Signed Word to Unsigned Byte

Converts each 16-bit signed integer in the first and second source operands to an 8-bit unsigned integer and packs the converted values into bytes in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

Converted values from the first source operand are packed into the low-order bytes of the destination, and the converted values from the second source operand are packed into the high-order bytes of the destination.

For each packed value in the destination, if the value is larger than the largest unsigned 8-bit integer, it is saturated to FFh, and if the value is smaller than the smallest unsigned 8-bit integer, it is saturated to 00h.

The PACKUSWB instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PACKUSWB mmx1, mmx2/mem64</td>
        <td>0F 67 /r</td>
        <td>Packs 16-bit signed integers in an MMX register and another MMX register or 64-bit memory location into 8-bit unsigned integers in an MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PACKUSWB operation: two 64-bit source operands (mmx1 and mmx2/mem64) each containing four 16-bit signed words are converted and packed into one 64-bit destination register (mmx1) as eight 8-bit unsigned bytes.

## Related Instructions

PACKSSDW, PACKSSWB

<page_number>

46
</page_number>

PACKUSWB 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# rFLAGS Affected

None

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th> </th>
        <th>Virtual</th>
        <th> </th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>Real</th>
        <th>8086</th>
        <th>Protected</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
**PACKUSWB**
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>47</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PADDB Packed Add Bytes

Adds each packed 8-bit integer value in the first source operand to the corresponding packed 8-bit integer in the second source operand and writes the integer result of each addition in the corresponding byte of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PADDB instruction operates on both signed and unsigned integers. If the result overflows, the carry is ignored (neither the overflow nor carry bit in rFLAGS is set), and only the low-order 8 bits of each result are written in the destination.

The PADDB instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PADDB mmx1, mmx2/mem64</td>
        <td>0F FC /r</td>
        <td>Adds packed byte integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PADDB operation adding 8-bit packed integers from two 64-bit operands into a destination MMX register.

## Related Instructions

PADDD, PADDQ, PADDSB, PADDSW, PADDUSB, PADDUSW, PADDW

## rFLAGS Affected

None

<page_number>

48
</page_number>

[AMD Confidential - Distribution with NDA] **PADDB** **64-Bit Media Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential PADDB Instruction Reference - Distribution with NDA]

<page_number>49</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PADDD

# Packed Add Doublewords

Adds each packed 32-bit integer value in the first source operand to the corresponding packed 32-bit integer in the second source operand and writes the integer result of each addition in the corresponding doubleword of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PADDD instruction operates on both signed and unsigned integers. If the result overflows, the carry is ignored (neither the overflow nor carry bit in rFLAGS is set), and only the low-order 32 bits of each result are written in the destination.

The PADDD instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PADDD mmx1, mmx2/mem64</td>
        <td>0F FE /r</td>
        <td>Adds packed 32-bit integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PADDD operation adding two 32-bit integers from two 64-bit operands (mmx1 and mmx2/mem64) and storing the results back into mmx1.

## Related Instructions

PADDB, PADDQ, PADDSB, PADDSW, PADDUSB, PADDUSW, PADDW

## rFLAGS Affected

None

<page_number>

50
</page_number>

PADDD [AMD Confidential - Distribution with NDA] Instruction Reference

64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential <mark>PADDD</mark> Distribution with NDA]
Instruction Reference

<page_number>51</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PADDQ

# Packed Add Quadwords

Adds each packed 64-bit integer value in the first source operand to the corresponding packed 64-bit integer in the second source operand and writes the integer result of each addition in the corresponding quadword of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PADDQ instruction operates on both signed and unsigned integers. If the result overflows, the carry is ignored (neither the overflow nor carry bit in rFLAGS is set), and only the low-order 64 bits of each result are written in the destination.

The PADDQ instruction is an SSE2 instruction. The presence of this instruction set is indicated by a CPUID Fn0000_0001_EDX[SSE2] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PADDQ mmx1, mmx2/mem64</td>
        <td>0F D4 /r</td>
        <td>Adds 64-bit integer value in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the addition of two 64-bit quadwords from mmx1 and mmx2/mem64, with the result stored back in mmx1.

## Related Instructions

PADDB, PADDD, PADDSB, PADDSW, PADDUSB, PADDUSW, PADDW

## rFLAGS Affected

None

<page_number>

52
</page_number>

PADDQ 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

[AMD Confidential PADDQ - Distribution with NDA]

<page_number>53</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PADDSB Packed Add Signed with Saturation Bytes

Adds each packed 8-bit signed integer value in the first source operand to the corresponding packed 8-bit signed integer in the second source operand and writes the signed integer result of each addition in the corresponding byte of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

For each packed value in the destination, if the value is larger than the largest representable signed 8-bit integer, it is saturated to 7Fh, and if the value is smaller than the smallest signed 8-bit integer, it is saturated to 80h.

The PADDSB instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PADDSB mmx1, mmx2/mem64</td>
        <td>0F EC /r</td>
        <td>Adds packed byte signed integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the packed addition of signed bytes with saturation for the PADDSB instruction.

## Related Instructions

PADDB, PADDD, PADDQ, PADDSW, PADDUSB, PADDUSW, PADDW

## rFLAGS Affected

None

<page_number>54</page_number>

PADDSB 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
<th>Exception</th>
<th>Real</th>
<th>Virtual<br/>8086</th>
<th>Protected</th>
<th>Cause of Exception</th>
    </tr>
    <tr>
<th rowspan="2">Invalid opcode, #UD</th>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The emulate bit (EM) of CR0 was set to 1.</th>
    </tr>
    <tr>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<td>Device not available, #NM</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
<td>Stack, #SS</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
<td rowspan="2">General protection, #GP</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
<td> </td>
<td>X</td>
<td>A null data segment was used to reference memory.</td>
<td></td>
    </tr>
    <tr>
<td>Page fault, #PF</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
<td>x87 floating-point exception pending, #MF</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
<td>Alignment check, #AC</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media**
**Instruction Reference**

**PADDSB**
[AMD Confidential - Distribution with NDA]

<page_number>55</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PADDSW Packed Add Signed with Saturation Words

Adds each packed 16-bit signed integer value in the first source operand to the corresponding packed 16-bit signed integer in the second source operand and writes the signed integer result of each addition in the corresponding word of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

For each packed value in the destination, if the value is larger than the largest representable signed 16-bit integer, it is saturated to 7FFFh, and if the value is smaller than the smallest signed 16-bit integer, it is saturated to 8000h.

The PADDSW instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PADDSW mmx1, mmx2/mem64</td>
        <td>0F ED /r</td>
        <td>Adds packed 16-bit signed integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PADDSW operation on 64-bit MMX registers, illustrating the addition and saturation of four packed 16-bit signed words.

## Related Instructions

PADDB, PADDD, PADDQ, PADDSB, PADDUSB, PADDUSW, PADDW

## rFLAGS Affected

None

<page_number>

56
</page_number>

PADDSW
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PADDSW <page_number>57</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PADDUSB Packed Add Unsigned with Saturation Bytes

Adds each packed 8-bit unsigned integer value in the first source operand to the corresponding packed 8-bit unsigned integer in the second source operand and writes the unsigned integer result of each addition in the corresponding byte of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

For each packed value in the destination, if the value is larger than the largest unsigned 8-bit integer, it is saturated to FFh.

The PADDUSB instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PADDUSB mmx1, mmx2/mem64</td>
        <td>0F DC /r</td>
        <td>Adds packed byte unsigned integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PADDUSB operation on 64-bit registers mmx1 and mmx2/mem64, illustrating the addition and saturation of packed bytes.

## Related Instructions

PADDB, PADDD, PADDQ, PADDSB, PADDSW, PADDUSW, PADDW

## rFLAGS Affected

None

<page_number>

58
</page_number>

PADDUSB 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as<br/>indicated by EDX[MMX] = 0, returned by CPUID<br/>Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit<br/>or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or<br/>was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the<br/>instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was<br/>pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while<br/>alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PADDUSB**
Instruction Reference
<mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>59</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PADDUSW Packed Add Unsigned with Saturation Words

Adds each packed 16-bit unsigned integer value in the first source operand to the corresponding packed 16-bit unsigned integer in the second source operand and writes the unsigned integer result of each addition in the corresponding word of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

For each packed value in the destination, if the value is larger than the largest unsigned 16-bit integer, it is saturated to FFFFh.

The PADDUSW instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PADDUSW mmx1, mmx2/mem64</td>
        <td>0F DD /r</td>
        <td>Adds packed 16-bit unsigned integer values in an MMX register and another MMX register or 64-bit memory location and writes result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PADDUSW operation on 64-bit media registers, where packed 16-bit words from mmx2/mem64 are added to corresponding words in mmx1 with saturation.

## Related Instructions

PADDB, PADDD, PADDQ, PADDSB, PADDSW, PADDUSB, PADDW

## rFLAGS Affected

None

<page_number>

60
</page_number>

PADDUSW 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

PADDUSW
[AMD Confidential - Distribution with NDA]

<page_number>61</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PADDW Packed Add Words

Adds each packed 16-bit integer value in the first source operand to the corresponding packed 16-bit integer in the second source operand and writes the integer result of each addition in the corresponding word of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

This instruction operates on both signed and unsigned integers. If the result overflows, the carry is ignored (neither the overflow nor carry bit in rFLAGS is set), and only the low-order 16 bits of the result are written in the destination.

The PADDW instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PADDW mmx1, mmx2/mem64</td>
        <td>0F FD /r</td>
        <td>Adds packed 16-bit integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PADDW operation adding four 16-bit words from two 64-bit operands.

## Related Instructions

PADDB, PADDD, PADDQ, PADDSB, PADDSW, PADDUSB, PADDUSW

## rFLAGS Affected

None

<page_number>

62
</page_number>

PADDW 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PADDW
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>63</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PAND

# Packed Logical Bitwise AND

Performs a bitwise logical AND of the values in the first and second source operands and writes the result in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PAND instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PAND mmx1, mmx2/mem64</td>
        <td>0F DB /r</td>
        <td>Performs bitwise logical AND of values in an MMX register and in another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing bitwise AND operation between mmx1 and mmx2/mem64 registers, both 64 bits wide (63 to 0). The result is written back to mmx1.

## Related Instructions

PANDN, POR, PXOR

## rFLAGS Affected

None

<page_number>

64
</page_number>

[AMD Confidential - Distribution with NDA]

PAND

64-Bit Media

Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>65</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PANDN Packed Logical Bitwise AND NOT

Performs a bitwise logical AND of the value in the second source operand and the one’s complement of the value in the first source operand and writes the result in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PANDN instruction is an MMX™ instruction. Support for this instruction subset is indicated by EDX[MMX] = 1, as returned by CPUID Fn0000_0001 or CPUID Fn8000_0001. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PANDN mmx1, mmx2/mem64</td>
        <td>0F DF /r</td>
        <td>Performs bitwise logical AND NOT of values in an MMX register and in another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PANDN operation: mmx1 is inverted and then ANDed with mmx2/mem64, with the result stored back in mmx1.

## Related Instructions

PAND, POR, PXOR

## rFLAGS Affected

None

<page_number>66</page_number>

PANDN 64-Bit Media [AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media Instruction Reference [AMD Confidential PANDN - Distribution with NDA] <page_number>67</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PAVGB

# Packed Average Unsigned Bytes

Computes the rounded average of each packed unsigned 8-bit integer value in the first source operand and the corresponding packed 8-bit unsigned integer in the second source operand and writes each average in the corresponding byte of the destination (first source). The average is computed by adding each pair of operands, adding 1 to the 9-bit temporary sum, and then right-shifting the temporary sum by one bit position. The destination and source operands are an MMX register and another MMX register or 64-bit memory location.

The PAVGB instruction is a member of both the AMD MMX™ extensions and the SSE1 instruction sets. Support for the SSE1 instruction subset is indicated by CPUID Fn0000_0001_EDX[SSE] = 1. Support for AMD’s extensions to the MMX instruction subset is indicated by CPUID Fn8000_0001_EDX[MmxExt] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PAVGB mmx1, mmx2/mem64</td>
        <td>0F E0 /r</td>
        <td>Averages packed 8-bit unsigned integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PAVGB operation on 64-bit MMX registers, averaging packed 8-bit unsigned integers from mmx1 and mmx2/mem64 and storing the result in mmx1.

## Related Instructions

PAVGW

## rFLAGS Affected

None

<page_number>

68
</page_number>

PAVGB 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th> </th>
        <th>Virtual</th>
        <th> </th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>Real</th>
        <th>8086</th>
        <th>Protected</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as<br/>indicated by CPUID Fn0000_0001_EDX[SSE] = 0;<br/>and the AMD extensions to the MMX™ instruction set<br/>are not supported, as indicated by<br/>CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit<br/>or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or<br/>was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the<br/>instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was<br/>pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while<br/>alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential PAVGB Distribution with NDA] 69
Instruction Reference

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PAVGUSB

# Packed Average Unsigned Bytes

Computes the rounded-up average of each packed unsigned 8-bit integer value in the first source operand and the corresponding packed 8-bit unsigned integer in the second source operand and writes each average in the corresponding byte of the destination (first source). The average is computed by adding each pair of operands, adding 1 to the 9-bit temporary sum, and then right-shifting the temporary sum by one bit position. The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location.

The PAVGUSB instruction performs a function identical to the 64-bit version of the PAVGB instruction, although the two instructions have different opcodes. PAVGUSB is a 3DNow! instruction. It is useful for pixel averaging in MPEG-2 motion compensation and video scaling operations.

The PAVGUSB instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by a CPUID feature bit. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

PAVGB

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td colspan="3">

</td>
    </tr>
    <tr>
        <td>PAVGUSB mmx1, mmx2/mem64</td>
        <td>0F 0F /r BF</td>
        <td>Averages packed 8-bit unsigned integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

<page_number>70</page_number>

[AMD Confidential - Distribution with NDA] PAVGUSB 64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

Engineering drawing showing PAVGUSB operation between mmx1 and mmx2/mem64 registers

## Related Instructions

None

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
<th rowspan="2">Exception</th>
<th>Real</th>
<th>Virtual<br/>8086</th>
<th>Protected</th>
<th colspan="5">Cause of Exception</th>
    </tr>
    <tr>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The emulate bit (EM) of CR0 was set to 1.</th>
    </tr>
    <tr>
<th>Invalid opcode, #UD</th>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</th>
<th colspan="3"></th>
    </tr>
  </thead>
  <tbody>
    <tr>
<td>Device not available, #NM</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>The task-switch bit (TS) of CR0 was set to 1.</td>
<td colspan="4"></td>
    </tr>
    <tr>
<td>Stack, #SS</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded the stack segment limit or was non-canonical.</td>
<td colspan="4"></td>
    </tr>
    <tr>
<td rowspan="2">General protection, #GP</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded a data segment limit or was was non-canonical.</td>
<td colspan="4"></td>
    </tr>
    <tr>
<td> </td>
<td>X</td>
<td>A null data segment was used to reference memory.</td>
<td colspan="5"></td>
    </tr>
    <tr>
<td>Page fault, #PF</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>A page fault resulted from the execution of the instruction.</td>
<td colspan="4"></td>
    </tr>
    <tr>
<td>x87 floating-point exception pending, #MF</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>An unmasked x87 floating-point exception was pending.</td>
<td colspan="4"></td>
    </tr>
    <tr>
<td>Alignment check, #AC</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>An unaligned memory reference was performed while alignment checking was enabled.</td>
<td colspan="4"></td>
    </tr>
  </tbody>
</table>

64-Bit Media

PAVGUSB

<page_number>71</page_number>

[AMD Confidential - Distribution with NDA]

Instruction Reference

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PAVGW Packed Average Unsigned Words

Computes the rounded average of each packed unsigned 16-bit integer value in the first source operand and the corresponding packed 16-bit unsigned integer in the second source operand and writes each average in the corresponding word of the destination (first source). The average is computed by adding each pair of operands, adding 1 to the 17-bit temporary sum, and then right-shifting the temporary sum by one bit position. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PAVGW instruction is a member of both the AMD MMX™ extensions and the SSE1 instruction sets. Support for the SSE1 instruction subset is indicated by CPUID Fn0000_0001_EDX[SSE] = 1. Support for AMD’s extensions to the MMX instruction subset is indicated by CPUID Fn8000_0001_EDX[MmxExt] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PAVGW mmx1, mmx2/mem64</td>
        <td>0F E3 /r</td>
        <td>Averages packed 16-bit unsigned integer values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PAVGW operation on 64-bit media registers mmx1 and mmx2/mem64, illustrating the averaging of packed 16-bit unsigned integer values.

## Related Instructions

PAVGB

## rFLAGS Affected

None

<page_number>

72
</page_number>

PAVGW 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

# Exceptions

<table>
  <thead>
    <tr>
<th>Exception</th>
<th>Real</th>
<th>Virtual<br/>8086</th>
<th>Protected</th>
<th>Cause of Exception</th>
    </tr>
    <tr>
<th rowspan="2">Invalid opcode, #UD</th>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The emulate bit (EM) of CR0 was set to 1.</th>
    </tr>
    <tr>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0; and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<td>Device not available, #NM</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
<td>Stack, #SS</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
<td rowspan="2">General protection, #GP</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
<td> </td>
<td>X</td>
<td>A null data segment was used to reference memory.</td>
<td></td>
    </tr>
    <tr>
<td>Page fault, #PF</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
<td>x87 floating-point exception pending, #MF</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
<td>Alignment check, #AC</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media** **PAVGW** <page_number>73</page_number>
**Instruction Reference** <mark>[AMD Confidential - Distribution with NDA]</mark>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PCMPEQB

# Packed Compare Equal Bytes

Compares corresponding packed bytes in the first and second source operands and writes the result of each compare in the corresponding byte of the destination (first source). For each pair of bytes, if the values are equal, the result is all 1s. If the values are not equal, the result is all 0s. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PCMPEQB instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PCMPEQB mmx1, mmx2/mem64</td>
        <td>0F 74 /r</td>
        <td>Compares packed bytes in an MMX register and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PCMPEQB operation: comparing bytes between mmx1 and mmx2/mem64 registers, resulting in all 1s or 0s in the destination register.

## Related Instructions

PCMPEQD, PCMPEQW, PCMPGTB, PCMPGTD, PCMPGTW

## rFLAGS Affected

None

<page_number>

74
</page_number>

[AMD Confidential - Distribution with NDA]

PCMPEQB

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PCMPEQB 75
[AMD Confidential - Distribution with NDA]
Instruction Reference
<page_number>75</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PCMPEQD Packed Compare Equal Doublewords

Compares corresponding packed 32-bit values in the first and second source operands and writes the result of each compare in the corresponding 32 bits of the destination (first source). For each pair of doublewords, if the values are equal, the result is all 1s. If the values are not equal, the result is all 0s. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PCMPEQD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PCMPEQD mmx1, mmx2/mem64</td>
        <td>0F 76 /r</td>
        <td>Compares packed doublewords in an MMX register<br/>and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PCMPEQD operation on 64-bit media operands mmx1 and mmx2/mem64, comparing two 32-bit doublewords and storing the result (all 1s or 0s) in the destination.

## Related Instructions

PCMPEQB, PCMPEQW, PCMPGTB, PCMPGTD, PCMPGTW

## rFLAGS Affected

None

<page_number>

76
</page_number>

PCMPEQD 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PCMPEQD <page_number>77</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# PCMPEQW Packed Compare Equal Words

Compares corresponding packed 16-bit values in the first and second source operands and writes the result of each compare in the corresponding 16 bits of the destination (first source). For each pair of words, if the values are equal, the result is all 1s. If the values are not equal, the result is all 0s. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PCMPEQW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PCMPEQW mmx1, mmx2/mem64</td>
        <td>0F 75 /r</td>
        <td>Compares packed 16-bit values in an MMX register and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PCMPEQW operation on 64-bit MMX registers. It illustrates how four 16-bit words from mmx1 and mmx2/mem64 are compared, with the results (all 1s or 0s) written back to mmx1.

## Related Instructions

PCMPEQB, PCMPEQD, PCMPGTB, PCMPGTD, PCMPGTW

## rFLAGS Affected

None

<page_number>78</page_number> PCMPEQW 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PCMPEQW <page_number>79</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PCMPGTB Packed Compare Greater Than Signed Bytes

Compares corresponding packed signed bytes in the first and second source operands and writes the result of each compare in the corresponding byte of the destination (first source). For each pair of bytes, if the value in the first source operand is greater than the value in the second source operand, the result is all 1s. If the value in the first source operand is less than or equal to the value in the second source operand, the result is all 0s. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PCMPGTB instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PCMPGTB mmx1, mmx2/mem64</td>
        <td>0F 64 /r</td>
        <td>Compares packed signed bytes in an MMX register and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PCMPGTB operation comparing packed signed bytes between mmx1 and mmx2/mem64 registers, resulting in all 1s or 0s for each byte.

## Related Instructions

PCMPEQB, PCMPEQD, PCMPEQW, PCMPGTD, PCMPGTW

## rFLAGS Affected

None

<page_number>80</page_number>

PCMPGTB 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PCMPGTB <page_number>81</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PCMPGTD

# Packed Compare Greater Than Signed Doublewords

Compares corresponding packed signed 32-bit values in the first and second source operands and writes the result of each compare in the corresponding 32 bits of the destination (first source). For each pair of doublewords, if the value in the first source operand is greater than the value in the second source operand, the result is all 1s. If the value in the first source operand is less than or equal to the value in the second source operand, the result is all 0s. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PCMPGTD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PCMPGTD mmx1, mmx2/mem64</td>
        <td>0F 66 /r</td>
        <td>Compares packed signed 32-bit values in an MMX register and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PCMPGTD operation comparing two 64-bit operands (mmx1 and mmx2/mem64) as packed 32-bit doublewords, resulting in all 1s or 0s in the destination.

## Related Instructions

PCMPEQB, PCMPEQD, PCMPEQW, PCMPGTB, PCMPGTW

## rFLAGS Affected

None

<page_number>

82
</page_number>

PCMPGTD
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

26569—Rev. 3.16—November 2021 AMD logo AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PCMPGTD** <page_number>83</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PCMPGTW Packed Compare Greater Than Signed Words

Compares corresponding packed signed 16-bit values in the first and second source operands and writes the result of each compare in the corresponding 16 bits of the destination (first source). For each pair of words, if the value in the first source operand is greater than the value in the second source operand, the result is all 1s. If the value in the first source operand is less than or equal to the value in the second source operand, the result is all 0s. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PCMPGTW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PCMPGTW mmx1, mmx2/mem64</td>
        <td>0F 65 /r</td>
        <td>Compares packed signed 16-bit values in an MMX register and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PCMPGTW operation on 64-bit registers mmx1 and mmx2/mem64, comparing four 16-bit signed words and storing the result (all 1s or 0s) back into mmx1.

## Related Instructions

PCMPEQB, PCMPEQD, PCMPEQW, PCMPGTB, PCMPGTD

## rFLAGS Affected

None

<page_number>

84
</page_number>

PCMPGTW 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PCMPGTW <page_number>85</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PEXTRW

# Extract Packed Word

Extracts a 16-bit value from an MMX register, as selected by the immediate byte operand (as shown in Table 1-1) and writes it to the low-order word of a 32-bit general-purpose register, with zero-extension to 32 bits.

The PEXTRW instruction is a member of both the AMD MMX™ extensions and the SSE1 instruction set. Support for the SSE1 instruction subset is indicated by CPUID Fn0000_0001_EDX[SSE] = 1. Support for AMD’s extensions to the MMX instruction subset is indicated by CPUID Fn8000_0001_EDX[MmxExt] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PEXTRW reg32, mmx, imm8</td>
        <td>0F C5 /r ib</td>
        <td>Extracts a 16-bit value from an MMX register and writes it to low-order 16 bits of a general-purpose register.</td>
    </tr>
  </tbody>
</table>

Engineering drawing showing PEXTRW operation: extracting a 16-bit word from an MMX register to a 32-bit general-purpose register based on an immediate byte operand.

Table 1-1. Immediate-Byte Operand Encoding for 64-Bit PEXTRW

<table>
  <thead>
    <tr>
        <th>Immediate-Byte<br/>Bit Field</th>
        <th>Value of Bit Field</th>
        <th>Source Bits Extracted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="4">1–0</td>
        <td>0</td>
        <td>15–0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>31–16</td>
    </tr>
    <tr>
        <td>2</td>
        <td>47–32</td>
    </tr>
    <tr>
        <td>3</td>
        <td>63–48</td>
    </tr>
  </tbody>
</table>

## Related Instructions

PINSRW

## rFLAGS Affected

<page_number>

86
</page_number>

PEXTRW
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

26569—Rev. 3.16—November 2021 AMD64 Technology AMD

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0; and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PEXTRW <page_number>87</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PF2ID Packed Floating-Point to Integer Doubleword Converson

Converts two packed single-precision floating-point values in an MMX register or a 64-bit memory location to two packed 32-bit signed integer values and writes the converted values in another MMX register. If the result of the conversion is an inexact value, the value is truncated (rounded toward zero). The numeric range for source and destination operands is shown in Table 1-2 on page 89.

The PF2ID instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

CVTTPS2DQ

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PF2ID mmx1, mmx2/mem64</td>
        <td>0F 0F /r 1D</td>
        <td>Converts packed single-precision floating-point values in an MMX register or memory location to a doubleword integer value in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two packed single-precision floating-point values from mmx2/mem64 to two packed 32-bit signed integer values in mmx1. The diagram shows 64-bit registers divided into two 32-bit halves (bits 63-32 and 31-0).

<page_number>

88
</page_number>

PF2ID [AMD Confidential - Distribution with NDA]

64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

Table 1-2. Numeric Range for PF2ID Results

<table>
  <thead>
    <tr>
        <th>Source 2</th>
        <th>Source 1 and Destination</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
    </tr>
    <tr>
        <td>Normal, abs(Source 2) &lt; 1</td>
        <td>0</td>
    </tr>
    <tr>
        <td>Normal, –2<sup>31</sup> &lt; Source 2 &lt;= –1</td>
        <td>Round to zero (Source 2)</td>
    </tr>
    <tr>
        <td>Normal, 1 &lt;= Source 2 &lt; 2<sup>31</sup></td>
        <td>Round to zero (Source 2)</td>
    </tr>
    <tr>
        <td>Normal, Source 2 &gt;= 2<sup>31</sup></td>
        <td>7FFF_FFFFh</td>
    </tr>
    <tr>
        <td>Normal, Source 2 &lt;= –2<sup>31</sup></td>
        <td>8000_0000h</td>
    </tr>
    <tr>
        <td>Unsupported</td>
        <td>Undefined</td>
    </tr>
  </tbody>
</table>

## Related Instructions

PF2IW, PI2FD, PI2FW

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference
[AMD Confidential PF2ID Distribution with NDA]

<page_number>89</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PF2IW Packed Floating-Point to Integer Word Conversion

Converts two packed single-precision floating-point values in an MMX register or a 64-bit memory location to two packed 16-bit signed integer values, sign-extended to 32 bits, and writes the converted values in another MMX register. If the result of the conversion is an inexact value, the value is truncated (rounded toward zero). The numeric range for source and destination operands is shown in Table 1-3 on page 91. Arguments outside the range representable by signed 16-bit integers are saturated to the largest and smallest 16-bit integer, depending on their sign.

The PF2IW instruction is an extension to the AMD 3DNow!™ instruction set. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

CVTTPS2DQ

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PF2IW mmx1, mmx2/mem64</td>
        <td>0F 0F /r 1C</td>
        <td>Converts packed single-precision floating-point values in an MMX register or memory location to word integer values in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two 32-bit floating-point values from mmx2/mem64 to two 16-bit signed integers in mmx1, sign-extended to 32 bits.

<page_number>

90
</page_number>

PF2IW

64-Bit Media

[AMD Confidential - Distribution with NDA]

Instruction Reference

26569—Rev. 3.16—November 2021 AMD logo AMD64 Technology

Table 1-3. Numeric Range for PF2IW Results

<table>
  <thead>
    <tr>
        <th>Source 2</th>
        <th>Source 1 and Destination</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
    </tr>
    <tr>
        <td>Normal, abs(Source 2) &lt; 1</td>
        <td>0</td>
    </tr>
    <tr>
        <td>Normal, –2<sup>15</sup> &lt; Source 2 &lt;= –1</td>
        <td>Round to zero (Source 2)</td>
    </tr>
    <tr>
        <td>Normal, 1 &lt;= Source 2 &lt; 2<sup>15</sup></td>
        <td>Round to zero (Source 2)</td>
    </tr>
    <tr>
        <td>Normal, Source 2 &gt;= 2<sup>15</sup></td>
        <td>0000_7FFFh</td>
    </tr>
    <tr>
        <td>Normal, Source 2 &lt;= –2<sup>15</sup></td>
        <td>FFFF_8000h</td>
    </tr>
    <tr>
        <td>Unsupported</td>
        <td>Undefined</td>
    </tr>
  </tbody>
</table>

# Related Instructions

PF2ID, PI2FD, PI2FW

# rFLAGS Affected

None

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>X</th>
        <th>X</th>
        <th>X</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD extensions to 3DNow!™ are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNowExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media <mark>[AMD Confidential PF2IW Instruction Reference - Distribution with NDA]</mark>
Instruction Reference
<page_number>91</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PFACC Packed Floating-Point Accumulate

Adds the two single-precision floating-point values in the first source operand and adds the two single-precision values in the second source operand and writes the two results to the low-order and high-order doubleword, respectively, of the destination (first source). The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location.

The PFACC instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

HADDPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFACC mmx1, mmx2/mem64</td>
        <td>0F 0F /r AE</td>
        <td>Accumulates packed single-precision floating-point values in an MMX register or 64-bit memory location and another MMX register and writes each result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PFACC instruction operation: adding high and low 32-bit floating-point values within mmx1 and mmx2/mem64 registers and storing the results in mmx1.

The numeric range for operands is shown in Table 1-4 on page 93.

<page_number>

92
</page_number>

PFACC 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# Table 1-4. Numeric Range for PFACC Results

<table>
  <thead>
    <tr>
        <th colspan="2">Source Operand</th>
        <th colspan="3">High Operand<sup>2</sup></th>
    </tr>
    <tr>
        <th> </th>
        <th> </th>
        <th>0</th>
        <th>Normal</th>
        <th>Unsupported</th>
    </tr>
    <tr>
        <th rowspan="3">Low Operand<sup>1</sup></th>
        <th>0</th>
        <th>+/- 0<sup>3</sup></th>
        <th>High Operand</th>
        <th>High Operand</th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>Low Operand</th>
        <th>Normal, +/- 0<sup>4</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Unsupported<sup>5</sup></th>
        <th>Low Operand</th>
        <th>Undefined</th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

**Note:**

1. Least-significant floating-point value in first or second source operand.

2. Most-significant floating-point value in first or second source operand.

3. The sign of the result is the logical AND of the signs of the low and high operands.

4. If the absolute value of the infinitely precise result is less than 2<sup>-126</sup> (but not zero), the result is a zero with the sign of the operand (low or high) that is larger in magnitude. If the infinitely precise result is exactly zero, the result is zero with the sign of the low operand. If the absolute value of the infinitely precise result is greater than or equal to 2<sup>128</sup>, the result is the largest normal number with the sign of the low operand.

5. "Unsupported" means that the exponent is all ones (1s).

## Related Instructions

PFADD, PFNACC, PFPNACC

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media Instruction Reference [AMD Confidential PFACC Instruction Reference - Distribution with NDA]

<page_number>93</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PFADD Packed Floating-Point Add

Adds each packed single-precision floating-point value in the first source operand to the corresponding packed single-precision floating-point value in the second operand and writes the result of each addition in the corresponding doubleword of the destination (first source). The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location. The numeric range for operands is shown in Table 1-5 on page 95.

The PFADD instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

ADDPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFADD mmx1, mmx2/mem64</td>
        <td>0F 0F /r 9E</td>
        <td>Adds two packed single-precision floating-point values in an MMX register or 64-bit memory location and another MMX register and writes each result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PFADD operation: two 64-bit operands (mmx1 and mmx2/mem64) each containing two 32-bit single-precision floating-point values are added together, and the results are stored back into mmx1.

<page_number>94</page_number> PFADD 64-Bit Media [AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# Table 1-5. Numeric Range for the PFADD Results

<table>
  <thead>
    <tr>
        <th> </th>
        <th colspan="4">Most-Significant Doubleword</th>
    </tr>
    <tr>
        <th>Source Operand</th>
        <th>0</th>
        <th>Normal</th>
        <th colspan="2">Unsupported</th>
    </tr>
    <tr>
        <th rowspan="3">Source 1 and<br/>Destination</th>
        <th>0</th>
        <th>+/- 0<sup>1</sup></th>
        <th>Source 2</th>
        <th>Source 2</th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>Source 1</th>
        <th>Normal, +/- 0<sup>2</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Unsupported<sup>3</sup></th>
        <th>Source 1</th>
        <th>Undefined</th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

**Note:**

1. The sign of the result is the logical AND of the signs of the source operands.

2. If the absolute value of the infinitely precise result is less than 2<sup>–126</sup> (but not zero), the result is a zero with the sign of the source operand that is larger in magnitude. If the infinitely precise result is exactly zero, the result is zero with the sign of source 1. If the absolute value of the infinitely precise result is greater than or equal to 2<sup>128</sup>, the result is the largest normal number with the sign of source 1.

3. “Unsupported” means that the exponent is all ones (1s).

## Related Instructions

PFACC, PFNACC, PFPNACC

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential PFADD Instruction Reference - Distribution with NDA]

<page_number>95</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PFCMPEQ Packed Floating-Point Compare Equal

Compares each of the two packed single-precision floating-point values in the first source operand with the corresponding packed single-precision floating-point value in the second source operand and writes the result of each comparison in the corresponding doubleword of the destination (first source). For each pair of floating-point values, if the values are equal, the result is all 1s. If the values are not equal, the result is all 0s. The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location. The numeric range for operands is shown in Table 1-6 on page 97.

The PFCMPEQ instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

CMPSS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFCMPEQ mmx1, mmx2/mem64</td>
        <td>0F 0F /r B0</td>
        <td>Compares two pairs of packed single-precision floating-point values in an MMX register and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>
<table>
  <thead>
    <tr>
        <th>Operand 1 (mmx1)</th>
        <th>Operand 2 (mmx2/mem64)</th>
        <th>Operation</th>
        <th>Result (to mmx1)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Bits [63:32]</td>
        <td>Bits [63:32]</td>
        <td>compare</td>
        <td>all 1s or 0s</td>
    </tr>
    <tr>
        <td>Bits [31:0]</td>
        <td>Bits [31:0]</td>
        <td>compare</td>
        <td>all 1s or 0s</td>
    </tr>
  </tbody>
</table>

<page_number>96</page_number>

PFCMPEQ [AMD Confidential - Distribution with NDA]

64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

Table 1-6. Numeric Range for the PFCMPEQ Instruction

<table>
  <thead>
    <tr>
        <th rowspan="2">Operand</th>
        <th rowspan="2">Value</th>
        <th colspan="3">Source 2</th>
    </tr>
    <tr>
        <th>0</th>
        <th>Normal</th>
        <th>Unsupported</th>
    </tr>
    <tr>
        <th rowspan="3">Source 1 and Destination</th>
        <th>0</th>
        <th>FFFF_FFFFh<sup>1</sup></th>
        <th>0000_0000h</th>
        <th>0000_0000h</th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>0000_0000h</th>
        <th>0000_0000h or FFFF_FFFFh<sup>2</sup></th>
        <th>0000_0000h</th>
    </tr>
    <tr>
        <th>Unsupported<sup>3</sup></th>
        <th>0000_0000h</th>
        <th>0000_0000h</th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

Note:

1. Positive zero is equal to negative zero.

2. The result is FFFF_FFFFh if source 1 and source 2 have identical signs, exponents, and mantissas. Otherwise, the result is 0000_0000h.

3. "Unsupported" means that the exponent is all ones (1s).

## Related Instructions

PFCMPGE, PFCMPGT

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PFCMPEQ
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>97</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PFCMPGE Packed Floating-Point Compare Greater or Equal

Compares each of the two packed single-precision floating-point values in the first source operand with the corresponding packed single-precision floating-point value in the second source operand and writes the result of each comparison in the corresponding doubleword of the destination (first source). For each pair of floating-point values, if the value in the first source operand is greater than or equal to the value in the second source operand, the result is all 1s. If the value in the first source operand is less than the value in the second source operand, the result is all 0s. The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location. The numeric range for operands is shown in Table 1-7 on page 99.

The PFCMPGE instruction is a 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

CMPPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFCMPGE mmx1, mmx2/mem64</td>
        <td>0F 0F /r 90</td>
        <td>Compares two pairs of packed single-precision floating-point values in an MMX register and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph mmx1
        m1_high[63 ... 32]
        m1_low[31 ... 0]
    end
    subgraph mmx2_mem64
        m2_high[63 ... 32]
        m2_low[31 ... 0]
    end
    m1_high --- comp1[compare]
    m2_high --- comp1
    m1_low --- comp2[compare]
    m2_low --- comp2
    comp1 --> res1[all 1s or 0s]
    comp2 --> res2[all 1s or 0s]
    res1 --> m1_high
    res2 --> m1_low
```

<page_number>98</page_number>

PFCMPGE

[AMD Confidential - Distribution with NDA]

64-Bit Media

Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# Table 1-7. Numeric Range for the PFCMPGE Instruction

<table>
  <thead>
    <tr>
        <th>Operand</th>
        <th>Value</th>
        <th colspan="3">Source 2</th>
    </tr>
    <tr>
        <th> </th>
        <th> </th>
        <th>0</th>
        <th>Normal</th>
        <th>Unsupported</th>
    </tr>
    <tr>
        <th rowspan="3">Source 1 and Destination</th>
        <th>0</th>
        <th>FFFF_FFFFh<sup>1</sup></th>
        <th>0000_0000h,<br/>FFFF_FFFFh<sup>2</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>0000_0000h,<br/>FFFF_FFFFh<sup>3</sup></th>
        <th>0000_0000h,<br/>FFFF_FFFFh<sup>4</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Unsupported<sup>5</sup></th>
        <th>Undefined</th>
        <th>Undefined</th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

**Note:**

1. Positive zero is equal to negative zero.

2. The result is FFFF_FFFFh, if source 2 is negative. Otherwise, the result is 0000_0000h.

3. The result is FFFF_FFFFh, if source 1 is positive. Otherwise, the result is 0000_0000h.

4. The result is FFFF_FFFFh, if source 1 is positive and source 2 is negative, or if they are both negative and source 1 is smaller than or equal in magnitude to source 2, or if source 1 and source 2 are both positive and source 1 is greater than or equal in magnitude to source 2. The result is 0000_0000h in all other cases.

5. “Unsupported” means that the exponent is all ones (1s).

## Related Instructions

PFCMPEQ, PFCMPGT

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PFCMPGE
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>99</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

100
</page_number>

[AMD Confidential - Distribution with NDA]

**PFCMPGE**

64-Bit Media Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PFCMPGT Packed Floating-Point Compare Greater Than

Compares each of the two packed single-precision floating-point values in the first source operand with the corresponding packed single-precision floating-point value in the second source operand and writes the result of each comparison in the corresponding doubleword of the destination (first source). For each pair of floating-point values, if the value in the first source operand is greater than the value in the second source operand, the result is all 1s. If the value in the first source operand is less than or equal to the value in the second source operand, the result is all 0s. The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location. The numeric range for operands is shown in Table 1-8 on page 102.

The PFCMPGT instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

CMPPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFCMPGT mmx1,<br/>mmx2/mem64</td>
        <td>0F 0F /r A0</td>
        <td>Compares two pairs of packed single-precision floating-point values in an MMX register and an MMX register or 64-bit memory location.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph mmx1
        m1_63[63] --- m1_32[32 31] --- m1_0[0]
    end
    subgraph mmx2_mem64["mmx2/mem64"]
        m2_63[63] --- m2_32[32 31] --- m2_0[0]
    end

    m1_32 -- compare --- m2_32
    m1_0 -- compare --- m2_0

    m2_32 --> res1["all 1s or 0s"]
    m2_0 --> res2["all 1s or 0s"]

    res1 --> m1_32
    res2 --> m1_0
```

64-Bit Media
Instruction Reference
PFCMPGT
[AMD Confidential - Distribution with NDA]

<page_number>101</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# Table 1-8. Numeric Range for the PFCMPGT Instruction

<table>
  <thead>
    <tr>
        <th> </th>
        <th> </th>
        <th colspan="3">Source 2</th>
    </tr>
    <tr>
        <th>Operand</th>
        <th>Value</th>
        <th>0</th>
        <th>Normal</th>
        <th>Unsupported</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">Source 1 and<br/>Destination</td>
        <td>0</td>
        <td>0000_0000h</td>
        <td>0000_0000h,<br/>FFFF_FFFFh<sup>1</sup></td>
        <td>Undefined</td>
    </tr>
    <tr>
        <td>Normal</td>
        <td>0000_0000h,<br/>FFFF_FFFFh<sup>2</sup></td>
        <td>0000_0000h,<br/>FFFF_FFFFh<sup>3</sup></td>
        <td>Undefined</td>
    </tr>
    <tr>
        <td>Unsupported<sup>4</sup></td>
        <td>Undefined</td>
        <td>Undefined</td>
        <td>Undefined</td>
    </tr>
  </tbody>
</table>

**Note:**

1. *The result is FFFF_FFFFh, if source 2 is negative. Otherwise, the result is 0000_0000h.*

2. *The result is FFFF_FFFFh, if source 1 is positive. Otherwise, the result is 0000_0000h.*

3. *The result is FFFF_FFFFh, if source 1 is positive and source 2 is negative, or if they are both negative and source 1 is smaller in magnitude than source 2, or if source 1 and source 2 are positive and source 1 is greater in magnitude than source 2. The result is 0000_0000h in all other cases.*

4. *"Unsupported" means that the exponent is all ones (1s).*

## Related Instructions

PFCMPEQ, PFCMPGE

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by ECPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>102</page_number>

<mark>[AMD Confidential - Distribution with NDA]</mark> **PFCMPGT**

64-Bit Media Instruction Reference

26569—Rev. 3.16—November 2021

AMD AMD64 Technology

# PFMAX Packed Single-Precision Floating-Point Maximum

Compares each of the two packed single-precision floating-point values in the first source operand with the corresponding packed single-precision floating-point value in the second source operand and writes the maximum of the two values for each comparison in the corresponding doubleword of the destination (first source). The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location.

Any operation with a zero and a negative number returns positive zero. An operation consisting of two zeros returns positive zero. If either source operand is an undefined value, the result is undefined. The numeric range for source and destination operands is shown in Table 1-9 on page 104.

The PFMAX instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

MAXPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFMAX mmx1, mmx2/mem64</td>
        <td>0F 0F /r A4</td>
        <td>Compares two pairs of packed single-precision values in an MMX register and another MMX register or 64-bit memory location and writes the maximum value of each comparison in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PFMAX operation on two 64-bit MMX registers, comparing two pairs of 32-bit single-precision floating-point values and storing the maximums in the destination register.

64-Bit Media [AMD Confidential PFMAX Instruction Reference - Distribution with NDA]
Instruction Reference
<page_number>

103
</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

Table 1-9. Numeric Range for the PFMAX Instruction

<table>
  <thead>
    <tr>
        <th rowspan="2">Operand</th>
        <th rowspan="2">Value</th>
        <th colspan="3">Source 2</th>
    </tr>
    <tr>
        <th>0</th>
        <th>Normal</th>
        <th>Unsupported</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">Source 1 and Destination</td>
        <td>0</td>
        <td>+0</td>
        <td>Source 2, +0<sup>1</sup></td>
        <td>Undefined</td>
    </tr>
    <tr>
        <td>Normal</td>
        <td>Source 1, +0<sup>2</sup></td>
        <td>Source 1/Source 2<sup>3</sup></td>
        <td>Undefined</td>
    </tr>
    <tr>
        <td>Unsupported<sup>4</sup></td>
        <td>Undefined</td>
        <td>Undefined</td>
        <td>Undefined</td>
    </tr>
  </tbody>
</table>

Note:

1. *The result is source 2, if source 2 is positive. Otherwise, the result is positive zero.*

2. *The result is source 1, if source 1 is positive. Otherwise, the result is positive zero.*

3. *The result is source 1, if source 1 is positive and source 2 is negative. The result is source 1, if both are positive and source 1 is greater in magnitude than source 2. The result is source 1, if both are negative and source 1 is lesser in magnitude than source 2. The result is source 2 in all other cases.*

4. *"Unsupported" means that the exponent is all ones (1s).*

## Related Instructions

PFMIN

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>104</page_number>

PFMAX
[AMD Confidential - Distribution with NDA]

64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PFMIN Packed Single-Precision Floating-Point Minimum

Compares each of the two packed single-precision floating-point values in the first source operand with the corresponding packed single-precision floating-point value in the second source operand and writes the minimum of the two values for each comparison in the corresponding doubleword of the destination (first source). The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location.

Any operation with a zero and a positive number returns positive zero. An operation consisting of two zeros returns positive zero. If either source operand is an undefined value, the result is undefined. The numeric range for source and destination operands is shown in Table 1-10 on page 106.

The PFMIN instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

MINPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFMIN mmx1, mmx2/mem64</td>
        <td>0F 0F /r 94</td>
        <td>Compares two pairs of packed single-precision values in an MMX register and another MMX register or 64-bit memory location and writes the minimum value of each comparison in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing PFMIN operation: two 64-bit operands (mmx1 and mmx2/mem64) each containing two 32-bit single-precision values. The diagram illustrates the comparison of corresponding values and the storage of the minimum results back into mmx1.

64-Bit Media Instruction Reference [AMD Confidential PFMIN Distribution with NDA]

<page_number>105</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Table 1-10. Numeric Range for the PFMIN Instruction

<table>
  <thead>
    <tr>
        <th rowspan="2">Operand</th>
        <th>Value</th>
        <th colspan="3">Source 2</th>
    </tr>
    <tr>
        <th>0</th>
        <th>Normal</th>
        <th colspan="2">Unsupported</th>
    </tr>
    <tr>
        <th rowspan="3">Source 1 and<br/>Destination</th>
        <th>0</th>
        <th>+0</th>
        <th>Source 2, +0<sup>1</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>Source 1, +0<sup>2</sup></th>
        <th>Source 1/Source 2<sup>3</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Unsupported<sup>4</sup></th>
        <th>Undefined</th>
        <th>Undefined</th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

**Note:**

1. *The result is source 2, if source 2 is negative. Otherwise, the result is positive zero.*

2. *The result is source 1, if source 1 is negative. Otherwise, the result is positive zero.*

3. *The result is source 1, if source 1 is negative and source 2 is positive. The result is source 1, if both are negative and source 1 is greater in magnitude than source 2. The result is source 1, if both are positive and source 1 is lesser in magnitude than source 2. The result is source 2 in all other cases.*

4. *"Unsupported" means that the exponent is all ones (1s).*

## Related Instructions

PFMAX

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>106</page_number> PFMIN 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PFMUL

# Packed Floating-Point Multiply

Multiplies each of the two packed single-precision floating-point values in the first source operand by the corresponding packed single-precision floating-point value in the second source operand and writes the result of each multiplication in the corresponding doubleword of the destination (first source). The numeric range for source and destination operands is shown in Table 1-11 on page 108. The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location.

The PFMUL instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

MULPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFMUL mmx1, mmx2/mem64</td>
        <td>0F 0F /r<br/>B4</td>
        <td>Multiplies packed single-precision floating-point values in an MMX register and another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PFMUL operation: two 64-bit operands (mmx1 and mmx2/mem64) each containing two 32-bit floating-point values are multiplied element-wise, and the results are stored back into mmx1.

64-Bit Media
Instruction Reference
[AMD Confidential PFMUL Instruction Reference - Distribution with NDA]
<page_number>

107
</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

Table 1-11. Numeric Range for the PFMUL Instruction

<table>
  <thead>
    <tr>
        <th rowspan="2">Operand</th>
        <th rowspan="2">Value</th>
        <th colspan="3">Source 2</th>
    </tr>
    <tr>
        <th>0</th>
        <th>Normal</th>
        <th>Unsupported</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">Source 1 and Destination</td>
        <td>0</td>
        <td>+/– 0<sup>1</sup></td>
        <td>+/– 0<sup>1</sup></td>
        <td>+/– 0<sup>1</sup></td>
    </tr>
    <tr>
        <td>Normal</td>
        <td>+/– 0<sup>1</sup></td>
        <td>Normal, +/– 0<sup>2</sup></td>
        <td>Undefined</td>
    </tr>
    <tr>
        <td>Unsupported<sup>3</sup></td>
        <td>+/– 0<sup>1</sup></td>
        <td>Undefined</td>
        <td>Undefined</td>
    </tr>
  </tbody>
</table>

Note:

1. The sign of the result is the exclusive-OR of the signs of the source operands.

2. If the absolute value of the result is less than 2<sup>–126</sup>, the result is zero with the sign being the exclusive-OR of the signs of the source operands. If the absolute value of the product is greater than or equal to 2<sup>128</sup>, the result is the largest normal number with the sign being the exclusive-OR of the signs of the source operands.

3. “Unsupported” means that the exponent is all ones (1s).

## Related Instructions

None

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>108</page_number>

PFMUL 64-Bit Media [AMD Confidential - Distribution with NDA] Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PFNACC Packed Floating-Point Negative Accumulate

Subtracts the first source operand’s high-order single-precision floating-point value from its low-order single-precision floating-point value, subtracts the second source operand’s high-order single-precision floating-point value from its low-order single-precision floating-point value, and writes each result to the low-order or high-order doubleword, respectively, of the destination (first source). The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location.

The numeric range for operands is shown in Table 1-12 on page 110.

The PFNACC instruction is an extension to the AMD 3DNow!™ instruction set. The presence of this instruction set is indicated by CPUID Fn8000_0001_EDX[3DNowExt] = 1. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

HSUBPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFNACC mmx1, mmx2/mem64</td>
        <td>0F 0F /r 8A</td>
        <td>Subtracts the packed single-precision floating-point values in an MMX register or 64-bit memory location and another MMX register and writes each value in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PFNACC operation: mmx1 and mmx2/mem64 registers are divided into two 32-bit single-precision floating-point values. For each register, the high-order value (bits 63-32) is subtracted from the low-order value (bits 31-0). The results are written back to the corresponding doublewords in mmx1.

64-Bit Media
PFNACC
[AMD Confidential - Distribution with NDA]
Instruction Reference
<page_number>

109
</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

Table 1-12. Numeric Range of PFNACC Results

<table>
  <thead>
    <tr>
        <th> </th>
        <th colspan="4">High Operand<sup>2</sup></th>
    </tr>
    <tr>
        <th colspan="2">Source Operand</th>
        <th>0</th>
        <th>Normal</th>
        <th>Unsupported</th>
    </tr>
    <tr>
        <th rowspan="3">Low Operand<sup>1</sup></th>
        <th>0</th>
        <th>+/- 0<sup>3</sup></th>
        <th>- High Operand</th>
        <th>- High Operand</th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>Low Operand</th>
        <th>Normal, +/- 0<sup>4</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Unsupported<sup>5</sup></th>
        <th>Low Operand</th>
        <th>Undefined</th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

Note:

1. Least-significant floating-point value in first or second source operand.

2. Most-significant floating-point value in first or second source operand.

3. The sign is the logical AND of the sign of the low operand and the inverse of the sign of the high operand.

4. If the absolute value of the infinitely precise result is less than 2<sup>-126</sup> (but not zero), the result is a zero. If the low operand is larger in magnitude than the high operand, the sign of this zero is the same as the sign of the low operand, else it is the inverse of the sign of the high operand. If the infinitely precise result is exactly zero, the result is zero with the sign of the low operand. If the absolute value of the infinitely precise result is greater than or equal to 2<sup>128</sup>, the result is the largest normal number with the sign of the low operand.

5. "Unsupported" means that the exponent is all ones (1s).

## Related Instructions

PFSUB, PFACC, PFPNACC

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD extensions to 3DNow!™ are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNowExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
  </tbody>
</table>

<page_number>110</page_number>

[AMD Confidential - Distribution with NDA] PFNACC 64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PFNACC** <page_number>111</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PFPNACC Packed Floating-Point Positive-Negative Accumulate

Subtracts the first source operand’s high-order single-precision floating-point value from its low-order single-precision floating-point value, adds the two single-precision values in the second source operand, and writes each result to the low-order or high-order doubleword, respectively, of the destination (first source). The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location.

The numeric range for operands is shown in Table 1-13 (for the low result) and Table 1-14 (for the high result), both on page 113.

The PFPNACC instruction is an extension to the AMD 3DNow!™ instruction set. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

ADDSUBPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFPNACC mmx1, mmx2/mem64</td>
        <td>0F 0F /r 8E</td>
        <td>Subtracts the packed single-precision floating-point values in an MMX register, adds the packed single-precision floating-point values in another MMX register or 64-bit memory location, and writes each value in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Engineering drawing showing the PFPNACC operation: mmx1 (63-32, 31-0) and mmx2/mem64 (63-32, 31-0) registers. The high and low parts of mmx1 are subtracted, and the high and low parts of mmx2/mem64 are added, with results written back to mmx1.

<page_number>112</page_number>

PFPNACC 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

Table 1-13. Numeric Range of PFPNACC Result (Low Result)

<table>
  <thead>
    <tr>
        <th rowspan="2">Source Operand</th>
        <th colspan="4">High Operand²</th>
    </tr>
    <tr>
        <th>0</th>
        <th>Normal</th>
        <th colspan="2">Unsupported</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">Low Operand¹</td>
        <td>0</td>
        <td>+/– 0<sup>3</sup></td>
        <td>- High Operand</td>
        <td>- High Operand</td>
    </tr>
    <tr>
        <td>Normal</td>
        <td>Low Operand</td>
        <td>Normal, +/– 0<sup>4</sup></td>
        <td>Undefined</td>
    </tr>
    <tr>
        <td>Unsupported⁵</td>
        <td>Low Operand</td>
        <td>Undefined</td>
        <td>Undefined</td>
    </tr>
  </tbody>
</table>

**Note:**

1. *Least-significant floating-point value in first or second source operand.*

2. *Most-significant floating-point value in first or second source operand.*

3. *The sign is the logical AND of the sign of the low operand and the inverse of the sign of the high operand.*

4. *If the absolute value of the infinitely precise result is less than 2<sup>–126</sup> (but not zero), the result is a zero. If the low operand is larger in magnitude than the high operand, the sign of this zero is the same as the sign of the low operand, else it is the inverse of the sign of the high operand. If the infinitely precise result is exactly zero, the result is zero with the sign of the low operand. If the absolute value of the infinitely precise result is greater than or equal to 2<sup>128</sup>, the result is the largest normal number with the sign of the low operand.*

5. *“Unsupported” means that the exponent is all ones (1s).*

Table 1-14. Numeric Range of PFPNACC Result (High Result)

<table>
  <thead>
    <tr>
        <th rowspan="2">Source Operand</th>
        <th colspan="4">High Operand²</th>
    </tr>
    <tr>
        <th>0</th>
        <th>Normal</th>
        <th colspan="2">Unsupported</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">Low Operand¹</td>
        <td>0</td>
        <td>+/– 0<sup>3</sup></td>
        <td>High Operand</td>
        <td>High Operand</td>
    </tr>
    <tr>
        <td>Normal</td>
        <td>Low Operand</td>
        <td>Normal, +/– 0<sup>4</sup></td>
        <td>Undefined</td>
    </tr>
    <tr>
        <td>Unsupported⁵</td>
        <td>Low Operand</td>
        <td>Undefined</td>
        <td>Undefined</td>
    </tr>
  </tbody>
</table>

**Note:**

1. *Least-significant floating-point value in first or second source operand.*

2. *Most-significant floating-point value in first or second source operand.*

3. *The sign is the logical AND of the signs of the low and high operands.*

4. *If the absolute value of the infinitely precise result is less than 2<sup>–126</sup> (but not zero), the result is zero with the sign of the operand (low or high) that is larger in magnitude. If the infinitely precise result is exactly zero, the result is zero with the sign of the low operand. If the absolute value of the infinitely precise result is greater than or equal to 2<sup>128</sup>, the result is the largest normal number with the sign of the low operand.*

5. *“Unsupported” means that the exponent is all ones (1s).*

### Related Instructions

PFADD, PFSUB, PFACC, PFNACC

### rFLAGS Affected

None

64-Bit Media
PFPNACC
Instruction Reference
[AMD Confidential - Distribution with NDA]

<page_number>113</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD extensions to 3DNow!™ are not supported,<br/>as indicated by<br/>CPUID Fn8000_0001_EDX[3DNowExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>114</page_number>

PFPNACC
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# PFRCP Floating-Point Reciprocal Approximation

Computes the approximate reciprocal of the single-precision floating-point value in the low-order 32 bits of an MMX register or 64-bit memory location and writes the result in both doublewords of another MMX register. The result is accurate to 14 bits.

The PFRCP result can be forwarded to the Newton-Raphson iteration step 1 (PFRCPIT1) and Newton-Raphson iteration step 2 (PFRCPIT2) instructions to increase the accuracy of the reciprocal. The first stage of this refinement in accuracy (PFRCPIT1) requires that the input and output of the previously executed PFRCP instruction be used as input to the PFRCPIT1 instruction.

The estimate contains the correct round-to-nearest value for approximately 99% of all arguments. The remaining arguments differ from the correct round-to-nearest value for the reciprocal by 1 unit-in-the-last-place (ulp). For details, see the data sheet or other software-optimization documentation relating to particular hardware implementations.

PFRCP(x) returns 0 for x >= 2<sup>-126</sup>. The numeric range for operands is shown in Table 1-15 on page 116.

The PFRCP instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

RCPSS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFRCP mmx1, mmx2/mem64</td>
        <td>0F 0F /r 96</td>
        <td>Computes approximate reciprocal of single-precision floating-point value in an MMX register or 64-bit memory location and writes the result in both doublewords of the destination MMX register.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential PFRCP Instruction Reference - Distribution with NDA]
<page_number>

115
</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

Diagram showing mmx1 and mmx2/mem64 registers for approximate reciprocal operation

# Table 1-15. Numeric Range for the PFRCP Result

<table>
  <thead>
    <tr>
        <th>Operand</th>
        <th colspan="2">Source 1 and Destination</th>
    </tr>
    <tr>
        <th rowspan="3">Source 2</th>
        <th>0</th>
        <th>+/– Maximum Normal<sup>1</sup></th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>Normal, +/– 0<sup>2</sup></th>
    </tr>
    <tr>
        <th>Unsupported<sup>3</sup></th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

**Note:**

1. The result has the same sign as the source operand.

2. If the absolute value of the result is less than 2<sup>–126</sup>, the result is zero with the sign being the sign of the source operand. Otherwise, the result is a normal with the sign being the same sign as the source operand.

3. "Unsupported" means that the exponent is all ones (1s).

## Examples

The general Newton-Raphson recurrence for the reciprocal 1/b is:

$$ Z_{i + 1} \leftarrow Z_i \cdot (2 - b \cdot Z_i) $$

The following code sequence shows the computation of a/b:

```
X0 = PFRCP(b)
X1 = PFRCPIT1(b, X0)
X2 = PFRCPIT2(X1, X0)
q = PFMUL(a, X2)
```

The 24-bit final reciprocal value is X<sub>2</sub>. The quotient is formed in the last step by multiplying the reciprocal by the dividend a.

## Related Instructions

PFRCPIT1, PFRCPIT2

## rFLAGS Affected

None

<page_number>

116
</page_number>

PFRCP
[AMD Confidential - Distribution with NDA]

64-Bit Media

Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td> </td>
        <td> </td>
        <td> </td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

[AMD Confidential PFRCP - Distribution with NDA]

<page_number>117</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PFRCPIT1 Packed Floating-Point Reciprocal Iteration 1

Performs the first step in the Newton-Raphson iteration to refine the reciprocal approximation produced by the PFRCP instruction. The first source/destination operand is an MMX register containing the results of two previous PFRCP instructions, and the second source operand is another MMX register or 64-bit memory location containing the source operands from the same PFRCP instructions.

This instruction is only defined for those combinations of operands such that the first source operand (*mmx1*) is the approximate reciprocal of the second source operand (*mmx2/mem64*), and thus the range of the product, *mmx1* * *mmx2/mem64*, is (0.5, 2). The initial approximation of an operand is accurate to about 12 bits, and the length of the operand itself is 24 bits, so the product of these two operands is greater than 24 bits. PFRCPIT1 applies the one's complement of the product and rounds the result to 32 bits. It then compresses the result to fit into 24 bits by removing the 8 redundant most-significant bits after the hidden integer bit.

The estimate contains the correct round-to-nearest value for approximately 99% of all arguments. The remaining arguments differ from the correct round-to-nearest value for the reciprocal by 1 unit-in-the-last-place (ulp). For details, see the data sheet or other software-optimization documentation relating to particular hardware implementations.

The PFRCPIT1 instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

PFRCP

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFRCPIT1 mmx1, mmx2/mem64</td>
        <td>0F 0F /r A6</td>
        <td>Refine approximate reciprocal of result from previous PFRCP instruction.</td>
    </tr>
  </tbody>
</table>

<page_number>118</page_number>

[AMD Confidential - Distribution with NDA]

PFRCPIT1

64-Bit Media

Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

Diagram showing the Newton-Raphson reciprocal step 1 operation between mmx1 and mmx2/mem64 registers.

## Operation

```
mmx1[ 31:0] = Compress (2 - mmx1[ 31:0] * (mmx2/mem64[ 31:0]) - 2³¹);
mmx1[ 63:32] = Compress (2 - mmx1[ 63:32] * (mmx2/mem64[ 63:32]) - 2³¹);
```

where:

“Compress” means discard the 8 redundant most-significant bits after the hidden integer bit.

## Examples

The general Newton-Raphson recurrence for the reciprocal 1/b is:

$$Z_{i\ +1} \leftarrow Z_i \cdot (2 - b \cdot Z_i)$$

The following code sequence computes a 24-bit approximation to a/b with one Newton-Raphson iteration:

```
X₀ = PFRCP(b)
X₁ = PFRCPIT1(b, X₀)
X₂ = PFRCPIT2(X₁, X₀)
q = PFMUL(a, X₂)
```

a/b is formed in the last step by multiplying the reciprocal approximation by a.

## Related Instructions

PFRCP, PFRCPIT2

## rFLAGS Affected

None

**64-Bit Media**

**PFRCPIT1**

<page_number>119</page_number>

[AMD Confidential - Distribution with NDA]

**Instruction Reference**

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th> </th>
        <th> </th>
        <th>Virtual</th>
        <th> </th>
        <th> </th>
    </tr>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>120</page_number>

PFRCPIT1
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PFRCPIT2 Packed Floating-Point Reciprocal or Reciprocal Square Root Iteration 2

Performs the second and final step in the Newton-Raphson iteration to refine the reciprocal approximation produced by the PFRCP instruction or the reciprocal square-root approximation produced by the PFSQRT instruction. PFRCPIT2 takes two paired elements in each source operand. These paired elements are the results of a PFRCP and PFRCPIT1 instruction sequence or of a PFRSQRT and PFRSQIT1 instruction sequence. The first source/destination operand is an MMX register that contains the PFRCPIT1 or PFRSQIT1 results and the second source operand is another MMX register or 64-bit memory location that contains the PFRCP or PFRSQRT results.

The PFRCPIT2 instruction expands the compressed PFRCPIT1 or PFRSQIT1 results from 24 to 32 bits and multiplies them by their respective source operands. An optimal correction factor is added to the product, which is then rounded to 24 bits.

The estimate contains the correct round-to-nearest value for approximately 99% of all arguments. The remaining arguments differ from the correct round-to-nearest value for the reciprocal by 1 unit-in-the-last-place (ulp). For details, see the data sheet or other software-optimization documentation relating to particular hardware implementations.

The PFRCPIT2 instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

PFRCP

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFRCPIT2 mmx1, mmx2/mem64</td>
        <td>0F 0F /r<br/>B6</td>
        <td>Refines approximate reciprocal result from previous PFRCP and PFRCPIT1 instructions or from previous PFRSQRT and PFRSQIT1 instructions.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

PFRCPIT2

<page_number>121</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

Diagram showing the PFRCPIT2 operation logic between mmx1 and mmx2/mem64 registers.

## Operation

```
mmx1[31:0] = Expand(mmx1[31:0]) * mmx2/mem64[31:0];
mmx1[63:32] = Expand(mmx1[63:32]) * mmx2/mem64[63:32];
```

where:

“Expand” means convert a 24-bit significand to a 32-bit significand according to the following rule:

```
temp[31:0] = {1’b1, 8{mmx1[22]}, mmx1[22:0]};
```

## Examples

The general Newton-Raphson recurrence for the reciprocal 1/b is:

$$ Z_{i+1} \leftarrow Z_i \cdot (2 - b \cdot Z_i) $$

The following code sequence computes a 24-bit approximation to a/b with one Newton-Raphson iteration:

```
X0 = PFRCP(b)
X1 = PFRCPIT1(b, X0)
X2 = PFRCPIT2(X1, X0)
q = PFMUL(a, X2)
```

a/b is formed in the last step by multiplying the reciprocal approximation by a.

## Related Instructions

PFRCP, PFRCPIT1, PFRSQRT, PFRSQIT1

## rFLAGS Affected

None

<page_number>122</page_number>

PFRCPIT2
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

PFRCPIT2 [AMD Confidential - Distribution with NDA]

<page_number>123</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PFRSQIT1 Packed Floating-Point Reciprocal Square Root Iteration 1

Performs the first step in the Newton-Raphson iteration to refine the reciprocal square-root approximation produced by the PFSQRT instruction. The first source/destination operand is an MMX register containing the result from a previous PFRSQRT instruction, and the second source operand is another MMX register or 64-bit memory location containing the source operand from the same PFRSQRT instruction.

This instruction is only defined for those combinations of operands such that the first source operand (mmx1) is the approximate reciprocal of the second source operand (mmx2/mem64), and thus the range of the product, mmx1 * mmx2/mem64, is (0.5, 2). The length of both operands is 24 bits, so the product of these two operands is greater than 24 bits. The product is normalized and then rounded to 32 bits. The one's complement of the result is applied, a 1 is added as the most-significant bit, and the result re-normalized. The result is then compressed to fit into 24 bits by removing 8 redundant most-significant bits after the hidden integer bit, and the exponent is reduced by 1 to account for the division by 2.

The PFRSQIT1 instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

PFRSQRT

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFRSQIT1 mmx1, mmx2/mem64</td>
        <td>0F 0F /r A7</td>
        <td>Refines reciprocal square root approximation of previous PFRSQRT instruction.</td>
    </tr>
  </tbody>
</table>

<page_number>

124
</page_number>

PFRSQIT1 [AMD Confidential - Distribution with NDA]

64-Bit Media Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

Diagram showing the Newton-Raphson reciprocal square root step 1 operation between mmx1 and mmx2/mem64 registers.

## Operation

```
mmx1[31:0] = Compress ((3 - mmx1[31:0] * (mmx2/mem64[31:0]) - 2^31)/2);
mmx1[63:32] = Compress ((3 - mmx1[63:32] * (mmx2/mem64[63:32]) - 2^31)/2);
```

where:

“Compress” means discard the 8 redundant most-significant bits after the hidden integer bit.

## Examples

The following code sequence shows how the PFRSQRT and PFMUL instructions can be used to compute a = 1/sqrt (b):

```
X0 = PFRSQRT(b)
X1 = PFMUL(X0,X0)
X2 = PFRSQIT1(b,X1)
a = PFRCPIT2(X2,X0)
```

## Related Instructions

PFRCPIT2, PFRSQRT

## rFLAGS Affected

None

64-Bit Media
PFRSQIT1
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>125</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>126</page_number> PFRSQIT1 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PFRSQRT Packed Floating-Point Reciprocal Square Root Approximation

Computes the approximate reciprocal square root of the single-precision floating-point value in the low-order 32 bits of an MMX register or 64-bit memory location and writes the result in each doubleword of another MMX register. The source operand is single-precision with a 24-bit significand, and the result is accurate to 15 bits. Negative operands are treated as positive operands for purposes of reciprocal square-root computation, with the sign of the result the same as the sign of the source operand.

This instruction can be used together with the PFRSQIT1 and PFRCPIT2 instructions to increase accuracy. The first stage of this refinement in accuracy (PFRSQIT1) requires that the input and output of the previously executed PFRSQRT instruction be used as input to the PFRSQIT1 instruction.

The estimate contains the correct round-to-nearest value for approximately 99% of all arguments. The remaining arguments differ from the correct round-to-nearest value for the reciprocal by 1 unit-in-the-last-place (ulp). For details, see the data sheet or other software-optimization documentation relating to particular hardware implementations.

The PFRSQRT instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

The numeric range for operands is shown in Table 1-16 on page 128.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

RSQRTSS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFRSQRT mmx1, mmx2/mem64</td>
        <td>0F 0F /r 97</td>
        <td>Computes approximate reciprocal square root of a packed single-precision floating-point value.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference
PFRSQRT
[AMD Confidential - Distribution with NDA]
<page_number>

127
</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

Diagram showing mmx1 and mmx2/mem64 registers with bit ranges 63, 32 31, and 0, illustrating a reciprocal square root operation.

Table 1-16. Numeric Range for the PFRCP Result

<table>
  <thead>
    <tr>
        <th>Operand</th>
        <th colspan="2">Source 1 and Destination</th>
    </tr>
    <tr>
        <th rowspan="3">Source 2</th>
        <th>0</th>
        <th>+/– Maximum Normal<sup>1</sup></th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>Normal<sup>1</sup></th>
    </tr>
    <tr>
        <th>Unsupported<sup>2</sup></th>
        <th>Undefined<sup>1</sup></th>
    </tr>
  </thead>
</table>

Note:
1. The result has the same sign as the source operand.
2. "Unsupported" means that the exponent is all ones (1s).

## Examples

The following code sequence shows how the PFRSQRT and PFMUL instructions can be used to compute a = 1/sqrt (b):

```
X0 = PFRSQRT(b)
X1 = PFMUL(X0, X0)
X2 = PFRSQIT1(b, X1)
a = PFRCPIT2(X2, X0)
```

## Related Instructions

PFRCPIT2, PFRSQIT1

## rFLAGS Affected

None

<page_number>

128
</page_number>

PFRSQRT 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media

PFRSQRT

<page_number>129</page_number>

<mark>[AMD Confidential - Distribution with NDA]</mark>

Instruction Reference

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# PFSUB Packed Floating-Point Subtract

Subtracts each packed single-precision floating-point value in the second source operand from the corresponding packed single-precision floating-point value in the first source operand and writes the result of each subtraction in the corresponding doubleword of the destination (first source). The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location. The numeric range for operands is shown in Table 1-17 on page 131.

The PFSUB instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

SUBPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFSUB mmx1, mmx2/mem64</td>
        <td>0F 0F /r 9A</td>
        <td>Subtracts packed single-precision floating-point values in an MMX register or 64-bit memory location from packed single-precision floating-point values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the subtraction of packed single-precision floating-point values from mmx2/mem64 from mmx1, with results stored back in mmx1.

<page_number>130</page_number>

PFSUB 64-Bit Media Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Table 1-17. Numeric Range for the PFSUB Results

<table>
  <thead>
    <tr>
        <th colspan="5">Source Operand</th>
    </tr>
    <tr>
        <th> </th>
        <th colspan="4">Source 2</th>
    </tr>
    <tr>
        <th>Source 1 and Destination</th>
        <th>0</th>
        <th>Normal</th>
        <th colspan="2">Unsupported</th>
    </tr>
    <tr>
        <th rowspan="3">Source 1 and Destination</th>
        <th>0</th>
        <th>+/- 0<sup>1</sup></th>
        <th>- Source 2</th>
        <th>- Source 2</th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>Source 1</th>
        <th>Normal, +/- 0<sup>2</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Unsupported<sup>3</sup></th>
        <th>Source 1</th>
        <th>Undefined</th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

**Note:**

1. The sign of the result is the logical AND of the sign of source 1 and the inverse of the sign of source 2.

2. If the absolute value of the infinitely precise result is less than 2<sup>–126</sup> (but not zero), the result is a zero. If the source operand that is larger in magnitude is source 1, the sign of this zero is the same as the sign of source 1, else it is the inverse of the sign of source 2. If the infinitely precise result is exactly zero, the result is zero with the sign of source 1. If the absolute value of the infinitely precise result is greater than or equal to 2<sup>128</sup>, the result is the largest normal number with the sign of source 1.

3. “Unsupported” means that the exponent is all ones (1s).

## Related Instructions

PFSUBR

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference
[AMD Confidential PFSUB Distribution with NDA]

<page_number>131</page_number>

AMDA

AMD64 Technology 26569—Rev. 3.16—November 2021

# PFSUBR Packed Floating-Point Subtract Reverse

Subtracts each packed single-precision floating-point value in the first source operand from the corresponding packed single-precision floating-point value in the second source operand and writes the result of each subtraction in the corresponding dword of the destination (first source). The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location. The numeric range for operands is shown in Table 1-18 on page 133.

The PFSUBR instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

SUBPS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PFSUBR mmx1, mmx2/mem64</td>
        <td>0F 0F /r AA</td>
        <td>Subtracts packed single-precision floating-point values in an MMX register from packed single-precision floating-point values in another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PFSUBR operation: subtracting packed single-precision floating-point values from mmx2/mem64 and mmx1, and storing the result in mmx1.

<page_number>

132
</page_number>

PFSUBR 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

Table 1-18. Numeric Range for the PFSUBR Results

<table>
  <thead>
    <tr>
        <th rowspan="2">Source Operand</th>
        <th colspan="4">Source 2</th>
    </tr>
    <tr>
        <th>0</th>
        <th>Normal</th>
        <th colspan="2">Unsupported</th>
    </tr>
    <tr>
        <th rowspan="3">Source 1 and Destination</th>
        <th>0</th>
        <th>+/- 0<sup>1</sup></th>
        <th>Source 2</th>
        <th>Source 2</th>
    </tr>
    <tr>
        <th>Normal</th>
        <th>- Source 1</th>
        <th>Normal, +/- 0<sup>2</sup></th>
        <th>Undefined</th>
    </tr>
    <tr>
        <th>Unsupported<sup>3</sup></th>
        <th>- Source 1</th>
        <th>Undefined</th>
        <th>Undefined</th>
    </tr>
  </thead>
</table>

Note:

1. The sign is the logical AND of the sign of source 2 and the inverse of the sign of source 1.

2. If the absolute value of the infinitely precise result is less than 2<sup>-126</sup> (but not zero), the result is a zero. If the source operand that is larger in magnitude is source 2, the sign of this zero is the same as the sign of source 2, else it is the inverse of the sign of source 1. If the infinitely precise result is exactly zero, the result is zero with the sign of source 2. If the absolute value of the infinitely precise result is greater than or equal to 2<sup>128</sup>, the result is the largest normal number with the sign of source 2.

3. "Unsupported" means that the exponent is all ones (1s).

## Related Instructions

PFSUB

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by ECPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

PFSUBR
[AMD Confidential - Distribution with NDA]

<page_number>133</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PI2FD

# Packed Integer to Floating-Point Doubleword Conversion

Converts two packed 32-bit signed integer values in an MMX register or a 64-bit memory location to two packed single-precision floating-point values and writes the converted values in another MMX register. If the result of the conversion is an inexact value, the value is truncated (rounded toward zero).

The PI2FD instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

AMD no longer recommends the use of 3DNow! instructions, which have been superceded by their more efficient 128-bit media counterparts. For a complete list of recommended instruction substitutions, see Appendix A, “Recommended Substitutions for 3DNow!™ Instructions” on page 333.

## Recommended Instruction Substitution

CVTDQ2PS

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PI2FD mmx1, mmx2/mem64</td>
        <td>0F 0F /r 0D</td>
        <td>Converts packed doubleword integers in an MMX register or 64-bit memory location to single-precision floating-point values in the destination MMX register. Inexact results are truncated.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two 32-bit integers from mmx2/mem64 to single-precision floating-point values in mmx1.

## Related Instructions

PF2ID, PF2IW, PI2FW

## rFLAGS Affected

None

<page_number>

134
</page_number>

PI2FD 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD 3DNow!™ instructions are not supported, as indicated by CPUID Fn8000_0001_EDX[3DNow] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential PI2FD Instruction Reference - Distribution with NDA]
Instruction Reference
<page_number>135</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PI2FW Packed Integer to Floating-Point Word Conversion

Converts two packed 16-bit signed integer values in an MMX register or a 64-bit memory location to two packed single-precision floating-point values and writes the converted values in another MMX register.

The PI2FW instruction is an extension to the AMD 3DNow!™ instruction set. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PI2FW mmx1, mmx2/mem64</td>
        <td>0F 0F /r 0C</td>
        <td>Converts packed 16-bit integers in an MMX register or 64-bit memory location to packed single-precision floating-point values in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the conversion of two 16-bit integers from mmx2/mem64 (bits 15:0 and 31:16) into two single-precision floating-point values in mmx1 (bits 31:0 and 63:32).

## Related Instructions

PF2ID, PF2IW, PI2FD

<page_number>

136
</page_number>

PI2FW 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD extensions to 3DNow!™ are not supported,<br/>as indicated by<br/>CPUID Fn8000_0001_EDX[3DNowExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit<br/>or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or<br/>was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the<br/>instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was<br/>pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while<br/>alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

[AMD Confidential - Distribution with NDA]

<page_number>137</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PINSRW Packed Insert Word

Inserts a 16-bit value from the low-order word of a 32-bit general purpose register or a 16-bit memory location into an MMX register. The location in the destination register is selected by the immediate byte operand, a shown in Table 1-19. The other words in the destination register operand are not modified.

The PINSRW instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PINSRW mmx, reg32/mem16, imm8</td>
        <td>0F C4 /r ib</td>
        <td>Inserts a 16-bit value from a general-purpose register or memory location into an MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the insertion of a 16-bit value from a general-purpose register or memory location into an MMX register based on an immediate byte operand.

Table 1-19. Immediate-Byte Operand Encoding for 64-Bit PINSRW

<table>
  <thead>
    <tr>
        <th>Immediate-Byte Bit Field</th>
        <th>Value of Bit Field</th>
        <th>Destination Bits Filled</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="4">1–0</td>
        <td>0</td>
        <td>15–0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>31–16</td>
    </tr>
    <tr>
        <td>2</td>
        <td>47–32</td>
    </tr>
    <tr>
        <td>3</td>
        <td>63–48</td>
    </tr>
  </tbody>
</table>

## Related Instructions

PEXTRW

## rFLAGS Affected

None

<page_number>138</page_number>

PINSRW [AMD Confidential - Distribution with NDA]

64-Bit Media Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference
**PINSRW**
[AMD Confidential - Distribution with NDA]

<page_number>139</page_number>

AMD
AMD64 Technology 26569—Rev. 3.16—November 2021

# PMADDWD Packed Multiply Words and Add Doublewords

Multiplies each packed 16-bit signed value in the first source operand by the corresponding packed 16-bit signed value in the second source operand, adds the adjacent intermediate 32-bit results of each multiplication (for example, the multiplication results for the adjacent bit fields 63–48 and 47–32, and 31–16 and 15–0), and writes the 32-bit result of each addition in the corresponding doubleword of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

If all four of the 16-bit source operands used to produce a 32-bit multiply-add result have the value 8000h, the 32-bit result is 8000_0000h, which is not the correct 32-bit signed result.

The PMADDWD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMADDWD mmx1, mmx2/mem64</td>
        <td>0F F5 /r</td>
        <td>Multiplies four packed 16-bit signed values in an MMX register and another MMX register or 64-bit memory location, adds intermediate results, and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PMADDWD operation: four 16-bit multiplications from two 64-bit source operands (mmx1 and mmx2/mem64) followed by two 32-bit additions to produce two 32-bit results in the destination register.

## Related Instructions

PMULHUW, PMULHW, PMULLW, PMULUDQ

## rFLAGS Affected

<page_number>140</page_number> PMADDWD 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PMADDWD** <page_number>141</page_number>
<mark>[AMD Confidential - Distribution with NDA]</mark>
Instruction Reference

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PMAXSW

# Packed Maximum Signed Words

Compares each of the packed 16-bit signed integer values in the first source operand with the corresponding packed 16-bit signed integer value in the second source operand and writes the maximum of the two values for each comparison in the corresponding word of the destination (first source). The first source/destination and second source operands are an MMX register and an MMX register or 64-bit memory location.

The PMAXSW instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMAXSW mmx1, mmx2/mem64</td>
        <td>0F EE /r</td>
        <td>Compares packed signed 16-bit integer values in an MMX register and another MMX register or 64-bit memory location and writes the maximum value of each compare in destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PMAXSW operation on 64-bit MMX registers, comparing four 16-bit signed words and storing the maximums in the destination register.

## Related Instructions

PMAXUB, PMINSW, PMINUB

## rFLAGS Affected

None

<page_number>

142
</page_number>

[AMD Confidential - Distribution with NDA]

PMAXSW 64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PMAXSW** <page_number>143</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PMAXUB Packed Maximum Unsigned Bytes

Compares each of the packed 8-bit unsigned integer values in the first source operand with the corresponding packed 8-bit unsigned integer value in the second source operand and writes the maximum of the two values for each comparison in the corresponding byte of the destination (first source). The first source/destination and second source operands are an MMX register and an MMX register or 64-bit memory location.

The PMAXUB instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMAXUB mmx1, mmx2/mem64</td>
        <td>0F DE /r</td>
        <td>Compares packed unsigned 8-bit integer values in an MMX register and another MMX register or 64-bit memory location and writes the maximum value of each compare in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PMAXUB operation on 64-bit MMX registers, comparing packed 8-bit unsigned bytes and storing the maximum values in the destination register.

## Related Instructions

PMAXSW, PMINSW, PMINUB

## rFLAGS Affected

None

<page_number>

144
</page_number>

PMAXUB [AMD Confidential - Distribution with NDA]

64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PMAXUB** <page_number>145</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PMINSW

# Packed Minimum Signed Words

Compares each of the packed 16-bit signed integer values in the first source operand with the corresponding packed 16-bit signed integer value in the second source operand and writes the minimum of the two values for each comparison in the corresponding word of the destination (first source). The first source/destination and second source operands are an MMX register and an MMX register or 64-bit memory location.

The PMINSW instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMINSW mmx1, mmx2/mem64</td>
        <td>0F EA /r</td>
        <td>Compares packed signed 16-bit integer values in an MMX register and another MMX register or 64-bit memory location and writes the minimum value of each compare in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PMINSW operation on 64-bit MMX registers, comparing four 16-bit signed words and storing the minimums in the destination register.

## Related Instructions

PMAXSW, PMAXUB, PMINUB

## rFLAGS Affected

None

<page_number>

146
</page_number>

[AMD Confidential - Distribution with NDA]

PMINSW

64-Bit Media
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as<br/>indicated by CPUID Fn0000_0001_EDX[SSE] = 0<br/>and the AMD extensions to the MMX™ instruction set<br/>are not supported, as indicated by CPUID<br/>Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit<br/>or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or<br/>was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the<br/>instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was<br/>pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while<br/>alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media**
**PMINSW**
**Instruction Reference**
<mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>147</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PMINUB

# Packed Minimum Unsigned Bytes

Compares each of the packed 8-bit unsigned integer values in the first source operand with the corresponding packed 8-bit unsigned integer value in the second source operand and writes the minimum of the two values for each comparison in the corresponding byte of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PMINUB instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMINUB mmx1, mmx2/mem64</td>
        <td>0F DA /r</td>
        <td>Compares packed unsigned 8-bit integer values in an MMX register and another MMX register or 64-bit memory location and writes the minimum value of each comparison in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PMINUB operation comparing 8-bit unsigned bytes from mmx1 and mmx2/mem64 and storing the minimum values back into mmx1.

## Related Instructions

PMAXSW, PMAXUB, PMINSW

## rFLAGS Affected

None

<page_number>

148
</page_number>

[AMD Confidential - Distribution with NDA]
**PMINUB**
**64-Bit Media**
**Instruction Reference**

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media**
**Instruction Reference**
**PMINUB**
[AMD Confidential - Distribution with NDA]

<page_number>149</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PMOVMSKB Packed Move Mask Byte

Moves the most-significant bit of each byte in the source operand in bitwise order to the low order byte of the destination operand. The upper 24 bits of the destination operand are cleared to zeros. The destination operand is a 32-bit general-purpose register and the source operand is an MMX register.

The PMOVMSKB instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMOVMSKB reg32, mmx</td>
        <td>0F D7 /r</td>
        <td>Moves most-significant bit of each byte in an MMX register to the low-order byte of a 32-bit general-purpose register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the operation of PMOVMSKB: copying the most-significant bit of each of the 8 bytes in an MMX register (mmx) to the low-order byte (bits 0-7) of a 32-bit general-purpose register (reg32), with the upper 24 bits of reg32 cleared to zero.

## Related Instructions

MOVMSKPD, MOVMSKPS

## rFLAGS Affected

None

<page_number>

150
</page_number>

PMOVMSKB 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PMOVMSKB <page_number>151</page_number>

[AMD Confidential - Distribution with NDA]

Instruction Reference

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PMULHRW

# Packed Multiply High Rounded Word

Multiplies each of the four packed 16-bit signed integer values in the first source operand by the corresponding packed 16-bit integer value in the second source operand, adds 8000h to the lower 16 bits of the intermediate 32-bit result of each multiplication, and writes the high-order 16 bits of each result in the corresponding word of the destination (first source). The addition of 8000h results in the rounding of the result, providing a numerically more accurate result than the PMULHW instruction, which truncates the result. The first source/destination operand is an MMX register. The second source operand is another MMX register or 64-bit memory location.

The PMULHRW instruction is an AMD 3DNow!™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See "CPUID" in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMULHRW mmx1, mmx2/mem64</td>
        <td>0F 0F /r B7</td>
        <td>Multiply 16-bit signed integer values in an MMX register and another MMX register or 64-bit memory location and write rounded result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PMULHRW operation on MMX registers mmx1 and mmx2/mem64, illustrating the multiplication and rounding of 16-bit words.

## Related Instructions

None

## rFLAGS Affected

None

<page_number>

152
</page_number>

PMULHRW

64-Bit Media

Instruction Reference

26569—Rev. 3.16—November 2021

AMD64 Technology

AMD logo

## Exceptions

<table>
  <thead>
    <tr>
<th>Exception</th>
<th>Real</th>
<th>Virtual<br/>8086</th>
<th>Protected</th>
<th>Cause of Exception</th>
    </tr>
    <tr>
<th rowspan="2">Invalid opcode, #UD</th>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The emulate bit (EM) of CR0 was set to 1.</th>
    </tr>
    <tr>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The AMD 3DNow!™ instructions are not supported,<br/>as indicated by CPUID Fn8000_0001_EDX[3DNow] =<br/>0.</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<td>Device not available,<br/>#NM</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
<td>Stack, #SS</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded the stack segment limit<br/>or was non-canonical.</td>
    </tr>
    <tr>
<td rowspan="2">General protection, #GP</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded a data segment limit or<br/>was non-canonical.</td>
    </tr>
    <tr>
<td> </td>
<td>X</td>
<td>A null data segment was used to reference memory.</td>
<td></td>
    </tr>
    <tr>
<td>Page fault, #PF</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>A page fault resulted from the execution of the<br/>instruction.</td>
    </tr>
    <tr>
<td>x87 floating-point<br/>exception pending, #MF</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>An unmasked x87 floating-point exception was<br/>pending.</td>
    </tr>
    <tr>
<td>Alignment check, #AC</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>An unaligned memory reference was performed while<br/>alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media**
**PMULHRW**
<mark>[AMD Confidential - Distribution with NDA]</mark>
**Instruction Reference**

<page_number>153</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# PMULHUW Packed Multiply High Unsigned Word

Multiplies each packed unsigned 16-bit values in the first source operand by the corresponding packed unsigned word in the second source operand and writes the high-order 16 bits of each intermediate 32-bit result in the corresponding word of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PMULHUW instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See "CPUID" in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMULHUW mmx1, mmx2/mem64</td>
        <td>0F E4 /r</td>
        <td>Multiplies packed 16-bit values in an MMX register by the packed 16-bit values in another MMX register or 64-bit memory location and writes the high-order 16 bits of each result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PMULHUW operation on 64-bit MMX registers, multiplying packed 16-bit words and storing the high-order 16 bits of the results.

## Related Instructions

PMADDWD, PMULHW, PMULLW, PMULUDQ

## rFLAGS Affected

None

<page_number>154</page_number>

PMULHUW
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

26569—Rev. 3.16—November 2021

AMD64 Technology

AMD logo



# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
**PMULHUW**
Instruction Reference
[AMD Confidential - Distribution with NDA]

<page_number>155</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PMULHW Packed Multiply High Signed Word

Multiplies each packed 16-bit signed integer value in the first source operand by the corresponding packed 16-bit signed integer in the second source operand and writes the high-order 16 bits of the intermediate 32-bit result of each multiplication in the corresponding word of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PMULHW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMULHW mmx1, mmx2/mem64</td>
        <td>0F E5 /r</td>
        <td>Multiplies packed 16-bit signed integer values in an MMX register and another MMX register or 64-bit memory location and writes the high-order 16 bits of each result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the multiplication of packed 16-bit signed integers from mmx1 and mmx2/mem64, with the high-order 16 bits of the results written back to mmx1.

## Related Instructions

PMADDWD, PMULHUW, PMULLW, PMULUDQ

## rFLAGS Affected

None

<page_number>

156
</page_number>

PMULHW 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media **PMULHW**

[AMD Confidential - Distribution with NDA]

Instruction Reference

<page_number>157</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# PMULLW

# Packed Multiply Low Signed Word

Multiplies each packed 16-bit signed integer value in the first source operand by the corresponding packed 16-bit signed integer in the second source operand and writes the low-order 16 bits of the intermediate 32-bit result of each multiplication in the corresponding word of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PMULLW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMULLW mmx1, mmx2/mem64</td>
        <td>0F D5 /r</td>
        <td>Multiplies packed 16-bit signed integer values in an MMX register and another MMX register or 64-bit memory location and writes the low-order 16 bits of each result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PMULLW operation where 16-bit signed integers from mmx1 and mmx2/mem64 are multiplied, and the low-order 16 bits of the results are written back to mmx1.

## Related Instructions

PMADDWD, PMULHUW, PMULHW, PMULUDQ

## rFLAGS Affected

None

<page_number>

158
</page_number>

PMULLW 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media
Instruction Reference

PMULLW
[AMD Confidential - Distribution with NDA]

<page_number>159</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PMULUDQ Packed Multiply Unsigned Doubleword and Store Quadword

Multiplies two 32-bit unsigned integer values in the low-order doubleword of the first and second source operands and writes the 64-bit result in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PMULUDQ instruction is an SSE2 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PMULUDQ mmx1, mmx2/mem64</td>
        <td>0F F4 /r</td>
        <td>Multiplies low-order 32-bit unsigned integer value in an MMX register and another MMX register or 64-bit memory location and writes the 64-bit result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph mmx1
        m1_high[63 ... 32]
        m1_low[31 ... 0]
    end
    subgraph mmx2_mem64
        m2_high[63 ... 32]
        m2_low[31 ... 0]
    end
    m1_low --> mult[multiply]
    m2_low --> mult
    mult --> mmx1_result[63 ... 0]
    style m1_high fill:#e0e0e0
    style m2_high fill:#e0e0e0
```
pmuludq-64.eps

## Related Instructions

PMADDWD, PMULHUW, PMULHW, PMULLW

## rFLAGS Affected

None

<page_number>

160
</page_number>

PMULUDQ 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

**64-Bit Media PMULUDQ** <mark>[AMD Confidential - Distribution with NDA]</mark> **161**
Instruction Reference
<page_number>161</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# POR Packed Logical Bitwise OR

Performs a bitwise logical OR of the values in the first and second source operands and writes the result in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The POR instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>POR mmx1, mmx2/mem64</td>
        <td>0F EB /r</td>
        <td>Performs bitwise logical OR of values in an MMX register and in another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing bitwise OR operation between mmx1 and mmx2/mem64 registers

## Related Instructions

PAND, PANDN, PXOR

## rFLAGS Affected

None

<page_number>

162
</page_number>

POR 64-Bit Media [AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021 AMD64 Technology AMD

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media [AMD Confidential - POR Distribution with NDA] 163
Instruction Reference

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# PSADBW Packed Sum of Absolute Differences of Bytes Into a Word

Computes the absolute differences of eight corresponding packed 8-bit unsigned integers in the first and second source operands and writes the unsigned 16-bit integer result of the sum of the eight differences in a word in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location. The result is stored in the low-order word of the destination operand, and the remaining bytes in the destination are cleared to all 0s.

The PSADBW instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSADBW mmx1, mmx2/mem64</td>
        <td>0F F6 /r</td>
        <td>Compute the sum of the absolute differences of packed 8-bit unsigned integer values in an MMX register and another MMX register or 64-bit memory location and writes the 16-bit unsigned integer result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSADBW operation: eight 8-bit unsigned integers from mmx1 and mmx2/mem64 are compared to find absolute differences, which are then added together to form a 16-bit result stored in the low word of the destination register.

## rFLAGS Affected

None

<page_number>164</page_number>

PSADBW [AMD Confidential - Distribution with NDA]

64-Bit Media Instruction Reference

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

64-Bit Media PSADBW 165
<mark>[AMD Confidential - Distribution with NDA]</mark>
Instruction Reference

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# PSHUFW Packed Shuffle Words

Moves any one of the four packed words in an MMX register or 64-bit memory location to a specified word location in another MMX register. In each case, the selection of the value of the destination word is determined by a two-bit field in the immediate-byte operand, with bits 0 and 1 selecting the contents of the low-order word, bits 2 and 3 selecting the second word, bits 4 and 5 selecting the third word, and bits 6 and 7 selecting the high-order word. Refer to Table 1-20 on page 167. A word in the source operand may be copied to more than one word in the destination.

The PSHUFW instruction is an AMD extension to MMX™ instruction set and is an SSE1 instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSHUFW mmx1, mmx2/mem64, imm8</td>
        <td>0F 70 /r ib</td>
        <td>Shuffles packed 16-bit values in an MMX register or 64-bit memory location and puts the result in another MMX register.</td>
    </tr>
  </tbody>
</table>

Engineering drawing showing the PSHUFW instruction logic, mapping source words from mmx2/mem64 to destination words in mmx1 based on the imm8 control byte.

<page_number>

166
</page_number>

PSHUFW 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# Table 1-20. Immediate-Byte Operand Encoding for PSHUFW

<table>
  <thead>
    <tr>
        <th>Destination Bits Filled</th>
        <th>Immediate-Byte Bit Field</th>
        <th>Value of Bit Field</th>
        <th>Source Bits Moved</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="4">15–0</td>
        <td rowspan="4">1–0</td>
        <td>0</td>
        <td>15–0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>31–16</td>
    </tr>
    <tr>
        <td>2</td>
        <td>47–32</td>
    </tr>
    <tr>
        <td>3</td>
        <td>63–48</td>
    </tr>
    <tr>
        <td rowspan="4">31–16</td>
        <td rowspan="4">3–2</td>
        <td>0</td>
        <td>15–0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>31–16</td>
    </tr>
    <tr>
        <td>2</td>
        <td>47–32</td>
    </tr>
    <tr>
        <td>3</td>
        <td>63–48</td>
    </tr>
    <tr>
        <td rowspan="4">47–32</td>
        <td rowspan="4">5–4</td>
        <td>0</td>
        <td>15–0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>31–16</td>
    </tr>
    <tr>
        <td>2</td>
        <td>47–32</td>
    </tr>
    <tr>
        <td>3</td>
        <td>63–48</td>
    </tr>
    <tr>
        <td rowspan="4">63–48</td>
        <td rowspan="4">7–6</td>
        <td>0</td>
        <td>15–0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>31–16</td>
    </tr>
    <tr>
        <td>2</td>
        <td>47–32</td>
    </tr>
    <tr>
        <td>3</td>
        <td>63–48</td>
    </tr>
  </tbody>
</table>

## Related Instructions

PSHUFD, PSHUFHW, PSHUFLW

## rFLAGS Affected

None

64-Bit Media PSHUFW
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>167</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE1 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE] = 0 and the AMD extensions to the MMX™ instruction set are not supported, as indicated by CPUID Fn8000_0001_EDX[MmxExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>168</page_number> **PSHUFW** 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSLLD

# Packed Shift Left Logical Doublewords

Left-shifts each of the packed 32-bit values in the first source operand by the number of bits specified in the second source operand and writes each shifted value in the corresponding doubleword of the destination (first source). The first source/destination and second source operands are:

*   an MMX register and another MMX register or 64-bit memory location, or

*   an MMX register and an immediate byte value.

The low-order bits that are emptied by the shift operation are cleared to 0. If the shift value is greater than 31, the destination is cleared to all 0s.

The PSLLD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSLLD mmx1, mmx2/mem64</td>
        <td>0F F2 /r</td>
        <td>Left-shifts packed doublewords in an MMX register by the amount specified in an MMX register or 64-bit memory location.</td>
    </tr>
    <tr>
        <td>PSLLD mmx, imm8</td>
        <td>0F 72 /6 ib</td>
        <td>Left-shifts packed doublewords in an MMX register by the amount specified in an immediate byte value.</td>
    </tr>
  </tbody>
</table>

Diagram showing PSLLD operation for MMX register with another MMX register/memory location and with an immediate byte value.

## Related Instructions

PSLLDQ, PSLLQ, PSLLW, PSRAD, PSRAW, PSRLD, PSRLDQ, PSRLQ, PSRLW

64-Bit Media [AMD Confidential PSLLD Instruction Reference - Distribution with NDA]

<page_number>169</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

170
</page_number>

[AMD Confidential - Distribution with NDA]

PSLLD 64-Bit Media Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# PSLLQ

# Packed Shift Left Logical Quadwords

Left-shifts each 64-bit value in the first source operand by the number of bits specified in the second source operand and writes each shifted value in the corresponding quadword of the destination (first source). The first source/destination and second source operands are:

* an MMX register and another MMX register or 64-bit memory location, or

* an MMX register and an immediate byte value.

The low-order bits that are emptied by the shift operation are cleared to 0. If the shift value is greater than 63, the destination is cleared to all 0s.

The PSLLQ instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSLLQ mmx1, mmx2/mem64</td>
        <td>0F F3 /r</td>
        <td>Left-shifts quadword in an MMX register by the amount specified in an MMX register or 64-bit memory location.</td>
    </tr>
    <tr>
        <td>PSLLQ mmx, imm8</td>
        <td>0F 73 /6 ib</td>
        <td>Left-shifts quadword in an MMX register by the amount specified in an immediate byte value.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSLLQ operation for both register/memory and immediate operands. The first part shows mmx2/mem64 providing the shift amount to mmx1. The second part shows an imm8 immediate value providing the shift amount to mmx.

## Related Instructions

PSLLD, PSLLDQ, PSLLW, PSRAD, PSRAW, PSRLD, PSRLDQ, PSRLQ, PSRLW

## rFLAGS Affected

None

64-Bit Media [AMD Confidential PSLLQ Instruction Reference - Distribution with NDA]

<page_number>171</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

172
</page_number>

[AMD Confidential - Distribution with NDA] **PSLLQ**

**64-Bit Media Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSLLW

# Packed Shift Left Logical Words

Left-shifts each of the packed 16-bit values in the first source operand by the number of bits specified in the second source operand and writes each shifted value in the corresponding word of the destination (first source). The first source/destination and second source operands are:

* an MMX register and another MMX register or 64-bit memory location, or

* an MMX register and an immediate byte value.

The low-order bits that are emptied by the shift operation are cleared to 0. If the shift value is greater than 15, the destination is cleared to all 0s.

The PSLLW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSLLW mmx1, mmx2/mem64</td>
        <td>0F F1 /r</td>
        <td>Left-shifts packed words in an MMX register by the amount specified in an MMX register or 64-bit memory location.</td>
    </tr>
    <tr>
        <td>PSLLW mmx, imm8</td>
        <td>0F 71 /6 ib</td>
        <td>Left-shifts packed words in an MMX register by the amount specified in an immediate byte value.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSLLW operation for both register/memory and immediate operands. The first diagram shows mmx1 being shifted by the value in mmx2/mem64. The second diagram shows mmx being shifted by the value in imm8.

## Related Instructions

PSLLD, PSLLDQ, PSLLQ, PSRAD, PSRAW, PSRLD, PSRLDQ, PSRLQ, PSRLW

64-Bit Media [AMD Confidential PSLLW Instruction Reference - Distribution with NDA]

<page_number>173</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# rFLAGS Affected

None

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th> </th>
        <th>Virtual</th>
        <th> </th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>Real</th>
        <th>8086</th>
        <th>Protected</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

174
</page_number>

PSLLW
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSRAD Packed Shift Right Arithmetic Doublewords

Right-shifts each of the packed 32-bit values in the first source operand by the number of bits specified in the second source operand and writes each shifted value in the corresponding doubleword of the destination (first source). The first source/destination and second source operands are:

* an MMX register and another MMX register or 64-bit memory location, or

* an MMX register and an immediate byte value.

The high-order bits that are emptied by the shift operation are filled with the sign bit of the doubleword’s initial value. If the shift value is greater than 31, each doubleword in the destination is filled with the sign bit of the doubleword’s initial value.

The PSRAD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSRAD mmx1, mmx2/mem64</td>
        <td>0F E2 /r</td>
        <td>Right-shifts packed doublewords in an MMX register by the amount specified in an MMX register or 64-bit memory location.</td>
    </tr>
    <tr>
        <td>PSRAD mmx, imm8</td>
        <td>0F 72 /4 ib</td>
        <td>Right-shifts packed doublewords in an MMX register by the amount specified in an immediate byte value.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSRAD operation for both register/memory and immediate operands. The first diagram shows mmx1 being shifted by the value in mmx2/mem64. The second diagram shows mmx being shifted by the value in imm8.

64-Bit Media [AMD Confidential PSRAD Instruction Reference - Distribution with NDA]
Instruction Reference

<page_number>175</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Related Instructions

PSLLD, PSLLDQ, PSLLQ, PSLLW, PSRAW, PSRLD, PSRLDQ, PSRLQ, PSRLW

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>X</th>
        <th>X</th>
        <th>X</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

176
</page_number>

PSRAD 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSRAW Packed Shift Right Arithmetic Words

Right-shifts each of the packed 16-bit values in the first source operand by the number of bits specified in the second source operand and writes each shifted value in the corresponding word of the destination (first source). The first source/destination and second source operands are:

*   an MMX register and another MMX register or 64-bit memory location, or

*   an MMX register and an immediate byte value.

The high-order bits that are emptied by the shift operation are filled with the sign bit of the word’s initial value. If the shift value is greater than 15, each word in the destination is filled with the sign bit of the word’s initial value.

The PSRAW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSRAW mmx1, mmx2/mem64</td>
        <td>0F E1 /r</td>
        <td>Right-shifts packed words in an MMX register by the amount specified in an MMX register or 64-bit memory location.</td>
    </tr>
    <tr>
        <td>PSRAW mmx, imm8</td>
        <td>0F 71 /4 ib</td>
        <td>Right-shifts packed words in an MMX register by the amount specified in an immediate byte value.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSRAW operation for both register/memory and immediate operands.

64-Bit Media [AMD Confidential PSRAW Instruction Reference - Distribution with NDA]

<page_number>177</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Related Instructions

PSLLD, PSLLDQ, PSLLQ, PSLLW, PSRAD, PSRLD, PSRLDQ, PSRLQ, PSRLW

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>178</page_number>

PSRAW
[AMD Confidential - Distribution with NDA]
64-Bit Media Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSRLD Packed Shift Right Logical Doublewords

Right-shifts each of the packed 32-bit values in the first source operand by the number of bits specified in the second source operand and writes each shifted value in the corresponding doubleword of the destination (first source). The first source/destination and second source operands are:

*   an MMX register and another MMX register or 64-bit memory location, or

*   an MMX register and an immediate byte value.

The high-order bits that are emptied by the shift operation are cleared to 0. If the shift value is greater than 31, the destination is cleared to 0.

The PSRLD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSRLD mmx1, mmx2/mem64</td>
        <td>0F D2 /r</td>
        <td>Right-shifts packed doublewords in an MMX register by the amount specified in an MMX register or 64-bit memory location.</td>
    </tr>
    <tr>
        <td>PSRLD mmx, imm8</td>
        <td>0F 72 /2 ib</td>
        <td>Right-shifts packed doublewords in an MMX register by the amount specified in an immediate byte value.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSRLD operation for both register/memory and immediate operands. The first diagram shows mmx1 being shifted by the value in mmx2/mem64. The second diagram shows mmx being shifted by an immediate byte value (imm8).

64-Bit Media [AMD Confidential PSRLD Instruction Reference - Distribution with NDA]

<page_number>179</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Related Instructions

PSLLD, PSLLDQ, PSLLQ, PSLLW, PSRAD, PSRAW, PSRLDQ, PSRLQ, PSRLW

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

180
</page_number>

[AMD Confidential - Distribution with NDA]

PSRLD 64-Bit Media
Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# PSRLQ Packed Shift Right Logical Quadwords

Right-shifts each 64-bit value in the first source operand by the number of bits specified in the second source operand and writes each shifted value in the corresponding quadword of the destination (first source). The first source/destination and second source operands are:

*   an MMX register and another MMX register or 64-bit memory location, or

*   an MMX register and an immediate byte value.

The high-order bits that are emptied by the shift operation are cleared to 0. If the shift value is greater than 63, the destination is cleared to 0.

The PSRLQ instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSRLQ mmx1, mmx2/mem64</td>
        <td>0F D3 /r</td>
        <td>Right-shifts quadword in an MMX register by the amount specified in an MMX register or 64-bit memory location.</td>
    </tr>
    <tr>
        <td>PSRLQ mmx, imm8</td>
        <td>0F 73 /2 ib</td>
        <td>Right-shifts quadword in an MMX register by the amount specified in an immediate byte value.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph PSRLQ_Register_Shift
        mmx1[mmx1]
        mmx2[mmx2/mem64]
        mmx2 -->|shift amount| shift1[shift right]
        mmx1 --> shift1
        shift1 --> mmx1
    end

    subgraph PSRLQ_Immediate_Shift
        mmx[mmx]
        imm8[imm8]
        imm8 -->|shift amount| shift2[shift right]
        mmx --> shift2
        shift2 --> mmx
    end
```
Diagram showing PSRLQ shift operations for register/memory and immediate operands

## Related Instructions

PSLLD, PSLLDQ, PSLLQ, PSLLW, PSRAD, PSRAW, PSRLD, PSRLDQ, PSRLW

64-Bit Media [AMD Confidential PSRLQ Distribution with NDA]
Instruction Reference

<page_number>181</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>182</page_number>

PSRLQ 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSRLW

# Packed Shift Right Logical Words

Right-shifts each of the packed 16-bit values in the first source operand by the number of bits specified in the second operand and writes each shifted value in the corresponding word of the destination (first source). The first source/destination and second source operands are:

*   an MMX register and another MMX register or 64-bit memory location, or

*   an MMX register and an immediate byte value.

The high-order bits that are emptied by the shift operation are cleared to 0. If the shift value is greater than 15, the destination is cleared to 0.

The PSRLW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSRLW mmx1, mmx2/mem64</td>
        <td>0F D1 /r</td>
        <td>Right-shifts packed words in an MMX register by the amount specified in an MMX register or 64-bit memory location.</td>
    </tr>
    <tr>
        <td>PSRLW mmx, imm8</td>
        <td>0F 71 /2 ib</td>
        <td>Right-shifts packed words in an MMX register by the amount specified in an immediate byte value.</td>
    </tr>
  </tbody>
</table>

Diagram showing PSRLW operation with mmx1 and mmx2/mem64 operands. The mmx1 register is divided into four 16-bit words (bits 0-15, 16-31, 32-47, 48-63). The mmx2/mem64 operand provides the shift count for each word.

Diagram showing PSRLW operation with mmx and imm8 operands. The mmx register is divided into four 16-bit words. The imm8 immediate value (bits 0-7) provides the shift count for all words.

64-Bit Media [AMD Confidential PSRLW Distribution with NDA]
Instruction Reference

<page_number>183</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Related Instructions

PSLLD, PSLLDQ, PSLLQ, PSLLW, PSRAD, PSRAW, PSRLD, PSRLDQ, PSRLQ

## rFLAGS Affected

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>184</page_number>

[AMD Confidential - Distribution with NDA]

PSRLW

64-Bit Media Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSUBB Packed Subtract Bytes

Subtracts each packed 8-bit integer value in the second source operand from the corresponding packed 8-bit integer in the first source operand and writes the integer result of each subtraction in the corresponding byte of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

This instruction operates on both signed and unsigned integers. If the result overflows, the carry is ignored (neither the overflow nor carry bit in rFLAGS is set), and only the low-order 8 bits of each result are written in the destination.

The PSUBB instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSUBB mmx1, mmx2/mem64</td>
        <td>0F F8 /r</td>
        <td>Subtracts packed byte integer values in an MMX register or 64-bit memory location from packed byte integer values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the packed subtraction of 8-bit integer values from two 64-bit operands (mmx1 and mmx2/mem64) into the destination mmx1 register.

## Related Instructions

PSUBD, PSUBQ, PSUBSB, PSUBSW, PSUBUSB, PSUBUSW, PSUBW

## rFLAGS Affected

None

64-Bit Media [AMD Confidential PSUBB Instruction Reference - Distribution with NDA]

<page_number>185</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as<br/>indicated by EDX[MMX] = 0, returned by CPUID<br/>Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit<br/>or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or<br/>was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the<br/>instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was<br/>pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while<br/>alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>186</page_number> PSUBB 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSUBD Packed Subtract Doublewords

Subtracts each packed 32-bit integer value in the second source operand from the corresponding packed 32-bit integer in the first source operand and writes the integer result of each subtraction in the corresponding doubleword of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

This instruction operates on both signed and unsigned integers. If the result overflows, the carry is ignored (neither the overflow nor carry bit in rFLAGS is set), and only the low-order 32 bits of each result are written in the destination.

The PSUBD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSUBD mmx1, mmx2/mem64</td>
        <td>0F FA /r</td>
        <td>Subtracts packed 32-bit integer values in an MMX register or 64-bit memory location from packed 32-bit integer values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the subtraction of two packed 32-bit doublewords from mmx2/mem64 from mmx1, with results stored in mmx1.

## Related Instructions

PSUBB, PSUBQ, PSUBSB, PSUBSW, PSUBUSB, PSUBUSW, PSUBW

## rFLAGS Affected

None

64-Bit Media
Instruction Reference
[AMD Confidential PSUBD Distribution with NDA]
<page_number>

187
</page_number>

AMD logo

AMD64 Technology [26569—Rev. 3.16—November 2021](26569—Rev. 3.16—November 2021)

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>188</page_number>

**PSUBD**
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSUBQ Packed Subtract Quadword

Subtracts each packed 64-bit integer value in the second source operand from the corresponding packed 64-bit integer in the first source operand and writes the integer result of each subtraction in the corresponding quadword of the destination (first source). The first source/destination and source operands are an MMX register and another MMX register or 64-bit memory location.

The PSUBQ instruction is an SSE2 instruction; check the status of EDX bit 26 returned by CPUID function 0000_0001h. See “CPUID” in Volume 3 for more information about the CPUID instruction.

This instruction operates on both signed and unsigned integers. If the result overflows, the carry is ignored (neither the overflow nor carry bit in rFLAGS is set), and only the low-order 64 bits of each result are written in the destination.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSUBQ mmx1, mmx2/mem64</td>
        <td>0F FB /r</td>
        <td>Subtracts packed 64-bit integer values in an MMX register or 64-bit memory location from packed 64-bit integer values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the subtraction of a 64-bit value in mmx2/mem64 from a 64-bit value in mmx1, with the result stored back in mmx1.

## Related Instructions

PSUBB, PSUBD, PSUBSB, PSUBSW, PSUBUSB, PSUBUSW, PSUBW

## rFLAGS Affected

None

64-Bit Media
Instruction Reference
[AMD Confidential PSUBQ Instruction Reference - Distribution with NDA]
<page_number>

189
</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The SSE2 instructions are not supported, as indicated by CPUID Fn0000_0001_EDX[SSE2] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

190
</page_number>

**PSUBQ**
<mark>[AMD Confidential - Distribution with NDA]</mark>

64-Bit Media Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSUBSB Packed Subtract Signed With Saturation Bytes

Subtracts each packed 8-bit signed integer value in the second source operand from the corresponding packed 8-bit signed integer in the first source operand and writes the signed integer result of each subtraction in the corresponding byte of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

For each packed value in the destination, if the value is larger than the largest signed 8-bit integer, it is saturated to 7Fh, and if the value is smaller than the smallest signed 8-bit integer, it is saturated to 80h.

The PSUBBSB instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSUBSB mmx1, mmx2/mem64</td>
        <td>0F E8 /r</td>
        <td>Subtracts packed byte signed integer values in an MMX register or 64-bit memory location from packed byte integer values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the packed subtraction of signed bytes with saturation from mmx2/mem64 from mmx1, resulting in mmx1.

## Related Instructions

PSUBB, PSUBD, PSUBQ, PSUBSW, PSUBUSB, PSUBUSW, PSUBW

## rFLAGS Affected

None

64-Bit Media PSUBSB
[AMD Confidential - Distribution with NDA]

Instruction Reference
<page_number>

191
</page_number>

AMD logo

AMD64 Technology **26569—Rev. 3.16—November 2021**

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as<br/>indicated by EDX[MMX] = 0, returned by CPUID<br/>Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit<br/>or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or<br/>was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the<br/>instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was<br/>pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while<br/>alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>192</page_number>

**PSUBSB** [AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSUBSW Packed Subtract Signed With Saturation Words

Subtracts each packed 16-bit signed integer value in the second source operand from the corresponding packed 16-bit signed integer in the first source operand and writes the signed integer result of each subtraction in the corresponding word of the destination (first source). The first source/destination and source operands are an MMX register and another MMX register or 64-bit memory location.

For each packed value in the destination, if the value is larger than the largest signed 16-bit integer, it is saturated to 7FFFh, and if the value is smaller than the smallest signed 16-bit integer, it is saturated to 8000h.

The PSUBSW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSUBSW mmx1, mmx2/mem64</td>
        <td>0F E9 /r</td>
        <td>Subtracts packed 16-bit signed integer values in an MMX register or 64-bit memory location from packed 16-bit integer values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSUBSW operation on 64-bit registers mmx1 and mmx2/mem64, illustrating the subtraction and saturation of packed 16-bit words.

## Related Instructions

PSUBB, PSUBD, PSUBQ, PSUBSB, PSUBUSB, PSUBUSW, PSUBW

## rFLAGS Affected

None

64-Bit Media

[AMD Confidential - Distribution with NDA]

Instruction Reference

PSUBSW

<page_number>193</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

194
</page_number>

**PSUBSW**
[AMD Confidential - Distribution with NDA]

64-Bit Media

Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSUBUSB Packed Subtract Unsigned and Saturate Bytes

Subtracts each packed 8-bit unsigned integer value in the second source operand from the corresponding packed 8-bit unsigned integer in the first source operand and writes the unsigned integer result of each subtraction in the corresponding byte of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

For each packed value in the destination, if the value is smaller than the smallest unsigned 8-bit integer, it is saturated to 00h.

The PSUBUSB instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSUBUSB mmx1, mmx2/mem64</td>
        <td>0F D8 /r</td>
        <td>Subtracts packed byte unsigned integer values in an MMX register or 64-bit memory location from packed byte integer values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSUBUSB operation on 64-bit registers mmx1 and mmx2/mem64, illustrating the subtraction and saturation of packed bytes.

## Related Instructions

PSUBB, PSUBD, PSUBQ, PSUBSB, PSUBSW, PSUBUSW, PSUBW

## rFLAGS Affected

None

64-Bit Media
Instruction Reference
PSUBUSB
[AMD Confidential - Distribution with NDA]
<page_number>

195
</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>196</page_number>

PSUBUSB 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

# PSUBUSW Packed Subtract Unsigned and Saturate Words

Subtracts each packed 16-bit unsigned integer value in the second source operand from the corresponding packed 16-bit unsigned integer in the first source operand and writes the unsigned integer result of each subtraction in the corresponding word of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

For each packed value in the destination, if the value is smaller than the smallest unsigned 16-bit integer, it is saturated to 0000h.

The PSUBUSW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSUBUSW mmx1, mmx2/mem64</td>
        <td>0F D9 /r</td>
        <td>Subtracts packed 16-bit unsigned integer values in an MMX register or 64-bit memory location from packed 16-bit integer values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PSUBUSW operation on 64-bit MMX registers, illustrating the subtraction and saturation of four 16-bit words.

## Related Instructions

PSUBB, PSUBD, PSUBQ, PSUBSB, PSUBSW, PSUBUSB, PSUBW

## rFLAGS Affected

None

64-Bit Media PSUBUSW <page_number>197</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

198
</page_number>

PSUBUSW
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSUBW

# Packed Subtract Words

Subtracts each packed 16-bit integer value in the second source operand from the corresponding packed 16-bit integer in the first source operand and writes the integer result of each subtraction in the corresponding word of the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

This instruction operates on both signed and unsigned integers. If the result overflows, the carry is ignored (neither the overflow nor carry bit in rFLAGS is set), and only the low-order 16 bits of the result are written in the destination.

The PSUBW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSUBW mmx1, mmx2/mem64</td>
        <td>0F F9 /r</td>
        <td>Subtracts packed 16-bit integer values in an MMX register or 64-bit memory location from packed 16-bit integer values in another MMX register and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the subtraction of packed 16-bit integer values between two 64-bit operands (mmx1 and mmx2/mem64).

## Related Instructions

PSUBB, PSUBD, PSUBQ, PSUBSB, PSUBSW, PSUBUSB, PSUBUSW

## rFLAGS Affected

None

64-Bit Media
Instruction Reference
PSUBW
[AMD Confidential - Distribution with NDA]

<page_number>199</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
<th>Exception</th>
<th>Real</th>
<th>Virtual<br/>8086</th>
<th>Protected</th>
<th>Cause of Exception</th>
    </tr>
    <tr>
<th rowspan="2">Invalid opcode, #UD</th>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The emulate bit (EM) of CR0 was set to 1.</th>
    </tr>
    <tr>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<td>Device not available, #NM</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
<td>Stack, #SS</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
<td rowspan="2">General protection, #GP</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
<td> </td>
<td>X</td>
<td>A null data segment was used to reference memory.</td>
<td></td>
    </tr>
    <tr>
<td>Page fault, #PF</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
<td>x87 floating-point exception pending, #MF</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
<td>Alignment check, #AC</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>200</page_number> **PSUBW** 64-Bit Media
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PSWAPD

# Packed Swap Doubleword

Swaps (reverses) the two packed 32-bit values in the source operand and writes each swapped value in the corresponding doubleword of the destination. The source operand is an MMX register or 64-bit memory location. The destination is another MMX register.

The PSWAPD instruction is an extension to the AMD 3DNow!™ instruction set. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PSWAPD mmx1, mmx2/mem64</td>
        <td>0F 0F /r BB</td>
        <td>Swaps packed 32-bit values in an MMX register or 64-bit memory location and writes each value in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph mmx2_mem64 ["mmx2/mem64"]
        direction LR
        S1["63 .. 32"]
        S2["31 .. 0"]
    end

    subgraph mmx1 ["mmx1"]
        direction LR
        D1["63 .. 32"]
        D2["31 .. 0"]
    end

    S1 -- "copy" --> D2
    S2 -- "copy" --> D1
```
pswapd.eps diagram

## Related Instructions

None

## rFLAGS Affected

None

64-Bit Media
Instruction Reference
PSWAPD
[AMD Confidential - Distribution with NDA]
<page_number>

201
</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The AMD Extensions to 3DNow!™ are not supported,<br/>as indicated by<br/>CPUID Fn8000_0001_EDX[3DNowExt] = 0.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

202
</page_number>

**PSWAPD** [AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

26569—Rev. 3.16—November 2021 AMD

AMD64 Technology

# PUNPCKHBW Unpack and Interleave High Bytes

Unpacks the high-order bytes from the first and second source operands and packs them into interleaved-byte words in the destination (first source). The low-order bytes of the source operands are ignored. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

If the second source operand is all 0s, the destination contains the bytes from the first source operand zero-extended to 16 bits. This operation is useful for expanding unsigned 8-bit values to unsigned 16-bit operands for subsequent processing that requires higher precision.

The PUNPCKHBW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PUNPCKHBW mmx1, mmx2/mem64</td>
        <td>0F 68 /r</td>
        <td>Unpacks the four high-order bytes in an MMX register and another MMX register or 64-bit memory location and packs them into interleaved bytes in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PUNPCKHBW operation: high-order bytes from mmx1 and mmx2/mem64 are interleaved into the destination register.

## Related Instructions

PUNPCKHDQ, PUNPCKHQDQ, PUNPCK HWD, PUNPCKLBW, PUNPCKLDQ, PUNPCKLQDQ, PUNPCKLWD

## rFLAGS Affected

None

64-Bit Media PUNPCKHBW
Instruction Reference [AMD Confidential - Distribution with NDA]

<page_number>203</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>204</page_number>

PUNPCKHBW
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PUNPCKHDQ Unpack and Interleave High Doublewords

Unpacks the high-order doublewords from the first and second source operands and packs them into interleaved-doubleword quadwords in the destination (first source). The low-order doublewords of the source operands are ignored. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

If the second source operand is all 0s, the destination contains the doubleword(s) from the first source operand zero-extended to 64 bits. This operation is useful for expanding unsigned 32-bit values to unsigned 64-bit operands for subsequent processing that requires higher precision.

The PUNPCKHDQ instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PUNPCKHDQ mmx1, mmx2/mem64</td>
        <td>0F 6A /r</td>
        <td>Unpacks the high-order doubleword in an MMX register and another MMX register or 64-bit memory location and packs them into interleaved doublewords in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PUNPCKHDQ operation: high doublewords (bits 63-32) from mmx1 and mmx2/mem64 are copied and interleaved into the destination register.

## Related Instructions

PUNPCKHBW, PUNPCKHQDQ, PUNPCKHWD, PUNPCKLBW, PUNPCKLDQ, PUNPCKLQDQ, PUNPCKLWD

## rFLAGS Affected

None

64-Bit Media
PUNPCKHDQ
Instruction Reference
<mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>205</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

206
</page_number>

[AMD Confidential - Distribution with NDA]

**PUNPCKHDQ**

64-Bit Media Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PUNPCKHWD Unpack and Interleave High Words

Unpacks the high-order words from the first and second source operands and packs them into interleaved-word doublewords in the destination (first source). The low-order words of the source operands are ignored. The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

If the second source operand is all 0s, the destination contains the words from the first source operand zero-extended to 32 bits. This operation is useful for expanding unsigned 16-bit values to unsigned 32-bit operands for subsequent processing that requires higher precision.

The PUNPCKHWD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PUNPCKHWD mmx1, mmx2/mem64</td>
        <td>0F 69 /r</td>
        <td>Unpacks two high-order words in an MMX register and another MMX register or 64-bit memory location and packs them into interleaved words in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the PUNPCKHWD operation where high-order words from two 64-bit source operands (mmx1 and mmx2/mem64) are interleaved into a 64-bit destination register.

## Related Instructions

PUNPCKHBW, PUNPCKHDQ, PUNPCKHQDQ, PUNPCKLBW, PUNPCKLDQ, PUNPCKLQDQ, PUNPCKLWD

## rFLAGS Affected

None

64-Bit Media
Instruction Reference
PUNPCKHWD
[AMD Confidential - Distribution with NDA]
<page_number>207</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
<th>Exception</th>
<th>Real</th>
<th>Virtual<br/>8086</th>
<th>Protected</th>
<th>Cause of Exception</th>
    </tr>
    <tr>
<th rowspan="2">Invalid opcode, #UD</th>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The emulate bit (EM) of CR0 was set to 1.</th>
    </tr>
    <tr>
<th>X</th>
<th>X</th>
<th>X</th>
<th>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<td>Device not available, #NM</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
<td>Stack, #SS</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
<td rowspan="2">General protection, #GP</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
<td> </td>
<td>X</td>
<td>A null data segment was used to reference memory.</td>
<td></td>
    </tr>
    <tr>
<td>Page fault, #PF</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
<td>x87 floating-point exception pending, #MF</td>
<td>X</td>
<td>X</td>
<td>X</td>
<td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
<td>Alignment check, #AC</td>
<td> </td>
<td>X</td>
<td>X</td>
<td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

208
</page_number>

PUNPCKHWD
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# PUNPCKLBW

# Unpack and Interleave Low Bytes

Unpacks the low-order bytes from the first and second source operands and packs them into interleaved-byte words in the destination (first source). The high-order bytes of the source operands are ignored. The first source/destination operand is an MMX register and the second source operand is another MMX register or 32-bit memory location.

If the second source operand is all 0s, the destination contains the bytes from the first source operand zero-extended to 16 bits. This operation is useful for expanding unsigned 8-bit values to unsigned 16-bit operands for subsequent processing that requires higher precision.

The PUNPCKLBW instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PUNPCKLBW mmx1, mmx2/mem32</td>
        <td>0F 60 /r</td>
        <td>Unpacks the four low-order bytes in an MMX register and another MMX register or 32-bit memory location and packs them into interleaved bytes in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the unpacking and interleaving of low bytes from two 64-bit registers (mmx1 and mmx2/mem64) into a destination register.

## Related Instructions

PUNPCKHBW, PUNPCKHDQ, PUNPCKHQDQ, PUNPCKHWD, PUNPCKLDQ, PUNPCKLQDQ, PUNPCKLWD

## rFLAGS Affected

None

64-Bit Media
Instruction Reference
PUNPCKLBW
[AMD Confidential - Distribution with NDA]

<page_number>209</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

210
</page_number>

PUNPCKLBW 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# PUNPCKLDQ Unpack and Interleave Low Doublewords

Unpacks the low-order doublewords from the first and second source operands and packs them into interleaved-doubleword quadwords in the destination (first source). The high-order doublewords of the source operands are ignored. The first source/destination operand is an MMX register and the second source operand is another MMX register or 32-bit memory location.

If the second source operand is all 0s, the destination contains the doubleword(s) from the first source operand zero-extended to 64 bits. This operation is useful for expanding unsigned 32-bit values to unsigned 64-bit operands for subsequent processing that requires higher precision.

The PUNPCKLDQ instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PUNPCKLDQ mmx1, mmx2/mem32</td>
        <td>0F 62 /r</td>
        <td>Unpacks the low-order doubleword in an MMX register and another MMX register or 32-bit memory location and packs them into interleaved doublewords in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph mmx1
        A[63:32]
        B[31:0]
    end
    subgraph mmx2_mem64["mmx2/mem64"]
        C[63:32]
        D[31:0]
    end
    subgraph Destination
        E[63:32]
        F[31:0]
    end
    B -- copy --> E
    D -- copy --> F
    style A fill:none,stroke:#000
    style B fill:none,stroke:#000
    style C fill:none,stroke:#000
    style D fill:none,stroke:#000
    style E fill:none,stroke:#000
    style F fill:none,stroke:#000
```
punpckldq-64.eps

## Related Instructions

PUNPCKHBW, PUNPCKHDQ, PUNPCKHQDQ, PUNPCKHWD, PUNPCKLBW, PUNPCKLQDQ, PUNPCKLWD

## rFLAGS Affected

None

64-Bit Media
PUNPCKLDQ
[AMD Confidential - Distribution with NDA]
Instruction Reference
<page_number>

211
</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>212</page_number>

PUNPCKLDQ
[AMD Confidential - Distribution with NDA]

64-Bit Media
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# PUNPCKLWD Unpack and Interleave Low Words

Unpacks the low-order words from the first and second source operands and packs them into interleaved-word doublewords in the destination (first source). The high-order words of the source operands are ignored. The first source/destination operand is an MMX register and the second source operand is another MMX register or 32-bit memory location.

If the second source operand is all 0s, the destination contains the words from the first source operand zero-extended to 32 bits. This operation is useful for expanding unsigned 16-bit values to unsigned 32-bit operands for subsequent processing that requires higher precision.

The PUNPCKLWD instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PUNPCKLWD mmx1, mmx2/mem32</td>
        <td>0F 61 /r</td>
        <td>Unpacks the two low-order words in an MMX register and another MMX register or 32-bit memory location and packs them into interleaved words in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

```mermaid
graph TD
    subgraph mmx1
        m1_hi[63 ... 32]
        m1_w1[31 ... 16]
        m1_w0[15 ... 0]
    end

    subgraph mmx2_mem64["mmx2/mem64"]
        m2_hi[63 ... 32]
        m2_w1[31 ... 16]
        m2_w0[15 ... 0]
    end

    subgraph Destination
        d_w3[63 ... 48]
        d_w2[47 ... 32]
        d_w1[31 ... 16]
        d_w0[15 ... 0]
    end

    m2_w1 -- copy --> d_w3
    m1_w1 -- copy --> d_w2
    m2_w0 -- copy --> d_w1
    m1_w0 -- copy --> d_w0
```
punpcklwd-64.eps

## Related Instructions

PUNPCKHBW, PUNPCKHDQ, PUNPCKHQDQ, PUNPCKHWD, PUNPCKLBW, PUNPCKLDQ, PUNPCKLQDQ

## rFLAGS Affected

None

64-Bit Media PUNPCKLWD
Instruction Reference
[AMD Confidential - Distribution with NDA]

<page_number>213</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>214</page_number> PUNPCKLWD 64-Bit Media
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# PXOR Packed Logical Bitwise Exclusive OR

Performs a bitwise exclusive OR of the values in the first and second source operands and writes the result in the destination (first source). The first source/destination operand is an MMX register and the second source operand is another MMX register or 64-bit memory location.

The PXOR instruction is an MMX™ instruction. The presence of this instruction set is indicated by CPUID feature bits. See “CPUID” in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PXOR mmx1, mmx2/mem64</td>
        <td>0F EF /r</td>
        <td>Performs bitwise logical XOR of values in an MMX register and in another MMX register or 64-bit memory location and writes the result in the destination MMX register.</td>
    </tr>
  </tbody>
</table>

Diagram showing the bitwise XOR operation between mmx1 and mmx2/mem64 registers, both 64 bits wide (63 to 0), with the result written back to mmx1.

## Related Instructions

PAND, PANDN, POR

## rFLAGS Affected

None

64-Bit Media [AMD Confidential PXOR Instruction Reference - Distribution with NDA]

<page_number>215</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">Invalid opcode, #UD</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The MMX™ instructions are not supported, as indicated by EDX[MMX] = 0, returned by CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The task-switch bit (TS) of CR0 was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

<page_number>

216
</page_number>

**PXOR**
[AMD Confidential - Distribution with NDA]

64-Bit Media Instruction Reference

AMD

26569—Rev. 3.16—November 2021 AMD64 Technology

# 2 x87 Floating-Point Instruction Reference

This chapter describes the function, mnemonic syntax, opcodes, condition codes, affected flags, and possible exceptions generated by the x87 floating-point instructions. The x87 floating-point instructions are used in legacy floating-point applications. Most of these instructions load, store, or operate on data located in the x87 ST(0)–ST(7) stack registers (the FPR0–FPR7 physical registers). The remaining instructions within this category are used to manage the x87 floating-point environment.

The AMD64 architecture requires support of the x87 floating-point instruction subset including the floating-point conditional moves and the FCOMI(P) and FUCOMI(P) instructions. On compliant processor implementations both the FPU and the CMOV feature flags are set. These are indicated by EDX[FPU] (bit 0) and EDX[CMOV] (bit 15) respectively returned by CPUID Fn0000_0001 or CPUID Fn8000_0001.

This is augmented by instructions that are members of the MMX, 3DNow!™, SSE3, and FXSR subsets. Support for the following instructions is implementation-specific:

* EMMS, which is an MMX instruction. Support for this instruction is indicated by CPUID Fn0000_0001_EDX[MMX] = 1 or CPUID Fn8000_0001_EDX[MMX] = 1.

* FEMMS, which is a 3DNow!™ instruction. Support for this instruction is indicated by CPUID Fn8000_0001_EDX[3DNow] = 1.

* FISTTP, which is an SSE3 instruction. Support for this instruction is indicated by CPUID Fn0000_0001_ECX[SSE3] = 1.

* FXSAVE / FXRSTOR. Support for these instructions is indicated by CPUID Fn8000_0001_EDX[FXSR] = 1 or CPUID Fn0000_0001_EDX[FXSR] = 1

EMMS and FEMMS are described in Chapter 1, “64-Bit Media Instruction Reference”, on page 1.

The x87 instructions can be used in legacy mode or long mode. Their use in long mode is available if the following feature bit is set:

* Long Mode, as indicated by CPUID Fn8000_0001_EDX[LM] = 1.

Compilation of x87 media programs for execution in 64-bit mode offers two primary advantages: access to the 64-bit virtual address space and access to the RIP-relative addressing mode.

For further information about the x87 floating-point instructions and register resources, see:

* “x87 Floating-Point Programming” in Volume 1.

* “SSE, MMX, and x87 Programming” in Volume 2.

* “Summary of Registers and Data Types” in Volume 3.

* “Notation” in Volume 3.

* “Instruction Prefixes” in Volume 3.

For information on using the CPUID instruction, see the instruction description in Volume 3.

x87 Floating-Point <mark>[AMD Confidential - Distribution with NDA]</mark> Instruction Reference

<page_number>217</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# F2XM1

# Floating-Point Compute 2<sup>x</sup>–1

Raises 2 to the power specified by the value in ST(0), subtracts 1, and stores the result in ST(0). The source value must be in the range –1.0 to +1.0. The result is undefined for source values outside this range.

This instruction, when used in conjunction with the FYL2X instruction, can be applied to calculate z = x<sup>y</sup> by taking advantage of the log property x<sup>y</sup> = 2<sup>y*log<sub>2</sub>x</sup>.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>F2XM1</td>
        <td>D9 F0</td>
        <td>Replace ST(0) with (2<sup>ST(0)</sup> – 1).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FYL2X, FYL2XP1

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td rowspan="3">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>

218
</page_number>

[AMD Confidential - Distribution with NDA] F2XM1 x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) were set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference
F2XM1
[AMD Confidential - Distribution with NDA]

<page_number>219</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FABS

# Floating-Point Absolute Value

Converts the value in ST(0) to its absolute value by clearing the sign bit. The resulting value depends upon the type of number used as the source value:

<table>
  <thead>
    <tr>
        <th>Source Value (ST(0))</th>
        <th>Result (ST(0))</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>-∞</td>
        <td>+∞</td>
    </tr>
    <tr>
        <td>-FiniteReal</td>
        <td>+FiniteReal</td>
    </tr>
    <tr>
        <td>-0</td>
        <td>+0</td>
    </tr>
    <tr>
        <td>+0</td>
        <td>+0</td>
    </tr>
    <tr>
        <td>+FiniteReal</td>
        <td>+FiniteReal</td>
    </tr>
    <tr>
        <td>+∞</td>
        <td>+∞</td>
    </tr>
    <tr>
        <td>NaN</td>
        <td>NaN</td>
    </tr>
  </tbody>
</table>

This operation applies even if the value in ST(0) is negative zero or negative infinity.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FABS</td>
        <td>D9 E1</td>
        <td>Replace ST(0) with its absolute value.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FPREM, FRNDINT, FXTRACT, FCHS

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>

220
</page_number>

[AMD Confidential - Distribution with NDA]
FABS x87 Floating-Point
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference <mark>AMD Confidential - Distribution with NDA</mark> FABS

<page_number>221</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FADD FADDP FIADD Floating-Point Add

Adds two values and stores the result in a floating-point register. If two operands are specified, the values are in ST(0) and another floating-point register and the instruction stores the result in the first register specified. If one operand is specified, the instruction adds the 32-bit or 64-bit value in the specified memory location to the value in ST(0).

The FADDP instruction adds the value in ST(0) to the value in another floating-point register and pops the register stack. If two operands are specified, the first operand is the other register. If no operand is specified, then the other register is ST(1).

The FIADD instruction reads a 16-bit or 32-bit signed integer value from the specified memory location, converts it to double-extended-real format, and adds it to the value in ST(0).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FADD ST(0),ST(i)</td>
        <td>D8 C0+i</td>
        <td>Replace ST(0) with ST(0) + ST(i).</td>
    </tr>
    <tr>
        <td>FADD ST(i),ST(0)</td>
        <td>DC C0+i</td>
        <td>Replace ST(i) with ST(0) + ST(i).</td>
    </tr>
    <tr>
        <td>FADD mem32real</td>
        <td>D8 /0</td>
        <td>Replace ST(0) with ST(0) + mem32real.</td>
    </tr>
    <tr>
        <td>FADD mem64real</td>
        <td>DC /0</td>
        <td>Replace ST(0) with ST(0) + mem64real.</td>
    </tr>
    <tr>
        <td>FADDP</td>
        <td>DE C1</td>
        <td>Replace ST(1) with ST(0) + ST(1), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FADDP ST(i),ST(0)</td>
        <td>DE C0+i</td>
        <td>Replace ST(i) with ST(0) + ST(i), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FIADD mem16int</td>
        <td>DE /0</td>
        <td>Replace ST(0) with ST(0) + mem16int.</td>
    </tr>
    <tr>
        <td>FIADD mem32int</td>
        <td>DA /0</td>
        <td>Replace ST(0) with ST(0) + mem32int.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

None

## rFLAGS Affected

None

<page_number>222</page_number>

[AMD Confidential - Distribution with NDA] FADDx x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td rowspan="3">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

**Note:** A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>A page fault resulted from the execution of the 
instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXX+infinity</td>
      <td>was added to –infinity.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference
FADDx
[AMD Confidential - Distribution with NDA]

<page_number>223</page_number>

AMD logo

**AMD64 Technology** **26569—Rev. 3.16—November 2021**

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Underflow exception (UE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A rounded result was too small to fit into the format of the destination operand.</td>
    </tr>
    <tr>
        <td>Precision exception (PE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A result could not be represented exactly in the destination format.</td>
    </tr>
  </tbody>
</table>

<page_number>224</page_number>

**FADDx** **x87 Floating-Point**
**[AMD Confidential — Distribution with NDA]** **Instruction Reference**

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# FBLD

# Floating-Point Load Binary-Coded Decimal

Converts a 10-byte packed BCD value in memory into double-extended-precision format, and pushes the result onto the x87 stack. In the process, it preserves the sign of the source value.

The packed BCD digits should be in the range 0 to 9. Attempting to load invalid digits (Ah through Fh) produces undefined results.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FBLD <em>mem80dec</em></td>
        <td>DF /4</td>
        <td>Convert a packed BCD value to floating-point and push the result onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FBSTP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>If no other flags are set.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

\*Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.

**x87 Floating-Point Instruction Reference**

FBLD

[AMD Confidential - Distribution with NDA]

<page_number>225</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

<page_number>226</page_number>

FBLD x87 Floating-Point
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# FBSTP Floating-Point Store Binary-Coded Decimal and Pop

Converts the value in ST(0) to an 18-digit packed BCD integer, stores the result in the specified memory location, and pops the register stack. It rounds a non-integral value to an integer value, depending on the rounding mode specified by the RC field of the x87 control word.

The operand specifies the memory address of the first byte of the resulting 10-byte value.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FBSTP mem80dec</td>
        <td>DF /6</td>
        <td>Convert the floating-point value in ST(0) to BCD, store the result in mem80, and pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FBLD

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td rowspan="3">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference
FBSTP
[AMD Confidential - Distribution with NDA]
<page_number>

227
</page_number>

AMD logo

26569—Rev. 3.16—November 2021

# Exceptions

<table>
  <thead>
    <tr>
      <th colspan="5">AMD64 Technology 26569—Rev.3.16—November 2021
<br/>
Exceptions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>ExceptionReal</td>
      <td></td>
      <td>Virtual</td>
      <td></td>
      <td>8086ProtectedCause of Exception</td>
    </tr>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection,</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td>#GP</td>
      <td></td>
      <td></td>
      <td>XThe</td>
      <td>destination operand was in a nonwritable segment.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN value, 
±infinity or an unsupported format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was too large to fit in the destination 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

<page_number>

228
</page_number>

**FBSTP** x87 Floating-Point Instruction Reference
[AMD Confidential - Distribution with NDA]

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# FCHS Floating-Point Change Sign

Compliments the sign bit of ST(0), changing the value from negative to positive or vice versa. This operation applies to positive and negative floating point values, as well as –0 and +0, NaNs, and +∞ and –∞.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FCHS</td>
        <td>D9 E0</td>
        <td>Reverse the sign bit of ST(0).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FABS, FPREM, FRNDINT, FXTRACT

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference FCHS [AMD Confidential - Distribution with NDA]

<page_number>229</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FCLEX (FNCLEX)

# Floating-Point Clear Flags

Clears the following flags in the x87 status word:

* Floating-point exception flags (PE, UE, OE, ZE, DE, and IE)

* Stack fault flag (SF)

* Exception summary status flag (ES)

* Busy flag (B)

It leaves the four condition-code bits undefined. It does not check for possible floating-point exceptions before clearing the flags.

Assemblers usually provide an FCLEX macro that expands into the instruction sequence

```
WAIT                          ; Opcode 9B
FNCLEX destination            ; Opcode DB E2
```

The WAIT (9Bh) instruction checks for pending x87 exceptions and calls an exception handler, if necessary. The FNCLEX instruction then clears all the relevant x87 exception flags.

### Description

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FCLEX</td>
        <td>9B DB E2</td>
        <td>Perform a WAIT (9B) to check for pending floating-point exceptions, and then clear the floating-point exception flags.</td>
    </tr>
    <tr>
        <td>FNCLEX</td>
        <td>DB E2</td>
        <td>Clear the floating-point flags without checking for pending unmasked floating-point exceptions.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

WAIT

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

**Note:** *A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.*

<page_number>

230
</page_number>

FCLEX (FNCLEX) x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference FCLEX (FNCLEX)
[AMD Confidential - Distribution with NDA]

<page_number>231</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FCMOVcc Floating-Point Conditional Move

Tests the flags in the rFLAGS register and, depending upon the values encountered, moves the value in another stack register to ST(0).

This set of instructions includes the mnemonics FCMOVB, FCMOVBE, FCMOVE, FCMOVNB, FCMOVNBE, FCMOVNE, FCMOVNU, and FCMOVU.

Support for the FCMOVcc instruction is indicated when both EDX[FPU] (bit 0) and EDX[CMOV] (bit 15) are set, as returned by either CPUID function 0000_0001h or function 8000_0001h.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FCMOVB ST(0),ST(i)</td>
        <td>DA C0+i</td>
        <td>Move the contents of ST(i) into ST(0) if below (CF = 1).</td>
    </tr>
    <tr>
        <td>FCMOVBE ST(0),ST(i)</td>
        <td>DA D0+i</td>
        <td>Move the contents of ST(i) into ST(0) if below or equal (CF = 1 or ZF = 1).</td>
    </tr>
    <tr>
        <td>FCMOVE ST(0),ST(i)</td>
        <td>DA C8+i</td>
        <td>Move the contents of ST(i) into ST(0) if equal (ZF = 1).</td>
    </tr>
    <tr>
        <td>FCMOVNB ST(0),ST(i)</td>
        <td>DB C0+i</td>
        <td>Move the contents of ST(i) into ST(0) if not below (CF = 0).</td>
    </tr>
    <tr>
        <td>FCMOVNBE ST(0),ST(i)</td>
        <td>DB D0+i</td>
        <td>Move the contents of ST(i) into ST(0) if not below or equal (CF = 0 and ZF = 0).</td>
    </tr>
    <tr>
        <td>FCMOVNE ST(0),ST(i)</td>
        <td>DB C8+i</td>
        <td>Move the contents of ST(i) into ST(0) if not equal (ZF = 0).</td>
    </tr>
    <tr>
        <td>FCMOVNU ST(0),ST(i)</td>
        <td>DB D8+i</td>
        <td>Move the contents of ST(i) into ST(0) if not unordered (PF = 0).</td>
    </tr>
    <tr>
        <td>FCMOVU ST(0),ST(i)</td>
        <td>DA D8+i</td>
        <td>Move the contents of ST(i) into ST(0) if unordered (PF = 1).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

None

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>

232
</page_number>

[AMD Confidential - Distribution with NDA]
**FCMOVcc** x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual
8086</th>
      <th>Protecte</th>
      <th>dCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Invalid opcode, 
#UD</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The Conditional Move instructions are not supported, as 
indicated by EDX[FPU] and EDX[CMOV] returned by CPUID 
Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the control 
register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FCMOVcc [AMD Confidential - Distribution with NDA] Instruction Reference

<page_number>233</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FCOM
# FCOMP
# FCOMPP

# Floating-Point Compare

Compares the specified value to the value in ST(0) and sets the C0, C2, and C3 condition code flags in the x87 status word as shown in the x87 Condition Code table below. The specified value can be in a floating-point register or a memory location.

The no-operand version compares the value in ST(1) with the value in ST(0).

The comparison operation ignores the sign of zero (–0.0 = +0.0).

After performing the comparison operation, the FCOMP instruction pops the x87 register stack and the FCOMPP instruction pops the x87 register stack twice.

If either or both of the compared values is a NaN or is in an unsupported format, the FCOMx instruction sets the invalid-operation exception (IE) bit in the x87 status word to 1, and sets the condition flags to 'unordered.'

The FUCOMx instructions perform the same operations as the FCOMx instructions, but do not set the IE bit for QNaNs.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FCOM</td>
        <td>D8 D1</td>
        <td>Compare the contents of ST(0) to the contents of ST(1) and set condition flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FCOM ST(i)</td>
        <td>D8 D0+i</td>
        <td>Compare the contents of ST(0) to the contents of ST(i) and set condition flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FCOM <em>mem32real</em></td>
        <td>D8 /2</td>
        <td>Compare the contents of ST(0) to the contents of <em>mem32real</em> and set condition flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FCOM <em>mem64real</em></td>
        <td>DC /2</td>
        <td>Compare the contents of ST(0) to the contents of <em>mem64real</em> and set condition flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FCOMP</td>
        <td>D8 D9</td>
        <td>Compare the contents of ST(0) to the contents of ST(1), set condition flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FCOMP ST(i)</td>
        <td>D8 D8+i</td>
        <td>Compare the contents of ST(0) to the contents of ST(i), set condition flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FCOMP <em>mem32real</em></td>
        <td>D8 /3</td>
        <td>Compare the contents of ST(0) to the contents of <em>mem32real</em>, set condition flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

<page_number>

234
</page_number>

FCOMx x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

<table>
  <tbody>
    <tr>
        <td>FCOMP mem64real</td>
        <td>DC /3</td>
        <td>Compare the contents of ST(0) to the contents of mem64real, set condition flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FCOMPP</td>
        <td>DE D9</td>
        <td>Compare the contents of ST(0) to the contents of ST(1), set condition flags to reflect the results of the comparison, and pop the x87 register stack twice.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOMI, FCOMIP, FICOM, FICOMP, FTST, FUCOMI, FUCOMIP, FXAM

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>C3</th>
        <th>C2</th>
        <th>C1</th>
        <th>C0</th>
        <th>Compare Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) &gt; source</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>ST(0) &lt; source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) = source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>1</td>
        <td>0</td>
        <td>1</td>
        <td>Operands were unordered</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN value, or 
an unsupported format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FCOMx <page_number>235</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Invalid-operation exception (IE) with stack fault (SF)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An x87 stack underflow occurred.</td>
    </tr>
    <tr>
        <td>Denormalized-operand exception (DE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A source operand was a denormal value.</td>
    </tr>
  </tbody>
</table>

<page_number>236</page_number>

**FCOMx** x87 Floating-Point
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FCOMI FCOMIP Floating-Point Compare and Set Flags

Compares the value in ST(0) with the value in another floating-point register and sets the zero flag (ZF), parity flag (PF), and carry flag (CF) in the rFLAGS register based on the result as shown in the table in the x87 Condition Code section.

The comparison operation ignores the sign of zero (–0.0 = +0.0).

After performing the comparison operation, FCOMIP pops the x87 register stack.

If either or both of the compared values is a NaN or is in an unsupported format, the FCOMIx instruction sets the invalid-operation exception (IE) bit in the x87 status word to 1 and sets the flags to “unordered.”

The FUCOMIx instructions perform the same operations as the FCOMIx instructions, but do not set the IE bit for QNaNs.

Support for the FCOMIx instruction can be determined by executing either CPUID Fn0000_0001 or CPUID Fn8000_0001. Support is indicated when both EDX[FPU] (bit 0) and EDX[CMOV] (bit 15) are set.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FCOMI ST(0),ST(i)</td>
        <td>DB F0+i</td>
        <td>Compare the contents of ST(0) with the contents of ST(i) and set status flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FCOMIP ST(0),ST(i)</td>
        <td>DF F0+i</td>
        <td>Compare the contents of ST(0) with the contents of ST(i), set status flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOM, FCOMPP, FICOM, FICOMP, FTST, FUCOMI, FUCOMIP, FXAM

## rFLAGS Affected

<table>
  <thead>
    <tr>
        <th>ZF</th>
        <th>PF</th>
        <th>CF</th>
        <th>Compare Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) &gt; source</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>ST(0) &lt; source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) = source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>1</td>
        <td>1</td>
        <td>Operands were unordered</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FCOMIx
Instruction Reference
[AMD Confidential - Distribution with NDA]

<page_number>237</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td colspan="3">C0</td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Invalid opcode, #UDXXX</td>
      <td></td>
      <td></td>
      <td></td>
      <td>The conditional move instructions are not supported, as 
indicated by EDX[FPU] and EDX[CMOV] returned by 
CPUID Fn0000_0001 or Fn8000_0001.</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN value, or 
an unsupported format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
  </tbody>
</table>

<page_number>

238
</page_number>

FCOMIx x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FCOS

# Floating-Point Cosine

Computes the cosine of the radian value in ST(0) and stores the result in ST(0).

If the radian value lies outside the valid range of –2<sup>63</sup> to +2<sup>63</sup> radians, the instruction sets the C2 flag in the x87 status word to 1 to indicate the value is out of range and does not change the value in ST(0).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FCOS</td>
        <td>D9 FF</td>
        <td>Replace ST(0) with the cosine of ST(0).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FPTAN, FPATAN, FSIN, FSINCOS

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td> </td>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Source operand was in range.</td>
    </tr>
    <tr>
        <td rowspan="2">C2</td>
        <td>1</td>
        <td>Source operand was out of range.</td>
    </tr>
    <tr>
        <td> </td>
        <td></td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point**
**Instruction Reference**
FCOS
[AMD Confidential - Distribution with NDA]
<page_number>

239
</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

<page_number>

240
</page_number>

FCOS x87 Floating-Point Instruction Reference
[AMD Confidential - Distribution with NDA]

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# FDECSTP Floating-Point Decrement Stack-Top Pointer

Decrements the top-of-stack pointer (TOP) field of the x87 status word. If the TOP field contains 0, it is set to 7. In other words, this instruction rotates the stack by one position.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FDECSTP</td>
        <td>D9 F6</td>
        <td>Decrement the TOP field in the x87 status word.</td>
    </tr>
  </tbody>
</table>
<table>
  <thead>
    <tr>
        <th rowspan="2">Data Register</th>
        <th colspan="2">Before FDECSTP</th>
        <th colspan="2">After FDECSTP</th>
    </tr>
    <tr>
        <th>Value</th>
        <th>Stack Pointer</th>
        <th>Stack Pointer</th>
        <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>7</td>
        <td>num1</td>
        <td>ST(7)</td>
        <td>ST(0)</td>
        <td>num1</td>
    </tr>
    <tr>
        <td>6</td>
        <td>num2</td>
        <td>ST(6)</td>
        <td>ST(7)</td>
        <td>num2</td>
    </tr>
    <tr>
        <td>5</td>
        <td>num3</td>
        <td>ST(5)</td>
        <td>ST(6)</td>
        <td>num3</td>
    </tr>
    <tr>
        <td>4</td>
        <td>num4</td>
        <td>ST(4)</td>
        <td>ST(5)</td>
        <td>num4</td>
    </tr>
    <tr>
        <td>3</td>
        <td>num5</td>
        <td>ST(3)</td>
        <td>ST(4)</td>
        <td>num5</td>
    </tr>
    <tr>
        <td>2</td>
        <td>num6</td>
        <td>ST(2)</td>
        <td>ST(3)</td>
        <td>num6</td>
    </tr>
    <tr>
        <td>1</td>
        <td>num7</td>
        <td>ST(1)</td>
        <td>ST(2)</td>
        <td>num7</td>
    </tr>
    <tr>
        <td>0</td>
        <td>num8</td>
        <td>ST(0)</td>
        <td>ST(1)</td>
        <td>num8</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FINCSTP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point
Instruction Reference
FDECSTP
[AMD Confidential - Distribution with NDA]

<page_number>241</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

<page_number>242</page_number>

[AMD Confidential - Distribution with NDA] **FDECSTP** x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FDIV FDIVP FIDIV Floating-Point Divide

Divides the value in a floating-point register by the value in another register or a memory location and stores the result in the register containing the dividend. For the FDIV and FDIVP instructions, the divisor value in memory can be stored in single-precision or double-precision floating-point format.

If only one operand is specified, the instruction divides the value in ST(0) by the value in the specified memory location.

If no operands are specified, the FDIVP instruction divides the value in ST(1) by the value in ST(0), stores the result in ST(1), and pops the x87 register stack.

The FIDIV instruction converts a divisor in word integer or short integer format to double-extended-precision floating-point format before performing the division. It treats an integer 0 as +0.

If the zero-divide exception is not masked (ZM bit cleared to 0 in the x87 control word) and the operation causes a zero-divide exception (sets the ZE bit in the x87 status word to 1), the operation stores no result. If the zero-divide exception is masked (ZM bit set to 1), a zero-divide exception causes ±∞ to be stored.

The sign of the operands, even if one of the operands is 0, determines the sign of the result.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FDIV ST(0),ST(i)</td>
        <td>D8 F0+i</td>
        <td>Replace ST(0) with ST(0)/ST(i).</td>
    </tr>
    <tr>
        <td>FDIV ST(i),ST(0)</td>
        <td>DC F8+i</td>
        <td>Replace ST(i) with ST(i)/ST(0).</td>
    </tr>
    <tr>
        <td>FDIV mem32real</td>
        <td>D8 /6</td>
        <td>Replace ST(0) with ST(0)/mem32real.</td>
    </tr>
    <tr>
        <td>FDIV mem64real</td>
        <td>DC /6</td>
        <td>Replace ST(0) with ST(0)/mem64real.</td>
    </tr>
    <tr>
        <td>FDIVP</td>
        <td>DE F9</td>
        <td>Replace ST(1) with ST(1)/ST(0), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FDIVP ST(i),ST(0)</td>
        <td>DE F8+i</td>
        <td>Replace ST(i) with ST(i)/ST(0), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FIDIV mem16int</td>
        <td>DE /6</td>
        <td>Replace ST(0) with ST(0)/mem16int.</td>
    </tr>
    <tr>
        <td>FIDIV mem32int</td>
        <td>DA /6</td>
        <td>Replace ST(0) with ST(0)/mem32int.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FDIVR, FDIVRP, FIDIVR

## rFLAGS Affected

None

x87 Floating-Point Instruction Reference FDIVx [AMD Confidential - Distribution with NDA]

<page_number>243</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

**Note:** A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td></td>
      <td>XXX±infinity</td>
      <td>was divided by ±infinity.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXX±zero</td>
      <td>was divided by ±zero.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Zero-divide 
exception (ZE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>non-zero value was divided by ±zero.</td>
    </tr>
  </tbody>
</table>

<page_number>

244
</page_number>

FDIVx x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Overflow exception (OE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A rounded result was too large to fit into the format of the destination operand.</td>
    </tr>
    <tr>
        <td>Underflow exception (UE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A rounded result was too small to fit into the format of the destination operand.</td>
    </tr>
    <tr>
        <td>Precision exception (PE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A result could not be represented exactly in the destination format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference FDIVx [AMD Confidential - Distribution with NDA] <page_number>245</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FDIVR FDIVRP FIDIVR

# Floating-Point Divide Reverse

Divides a value in a floating-point register or a memory location by the value in a floating-point register and stores the result in the register containing the divisor. For the FDIVR and FDIVRP instructions, a dividend value in memory can be stored in single-precision or double-precision floating-point format.

If one operand is specified, the instruction divides the value at the specified memory location by the value in ST(0). If two operands are specified, it divides the value in ST(0) by the value in another x87 stack register or vice versa.

The FIDIVR instruction converts a dividend in word integer or short integer format to double-extended-precision format before performing the division.

The FDIVRP instruction pops the x87 register stack after performing the division operation. If no operand is specified, the FDIVRP instruction divides the value in ST(0) by the value in ST(1).

If the zero-divide exception is not masked (ZM bit cleared to 0 in the x87 control word) and the operation causes a zero-divide exception (sets the ZE bit in the x87 status word to 1), the operation stores no result. If the zero-divide exception is masked (ZM bit set to 1), a zero-divide exception causes ±∞ to be stored.

The sign of the operands, even if one of the operands is 0, determines the sign of the result.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FDIVR ST(0),ST(i)</td>
        <td>D8 F8+i</td>
        <td>Replace ST(0) with ST(i)/ST(0).</td>
    </tr>
    <tr>
        <td>FDIVR ST(i), ST(0)</td>
        <td>DC F0+i</td>
        <td>Replace ST(i) with ST(0)/ST(i).</td>
    </tr>
    <tr>
        <td>FDIVR mem32real</td>
        <td>D8 /7</td>
        <td>Replace ST(0) with mem32real/ST(0).</td>
    </tr>
    <tr>
        <td>FDIVR mem64real</td>
        <td>DC /7</td>
        <td>Replace ST(0) with mem64real/ST(0).</td>
    </tr>
    <tr>
        <td>FDIVRP</td>
        <td>DE F1</td>
        <td>Replace ST(1) with ST(0)/ST(1), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FDIVRP ST(i), ST(0)</td>
        <td>DE F0 +i</td>
        <td>Replace ST(i) with ST(0)/ST(i), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FIDIVR mem16int</td>
        <td>DE /7</td>
        <td>Replace ST(0) with mem16int/ST(0).</td>
    </tr>
    <tr>
        <td>FIDIVR mem32int</td>
        <td>DA /7</td>
        <td>Replace ST(0) with mem32int/ST(0).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FDIV, FDIVP, FIDIV

<page_number>

246
</page_number>

[AMD Confidential - Distribution with NDA]
**FDIVRx**
**x87 Floating-Point Instruction Reference**

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or is 
non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or is 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td></td>
      <td>XXX±infinity</td>
      <td>was divided by ±infinity.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXX±zero</td>
      <td>was divided by ±zero.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference [AMD Confidential - Distribution with NDA] FDIVRx

<page_number>247</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Denormalized-operand exception (DE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A source operand was a denormal value.</td>
    </tr>
    <tr>
        <td>Zero-divide exception (ZE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A non-zero value was divided by ±zero.</td>
    </tr>
    <tr>
        <td>Overflow exception (OE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A rounded result was too large to fit into the format of the destination operand.</td>
    </tr>
    <tr>
        <td>Underflow exception (UE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A rounded result was too small to fit into the format of the destination operand.</td>
    </tr>
    <tr>
        <td>Precision exception (PE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A result could not be represented exactly in the destination format.</td>
    </tr>
  </tbody>
</table>

<page_number>

248
</page_number>

FDIVRx x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# FFREE Floating-Point Free Register

Frees the specified x87 stack register by marking its tag register entry as empty. The instruction does not affect the contents of the freed register or the top-of-stack pointer (TOP).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FFREE ST(i)</td>
        <td>DD C0+i</td>
        <td>Set the tag for x87 stack register i to empty (11b).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FST, FSTP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) is set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point Instruction Reference**

FFREE

<page_number>249</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FICOM FICOMP Floating-Point Integer Compare

Converts a 16-bit or 32-bit signed integer value to double-extended-precision format, compares it to the value in ST(0), and sets the C0, C2, and C3 condition code flags in the x87 status word to reflect the results.

The comparison operation ignores the sign of zero (–0.0 = +0.0).

After performing the comparison operation, the FICOMP instruction pops the x87 register stack.

If ST(0) is a NaN or is in an unsupported format, the instruction sets the condition flags to “unordered.”

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FICOM mem16int</td>
        <td>DE /2</td>
        <td>Convert the contents of mem16int to double-extended-precision format, compare the result to the contents of ST(0), and set condition flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FICOM mem32int</td>
        <td>DA /2</td>
        <td>Convert the contents of mem32int to double-extended-precision format, compare the result to the contents of ST(0), and set condition flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FICOMP mem16int</td>
        <td>DE /3</td>
        <td>Convert the contents of mem16int to double-extended-precision format, compare the result to the contents of ST(0), set condition flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FICOMP mem32int</td>
        <td>DA /3</td>
        <td>Convert the contents of mem32int to double-extended-precision format, compare the result to the contents of ST(0), set condition flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOM, FCOMPP, FCOMI, FCOMIP, FTST, FUCOMI, FUCOMIP, FXAM

## rFLAGS Affected

None

<page_number>250</page_number>

[AMD Confidential - Distribution with NDA]
FICOMx x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>C3</th>
        <th>C2</th>
        <th>C1</th>
        <th>C0</th>
        <th>Compare Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) &gt; source</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>ST(0) &lt; source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) = source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>1</td>
        <td>0</td>
        <td>1</td>
        <td>Operands were unordered</td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th>8086Protected</th>
      <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN value, or 
an unsupported format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference

FICOMx

[AMD Confidential - Distribution with NDA]

<page_number>251</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FILD Floating-Point Load Integer

Converts a signed-integer in memory to double-extended-precision format and pushes the value onto the x87 register stack. The value can be a 16-bit, 32-bit, or 64-bit integer value. Signed values from memory can always be represented exactly in x87 registers without rounding.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FILD mem16int</td>
        <td>DF /0</td>
        <td>Push the contents of mem16int onto the x87 register stack.</td>
    </tr>
    <tr>
        <td>FILD mem32int</td>
        <td>DB /0</td>
        <td>Push the contents of mem32int onto the x87 register stack.</td>
    </tr>
    <tr>
        <td>FILD mem64int</td>
        <td>DF /5</td>
        <td>Push the contents of mem64int onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FST, FSTP, FIST, FISTP, FBLD, FBSTP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>No stack overflow.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>252</page_number>

[AMD Confidential - Distribution with NDA]
FILD x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference
FILD
[AMD Confidential - Distribution with NDA]

<page_number>253</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FINCSTP Floating-Point Increment Stack-Top Pointer

Increments the top-of-stack pointer (TOP) field of the x87 status word. If the TOP field contains 7, it is cleared to 0. In other words, this instruction rotates the stack by one position.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FINCSTP</td>
        <td>D9 F7</td>
        <td>Increment the TOP field in the x87 status word.</td>
    </tr>
  </tbody>
</table>
<table>
  <thead>
    <tr>
        <th> </th>
        <th colspan="2">Before FINCSTP</th>
        <th> </th>
        <th colspan="2">After FINCSTP</th>
    </tr>
    <tr>
        <th>Data Register</th>
        <th>Value</th>
        <th>Stack Pointer</th>
        <th> </th>
        <th>Stack Pointer</th>
        <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>7</td>
        <td>num1</td>
        <td>ST(7)</td>
        <td rowspan="8">stack rotation diagram</td>
        <td>ST(6)</td>
        <td>num1</td>
    </tr>
    <tr>
        <td>6</td>
        <td>num2</td>
        <td>ST(6)</td>
        <td>ST(5)</td>
        <td>num2</td>
    </tr>
    <tr>
        <td>5</td>
        <td>num3</td>
        <td>ST(5)</td>
        <td>ST(4)</td>
        <td>num3</td>
    </tr>
    <tr>
        <td>4</td>
        <td>num4</td>
        <td>ST(4)</td>
        <td>ST(3)</td>
        <td>num4</td>
    </tr>
    <tr>
        <td>3</td>
        <td>num5</td>
        <td>ST(3)</td>
        <td>ST(2)</td>
        <td>num5</td>
    </tr>
    <tr>
        <td>2</td>
        <td>num6</td>
        <td>ST(2)</td>
        <td>ST(1)</td>
        <td>num6</td>
    </tr>
    <tr>
        <td>1</td>
        <td>num7</td>
        <td>ST(1)</td>
        <td>ST(0)</td>
        <td>num7</td>
    </tr>
    <tr>
        <td>0</td>
        <td>num8</td>
        <td>ST(0)</td>
        <td>ST(7)</td>
        <td>num8</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FDECSTP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>

254
</page_number>

FINCSTP x87 Floating-Point Instruction Reference
[AMD Confidential - Distribution with NDA]

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point Instruction Reference** **FINCSTP**
[AMD Confidential - Distribution with NDA]

<page_number>255</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FINIT Floating-Point Initialize
# FNINIT

Sets the x87 control word register, status word register, tag word register, instruction pointer, and data pointer to their default states as follows:

* Sets the x87 control word to 037Fh—round to nearest (RC = 00b); double-extended-precision (PC = 11b); all exceptions masked (PM, UM, OM, ZM, DM, and IM all set to 1).

* Clears all bits in the x87 status word (TOP is set to 0, which maps ST(0) onto FPR0).

* Marks all x87 stack registers as empty (11b) in the x87 tag register.

* Clears the instruction pointer and the data pointer.

These instructions do not actually zero out the x87 stack registers.

Assemblers usually provide an FINIT macro that expands into the instruction sequence

```
      WAIT                   ; Opcode 9B
      FNINIT destination     ; Opcode DB E3
```

The WAIT (9Bh) instruction checks for pending x87 exceptions and calls an exception handler, if necessary. The FNINIT instruction then resets the x87 environment to its default state.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FINIT</td>
        <td>9B DB E3</td>
        <td>Perform a WAIT (9B) to check for pending floating-point exceptions and then initialize the x87 unit.</td>
    </tr>
    <tr>
        <td>FNINIT</td>
        <td>DB E3</td>
        <td>Initialize the x87 unit without checking for unmasked floating-point exceptions.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FWAIT, WAIT

## rFLAGS Affected

None

<page_number>

256
</page_number>

FINIT (FNINIT) x87 Floating-Point Instruction Reference
<mark>[AMD Confidential - Distribution with NDA]</mark>

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><em>Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</em></td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point Instruction Reference**
**FINIT (FNINIT)**
[AMD Confidential - Distribution with NDA]

<page_number>257</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# FIST Floating-Point Integer Store
# FISTP

Converts the value in ST(0) to a signed integer, rounds it if necessary, and copies it to the specified memory location. The rounding control (RC) field of the x87 control word determines the type of rounding used.

The FIST instruction supports 16-bit and 32-bit values. The FISTP instructions supports 16-bit, 32-bit, and 64-bit values.

The FISTP instruction pops the stack after storing the rounded value in memory.

If the value is too large for the destination location, is a NaN, or is in an unsupported format, the instruction sets the invalid-operation exception (IE) bit in the x87 status word to 1. Then, if the exception is masked (IM bit set to 1 in the x87 control word), the instruction stores the integer indefinite value. If the exception is unmasked (IM bit cleared to 0), the instruction does not store the value.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FIST mem16int</td>
        <td>DF /2</td>
        <td>Convert the contents of ST(0) to integer and store the result in mem16int.</td>
    </tr>
    <tr>
        <td>FIST mem32int</td>
        <td>DB /2</td>
        <td>Convert the contents of ST(0) to integer and store the result in mem32int.</td>
    </tr>
    <tr>
        <td>FISTP mem16int</td>
        <td>DF /3</td>
        <td>Convert the contents of ST(0) to integer, store the result in mem16int, and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FISTP mem32int</td>
        <td>DB /3</td>
        <td>Convert the contents of ST(0) to integer, store the result in mem32int, and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FISTP mem64int</td>
        <td>DF /7</td>
        <td>Convert the contents of ST(0) to integer, store the result in mem64int, and pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

Table 2-1 shows the results of storing various types of numbers as integers.

## Table 2-1. Storing Numbers as Integers

<table>
  <thead>
    <tr>
        <th>ST(0)</th>
        <th>DEST</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>-∞</td>
        <td>Invalid-operation (IE) exception</td>
    </tr>
    <tr>
        <td>–Finite-real &lt; –1</td>
        <td>–Integer (Invalid-operation (IE) exception if the integer is too large for the destination)</td>
    </tr>
    <tr>
        <td>–1 &lt; –Finite-real &lt; –0</td>
        <td>0 or –1, depending on the rounding mode</td>
    </tr>
    <tr>
        <td>-0</td>
        <td>0</td>
    </tr>
    <tr>
        <td>+0</td>
        <td>0</td>
    </tr>
    <tr>
        <td>+0 &lt; +Finite-real &lt; +1</td>
        <td>0 or +1, depending on the rounding mode</td>
    </tr>
  </tbody>
</table>

<page_number>258</page_number>

FISTx x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

Table 2-1. Storing Numbers as Integers (continued)

<table>
  <thead>
    <tr>
        <th>ST(0)</th>
        <th>DEST</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>+Finite-real &gt; +1</td>
        <td>+Integer (Invalid-operation (IE) exception if the integer is too large for the destination)</td>
    </tr>
    <tr>
        <td>+∞</td>
        <td>Invalid-operation (IE) exception</td>
    </tr>
    <tr>
        <td>NaN</td>
        <td>Invalid-operation (IE) exception</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FST, FSTP, FILD, FBLD, FBSTP, FISTTP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FISTx
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>259</page_number>

AMD

<table>
  <thead>
    <tr>
      <th colspan="5">AMD64 Technology 26569—Rev.3.16—November 2021
<br/>
Exceptions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>ExceptionReal</td>
      <td></td>
      <td>Virtual</td>
      <td></td>
      <td>8086ProtectedCause of Exception</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection,</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td>#GP</td>
      <td></td>
      <td></td>
      <td>XThe</td>
      <td>destination operand was in a nonwritable segment.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The source operand was too large for the destination 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN value, 
+-infinity, or an unsupported format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
      <th colspan="5">AMD64 Technology 26569—Rev.3.16—November 2021
<br/>
Exceptions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>ExceptionReal</td>
      <td></td>
      <td>Virtual</td>
      <td></td>
      <td>8086ProtectedCause of Exception</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection,</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td>#GP</td>
      <td></td>
      <td></td>
      <td>XThe</td>
      <td>destination operand was in a nonwritable segment.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The source operand was too large for the destination 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN value, 
+-infinity, or an unsupported format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

<page_number>

260
</page_number>

FISTx x87 Floating-Point [AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021 AMD AMD64 Technology

# FISTTP Floating Point Integer Truncate and Store

Converts a floating-point value in ST(0) to an integer by truncating the fractional part of the number and storing the integer result to the memory address specified by the destination operand. FISTTP then pops the floating point register stack. The FISTTP instruction ignores the rounding mode specified by the x87 control word.

The FISTTP instruction applies to 16-bit, 32-bit, and 64-bit operands.

The FISTTP instruction is an SSE3 instruction. Support for this instruction subset is indicated by CPUID Fn0000_0001_ECX[SSE3] = 1. See "CPUID" in Volume 3 for more information about the CPUID instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FISTTP <em>mem16int</em></td>
        <td>DF /1</td>
        <td>Store the truncated floating-point value in ST(0) in memory location <em>mem16int</em> and pop the floating-point register stack.</td>
    </tr>
    <tr>
        <td>FISTTP <em>mem32int</em></td>
        <td>DB /1</td>
        <td>Store the truncated floating-point value in ST(0) in memory location <em>mem32int</em> and pop the floating-point register stack.</td>
    </tr>
    <tr>
        <td>FISTTP <em>mem64int</em></td>
        <td>DD /1</td>
        <td>Store the truncated floating-point value in ST(0) in memory location <em>mem64int</em> and pop the floating-point register stack.</td>
    </tr>
  </tbody>
</table>

Table 2-2 shows the results of storing various types of numbers as integers.

Table 2-2. Storing Numbers as Integers

<table>
  <thead>
    <tr>
        <th>ST(0)</th>
        <th>DESTINATION</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>-∞</td>
        <td>Invalid-operation (IE) exception</td>
    </tr>
    <tr>
        <td>-Finite-real ≤ -1</td>
        <td>-Integer (Invalid-operation (IE) exception if the integer is too large for the destination)</td>
    </tr>
    <tr>
        <td>-1 &lt; Finite-real &lt; +1</td>
        <td>0</td>
    </tr>
    <tr>
        <td>+Finite-real ≥ +1</td>
        <td>+Integer (Invalid-operation (IE) exception if the integer is too large for the destination)</td>
    </tr>
    <tr>
        <td>+∞</td>
        <td>Invalid-operation (IE) exception</td>
    </tr>
    <tr>
        <td>NaN</td>
        <td>Invalid-operation (IE) exception</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FST, FSTP, FILD, FBLD, FBSTP, FISTP

## rFLAGS Affected

None

x87 Floating-Point FISTTP 261
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value*</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td rowspan="2">0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>FP number is rounded down (always done since the instruction forces truncate mode).</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

**Note:** *A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.*

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>#UDXXX</td>
      <td></td>
      <td></td>
      <td></td>
      <td>The SSE3 instructions are not supported, as indicated by 
CPUID Fn0000_0001_ECX[SSE3] = 0.</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection,</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td>#GP</td>
      <td></td>
      <td></td>
      <td>XThe</td>
      <td>destination operand was in a nonwritable segment.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The source operand was too large for the destination 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value, a QNaN value,+-
infinity, or an unsupported format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

<page_number>

262
</page_number>

**FISTTP** x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FLD

# Floating-Point Load

Pushes a value in memory or in a floating-point register onto the register stack. If in memory, the value can be a single-precision, double-precision, or double-extended-precision floating-point value. The operation converts a single-precision or double-precision value to double-extended-precision format before pushing it onto the stack.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLD ST(i)</td>
        <td>D9 C0+i</td>
        <td>Push the contents of ST(i) onto the x87 register stack.</td>
    </tr>
    <tr>
        <td>FLD mem32real</td>
        <td>D9 /0</td>
        <td>Push the contents of mem32real onto the x87 register stack.</td>
    </tr>
    <tr>
        <td>FLD mem64real</td>
        <td>DD /0</td>
        <td>Push the contents of mem64real onto the x87 register stack.</td>
    </tr>
    <tr>
        <td>FLD mem80real</td>
        <td>DB /5</td>
        <td>Push the contents of mem80real onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FFREE, FST, FSTP, FILD, FIST, FISTP, FBLD, FBSTP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="3">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>No x87 stack fault.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point
Instruction Reference
FLD
[AMD Confidential - Distribution with NDA]
<page_number>

263
</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value. This exception does 
not occur if the source operand was in double-extended
precision format.</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was a denormal value. This exception 
does not occur if the source operand was in double
extended-precision format.</td>
    </tr>
  </tbody>
</table>

<page_number>264</page_number>

FLD x87 Floating-Point Instruction Reference
[AMD Confidential - Distribution with NDA]

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FLD1

# Floating-Point Load +1.0

Pushes the floating-point value +1.0 onto the register stack.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLD1</td>
        <td>D9 E8</td>
        <td>Push +1.0 onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FLDZ, FLDPI, FLDL2T, FLDL2E, FLDLG2, FLDLN2

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>No x87 stack fault occurred.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <th colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</th>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point
Instruction Reference
FLD1
[AMD Confidential - Distribution with NDA]

<page_number>265</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# FLDCW Floating-Point Load x87 Control Word

Loads a 16-bit value from the specified memory location into the x87 control word. If the new x87 control word unmasks any pending floating point exceptions, then they are handled upon execution of the next x87 floating-point or 64-bit media instruction.

To avoid generating exceptions when loading a new control word, use the FCLEX or FNCLEX instruction to clear any pending exceptions.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLDCW mem2env</td>
        <td>D9 /5</td>
        <td>Load the contents of mem2env into the x87 control word.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSTCW, FNSTCW, FSTSW, FNSTSW, FSTENV, FNSTENV, FLDENV, FCLEX, FNCLEX

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

\*Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.

<page_number>266</page_number>

[AMD Confidential - Distribution with NDA]
FLDCW x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point**
**FLDCW**
<mark>[AMD Confidential - Distribution with NDA]</mark>
**Instruction Reference**

<page_number>267</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# FLDENV Floating-Point Load x87 Environment

Restores the x87 environment from memory starting at the specified address. The x87 environment consists of the x87 control, status, and tag word registers, the last non-control x87 instruction pointer, the last x87 data pointer, and the opcode of the last completed non-control x87 instruction.

The FLDENV instruction takes a memory operand that specifies the starting address of either a 14-byte or 28-byte area in memory. The 14-byte operand is required for a 16-bit operand-size; the 28-byte memory area is required for both 32-bit and 64-bit operand sizes. The layout of the saved x87 environment within the specified memory area depends on whether the processor is operating in protected or real mode. See “Media and x87 Processor State” in Volume 2 for details on how this instruction loads the x87 environment from memory. (Because FSTENV does not save the full 64-bit data and instruction pointers, 64-bit applications should use FXSAVE/FXRSTOR, rather than FSTENV/FLDENV.)

The environment to be loaded is typically stored by a previous FNSTENV or FSTENV instruction. The FLDENV instruction should be executed in the same operating mode as the instruction that stored the x87 environment.

If FLDENV results in set exception flags in the loaded x87 status word register, and these exceptions are unmasked in the x87 control word register, a floating-point exception occurs when the next floating-point instruction is executed (except for the no-wait floating-point instructions).

To avoid generating exceptions when loading a new environment, use the FCLEX or FNCLEX instruction to clear the exception flags in the x87 status word before storing that environment.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLDENV mem14/28env</td>
        <td>D9 /4</td>
        <td>Load the complete contents of the x87 environment from mem14/28env.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSTENV, FNSTENV, FCLEX, FNCLEX

## rFLAGS Affected

None

<page_number>

268
</page_number>

FLDENV x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021 AMD logo

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C1</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C3</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point FLDENV**
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>269</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FLDL2E Floating-Point Load Log<sub>2</sub> e

Pushes log<sub>2</sub>e onto the x87 register stack. The value in ST(0) is the result, in double-extended-precision format, of rounding an internal 66-bit constant according to the setting of the RC field in the x87 control word register.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLDL2E</td>
        <td>D9 EA</td>
        <td>Push log2e onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FLD1, FLDZ, FLDPI, FLDL2T, FLDLG2, FLDLN2

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>No x87 stack fault occurred.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <th colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</th>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

<page_number>270</page_number>

FLDL2E x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FLDL2T Floating-Point Load Log<sub>2</sub> 10

Pushes log<sub>2</sub> 10 onto the x87 register stack. The value in ST(0) is the result, in double-extended-precision format, of rounding an internal 66-bit constant according to the setting of the RC field in the x87 control word register.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLDL2T</td>
        <td>D9 E9</td>
        <td>Push log<sub>2</sub>10 onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FLD1, FLDZ, FLDPI, FLDL2E, FLDLG2, FLDLN2

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>No x87 stack fault occurred.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point
Instruction Reference

FLDL2T

[AMD Confidential - Distribution with NDA]

<page_number>271</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FLDLG2

# Floating-Point Load Log<sub>10</sub> 2

Pushes log<sub>10</sub> 2 onto the x87 register stack. The value in ST(0) is the result, in double-extended-precision format, of rounding an internal 66-bit constant according to the setting of the RC field in the x87 control word register.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLDLG2</td>
        <td>D9 EC</td>
        <td>Push log<sub>10</sub>2 onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FLD1, FLDZ, FLDPI, FLDL2T, FLDL2E, FLDLN2

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>No x87 stack fault occurred.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

<page_number>

272
</page_number>

FLDLG2 x87 Floating-Point Instruction Reference
[AMD Confidential - Distribution with NDA]

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# FLDLN2

# Floating-Point Load Ln 2

Pushes log<sub>e</sub>2 onto the x87 register stack. The value in ST(0) is the result, in double-extended-precision format, of rounding an internal 66-bit constant according to the setting of the RC field in the x87 control word register.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLDLN2</td>
        <td>D9 ED</td>
        <td>Push log<sub>e</sub>2 onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FLD1, FLDZ, FLDPI, FLDL2T, FLDL2E, FLDLG2

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>No x87 stack fault occurred.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference

FLDLN2

[AMD Confidential - Distribution with NDA]

<page_number>273</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FLDPI

# Floating-Point Load Pi

Pushes π onto the x87 register stack. The value in ST(0) is the result, in double-extended-precision format, of rounding an internal 66-bit constant according to the setting of the RC field in the x87 control word register.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLDPI</td>
        <td>D9 EB</td>
        <td>Push π onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FLD1, FLDZ, FLDL2T, FLDL2E, FLDLG2, FLDLN2

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>No x87 stack fault occurred.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

<page_number>274</page_number>

[AMD Confidential - Distribution with NDA]
**FLDPI**
**x87 Floating-Point Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FLDZ

# Floating-Point Load +0.0

Pushes +0.0 onto the x87 register stack.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLDZ</td>
        <td>D9 EE</td>
        <td>Push zero onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FLD1, FLDPI, FLDL2T, FLDL2E, FLDLG2, FLDLN2

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>No x87 stack fault occurred.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference

[AMD Confidential - Distribution with NDA]

FLDZ

<page_number>275</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FMUL
# FMULP
# FIMUL

# Floating-Point Multiply

Multiplies the value in a floating-point register by the value in a memory location or another stack register and stores the result in the first register. The instruction converts a single-precision or double-precision value in memory to double-extended-precision format before multiplying.

If one operand is specified, the instruction multiplies the value in the ST(0) register by the value in the specified memory location and stores the result in the ST(0) register.

If two operands are specified, the instruction multiplies the value in the ST(0) register by the value in another specified floating-point register and stores the result in the register specified in the first operand.

The FMULP instruction pops the x87 stack after storing the product. The no-operand version of the FMULP instruction multiplies the value in the ST(1) register by the value in the ST(0) register and stores the product in the ST(1) register.

The FIMUL instruction converts a short-integer or word-integer value in memory to double-extended-precision format, multiplies it by the value in ST(0), and stores the product in ST(0).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FMUL ST(0),ST(i)</td>
        <td>D8 C8+i</td>
        <td>Replace ST(0) with ST(0) ∗ ST(i).</td>
    </tr>
    <tr>
        <td>FMUL ST(i),ST(0)</td>
        <td>DC C8+i</td>
        <td>Replace ST(i) with ST(0) ∗ ST(i).</td>
    </tr>
    <tr>
        <td>FMUL mem32real</td>
        <td>D8 /1</td>
        <td>Replace ST(0) with mem32real ∗ ST(0).</td>
    </tr>
    <tr>
        <td>FMUL mem64real</td>
        <td>DC /1</td>
        <td>Replace ST(0) with mem64real ∗ ST(0).</td>
    </tr>
    <tr>
        <td>FMULP</td>
        <td>DE C9</td>
        <td>Replace ST(1) with ST(0) ∗ ST(1), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FMULP ST(i),ST(0)</td>
        <td>DE C8+i</td>
        <td>Replace ST(i) with ST(0) ∗ ST(i), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FIMUL mem16int</td>
        <td>DE /1</td>
        <td>Replace ST(0) with mem16int ∗ ST(0).</td>
    </tr>
    <tr>
        <td>FIMUL mem32int</td>
        <td>DA /1</td>
        <td>Replace ST(0) with mem32int ∗ ST(0).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

None

## rFLAGS Affected

None

<page_number>

276
</page_number>

**FMULx**
**x87 Floating-Point Instruction Reference**
[AMD Confidential — Distribution with NDA]

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td rowspan="3">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th>8086Protected</th>
      <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXX±infinity</td>
      <td>was multiplied by ±zero.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference [AMD Confidential - Distribution with NDA] FMULx

<page_number>277</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Underflow exception (UE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A rounded result was too small to fit into the format of the destination operand.</td>
    </tr>
    <tr>
        <td>Precision exception (PE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A result could not be represented exactly in the destination format.</td>
    </tr>
  </tbody>
</table>

<page_number>278</page_number> **FMULx** x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FNOP

# Floating-Point No Operation

Performs no operation. This instruction affects only the rIP register. It does not otherwise affect the processor context.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FNOP</td>
        <td>D9 D0</td>
        <td>Perform no operation.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FWAIT, NOP

## rFLAGS Affected

None

## x87 Condition Code

None

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point
Instruction Reference
FNOP
[AMD Confidential - Distribution with NDA]

<page_number>279</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FPATAN

# Floating-Point Partial Arctangent

Computes the arctangent of the ordinate (Y) in ST(1) divided by the abscissa (X) in ST(0), which is the angle in radians between the X axis and the radius vector from the origin to the point (X, Y). It then stores the result in ST(1) and pops the x87 register stack. The resulting value has the same sign as the ordinate value and a magnitude less than or equal to π.

There is no restriction on the range of values that FPATAN can accept. Table 2-3 shows the results obtained when computing the arctangent of various classes of numbers, assuming that underflow does not occur:

Table 2-3. Computing Arctangent of Numbers

<table>
  <thead>
    <tr>
        <th> </th>
        <th colspan="7">X (ST(0))</th>
    </tr>
    <tr>
        <th> </th>
        <th>–∞</th>
        <th>–Finite</th>
        <th>–0</th>
        <th>+0</th>
        <th>+Finite</th>
        <th>+∞</th>
        <th>NaN</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>–∞</td>
        <td>–3π/4</td>
        <td>–π/2</td>
        <td>–π/2</td>
        <td>–π/2</td>
        <td>–π/2</td>
        <td>–π/4</td>
        <td>NaN</td>
    </tr>
    <tr>
        <td>–Finite</td>
        <td>–π</td>
        <td>–π to –π/2</td>
        <td>–π/2</td>
        <td>–π/2</td>
        <td>–π/2 to –0</td>
        <td>–0</td>
        <td>NaN</td>
    </tr>
    <tr>
        <td>–0</td>
        <td>–π</td>
        <td>–π</td>
        <td>–π</td>
        <td>–0</td>
        <td>–0</td>
        <td>–0</td>
        <td>NaN</td>
    </tr>
    <tr>
        <td>+0</td>
        <td>+π</td>
        <td>+π</td>
        <td>+π</td>
        <td>+0</td>
        <td>+0</td>
        <td>+0</td>
        <td>NaN</td>
    </tr>
    <tr>
        <td>+Finite</td>
        <td>+π</td>
        <td>+π to +π/2</td>
        <td>+π/2</td>
        <td>+π/2</td>
        <td>+π/2 to +0</td>
        <td>+0</td>
        <td>NaN</td>
    </tr>
    <tr>
        <td>+∞</td>
        <td>+3π/4</td>
        <td>+π/2</td>
        <td>+π/2</td>
        <td>+π/2</td>
        <td>+π/2</td>
        <td>+π/4</td>
        <td>NaN</td>
    </tr>
    <tr>
        <td>Y (ST(1))</td>
        <td>NaN</td>
        <td>NaN</td>
        <td>NaN</td>
        <td>NaN</td>
        <td>NaN</td>
        <td>NaN</td>
        <td>NaN</td>
    </tr>
  </tbody>
</table>
<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>

FPATAN</td>
        <td>D9 F3</td>
        <td>Compute arctan(ST(1)/ST(0)), store the result in ST(1), and pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOS, FPTAN, FSIN, FSINCOS

## rFLAGS Affected

None

<page_number>

280
</page_number>

FPATAN x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021 AMD
AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

**Note:** A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FPATAN 281
Instruction Reference [AMD Confidential - Distribution with NDA]

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FPREM Floating-Point Partial Remainder

Computes the exact remainder obtained by dividing the value in ST(0) by that in ST(1), and stores the result in ST(0). It computes the remainder by an iterative subtract-and-shift long division algorithm in which one quotient bit is calculated in each iteration.

If the exponent difference between ST(0) and ST(1) is less than 64, the instruction computes all integer bits of the quotient, guaranteeing that the remainder is less in magnitude than the divisor in ST(1). If the exponent difference is equal to or greater than 64, it computes only the subset of integer quotient bits numbering between 32 and 63, returns a partial remainder, and sets the C2 condition code bit to 1.

FPREM is supported for software that was written for early x87 coprocessors. Unlike the FPREM1 instruction, FPREM does not compute the partial remainder as specified in IEEE Standard 754.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FPREM</td>
        <td>D9 F8</td>
        <td>Compute the remainder of the division of ST(0) by ST(1) and store the result in ST(0).</td>
    </tr>
  </tbody>
</table>

## Action

```
ExpDiff = Exponent(ST(0)) - Exponent(ST(1))
IF (ExpDiff < 0)
{
    SW.C2 = 0
    {SW.C0, SW.C3, SW.C1} = 0
}
ELSIF (ExpDiff < 64)
{
    Quotient = Truncate(ST(0)/ST(1))
    ST(0) = ST(0) - (ST(1) * Quotient)
    SW.C2 = 0
    {SW.C0, SW.C3, SW.C1} = Quotient mod 8
}
ELSE
{
    N = 32 + (ExpDiff mod 32)
    Quotient = Truncate ((ST(0)/ST(1))/2^(ExpDiff-N))
    ST(0) = ST(0) - (ST(1) * Quotient * 2^(ExpDiff-N))
    SW.C2 = 1
    {SW.C0, SW.C3, SW.C1} = 0
}
```

## Related Instructions

FPREM1, FABS, FRNDINT, FXTRACT, FCHS

## rFLAGS Affected

None

<page_number>

282
</page_number>

[AMD Confidential - Distribution with NDA]
FPREM x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>M</td>
        <td>Set equal to the value of bit 2 of the quotient.</td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>M</td>
        <td>Set equal to the value of bit 0 of the quotient, if there was no fault.</td>
    </tr>
    <tr>
        <td rowspan="2">C2</td>
        <td>0</td>
        <td>FPREM generated the partial remainder.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>The source operands differed by more than a factor of 2<sup>64</sup>, so the result is incomplete.</td>
    </tr>
    <tr>
        <td>C3</td>
        <td>M</td>
        <td>Set equal to the value of bit 1 of the quotient.</td>
    </tr>
  </tbody>
</table>

**Note:** *A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.*

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the control 
register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td></td>
      <td>XXXST(0)</td>
      <td>was ±infinity.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXST(1)</td>
      <td>was ±zero.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FPREM
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>283</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FPREM1

# Floating-Point Partial Remainder

Computes the IEEE Standard 754 remainder obtained by dividing the value in ST(0) by that in ST(1), and stores the result in ST(0). Unlike FPREM, it rounds the integer quotient to the nearest even integer and returns the remainder corresponding to the back multiply of the rounded quotient.

If the exponent difference between ST(0) and ST(1) is less than 64, the instruction computes all integer as well as additional fractional bits of the quotient to do the rounding. The remainder returned is a complete remainder and is less than or equal to one half of the magnitude of the divisor. If the exponent difference is equal to or greater than 64, it computes only the subset of integer quotient bits numbering between 32 and 63, returns the partial remainder, and sets the C2 condition code bit to 1.

Rounding control has no effect. FPREM1 results are exact.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FPREM1</td>
        <td>D9 F5</td>
        <td>Compute the IEEE standard 754 remainder of the division of ST(0) by ST(1) and store the result in ST(0).</td>
    </tr>
  </tbody>
</table>

## Action

```
ExpDiff = Exponent(ST(0)) - Exponent(ST(1))
IF (ExpDiff < 0)
{
  SW.C2 = 0
  {SW.C0, SW.C3, SW.C1} = 0
}
ELSIF (ExpDiff < 64)
{
  Quotient = Integer obtained by rounding (ST(0)/ST(1))
            to nearest even integer
  ST(0) = ST(0) - (ST(1) * Quotient)
  SW.C2 = 0
  {SW.C0, SW.C3, SW.C1} = Quotient mod 8
}
ELSE
{
  N = 32 + (ExpDiff mod 32)
  Quotient = Truncate ((ST(0)/ST(1))/2^(ExpDiff-N))
  ST(0) = ST(0) - (ST(1) * Quotient * 2^(ExpDiff-N))
  SW.C2 = 1
  {SW.C0, SW.C3, SW.C1} = 0
}
```

## Related Instructions

FPREM, FABS, FRNDINT, FXTRACT, FCHS

<page_number>

284
</page_number>

[AMD Confidential - Distribution with NDA] **FPREM1** x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>M</td>
        <td>Set equal to the value of bit 2 of the quotient.</td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>M</td>
        <td>Set equal to the value of the bit 0 of the quotient, if there was no fault.</td>
    </tr>
    <tr>
        <td rowspan="2">C2</td>
        <td>0</td>
        <td>FPREM1 generated the partial remainder.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>The source operands differed by more than a factor of 2<sup>64</sup>, so the result is incomplete.</td>
    </tr>
    <tr>
        <td>C3</td>
        <td>M</td>
        <td>Set equal to the value of bit 1 of the quotient.</td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td></td>
      <td>XXXST(0)</td>
      <td>was ±infinity.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXST(1)</td>
      <td>was ±zero.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-PointInstruction Reference**

FPREM1
<mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>285</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FPTAN Floating-Point Partial Tangent

Computes the tangent of the radian value in ST(0), stores the result in ST(0), and pushes a value of 1.0 onto the x87 register stack.

The source value must be between –2<sup>63</sup> and +2<sup>63</sup> radians. If the source value lies outside the specified range, the instruction sets the C2 bit of the x87 status word to 1 and does not change the value in ST(0).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FPTAN</td>
        <td>D9 F2</td>
        <td>Replace ST(0) with the tangent of ST(0), then push 1.0 onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOS, FPATAN, FSIN, FSINCOS

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td rowspan="2">C2</td>
        <td>0</td>
        <td>Source operand was in range.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Source operand was out of range.</td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>286</page_number>

[AMD Confidential - Distribution with NDA] **FPTAN** x87 Floating-Point Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the control 
register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was ±infinity</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference
FPTAN
[AMD Confidential - Distribution with NDA]

<page_number>287</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FRNDINT Floating-Point Round to Integer

Rounds the value in ST(0) to an integer, depending on the setting of the rounding control (RC) field of the x87 control word, and stores the result in ST(0).

If the initial value in ST(0) is ∞, the instruction does not change ST(0). If the value in ST(0) is not an integer, it sets the precision exception (PE) bit of the x87 status word to 1.

<table>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
    <tr>
        <td>FRNDINT</td>
        <td>D9 FC</td>
        <td>Round the contents of ST(0) to an integer.</td>
    </tr>
</table>

## Related Instructions

FABS, FPREM, FXTRACT, FCHS

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td rowspan="3">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>

288
</page_number>

FRNDINT x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>source operand was not an integral value.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FRNDINT [AMD Confidential - Distribution with NDA] Instruction Reference

<page_number>289</page_number>

AMD

AMD64 Technology

26569—Rev. 3.16—November 2021

# FRSTOR Floating-Point Restore x87 and MMX™ State

Restores the complete x87 state from memory starting at the specified address, as stored by a previous call to F(N)SAVE.

The FRSTOR instruction takes a memory operand that specifies the starting address of either a 94-byte or 108-byte area in memory. The 94-byte operand is required for a 16-bit operand-size; the 108-byte memory area is required for both 32-bit and 64-bit operand sizes. The layout of the saved x87 state within the specified memory area depends on whether the processor is operating in protected or real mode. See “Media and x87 Processor State” in Volume 2 for details on how this instruction stores the x87 environment in memory. (Because FSAVE does not save the full 64-bit data and instruction pointers, 64-bit applications should use FXSAVE/FXRSTOR, rather than FSAVE/FRSTOR.)

Because the MMX registers are mapped onto the low 64 bits of the x87 floating-point registers, this operation also restores the MMX state.

If FRSTOR results in set exception flags in the loaded x87 status word register, and these exceptions are unmasked in the x87 control word register, a floating-point exception occurs when the next floating-point instruction is executed (except for the no-wait floating-point instructions).

To avoid generating exceptions when loading a new environment, use the FCLEX or FNCLEX instruction to clear the exception flags in the x87 status word before storing that environment.

For details about the memory image restored by FRSTOR, see “Media and x87 Processor State” in Volume 2.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FRSTOR mem94/108env</td>
        <td>DD /4</td>
        <td>Load the x87 state from mem94/108env.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSAVE, FNSAVE, FXSAVE, FXRSTOR

## rFLAGS Affected

None

<page_number>

290
</page_number>

FRSTOR x87 Floating-Point [AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C1</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td>C3</td>
        <td>M</td>
        <td>Loaded from memory.</td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="2">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point**
**Instruction Reference**
**FRSTOR**
[AMD Confidential - Distribution with NDA]

<page_number>291</page_number>

AMD
AMD64 Technology

26569—Rev. 3.16—November 2021

# FSAVE Floating-Point Save x87 and MMX™ State
# FNSAVE

Stores the complete x87 state to memory starting at the specified address and reinitializes the x87 state.

The FSAVE instruction takes a memory operand that specifies the starting address of either a 94-byte or 108-byte area in memory. The 94-byte operand is required for a 16-bit operand-size; the 108-byte memory area is required for both 32-bit and 64-bit operand sizes. The layout of the saved x87 state within the specified memory area depends on whether the processor is operating in protected or real mode. See “Media and x87 Processor State” in Volume 2 for details on how this instruction stores the x87 environment in memory. (Because FSAVE does not save the full 64-bit data and instruction pointers, 64-bit applications should use FXSAVE/FXRSTOR, rather than FSAVE/FRSTOR.)

Because the MMX registers are mapped onto the low 64 bits of the x87 floating-point registers, this operation also saves the MMX state.

The FNSAVE instruction does not wait for pending unmasked x87 floating-point exceptions to be processed.

Assemblers usually provide an FSAVE macro that expands into the instruction sequence

```
WAIT                           ; Opcode 9B
FNSAVE destination             ; Opcode DD /6
```

The WAIT (9Bh) instruction checks for pending x87 exceptions and calls an exception handler, if necessary. The FNSAVE instruction then stores the x87 state to the specified destination.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSAVE mem94/108env</td>
        <td>9B DD /6</td>
        <td>Copy the x87 state to mem94/108env after checking for pending floating-point exceptions, then reinitialize the x87 state.</td>
    </tr>
    <tr>
        <td>FNSAVE mem94/108env</td>
        <td>DD /6</td>
        <td>Copy the x87 state to mem94/108env without checking for pending floating-point exceptions, then reinitialize the x87 state.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FRSTOR, FXSAVE, FXRSTOR

## rFLAGS Affected

None

<page_number>292</page_number>

FSAVE (FNSAVE) x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>0</td>
        <td> </td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>The destination operand was in a nonwritable segment.</td>
        <td></td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference
FSAVE (FNSAVE)
[AMD Confidential - Distribution with NDA]

<page_number>293</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# FSCALE Floating-Point Scale

Multiplies the floating-point value in ST(0) by 2 to the power of the integer portion of the floating-point value in ST(1).

This instruction provides an efficient method of multiplying (or dividing) by integral powers of 2 because, typically, it simply adds the integer value to the exponent of the value in ST(0), leaving the significand unaffected. However, if the value in ST(0) is a denormal value, the mantissa is also modified and the result may end up being a normalized number. Likewise, if overflow or underflow results from a scale operation, the mantissa of the resulting value will be different from that of the source.

The FSCALE instruction performs the reverse operation to that of the FXTRACT instruction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSCALE</td>
        <td>D9 FD</td>
        <td>Replace ST(0) with ST(0) ∗ 2<sup>rndint(ST(1))</sup></td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSQRT, FPREM, FPREM1, FRNDINT, FXTRACT, FABS, FCHS

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td>Undefined.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td>Undefined.</td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td>Undefined.</td>
    </tr>
    <tr>
        <th colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</th>
    </tr>
  </tbody>
</table>

<page_number>

294
</page_number>

FSCALE x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD

26569—Rev. 3.16—November 2021

AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point **FSCALE** [AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>295</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FSIN Floating-Point Sine

Computes the sine of the radian value in ST(0) and stores the result in ST(0).

The source value must be in the range –2<sup>63</sup> to +2<sup>63</sup> radians. If the value lies outside this range, the instruction sets the C2 bit in the x87 status word to 1 and does not change the value in ST(0).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSIN</td>
        <td>D9 FE</td>
        <td>Replace ST(0) with the sine of ST(0).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOS, FPATAN, FPTAN, FSINCOS

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td rowspan="2">C2</td>
        <td>0</td>
        <td>Source operand was in range.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Source operand was out of range.</td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>

296
</page_number>

[AMD Confidential - Distribution with NDA]
**FSIN**
x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was ±infinity.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FSIN [AMD Confidential - Distribution with NDA] Instruction Reference

<page_number>297</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FSINCOS Floating-Point Sine and Cosine

Computes the sine and cosine of the value in ST(0), stores the sine in ST(0), and pushes the cosine onto the x87 register stack. The source value must be in the range –2<sup>63</sup> to +2<sup>63</sup> radians.

If the source operand is outside this range, the instruction sets the C2 bit in the x87 status word to 1 and does not change the value in ST(0).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSINCOS</td>
        <td>D9 FB</td>
        <td>Replace ST(0) with the sine of ST(0), then push the cosine of ST(0) onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOS, FPATAN, FPTAN, FSIN

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td rowspan="5">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result in ST(1) was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result in ST(1) was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Source operand was in range.</td>
    </tr>
    <tr>
        <td rowspan="2">C2</td>
        <td>1</td>
        <td>Source operand was out of range.</td>
    </tr>
    <tr>
        <td> </td>
        <td></td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

<page_number>

298
</page_number>

FSINCOS x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021 AMD64 Technology AMD logo

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the control 
register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was ±infinity.</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point **FSINCOS** 299
Instruction Reference [AMD Confidential - Distribution with NDA]
<page_number>299</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

# FSQRT Floating-Point Square Root

Computes the square root of the value in ST(0) and stores the result in ST(0). Taking the square root of +infinity returns +infinity.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSQRT</td>
        <td>D9 FA</td>
        <td>Replace ST(0) with the square root of ST(0).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSCALE, FPREM, FPREM1, FRNDINT, FXTRACT, FABS, FCHS

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

300 FSQRT x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was a negative value (not including -
zero).</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FSQRT <page_number>301</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FST Floating-Point Store Stack Top
# FSTP

Copies the value in ST(0) to the specified floating-point register or memory location.

The FSTP instruction pops the x87 stack after copying the value. The instruction FSTP ST(0) is the same as popping the stack with no data transfer.

If the specified destination is a single-precision or double-precision memory location, the instruction converts the value to the appropriate precision format. It does this by rounding the significand of the source value as specified by the rounding mode determined by the RC field of the x87 control word and then converting to the format of destination. It also converts the exponent to the width and bias of the destination format.

If the value is too large for the destination format, the instruction sets the overflow exception (OE) bit of the x87 status word. Then, if the overflow exception is unmasked (OM bit cleared to 0 in the x87 control word), the instruction does not perform the store.

If the value is a denormal value, the instruction sets the underflow exception (UE) bit in the x87 status word.

If the value is ±0, ±∞, or a NaN, the instruction truncates the least significant bits of the significand and exponent to fit the destination location.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FST ST(i)</td>
        <td>DD D0+i</td>
        <td>Copy the contents of ST(0) to ST(i).</td>
    </tr>
    <tr>
        <td>FST mem32real</td>
        <td>D9 /2</td>
        <td>Copy the contents of ST(0) to mem32real.</td>
    </tr>
    <tr>
        <td>FST FST mem64real</td>
        <td>DD /2</td>
        <td>Copy the contents of ST(0) to mem64real.</td>
    </tr>
    <tr>
        <td>FSTP ST(i)</td>
        <td>DD D8+i</td>
        <td>Copy the contents of ST(0) to ST(i) and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FSTP mem32real</td>
        <td>D9 /3</td>
        <td>Copy the contents of ST(0) to mem32real and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FSTP mem64real</td>
        <td>DD /3</td>
        <td>Copy the contents of ST(0) to mem64real and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FSTP mem80real</td>
        <td>DB /7</td>
        <td>Copy the contents of ST(0) to mem80real and pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FFREE, FLD, FILD, FIST, FISTP, FBLD, FBSTP

## rFLAGS Affected

None

<page_number>302</page_number> FSTx x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

**Note:** A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection,</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td>#GP</td>
      <td></td>
      <td></td>
      <td>XThe</td>
      <td>destination operand was in a nonwritable segment.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the 
destination format.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference
FSTx
[AMD Confidential - Distribution with NDA]

<page_number>303</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FSTCW (FNSTCW) Floating-Point Store Control Word

Stores the x87 control word in the specified 2-byte memory location. The FNSTCW instruction does not check for possible floating-point exceptions before copying the image of the x87 status register.

Assemblers usually provide an FSTCW macro that expands into the instruction sequence:

```
WAIT                     ; Opcode 9B
FNSTCW destination       ; Opcode D9 /7
```

The WAIT (9Bh) instruction checks for pending x87 exception and calls an exception handler, if necessary. The FNSTCW instruction then stores the state of the x87 control register to the desired destination.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSTCW mem2env</td>
        <td>9B D9 /7</td>
        <td>Perform a WAIT (9B) to check for pending floating-point exceptions, then copy the x87 control word to mem2env.</td>
    </tr>
    <tr>
        <td>FNSTCW mem2env</td>
        <td>D9 /7</td>
        <td>Copy the x87 control word to mem2env without checking for floating-point exceptions.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSTSW, FNSTSW, FSTENV, FNSTENV

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
  </tbody>
</table>

\*Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.

<page_number>

304
</page_number>

FSTCW (FNSTCW) x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>The destination operand was in a nonwritable segment.</td>
        <td></td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point**
**Instruction Reference**

FSTCW (FNSTCW)
[AMD Confidential - Distribution with NDA]

<page_number>305</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FSTENV (FNSTENV) Floating-Point Store Environment

Stores the current x87 environment to memory starting at the specified address, and then masks all floating-point exceptions. The x87 environment consists of the x87 control, status, and tag word registers, the last non-control x87 instruction pointer, the last x87 data pointer, and the opcode of the last completed non-control x87 instruction.

The FSTENV instruction takes a memory operand that specifies the start of either a 14-byte or 28-byte area in memory. The 14-byte operand is required for a 16-bit operand-size; the 28-byte memory area is required for both 32-bit and 64-bit operand sizes. The layout of the saved x87 environment within the specified memory area depends on whether the processor is operating in protected or real mode. See "Media and x87 Processor State" in Volume 2 for details on how this instruction stores the x87 environment in memory. (Because FLDENV/FSTENV do not save the full 64-bit data and instruction pointers, 64-bit applications should use FXSAVE/FXRSTOR, rather than FLDENV/FSTENV.)

The FNSTENV instruction does not check for possible floating-point exceptions before storing the environment.

Assemblers usually provide an FSTENV macro that expands into the instruction sequence

```
WAIT                ; Opcode 9B
FNSTENV destination ; Opcode D9 /6
```

The WAIT (9Bh) instruction checks for pending x87 exceptions and calls an exception handler if necessary. The FNSTENV instruction then stores the state of the x87 environment to the specified destination.

Exception handlers often use these instructions because they provide access to the x87 instruction and data pointers. An exception handler typically saves the environment on the stack. The instructions mask all floating-point exceptions after saving the environment to prevent those exceptions from interrupting the exception handler.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSTENV<br/>mem14/28env</td>
        <td>9B D9 /6</td>
        <td>Perform a WAIT (9B) to check for pending floating-point exceptions, then copy the x87 environment to mem14/28env and mask the floating-point exceptions.</td>
    </tr>
    <tr>
        <td>FNSTENV<br/>mem14/28env</td>
        <td>D9 /6</td>
        <td>Copy the x87 environment to mem14/28env without checking for pending floating-point exceptions, and mask the exceptions.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLDENV, FSTSW, FNSTSW, FSTCW, FNSTCW

<page_number>306</page_number> FSTENV (FNSTENV) x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# rFLAGS Affected

None

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th colspan="3">Virtual</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>Real</th>
        <th>8086</th>
        <th>Protected</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>The destination operand was in a nonwritable segment.</td>
        <td></td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point **FSTENV (FNSTENV)** <page_number>307</page_number>

[AMD Confidential - Distribution with NDA]

Instruction Reference

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FSTSW (FNSTSW) Floating-Point Store Status Word

Stores the current state of the x87 status word register in either the AX register or a specified two-byte memory location. The image of the status word placed in the AX register always reflects the result after the execution of the previous x87 instruction.

The AX form of the instruction is useful for performing conditional branching operations based on the values of x87 condition flags.

The FNSTSW instruction does not check for possible floating-point exceptions before storing the x87 status word.

Assemblers usually provide an FSTSW macro that expands into the instruction sequence:

```
WAIT                ; Opcode 9B
FNSTSW destination  ; Opcode DD /7 or DF E0
```

The WAIT (9Bh) instruction checks for pending x87 exceptions and calls an exception handler if necessary. The FNSTSW instruction then stores the state of the x87 status register to the desired destination.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSTSW AX</td>
        <td>9B DF E0</td>
        <td>Perform a WAIT (9B) to check for pending floating-point exceptions, then copy the x87 status word to the AX register.</td>
    </tr>
    <tr>
        <td>FSTSW <em>mem2env</em></td>
        <td>9B DD /7</td>
        <td>Perform a WAIT (9B) to check for pending floating-point exceptions, then copy the x87 status word to <em>mem12byte</em>.</td>
    </tr>
    <tr>
        <td>FNSTSW AX</td>
        <td>DF E0</td>
        <td>Copy the x87 status word to the AX register without checking for pending floating-point exceptions.</td>
    </tr>
    <tr>
        <td>FNSTSW <em>mem2env</em></td>
        <td>DD /7</td>
        <td>Copy the x87 status word to <em>mem12byte</em> without checking for pending floating-point exceptions.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSTCW, FNSTCW, FSTENV, FNSTENV

## rFLAGS Affected

None

<page_number>308</page_number>

FSTSW (FNSTSW) x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) was set to 1.</td>
    </tr>
    <tr>
        <td>Stack, #SS</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded the stack segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td rowspan="3">General protection, #GP</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A memory address exceeded a data segment limit or was non-canonical.</td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>The destination operand was in a nonwritable segment.</td>
        <td></td>
    </tr>
    <tr>
        <td> </td>
        <td>X</td>
        <td>A null data segment was used to reference memory.</td>
        <td></td>
    </tr>
    <tr>
        <td>Page fault, #PF</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>A page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
        <td>Alignment check, #AC</td>
        <td> </td>
        <td>X</td>
        <td>X</td>
        <td>An unaligned memory reference was performed while alignment checking was enabled.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point
**FSTSW (FNSTSW)**
[AMD Confidential - Distribution with NDA]
Instruction Reference

<page_number>309</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FSUB FSUBP FISUB

# Floating-Point Subtract

Subtracts the value in a floating-point register or memory location from the value in another register and stores the result in that register.

If no operands are specified, the instruction subtracts the value in ST(0) from that in ST(1) and stores the result in ST(1).

If one operand is specified, it subtracts a floating-point or integer value in memory from the contents of ST(0) and stores the result in ST(0).

If two operands are specified, it subtracts the value in ST(0) from the value in another floating-point register or vice versa.

The FSUBP instruction pops the x87 register stack after performing the subtraction.

The no-operand version of the instruction always pops the register stack. In some assemblers, the mnemonic for this instruction is FSUB rather than FSUBP.

The FISUB instruction converts a signed integer value to double-extended-precision format before performing the subtraction.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSUB ST(0),ST(i)</td>
        <td>D8 E0+i</td>
        <td>Replace ST(0) with ST(0) – ST(i).</td>
    </tr>
    <tr>
        <td>FSUB ST(i),ST(0)</td>
        <td>DC E8+i</td>
        <td>Replace ST(i) with ST(i) – ST(0).</td>
    </tr>
    <tr>
        <td>FSUB mem32real</td>
        <td>D8 /4</td>
        <td>Replace ST(0) with ST(0) – mem32real.</td>
    </tr>
    <tr>
        <td>FSUB mem64real</td>
        <td>DC /4</td>
        <td>Replace ST(0) with ST(0) – mem64real.</td>
    </tr>
    <tr>
        <td>FSUBP</td>
        <td>DE E9</td>
        <td>Replace ST(1) with ST(1) – ST(0) and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FSUBP ST(i),ST(0)</td>
        <td>DE E8+i</td>
        <td>Replace ST(i) with ST(i) – ST(0), and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FISUB mem16int</td>
        <td>DE /4</td>
        <td>Replace ST(0) with ST(0) – mem16int.</td>
    </tr>
    <tr>
        <td>FISUB mem32int</td>
        <td>DA /4</td>
        <td>Replace ST(0) with ST(0) – mem32int.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FSUBRP, FISUBR, FSUBR

## rFLAGS Affected

None

<page_number>

310
</page_number>

[AMD Confidential - Distribution with NDA]
FSUBx x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td></td>
      <td>XXX+infinity</td>
      <td>was subtracted from +infinity.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXX–infinity</td>
      <td>was subtracted from –infinity.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference [AMD Confidential - Distribution with NDA] FSUBx

<page_number>311</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Underflow exception (UE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A rounded result was too small to fit into the format of the destination operand.</td>
    </tr>
    <tr>
        <td>Precision exception (PE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A result could not be represented exactly in the destination format.</td>
    </tr>
  </tbody>
</table>

<page_number>312</page_number>

[AMD Confidential - Distribution with NDA] FSUBx x87 Floating-Point Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FSUBR FSUBRP FISUBR

# Floating-Point Subtract Reverse

Subtracts the value in a floating-point register from the value in another register or a memory location, and stores the result in the first specified register. Values in memory can be in single-precision or double-precision floating-point, word integer, or short integer format.

If one operand is specified, the instruction subtracts the value in ST(0) from the value in memory and stores the result in ST(0).

If two operands are specified, it subtracts the value in ST(0) from the value in another floating-point register or vice versa.

The FSUBRP instruction pops the x87 register stack after performing the subtraction.

The no-operand version of the instruction always pops the register stack. In some assemblers, the mnemonic for this instruction is FSUBR rather than FSUBRP.

The FISUBR instruction converts a signed integer operand to double-extended-precision format before performing the subtraction.

The FSUBR instructions perform the reverse operations of the FSUB instructions.

### Description

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FSUBR ST(0),ST(i)</td>
        <td>D8 E8+i</td>
        <td>Replace ST(0) with ST(i) - ST(0).</td>
    </tr>
    <tr>
        <td>FSUBR ST(i),ST(0)</td>
        <td>DC E0+i</td>
        <td>Replace ST(i) with ST(0) - ST(i).</td>
    </tr>
    <tr>
        <td>FSUBR mem32real</td>
        <td>D8 /5</td>
        <td>Replace ST(0) with mem32real - ST(0).</td>
    </tr>
    <tr>
        <td>FSUBR mem64real</td>
        <td>DC /5</td>
        <td>Replace ST(0) with mem64real - ST(0).</td>
    </tr>
    <tr>
        <td>FSUBRP</td>
        <td>DE E1</td>
        <td>Replace ST(1) with ST(0) - ST(1) and pop x87 stack.</td>
    </tr>
    <tr>
        <td>FSUBRP ST(i),ST(0)</td>
        <td>DE E0+i</td>
        <td>Replace ST(i) with ST(0) - ST(i) and pop x87 stack.</td>
    </tr>
    <tr>
        <td>FISUBR mem16int</td>
        <td>DE /5</td>
        <td>Replace ST(0) with mem16int - ST(0).</td>
    </tr>
    <tr>
        <td>FISUBR mem32int</td>
        <td>DA /5</td>
        <td>Replace ST(0) with mem32int - ST(0).</td>
    </tr>
  </tbody>
</table>

### Related Instructions

FSUB, FSUBP, FISUB

### rFLAGS Affected

None

x87 Floating-Point Instruction Reference
FSUBRx
[AMD Confidential - Distribution with NDA]

<page_number>313</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="3">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>Stack, #SS</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded the stack segment limit or 
was non-canonical.</td>
    </tr>
    <tr>
      <td>General protection, 
#GP</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A memory address exceeded a data segment limit or was 
non-canonical.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XA</td>
      <td>null data segment was used to reference memory.</td>
    </tr>
    <tr>
      <td>Page fault, #PF</td>
      <td></td>
      <td></td>
      <td>XXA</td>
      <td>page fault resulted from the execution of the instruction.</td>
    </tr>
    <tr>
      <td>Alignment check, 
#AC</td>
      <td></td>
      <td></td>
      <td>XX</td>
      <td>An unaligned memory reference was performed while 
alignment checking was enabled.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td></td>
      <td>XXX+infinity</td>
      <td>was subtracted from +infinity.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXX–infinity</td>
      <td>was subtracted from –infinity.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
  </tbody>
</table>

<page_number>314</page_number>

FSUBRx x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual<br/>8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Underflow exception (UE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A rounded result was too small to fit into the format of the destination operand.</td>
    </tr>
    <tr>
        <td>Precision exception (PE)</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>A result could not be represented exactly in the destination format.</td>
    </tr>
  </tbody>
</table>

**x87 Floating-Point Instruction Reference**
**FSUBRx**
[AMD Confidential - Distribution with NDA]

<page_number>315</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

# FTST Floating-Point Test with Zero

Compares the value in ST(0) with 0.0, and sets the condition code flags in the x87 status word as shown in the x87 Condition Code table below. The instruction ignores the sign distinction between –0.0 and +0.0.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FTST</td>
        <td>D9 E4</td>
        <td>Compare ST(0) to 0.0.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOM, FCOMP, FCOMPP, FCOMI, FCOMIP, FICOM, FICOMP, FUCOMI, FUCOMIP, FUCOM, FUCOMP, FUCOMPP, FXAM

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>C3</th>
        <th>C2</th>
        <th>C1</th>
        <th>C0</th>
        <th>Compare Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) &gt; 0.0</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>ST(0) &lt; 0.0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) = 0.0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>1</td>
        <td>0</td>
        <td>1</td>
        <td>ST(0) was unordered</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th>8086Protected</th>
      <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was a SNaN value, a QNaN value, or an 
unsupported format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
  </tbody>
</table>

<page_number>316</page_number> FTST x87 Floating-Point [AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FUCOM FUCOMP FUCOMPP Floating-Point Unordered Compare

Compares the value in ST(0) to the value in another x87 register, and sets the condition codes in the x87 status word as shown in the x87 Condition Code table below.

If no source operand is specified, the instruction compares the value in ST(0) to that in ST(1).

After making the comparison, the FUCOMP instruction pops the x87 stack register and the FUCOMPP instruction pops the x87 stack register twice.

The instruction carries out the same comparison operation as the FCOM instructions, but sets the invalid-operation exception (IE) bit in the x87 status word to 1 when either or both operands are an SNaN or are in an unsupported format. If either or both operands is a QNaN, it sets the condition code flags to unordered, but does not set the IE bit. The FCOM instructions, on the other hand, raise an IE exception when either or both of the operands are a NaN value or are in an unsupported format.

Support for the FCOM(P(P)) instruction can be determined by executing either CPUID function 0000_0001h or CPUID function 8000_0001. Support is indicated when both the EDX[FPU] (bit 0) and EDX[CMOV] (bit 15) feature flags are set.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FUCOM</td>
        <td>DD E1</td>
        <td>Compare ST(0) to ST(1) and set condition code flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FUCOM ST(i)</td>
        <td>DD E0+i</td>
        <td>Compare ST(0) to ST(i) and set condition code flags to reflect the results of the comparison.</td>
    </tr>
    <tr>
        <td>FUCOMP</td>
        <td>DD E9</td>
        <td>Compare ST(0) to ST(1), set condition code flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FUCOMP ST(i)</td>
        <td>DD E8+i</td>
        <td>Compare ST(0) to ST(i), set condition code flags to reflect the results of the comparison, and pop the x87 register stack.</td>
    </tr>
    <tr>
        <td>FUCOMPP</td>
        <td>DA E9</td>
        <td>Compare ST(0) to ST(1), set condition code flags to reflect the results of the comparison, and pop the x87 register stack twice.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOM, FCOMPP, FCOMI, FCOMIP, FICOM, FICOMP, FTST, FUCOMI, FUCOMIP, FXAM

## rFLAGS Affected

None

x87 Floating-Point Instruction Reference FUCOMx [AMD Confidential - Distribution with NDA]

<page_number>317</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>C3</th>
        <th>C2</th>
        <th>C1</th>
        <th>C0</th>
        <th>Compare Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) &gt; source</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>ST(0) &lt; source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) = source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>1</td>
        <td>0</td>
        <td>1</td>
        <td>Operands were unordered</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th>8086Protected</th>
      <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
  </tbody>
</table>

<page_number>

318
</page_number>

FUCOMx x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# 

 FUCOMI FUCOMIP Floating-Point Unordered Compare and Set eFLAGS

Compares the contents of ST(0) with the contents of another floating-point register, and sets the zero flag (ZF), parity flag (PF), and carry flag (CF) as shown in the rFLAGS Affected table below.

Unlike FCOMI and FCOMIP, the FUCOMI and FUCOMIP instructions do not set the invalid-operation exception (IE) bit in the x87 status word for QNaNs.

After completing the comparison, FUCOMIP pops the x87 register stack.

Support for the FCOMI(P) instruction can be determined by executing either CPUID function 0000_0001h or CPUID function 8000_0001. Support is indicated when both the EDX[FPU] (bit 0) and EDX[CMOV] (bit 15) feature flags are set.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FUCOMI ST(0),ST(i)</td>
        <td>DB E8+i</td>
        <td>Compare ST(0) to ST(i) and set eFLAGS to reflect the result of the comparison.</td>
    </tr>
    <tr>
        <td>FUCOMIP ST(0),ST(i)</td>
        <td>DF E8+i</td>
        <td>Compare ST(0) to ST(i), set eFLAGS to reflect the result of the comparison, and pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## 

 Related Instructions

FCOM, FCOMPP, FCOMI, FCOMIP, FICOM, FICOMP, FTST, FUCOM, FUCOMP, FUCOMPP, FXAM

## 

 rFLAGS Affected

<table>
  <thead>
    <tr>
        <th>ZF</th>
        <th>PF</th>
        <th>CF</th>
        <th>Compare Result</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) &gt; source</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>ST(0) &lt; source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>ST(0) = source</td>
    </tr>
    <tr>
        <td>1</td>
        <td>1</td>
        <td>1</td>
        <td>Operands were unordered</td>
    </tr>
  </tbody>
</table>

## 

 x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td colspan="3">C0</td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference FUCOMIx [AMD Confidential - Distribution with NDA]

<page_number>319</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C2</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

# Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Invalid opcode, #UDXXX</td>
      <td></td>
      <td></td>
      <td></td>
      <td>The conditional move instructions are not supported, as 
indicated by EDX[FPU] and EDX[CMOV] returned by 
CPUID function 0000_0001h or 8000_0001h.</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
  </tbody>
</table>

<page_number>

320
</page_number>

FUCOMIx x87 Floating-Point Instruction Reference
[AMD Confidential - Distribution with NDA]

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FWAIT (WAIT) Wait for Unmasked x87 Floating-Point Exceptions

Forces the processor to test for pending unmasked floating-point exceptions before proceeding.

If there is a pending floating-point exception and CR0.NE = 1, a numeric exception (#MF) is generated. If there is a pending floating-point exception and CR0.NE = 0, FWAIT asserts the FERR output signal, then waits for an external interrupt.

This instruction is useful for insuring that unmasked floating-point exceptions are handled before altering the results of a floating point instruction.

FWAIT and WAIT are synonyms for the same opcode.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FWAIT</td>
        <td>9B</td>
        <td>Check for any pending floating-point exceptions.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

None

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Real</th>
        <th>Virtual 8086</th>
        <th>Protected</th>
        <th>Cause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available, #NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The monitor coprocessor bit (MP) and the task switch bit (TS) of the control register (CR0) were both set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending, #MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference

FWAIT (WAIT) [AMD Confidential - Distribution with NDA]

<page_number>321</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FXAM

# Floating-Point Examine

Examines the value in ST(0) and sets the C0, C2, and C3 condition code flags in the x87 status word as shown in the x87 Condition Code table below to indicate whether the value is a NaN, infinity, zero, empty, denormal, normal finite, or unsupported value. The instruction also sets the C1 flag to indicate the sign of the value in ST(0) (0 = positive, 1 = negative).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FXAM</td>
        <td>D9 E5</td>
        <td>Characterize the number in the ST(0) register.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FCOM, FCOMP, FCOMPP, FCOMI, FCOMIP, FICOM, FICOMP, FTST, FUCOM, FUCOMI, FUCOMIP, FUCOMP, FUCOMPP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>C3</th>
        <th>C2</th>
        <th>C1</th>
        <th>C0</th>
        <th>Meaning</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>+unsupported format</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>+NaN</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>0</td>
        <td>–unsupported format</td>
    </tr>
    <tr>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>1</td>
        <td>–NaN</td>
    </tr>
    <tr>
        <td>0</td>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>+normal</td>
    </tr>
    <tr>
        <td>0</td>
        <td>1</td>
        <td>0</td>
        <td>1</td>
        <td>+infinity</td>
    </tr>
    <tr>
        <td>0</td>
        <td>1</td>
        <td>1</td>
        <td>0</td>
        <td>–normal</td>
    </tr>
    <tr>
        <td>0</td>
        <td>1</td>
        <td>1</td>
        <td>1</td>
        <td>–infinity</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>0</td>
        <td>+0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>1</td>
        <td>+empty</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>1</td>
        <td>0</td>
        <td>–0</td>
    </tr>
    <tr>
        <td>1</td>
        <td>0</td>
        <td>1</td>
        <td>1</td>
        <td>–empty</td>
    </tr>
    <tr>
        <td>1</td>
        <td>1</td>
        <td>0</td>
        <td>0</td>
        <td>+denormal</td>
    </tr>
    <tr>
        <td>1</td>
        <td>1</td>
        <td>1</td>
        <td>0</td>
        <td>–denormal</td>
    </tr>
  </tbody>
</table>

<page_number>322</page_number>

[AMD Confidential - Distribution with NDA]
**FXAM**
**x87 Floating-Point Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Exceptions

<table>
  <thead>
    <tr>
        <th rowspan="2">Exception</th>
        <th rowspan="2">Real</th>
        <th>Virtual</th>
        <th rowspan="2">Protected</th>
        <th rowspan="2">Cause of Exception</th>
    </tr>
    <tr>
        <th>8086</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Device not available,<br/>#NM</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>The emulate bit (EM) or the task switch bit (TS) of the control register (CR0) is set to 1.</td>
    </tr>
    <tr>
        <td>x87 floating-point exception pending,<br/>#MF</td>
        <td>X</td>
        <td>X</td>
        <td>X</td>
        <td>An unmasked x87 floating-point exception was pending.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FXAM <page_number>323</page_number>
[AMD Confidential - Distribution with NDA]
Instruction Reference

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

# FXCH

# Floating-Point Exchange

Exchanges the value in ST(0) with the value in any other x87 register. If no operand is specified, the instruction exchanges the values in ST(0) and ST(1).

Use this instruction to move a value from an x87 register to ST(0) for subsequent processing by a floating-point instruction that can only operate on ST(0).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FXCH</td>
        <td>D9 C9</td>
        <td>Exchange the contents of ST(0) and ST(1).</td>
    </tr>
    <tr>
        <td>FXCH ST(i)</td>
        <td>D9 C8+i</td>
        <td>Exchange the contents of ST(0) and ST(i).</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FLD, FST, FSTP

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C1</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
  </tbody>
</table>

<page_number>

324
</page_number>

[AMD Confidential - Distribution with NDA]
FXCH
x87 Floating-Point Instruction Reference

26569—Rev. 3.16—November 2021

AMD logo

AMD64 Technology

# FXTRACT Floating-Point Extract Exponent and Significand

Extracts the exponent and significand portions of the floating-point value in ST(0), stores the exponent in ST(0), and then pushes the significand onto the x87 register stack. After this operation, the new ST(0) contains a real number with the sign and value of the original significand and an exponent of 3FFFh (biased value for true exponent of zero), and ST(1) contains a real number that is the value of the original value’s true (unbiased) exponent.

The FXTRACT instruction is useful for converting a double-extended-precision number to its decimal representation.

If the zero-divide-exception mask (ZM) bit of the x87 control word is set to 1 and the source value is ±0, then the instruction stores ±zero in ST(0) and an exponent value of –∞ in register ST(1).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FXTRACT</td>
        <td>D9 F4</td>
        <td>Extract the exponent and significand of ST(0), store the exponent in ST(0), and push the significand onto the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FABS, FPREM, FRNDINT, FCHS

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>x87 stack overflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3"><strong>Note:</strong> A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point FXTRACT [AMD Confidential - Distribution with NDA] Instruction Reference

<page_number>325</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not 
available, #NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) is set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack overflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Zero-divide 
exception (ZE)</td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>source operand was ±zero.</td>
    </tr>
  </tbody>
</table>

<page_number>326</page_number>

FXTRACT x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FYL2X

# Floating-Point y ∗ Log<sub>2</sub> (x)

Computes (ST(1) ∗ log<sub>2</sub>(ST(0))), stores the result in ST(1), and pops the x87 register stack. The value in ST(0) must be greater than zero.

If the zero-divide-exception mask (ZM) bit in the x87 control word is set to 1 and ST(0) contains ±zero, the instruction returns ∞ with the opposite sign of the value in register ST(1).

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FYL2X</td>
        <td>D9 F1</td>
        <td>Replace ST(1) with ST(1) ∗ log2(ST(0)), then pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FYL2XP1, F2XM1

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="4">C1</td>
        <td>0</td>
        <td>No precision exception occurred.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point Instruction Reference
FYL2X
[AMD Confidential - Distribution with NDA]

<page_number>327</page_number>

AMD

26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
      <th colspan="5">AMD64 Technology 26569—Rev.3.16—November 2021
<br/>
Exceptions</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>ExceptionReal</td>
      <td></td>
      <td>Virtual</td>
      <td></td>
      <td>8086ProtectedCause of Exception</td>
    </tr>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A source operand was an SNaN value or an unsupported 
format.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The source operand in ST(0) was a negative finite value 
(not -zero).</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The source operand in ST(0) was +1 and the source 
operand in ST(1) was ±infinity.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
      <td>XXXThe</td>
      <td>source operand in ST(0) was -infinity.</td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The source operand in ST(0) was ±zero or ±infinity and the 
source operand in ST(1) was ±zero.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Zero-divide 
exception (ZE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The source operand in ST(0) was ±zero and the source 
operand in ST(1) was a finite value.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

<page_number>

328
</page_number>

**FYL2X** <mark>[AMD Confidential - Distribution with NDA]</mark> **x87 Floating-Point Instruction Reference**

AMD logo

26569—Rev. 3.16—November 2021

AMD64 Technology

# FYL2XP1

# Floating-Point y ∗ Log<sub>2</sub> (x+1)

Computes (ST(1) ∗ log<sub>2</sub>(ST(0) + 1.0)), stores the result in ST(1), and pops the x87 register stack. The value in ST(0) must be in the range sqrt(1/2)–1 to sqrt(2)-1.

<table>
  <thead>
    <tr>
        <th>Mnemonic</th>
        <th>Opcode</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FYL2XP1</td>
        <td>D9 F9</td>
        <td>Replace ST(1) with ST(1) ∗ log2(ST(0) + 1.0), then pop the x87 register stack.</td>
    </tr>
  </tbody>
</table>

## Related Instructions

FYL2X, F2XM1

## rFLAGS Affected

None

## x87 Condition Code

<table>
  <thead>
    <tr>
        <th>x87 Condition Code</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">C0</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>0</td>
        <td>x87 stack underflow, if an x87 register stack fault was detected.</td>
    </tr>
    <tr>
        <td rowspan="2">C1</td>
        <td>0</td>
        <td>Result was rounded down, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Result was rounded up, if a precision exception was detected.</td>
    </tr>
    <tr>
        <td>C2</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td>C3</td>
        <td>U</td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="3">Note: A flag set to 1 or cleared to 0 is M (modified). Unaffected flags are blank. Undefined flags are U.</td>
    </tr>
  </tbody>
</table>

x87 Floating-Point
Instruction Reference
FYL2XP1
[AMD Confidential - Distribution with NDA]

<page_number>329</page_number>

AMD

AMD64 Technology 26569—Rev. 3.16—November 2021

## Exceptions

<table>
  <thead>
    <tr>
      <th>ExceptionReal</th>
      <th></th>
      <th>Virtual</th>
      <th></th>
      <th>8086ProtectedCause of Exception</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Device not available, 
#NM</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The emulate bit (EM) or the task switch bit (TS) of the 
control register (CR0) was set to 1.</td>
    </tr>
    <tr>
      <td>x87 floating-point 
exception pending, 
#MF</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>unmasked x87 floating-point exception was pending.</td>
    </tr>
    <tr>
      <td colspan="5">x87 Floating-Point Exception Generated, #MF</td>
    </tr>
    <tr>
      <td>Invalid-operation</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was an SNaN or unsupported format.</td>
    </tr>
    <tr>
      <td>exception (IE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>The source operand in ST(0) was ±0 and the source 
operand in ST(1) was ±infinity.</td>
    </tr>
    <tr>
      <td>Invalid-operation 
exception (IE) with 
stack fault (SF)</td>
      <td></td>
      <td></td>
      <td>XXXAn</td>
      <td>x87 stack underflow occurred.</td>
    </tr>
    <tr>
      <td>Denormalized
operand exception 
(DE)</td>
      <td></td>
      <td></td>
      <td>XXXA</td>
      <td>source operand was a denormal value.</td>
    </tr>
    <tr>
      <td>Overflow exception 
(OE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too large to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Underflow exception 
(UE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A rounded result was too small to fit into the format of the 
destination operand.</td>
    </tr>
    <tr>
      <td>Precision exception 
(PE)</td>
      <td></td>
      <td>XXX</td>
      <td></td>
      <td>A result could not be represented exactly in the destination 
format.</td>
    </tr>
  </tbody>
</table>

<page_number>

330
</page_number>

FYL2XP1 x87 Floating-Point
[AMD Confidential - Distribution with NDA] Instruction Reference

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

x87 Floating-Point **FYL2XP1**
Instruction Reference
<mark>[AMD Confidential - Distribution with NDA]</mark>

<page_number>331</page_number>

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

<page_number>332</page_number>

x87 Floating-Point Instruction Reference
[AMD Confidential - Distribution with NDA]

AMD logo

26569—Rev. 3.16—November 2021 AMD64 Technology

# Appendix A Recommended Substitutions for 3DNow!™ Instructions

Table A-1 lists the deprecated 3DNow!™ instructions and the recommended substitutions.

Table A-1. Substitutions for 3DNow!™ Instructions

<table>
  <thead>
    <tr>
        <th>64-Bit 3DNow!™ Instruction</th>
        <th>128-Bit SSE Instruction</th>
        <th>64-Bit MMX™ Instruction</th>
        <th>Notes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FEMMS</td>
        <td>N/A</td>
        <td>EMMS (MMX)</td>
        <td> </td>
    </tr>
    <tr>
        <td>PAVGUSB</td>
        <td>PAVGB</td>
        <td>PAVGB</td>
        <td>SSE and MMX™ instructions round according to the current rounding mode; 3DNow!™ instructions always round up.</td>
    </tr>
    <tr>
        <td>PF2ID</td>
        <td>CVTTPS2DQ</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PF2IW</td>
        <td> </td>
        <td> </td>
        <td>CVTTPS2DQ may be used if 16-bit result is not necessary.</td>
    </tr>
    <tr>
        <td>PFACC</td>
        <td>HADDPS</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PFADD</td>
        <td>ADDPS</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PFCMPEQ</td>
        <td>CMPPS</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PFCMPGE</td>
        <td>CMPPS</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PFCMPGT</td>
        <td>CMPPS</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PFMAX</td>
        <td>MAXPS</td>
        <td> </td>
        <td>MAXPS may return -0.0.</td>
    </tr>
    <tr>
        <td>PFMIN</td>
        <td>MINPS</td>
        <td> </td>
        <td>MINPS may return -0.0.</td>
    </tr>
    <tr>
        <td>PFMUL</td>
        <td>MULPS</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PFNACC</td>
        <td>HSUBPS</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PFPNACC</td>
        <td>ADDSUBPS</td>
        <td> </td>
        <td>ADDSUBPS expects arguments in different positions from PFPNACC.</td>
    </tr>
    <tr>
        <td>PFRCP</td>
        <td> </td>
        <td> </td>
        <td>RCPSS may be used in conjunction with the Newton-Raphson algorithm.</td>
    </tr>
    <tr>
        <td>PFRCPIT1</td>
        <td> </td>
        <td> </td>
        <td>See PFRCP.</td>
    </tr>
    <tr>
        <td>PFRCPIT2</td>
        <td> </td>
        <td> </td>
        <td>See PFRCP.</td>
    </tr>
    <tr>
        <td>PFRSQIT1</td>
        <td> </td>
        <td> </td>
        <td>See PFRSQRT.</td>
    </tr>
    <tr>
        <td>PFRSQRT</td>
        <td> </td>
        <td> </td>
        <td>RSQRTSS may be used in conjunction with the Newton-Raphson algorithm.</td>
    </tr>
    <tr>
        <td>PFSUB</td>
        <td>SUBPS</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>PFSUBR</td>
        <td> </td>
        <td> </td>
        <td>SUBPS may be used.</td>
    </tr>
    <tr>
        <td>PI2FD</td>
        <td>CVTDQ2PS</td>
        <td> </td>
        <td>SSE instructions round according to the current rounding mode; 3DNow! instructions always truncate.</td>
    </tr>
    <tr>
        <td colspan="4">PI2FW</td>
    </tr>
    <tr>
        <td>PMULHRW</td>
        <td> </td>
        <td> </td>
        <td>PMULHW may be used if rounding is not necessary.</td>
    </tr>
    <tr>
        <td>PSWAPD</td>
        <td>PSHUFD</td>
        <td> </td>
        <td> </td>
    </tr>
  </tbody>
</table>

Recommended Substitutions for 3DNow!™ Instructions
[AMD Confidential - Distribution with NDA]

<page_number>333</page_number>

AMD logo

AMD64 Technology

26569—Rev. 3.16—November 2021

<page_number>334</page_number>

Recommended Substitutions for 3DNow!™ Instructions
[AMD Confidential - Distribution with NDA]

26569—Rev. 3.16—November 2021 AMD64 Technology

# Index

## Numerics

16-bit mode ........................................................... xvii
32-bit mode ........................................................... xvii
64-bit mode ........................................................... xvii

**A**

addressing
    RIP-relative ....................................................... xxii
AES ..................................................................... xviii
ASID ................................................................... xviii

**B**

biased exponent .................................................... xviii

**C**

commit ................................................................ xviii
compatibility mode ............................................... xviii
condition codes
    x87 .................................................................... 217
CVTPD2PI ................................................................ 3
CVTPI2PD ................................................................ 6
CVTPI2PS ................................................................ 8
CVTPS2PI .............................................................. 10
CVTTPD2PI ........................................................... 12
CVTTPS2PI ............................................................ 15

**D**

direct referencing .................................................. xviii
displacements ....................................................... xviii
double quadword .................................................... xix
doubleword ............................................................ xix

**E**

eAX–eSP register ................................................... xxv
effective address size ............................................... xix
effective operand size .............................................. xix
eFLAGS register .................................................... xxv
eIP register ............................................................ xxv
element .................................................................. xix
EMMS .................................................................... 17
endian order ........................................................ xxvii
exceptions .............................................................. xix
exponent .............................................................. xviii
extended SSE ......................................................... xix
    AES ................................................................. xviii
    AVX ................................................................. xviii
    FMA .................................................................. xix
    FMA4 ................................................................. xix
XOP ................................................................. xxiv

**F**

F2XM1 ................................................................. 218
FABS .................................................................... 220
FADD ................................................................... 222
FADDP ................................................................. 222
FBLD .................................................................... 225
FBSTP .................................................................. 227
FCHS .................................................................... 229
FCLEX ................................................................. 230
FCMOVcc ............................................................. 232
FCOM .................................................................. 234
FCOMI ................................................................. 237
FCOMIP ............................................................... 237
FCOMP ................................................................ 234
FCOMPP .............................................................. 234
FCOS .................................................................... 239
FDECSTP ............................................................. 241
FDIV .................................................................... 243
FDIVP .................................................................. 243
FDIVR .................................................................. 246
FDIVRP ................................................................ 246
FEMMS .................................................................. 18
FFREE .................................................................. 249
FIADD .................................................................. 222
FICOM ................................................................. 250
FICOMP ............................................................... 250
FIDIV ................................................................... 243
FIDIVR ................................................................. 246
FILD ..................................................................... 252
FIMUL ................................................................. 276
FINCSTP .............................................................. 254
FINIT .................................................................... 256
FIST ..................................................................... 258
FISTP ................................................................... 258
FISTTP ................................................................. 261
FISUB .................................................................. 310
FISUBR ................................................................ 313
FLD ...................................................................... 263
FLD1 .................................................................... 265
FLDCW ................................................................ 266
FLDENV .............................................................. 268
FLDL2E ................................................................ 270
FLDL2T ................................................................ 271
FLDLG2 ............................................................... 272
FLDLN2 ............................................................... 273
FLDPI ................................................................... 274

Index

<page_number>335</page_number>

[AMD Confidential - Distribution with NDA]

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

FLDZ ................................................................... 275
flush ...................................................................... xix
FMUL .................................................................. 276
FMULP ................................................................ 276
FNCLEX .............................................................. 230
FNINIT ................................................................. 256
FNOP ................................................................... 279
FNSAVE .......................................................... 22, 292
FNSTCW .............................................................. 304
FNSTENV ............................................................ 306
FNSTSW .............................................................. 308
FPATAN ............................................................... 280
FPREM ................................................................. 282
FPREM1 ............................................................... 284
FPTAN ................................................................. 286
FRNDINT ............................................................. 288
FRSTOR .......................................................... 20, 290
FSAVE ............................................................ 22, 292
FSCALE ............................................................... 294
FSIN ..................................................................... 296
FSINCOS .............................................................. 298
FSQRT ................................................................. 300
FST ...................................................................... 302
FSTCW ................................................................ 304
FSTENV ............................................................... 306
FSTP .................................................................... 302
FSTSW ................................................................. 308
FSUB ................................................................... 310
FSUBP ................................................................. 310
FSUBR ................................................................. 313
FSUBRP ............................................................... 313
FTST .................................................................... 316
FUCOM ................................................................ 317
FUCOMI .............................................................. 319
FUCOMIP ............................................................ 319
FUCOMP .............................................................. 317
FUCOMPP ............................................................ 317
FWAIT ................................................................. 321
FXAM .................................................................. 322
FXCH ................................................................... 324
FXRSTOR .............................................................. 24
FXSAVE ................................................................ 26
FXTRACT ............................................................ 325
FYL2X ................................................................. 327
FYL2XP1 ............................................................. 329

# I

IGN ........................................................................ xx
indirect ................................................................... xx
instructions
* 3DNow! ............................................................... 2
* 3DNow! Extensions ............................................. 2

3DNow!™ ............................................................. 1
64-bit media ........................................................... 1
FXSAVE/FXRSTOR ............................................... 2
MMX .................................................................... 2
MMX Extensions .................................................... 2
SSE1 ..................................................................... 2
SSE2 ..................................................................... 2
x87 .................................................................... 217

# L

legacy mode ............................................................ xx
legacy SSE .............................................................. xx
legacy x86 ............................................................... xx
long mode ............................................................... xx
LSB ....................................................................... xxi
lsb ......................................................................... xxi

# M

mask ...................................................................... xxi
MASKMOVQ ........................................................ 28
MBZ ...................................................................... xxi
media instructions
* 128-bit ............................................................... xvii
* 256-bit ............................................................... xvii
* 64-bit ................................................................. xvii
memory
* physical ............................................................. xxii
modes
* compatibility ..................................................... xviii
* legacy .................................................................. xx
* long ..................................................................... xx
* protected ............................................................ xxii
* real .................................................................... xxii
* virtual-8086 ....................................................... xxiv
MOVD .................................................................... 31
MOVDQ2Q ............................................................. 34
MOVNTQ ............................................................... 36
MOVQ .................................................................... 38
MOVQ2DQ ............................................................. 40
MSB ...................................................................... xxi
msb ....................................................................... xxi
MSR .................................................................... xxvi

# O

octword .................................................................. xxi
offset ...................................................................... xxi
overflow ................................................................. xxi

# P

packed ................................................................... xxi
PACKSSDW ........................................................... 42
PACKSSWB ........................................................... 44
PACKUSWB ........................................................... 46

<page_number>336</page_number>

Index

[AMD Confidential - Distribution with NDA]

AMD

26569—Rev. 3.16—November 2021 AMD64 Technology

PADDB................................................................... 48
PADDD .................................................................. 50
PADDQ .................................................................. 52
PADDSB................................................................. 54
PADDSW................................................................ 56
PADDUSB ............................................................. 58
PADDUSW ............................................................. 60
PADDW.................................................................. 62
PAE ...................................................................... xxii
PAND ................................................................... 64
PANDN................................................................... 66
PAVGB ................................................................. 68
PAVGUSB ............................................................. 70
PAVGW ................................................................. 72
PCMPEQB.............................................................. 74
PCMPEQD ............................................................. 76
PCMPEQW............................................................. 78
PCMPGTB.............................................................. 80
PCMPGTD ............................................................. 82
PCMPGTW............................................................. 84
PEXTRW................................................................ 86
PF2ID .................................................................... 88
PF2IW ................................................................... 90
PFACC ................................................................... 92
PFADD .................................................................. 94
PFCMPEQ.............................................................. 96
PFCMPGE ............................................................. 98
PFCMPGT ............................................................ 101
PFMAX ................................................................ 103
PFMIN ................................................................. 105
PFMUL ................................................................ 107
PFNACC .............................................................. 109
PFPNACC ............................................................ 112
PFRCP.................................................................. 115
PFRCPIT1 ............................................................ 118
PFRCPIT2 ............................................................ 121
PFRSQIT1 ............................................................ 124
PFRSQRT ............................................................. 127
PFSUB ................................................................. 130
PFSUBR ............................................................... 132
physical memory ................................................... xxii
PI2FD................................................................... 134
PI2FW .................................................................. 136
PINSRW ............................................................... 138
PMADDWD ......................................................... 140
PMAXSW............................................................. 142
PMAXUB ............................................................. 144
PMINSW .............................................................. 146
PMINUB .............................................................. 148
PMOVMSKB........................................................ 150
PMULHRW .......................................................... 152

PMULHUW .......................................................... 154
PMULHW............................................................. 156
PMULLW ............................................................. 158
PMULUDQ........................................................... 160
POR...................................................................... 162
probe..................................................................... xxii
processor modes
* 16-bit ................................................................. xvii
* 32-bit ................................................................. xvii
* 64-bit ................................................................. xvii
protected mode ...................................................... xxii
PSADBW.............................................................. 164
PSHUFW .............................................................. 166
PSLLD.................................................................. 169
PSLLQ.................................................................. 171
PSLLW ................................................................. 173
PSRAD ................................................................. 175
PSRAW................................................................. 177
PSRLD ................................................................. 179
PSRLQ ................................................................. 181
PSRLW................................................................. 183
PSUBB ................................................................. 185
PSUBD ................................................................. 187
PSUBQ ................................................................. 189
PSUBSB ............................................................... 191
PSUBSW .............................................................. 193
PSUBUSB............................................................. 195
PSUBUSW............................................................ 197
PSUBW ................................................................ 199
PSWAPD .............................................................. 201
PUNPCKHBW ...................................................... 203
PUNPCKHDQ....................................................... 205
PUNPCKHWD...................................................... 207
PUNPCKLBW ...................................................... 209
PUNPCKLDQ ....................................................... 211
PUNPCKLWD ...................................................... 213
PXOR ................................................................... 215

# Q
quadword .............................................................. xxii

# R
r8–r15 .................................................................. xxvi
rAX–rSP .............................................................. xxvi
RAZ...................................................................... xxii
real address mode. See real mode
real mode .............................................................. xxii
registers
* eAX–eSP ........................................................... xxv
* eFLAGS ............................................................ xxv
* eIP..................................................................... xxv
* r8–r15............................................................... xxvi

Index

<page_number>337</page_number>

[AMD Confidential - Distribution with NDA]

AMD logo

AMD64 Technology 26569—Rev. 3.16—November 2021

rAX–rSP xxvi
rFLAGS xxvii
rIP xxvii
relative xxii
reserved xxii
revision history xiii
REX xxii
rFLAGS register xxvii
rIP register xxvii
RIP-relative addressing xxii

# S

SBZ xxiii
scalar xxiii
set xxiii
SIB xxiii
SIMD xxiii
SSE Instructions xxiii
extended xix
legacy xx
SSE instructions
AES xviii
AVX xviii
FMA xix
FMA4 xix
SSE1 xxiii
SSE2 xxiii
SSE3 xxiii
SSE4.1 xxiii
SSE4.2 xxiii
SSE4A xxiii
SSSE3 xxiii
XOP xxiv
sticky bits xxiv
Streaming SIMD Extensions (SSE) xxiii

# T

TSS xxiv

# U

underflow xxiv

# V

vector xxiv
virtual-8086 mode xxiv

# W

WAIT 321

# X

XOP
Instructions xxiv
Prefix xxiv

<page_number>

338
</page_number>

Index

[AMD Confidential - Distribution with NDA]