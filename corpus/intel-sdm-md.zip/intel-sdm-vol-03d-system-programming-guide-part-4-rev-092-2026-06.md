Intel logo

# Intel® 64 and IA-32 Architectures Software Developer’s Manual

## Volume 3D: System Programming Guide, Part 4

**NOTE:** The *Intel® 64 and IA-32 Architectures Software Developer’s Manual* consists of ten volumes: *Basic Architecture*, Order Number 253665; *Instruction Set Reference, A-L*, Order Number 253666; *Instruction Set Reference, M-U*, Order Number 253667; *Instruction Set Reference, V*, Order Number 326018; *Instruction Set Reference, W-Z*, Order Number 334569; *System Programming Guide, Part 1*, Order Number 253668; *System Programming Guide, Part 2*, Order Number 253669; *System Programming Guide, Part 3*, Order Number 326019; *System Programming Guide, Part 4*, Order Number 332831; *Model-Specific Registers*, Order Number 335592. Refer to all ten volumes when evaluating your design needs.

Order Number: 332831-092US
June 2026

**Notices & Disclaimers**

Intel technologies may require enabled hardware, software or service activation.

No product or component can be absolutely secure.

Your costs and results may vary.

You may not use or facilitate the use of this document in connection with any infringement or other legal analysis concerning Intel products described herein. You agree to grant Intel a non-exclusive, royalty-free license to any patent claim thereafter drafted which includes subject matter disclosed herein.

All product plans and roadmaps are subject to change without notice.

The products described may contain design defects or errors known as errata which may cause the product to deviate from published specifications. Current characterized errata are available on request.

Intel disclaims all express and implied warranties, including without limitation, the implied warranties of merchantability, fitness for a particular purpose, and non-infringement, as well as any warranty arising from course of performance, course of dealing, or usage in trade.

Code names are used by Intel to identify products, technologies, or services that are in development and not publicly available. These are not “commercial” names and not intended to function as trademarks.

No license (express or implied, by estoppel or otherwise) to any intellectual property rights is granted by this document, with the sole exception that a) you may publish an unmodified copy and b) code, identified as Sample Code in this document is licensed subject to the Zero-Clause BSD open source license (0BSD), [https://opensource.org/licenses/0BSD](https://opensource.org/licenses/0BSD). You may create software implementations based on this document and in compliance with the foregoing that are intended to execute on the Intel product(s) referenced in this document. No rights are granted to create modifications or derivatives of this document.

© Intel Corporation. Intel, the Intel logo, and other Intel marks are trademarks of Intel Corporation or its subsidiaries. Other names and brands may be claimed as the property of others.

INTRODUCTION TO INTEL® SOFTWARE GUARD EXTENSIONS

# CHAPTER 37 INTRODUCTION TO INTEL® SOFTWARE GUARD EXTENSIONS

## 37.1 OVERVIEW

Intel® Software Guard Extensions (Intel® SGX) is a set of instructions and mechanisms for memory accesses added to Intel® Architecture processors. Intel SGX can encompass two collections of instruction extensions, referred to as SGX1 and SGX2, see Table 37-1 and Table 37-2. The SGX1 extensions allow an application to instantiate a protected container, referred to as an enclave. The enclave is a trusted area of memory, where critical aspects of the application functionality have hardware-enhanced confidentiality and integrity protections. New access controls to restrict access to software not resident in the enclave are also introduced. The SGX2 extensions allow additional flexibility in runtime management of enclave resources and thread execution within an enclave.

Chapter 38 covers main concepts, objects and data structure formats that interact within the Intel SGX architecture. Chapter 39 covers operational aspects ranging from preparing an enclave, transferring control to enclave code, and programming considerations for the enclave code and system software providing support for enclave execution. Chapter 40 describes the behavior of Asynchronous Enclave Exit (AEX) caused by events while executing enclave code. Chapter 41 covers the syntax and operational details of the instruction and associated leaf functions available in Intel SGX. Chapter 42 describes interaction of various aspects of IA32 and Intel® 64 architectures with Intel SGX. Chapter 43 covers Intel SGX support for application debug, profiling, and performance monitoring.

```mermaid
graph LR
    subgraph Application_Virtual_Address_Space [ ]
        direction TB
        OS[OS]
        Enclave[Enclave]
        AppCode1[App Code]
        AppCode2[App Code]
    end

    subgraph Enclave_Details [ ]
        direction TB
        EntryTable[Entry Table]
        EnclaveHeap[Enclave Heap]
        EnclaveStack[Enclave Stack]
        EnclaveCode[Enclave Code]
    end

    Enclave --> EntryTable
    Enclave --> EnclaveHeap
    Enclave --> EnclaveStack
    Enclave --> EnclaveCode

    style Application_Virtual_Address_Space fill:none,stroke:#000
    style Enclave_Details fill:none,stroke:none
    style OS fill:#fff,stroke:#000,rx:10,ry:10
    style Enclave fill:#ddd,stroke:#000,rx:10,ry:10
    style AppCode1 fill:#fff,stroke:#000,rx:10,ry:10
    style AppCode2 fill:#fff,stroke:#000,rx:10,ry:10
    style EntryTable fill:#ddd,stroke:#000,rx:10,ry:10
    style EnclaveHeap fill:#ddd,stroke:#000,rx:10,ry:10
    style EnclaveStack fill:#ddd,stroke:#000,rx:10,ry:10
    style EnclaveCode fill:#ddd,stroke:#000,rx:10,ry:10
```

Figure 37-1. An Enclave Within the Application’s Virtual Address Space

## 37.2 ENCLAVE INTERACTION AND PROTECTION

Intel SGX allows the protected portion of an application to be distributed in the clear. Before the enclave is built, the enclave code and data are free for inspection and analysis. The protected portion is loaded into an enclave where its code and data is measured. Once the application’s protected portion of the code and data are loaded into an enclave, memory access controls are in place to restrict access by external software. An enclave can prove its identity to a remote party and provide the necessary building-blocks for secure provisioning of keys and credentials. The application can also request an enclave-specific and platform-specific key that it can use to protect keys and data that it wishes to store outside the enclave.<sup>1</sup>

<sup>1.</sup> For additional information, see white papers on Intel SGX at [https://www.intel.com/content/www/us/en/developer/tools/isa-extensions/overview.html](https://www.intel.com/content/www/us/en/developer/tools/isa-extensions/overview.html).

Vol. 3D 37-1

INTRODUCTION TO INTEL® SOFTWARE GUARD EXTENSIONS

Intel SGX introduces two significant capabilities to the Intel Architecture. First is the change in enclave memory access semantics. The second is protection of the address mappings of the application.

## 37.3 ENCLAVE LIFE CYCLE

Enclave memory management is divided into two parts: address space allocation and memory commitment. Address space allocation is the specification of the range of linear addresses that the enclave may use. This range is called the ELRANGE. No actual resources are committed to this region. Memory commitment is the assignment of actual memory resources (as pages) within the allocated address space. This two-phase technique allows flexibility for enclaves to control their memory usage and to adjust dynamically without overusing memory resources when enclave needs are low. Commitment adds physical pages to the enclave. An operating system may support separate allocate and commit operations.

During enclave creation, code and data for an enclave are loaded from a clear-text source, i.e., from non-enclave memory.

Untrusted application code starts using an initialized enclave typically by using the EENTER leaf function provided by Intel SGX to transfer control to the enclave code residing in the protected Enclave Page Cache (EPC). The enclave code returns to the caller via the EEXIT leaf function. Upon enclave entry, control is transferred by hardware to software inside the enclave. The software inside the enclave switches the stack pointer to one inside the enclave. When returning back from the enclave, the software swaps back the stack pointer then executes the EEXIT leaf function.

On processors that support the SGX2 extensions, an enclave writer may add memory to an enclave using the SGX2 instruction set, after the enclave is built and running. These instructions allow adding additional memory resources to the enclave for use in such areas as the heap. In addition, SGX2 instructions allow the enclave to add new threads to the enclave. The SGX2 features provide additional capabilities to the software model without changing the security properties of the Intel SGX architecture.

Calling an external procedure from an enclave could be done using the EEXIT leaf function. Software would use EEXIT and a software convention between the trusted section and the untrusted section.

An active enclave consumes resources from the Enclave Page Cache (EPC, see Section 37.5). Intel SGX provides the EREMOVE instruction that an EPC manager can use to reclaim EPC pages committed to an enclave. The EPC manager uses EREMOVE on every enclave page when the enclave is torn down. After successful execution of EREMOVE the EPC page is available for allocation to another enclave.

## 37.4 DATA STRUCTURES AND ENCLAVE OPERATION

There are 2 main data structures associated with operating an enclave, the SGX Enclave Control Structure (SECS, see Section 38.7) and the Thread Control Structure (TCS, see Section 38.8).

There is one SECS for each enclave. The SECS contains meta-data about the enclave which is used by the hardware and cannot be directly accessed by software. Included in the SECS is a field that stores the enclave build measurement value. This field, MRENCLAVE, is initialized by the ECREATE instruction and updated by every EADD and EEXTEND. It is locked by EINIT.

Every enclave contains one or more TCS structures. The TCS contains meta-data used by the hardware to save and restore thread specific information when entering/exiting the enclave. There is one field, FLAGS, that may be accessed by software. This field can only be accessed by debug enclaves. The flag bit, DBGOPTIN, allows to single step into the thread associated with the TCS. (see Section 38.8.1)

The SECS is created when ECREATE (see Table 37-1) is executed. The TCS can be created using the EADD instruction or the SGX2 instructions (see Table 37-2).

## 37.5 ENCLAVE PAGE CACHE

The Enclave Page Cache (EPC) is the secure storage used to store enclave pages when they are a part of an executing enclave. For an EPC page, hardware performs additional access control checks to restrict access to the page. After the current page access checks and translations are performed, the hardware checks that the EPC page

<page_number>37-2</page_number> Vol. 3D

INTRODUCTION TO INTEL® SOFTWARE GUARD EXTENSIONS

is accessible to the program currently executing. Generally an EPC page is only accessed by the owner of the executing enclave or an instruction which is setting up an EPC page

The EPC is divided into EPC pages. An EPC page is 4KB in size and always aligned on a 4KB boundary.

Pages in the EPC can either be valid or invalid. Every valid page in the EPC belongs to one enclave instance. Each enclave instance has an EPC page that holds its SECS. The security metadata for each EPC page is held in an internal micro-architectural structure called Enclave Page Cache Map (EPCM, see Section 37.5.1).

The EPC is managed by privileged software. Intel SGX provides a set of instructions for adding and removing content to and from the EPC. The EPC may be configured by BIOS at boot time. On implementations in which EPC memory is part of system DRAM, the contents of the EPC are protected by an encryption engine.

## 37.5.1 Enclave Page Cache Map (EPCM)

The EPCM is a secure structure used by the processor to track the contents of the EPC. The EPCM holds one entry for each page in the EPC. The format of the EPCM is micro-architectural, and consequently is implementation dependent. However, the EPCM contains the following architectural information:

* The status of EPC page with respect to validity and accessibility.

* An SECS identifier (see Section 38.20) of the enclave to which the page belongs.

* The type of page: regular, SECS, TCS or VA.

* The linear address through which the enclave is allowed to access the page.

* The specified read/write/execute permissions on that page.

The EPCM structure is used by the CPU in the address-translation flow to enforce access-control on the EPC pages. The EPCM structure is described in Table 38-28, and the conceptual access-control flow is described in Section 38.5.

The EPCM entries are managed by the processor as part of various instruction flows.

## 37.6 ENCLAVE INSTRUCTIONS AND INTEL® SGX

The enclave instructions available with Intel SGX are organized as leaf functions under three instruction mnemonics: ENCLS (ring 0) and ENCLU (ring 3). Each leaf function uses EAX to specify the leaf function index, and may require additional implicit input registers as parameters. The use of EAX is implied implicitly by the ENCLS and ENCLU instructions; ModR/M byte encoding is not used with ENCLS and ENCLU. The use of additional registers does not use ModR/M encoding and is implied implicitly by the respective leaf function index.

Each leaf function index is also associated with a unique, leaf-specific mnemonic. A long-form expression of Intel SGX instruction takes the form of ENCLx[LEAF_MNEMONIC], where ‘x’ is either ‘S’, ‘U’, or ‘V’. The long-form expression provides clear association of the privilege-level requirement of a given “leaf mnemonic”. For simplicity, the unique “Leaf_Mnemonic” name is used (omitting the ENCLx for convenience) throughout in this document.

Details of individual SGX leaf functions are described in Chapter 41. Table 37-1 provides a summary of the instruction leaves that are available in the initial implementation of Intel SGX, which is introduced in the 6<sup>th</sup> generation Intel Core processors. Table 37-2 summarizes enhancement of Intel SGX for future Intel processors.

Table 37-1. Supervisor and User Mode Enclave Instruction Leaf Functions in Long-Form of SGX1

<table>
  <thead>
    <tr>
        <th>Supervisor Instruction</th>
        <th>Description</th>
        <th>User Instruction</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ENCLS[EADD]</td>
        <td>Add an EPC page to an enclave.</td>
        <td>ENCLU[EENTER]</td>
        <td>Enter an enclave.</td>
    </tr>
    <tr>
        <td>ENCLS[EBLOCK]</td>
        <td>Block an EPC page.</td>
        <td>ENCLU[EEXIT]</td>
        <td>Exit an enclave.</td>
    </tr>
    <tr>
        <td>ENCLS[ECREATE]</td>
        <td>Create an enclave.</td>
        <td>ENCLU[EGETKEY]</td>
        <td>Create a cryptographic key.</td>
    </tr>
    <tr>
        <td>ENCLS[EDBGRD]</td>
        <td>Read data from a debug enclave by debugger.</td>
        <td>ENCLU[EREPORT]</td>
        <td>Create a cryptographic report.</td>
    </tr>
    <tr>
        <td>ENCLS[EDBGWR]</td>
        <td>Write data into a debug enclave by debugger.</td>
        <td>ENCLU[ERESUME]</td>
        <td>Re-enter an enclave.</td>
    </tr>
  </tbody>
</table>

Vol. 3D 37-3
<page_number>37-3</page_number>

INTRODUCTION TO INTEL® SOFTWARE GUARD EXTENSIONS

Table 37-1. Supervisor and User Mode Enclave Instruction Leaf Functions in Long-Form of SGX1

<table>
  <thead>
    <tr>
        <th>Supervisor Instruction</th>
        <th>Description</th>
        <th>User Instruction</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ENCLS[EEXTEND]</td>
        <td>Extend EPC page measurement.</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>ENCLS[EINIT]</td>
        <td>Initialize an enclave.</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>ENCLS[ELDB]</td>
        <td>Load an EPC page in blocked state.</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>ENCLS[ELDU]</td>
        <td>Load an EPC page in unblocked state.</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>ENCLS[EPA]</td>
        <td>Add an EPC page to create a version array.</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>ENCLS[EREMOVE]</td>
        <td>Remove an EPC page from an enclave.</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>ENCLS[ETRACK]</td>
        <td>Activate EBLOCK checks.</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>ENCLS[EWB]</td>
        <td>Write back/invalidate an EPC page.</td>
        <td> </td>
        <td> </td>
    </tr>
  </tbody>
</table>

Table 37-2. Supervisor and User Mode Enclave Instruction Leaf Functions in Long-Form of SGX2

<table>
  <thead>
    <tr>
        <th>Supervisor Instruction</th>
        <th>Description</th>
        <th>User Instruction</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ENCLS[EAUG]</td>
        <td>Allocate EPC page to an existing enclave.</td>
        <td>ENCLU[EACCEPT]</td>
        <td>Accept EPC page into the enclave.</td>
    </tr>
    <tr>
        <td>ENCLS[EMODPR]</td>
        <td>Restrict page permissions.</td>
        <td>ENCLU[EMODPE]</td>
        <td>Enhance page permissions.</td>
    </tr>
    <tr>
        <td>ENCLS[EMODT]</td>
        <td>Modify EPC page type.</td>
        <td>ENCLU[EACCEPTCOPY]</td>
        <td>Copy contents to an augmented EPC page and accept the EPC page into the enclave.</td>
    </tr>
  </tbody>
</table>

# 37.7 DISCOVERING SUPPORT FOR INTEL® SGX AND ENABLING ENCLAVE INSTRUCTIONS

Detection of support of Intel SGX and enumeration of available and enabled Intel SGX resources are queried using the CPUID instruction. The enumeration interface comprises the following:

* Processor support of Intel SGX is enumerated by a feature flag in CPUID.07H: CPUID.07H.00H:EBX.SGX[2]. If CPUID.07H.00H:EBX.SGX = 1, the processor has support for Intel SGX, and requires opt-in enabling by BIOS via IA32_FEATURE_CONTROL MSR.

If CPUID.07H.00H:EBX.SGX = 1, CPUID will report via the available sub-leaves of CPUID.12H on available and/or configured Intel SGX resources.

* The available and configured Intel SGX resources enumerated by the sub-leaves of CPUID.12H depend on the state of BIOS configuration.

## 37.7.1 Intel® SGX Opt-In Configuration

On processors that support Intel SGX, IA32_FEATURE_CONTROL provides the SGX_ENABLE field (bit 18). Before system software can configure and enable Intel SGX resources, BIOS is required to set IA32_FEATURE_CONTROL.SGX_ENABLE = 1 to opt-in the use of Intel SGX by system software.

The semantics of setting SGX_ENABLE follows the rules of IA32_FEATURE_CONTROL.LOCK (bit 0). Software is considered to have opted into Intel SGX if and only if IA32_FEATURE_CONTROL.SGX_ENABLE and IA32_FEATURE_CONTROL.LOCK are set to 1. The setting of IA32_FEATURE_CONTROL.SGX_ENABLE (bit 18) is not reflected by CPUID.

Table 37-3. Intel® SGX Opt-in and Enabling Behavior

<table>
  <thead>
    <tr>
        <th>CPUID.07H.00H:EBX. SGX</th>
        <th>CPUID.12H</th>
        <th>FEATURE_CONTROL. LOCK</th>
        <th>FEATURE_CONTROL. SGX_ENABLE</th>
        <th>Enclave Instruction</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>Invalid</td>
        <td>X</td>
        <td>X</td>
        <td>#UD</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Valid*</td>
        <td>X</td>
        <td>X</td>
        <td>#UD**</td>
    </tr>
  </tbody>
</table>

37-4 Vol. 3D
<page_number>37-4</page_number>

INTRODUCTION TO INTEL® SOFTWARE GUARD EXTENSIONS

Table 37-3. Intel® SGX Opt-in and Enabling Behavior

<table>
  <thead>
    <tr>
        <th>CPUID.07H.00H:EBX.SGX</th>
        <th>CPUID.12H</th>
        <th>FEATURE_CONTROL.LOCK</th>
        <th>FEATURE_CONTROL.SGX_ENABLE</th>
        <th>Enclave Instruction</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>1</td>
        <td>Valid*</td>
        <td>0</td>
        <td>X</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Valid*</td>
        <td>1</td>
        <td>0</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>1</td>
        <td>Valid*</td>
        <td>1</td>
        <td>1</td>
        <td>Available***</td>
    </tr>
  </tbody>
</table>

\* Leaf 12H enumeration results are dependent on enablement.

\*\* See list of conditions in the #UD section of the reference pages of ENCLS and ENCLU.

\*\*\* See CPUID.12H in chapter 21 of the Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1 for details of SGX1 and SGX2.

## 37.7.2 Intel® SGX Resource Enumeration Leaves

If CPUID.07H.00H:EBX.SGX = 1, the processor also supports querying CPUID.12H on Intel SGX resource capability and configuration. The number of available sub-leaves in leaf 12H depends on the Opt-in and system software configuration. Information returned by CPUID.12H is thread specific; software should not assume that if Intel SGX instructions are supported on one hardware thread, they are also supported elsewhere.

A properly configured processor exposes Intel SGX functionality with CPUID.12H reporting valid information (non-zero content) in three or more sub-leaves, see CPUID.12H in Chapter 21 of the Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1.

* CPUID.12H.00H enumerates Intel SGX capability, including enclave instruction opcode support (see CPUID.12H in Chapter 21 of the Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1).

* CPUID.12H.01H enumerates Intel SGX capability of processor state configuration and enclave configuration in the SECS structure (see CPUID.12H in Chapter 21 of the Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1).

* CPUID.(12H, ECX >1) enumerates available EPC resources.

On processors that support Intel SGX1 and SGX2, CPUID.12H sub-leaf 2 report physical memory resources available for use with Intel SGX. These physical memory sections are typically allocated by BIOS as **Processor Reserved Memory**, and available to the OS to manage as EPC.

To enumerate how many EPC sections are available to the EPC manager, software can enumerate CPUID.12H with sub-leaf index starting from 2, and decode the sub-leaf-type encoding (returned in EAX[3:0]) until the sub-leaf type is invalid. All invalid sub-leaves of CPUID.12H return EAX/EBX/ECX/EDX with 0. See CPUID.12H in Chapter 21 of the Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1.

## 37.8 INTEL® SGX INTERACTIONS WITH CONTROL-FLOW ENFORCEMENT TECHNOLOGY

This section discusses extensions to the Intel SGX architecture to support CET.

### 37.8.1 CET in Enclaves Model

Each enclave has its private configuration for CET that is not shared with the CET configurations of the enclosing application. On entry into the enclave, the CET state of the enclosing application is saved into scratchpad registers inside the processor and the CET state of the enclave is established. On an asynchronous exit, the enclave CET state is saved into the enclave state save area frame. On exit from the enclave, the CET state of the enclosing application is re-established from the scratchpad registers.

A new page type, PT_SS_FIRST, is used to denote pages in an enclave that can be used as a first page of a shadow stack.

A new page type, PT_SS_REST, is used to denote pages in an enclave that can be used as a non-first page of a shadow stack.

Vol. 3D 37-5

INTRODUCTION TO INTEL® SOFTWARE GUARD EXTENSIONS

A page denoted as PT_SS_FIRST and PT_SS_REST will be a legal target for shadow_stack_load, shadow_stack_store, and regular load operations. Regular stores will be disallowed to such pages. A PT_SS_FIRST/PT_SS_REST page must be writeable in the IA page tables and in EPT.

When in enclave mode, shadow_stack_load and shadow_stack_store operations must be to addresses in the enclave ELRANGE.

The EAUG instruction is extended to allocate pages of type PT_SS_FIRST/PT_SS_REST; this page type requires specifying a SECINFO structure with page parameters. Shadow page permission must be R/W. Regular R/W pages may continue to be allocated by providing a SECINFO pointer value of 0. Regular R/W pages may also be allocated by providing a SECINFO structure that specifies the page parameters. The EAUG instruction creates a shadow-stack-restore token at offset 0xFF8 on a PT_SS_FIRST page. This allows a dynamically created shadow stack to be restored using the RSTORSSP instruction. The EADD and EAUG instructions disallow creation of a PT_SS_FIRST or PT_SS_REST page as the first or last page in ELRANGE.

The EADD instruction requires that the PT_SS_REST page be all zeroes. The EADD instruction requires that a PT_SS_FIRST page be all zeroes except the 8 bytes at offset 0xFF8 on that page that must have a shadow-stack-restore token. This shadow-stack-restore token must have a linear address which is the linear address of the PT_SS_FIRST page + 4096. As an enclave could be loaded at varying linear addresses, the enclave builder should not extend the measurement of the PT_SS_FIRST pages into the measurement registers. On first entry on to the enclave using a TCS, the enclave software can use the RSTORSSP instruction to restore its SSP. Subsequent to performing a RSTORSSP, the enclave software can use the INCSSP instruction to pop the previous-ssp token that is created by the RSTORSSP instruction at the top of the restored shadow stack.

On an enclave entry, the SSP will be initialized to the value in a new TCS field called PREVSSP. The PREVSSP field is written with the value of SSP on enclave exit and is loaded into SSP at enclave entry. When a TCS page is added using EADD or accepted using EACCEPT, the processor requires the PREVSSP field to be initialized to 0.

## 37.8.2 Operations Not Supported on Shadow Stack Pages

The following operations are not allowed on pages of type PT_SS_FIRST and PT_SS_REST:

* EACCEPTCOPY

* EMODPR

* EMODPE

## 37.8.3 Indirect Branch Tracking – Legacy Compatibility Treatment

The legacy code page bitmap is tested using the page offset within the ELRANGE instead of the absolute linear address of the address where ENDBRANCH was missed; see the detailed algorithm in Section 18.3.6, “Legacy Compatibility Treatment,” in the Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1, for additional details.

<page_number>37-6</page_number> Vol. 3D

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

# CHAPTER 38ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

## 38.1 OVERVIEW OF ENCLAVE EXECUTION ENVIRONMENT

When an enclave is created, it has a range of linear addresses to which the processor applies enhanced access control. This range is called the ELRANGE (see Section 37.3). When an enclave generates a memory access, the existing IA32 segmentation and paging architecture are applied. Additionally, linear addresses inside the ELRANGE must map to an EPC page otherwise when an enclave attempts to access that linear address a fault is generated.

The EPC pages need not be physically contiguous. System software allocates EPC pages to various enclaves. Enclaves must abide by OS/VMM imposed segmentation and paging policies. OS/VMM-managed page tables and extended page tables provide address translation for the enclave pages. Hardware requires that these pages are properly mapped to EPC (any failure generates an exception).

Enclave entry must happen through specific enclave instructions:

* ENCLU[EENTER], ENCLU[ERESUME].

Enclave exit must happen through specific enclave instructions or events:

* ENCLU[EEXIT], Asynchronous Enclave Exit (AEX).

Attempts to execute, read, or write to linear addresses mapped to EPC pages when not inside an enclave will result in the processor altering the access to preserve the confidentiality and integrity of the enclave. The exact behavior may be different between implementations. As an example a read of an enclave page may result in the return of all one's or return of cyphertext of the cache line. Writing to an enclave page may result in a dropped write or a machine check at a later time. The processor will provide the protections as described in Section 38.4 and Section 38.5 on such accesses.

## 38.2 TERMINOLOGY

A memory access to the ELRANGE and initiated by an instruction executed by an enclave is called a Direct Enclave Access (Direct EA).

Memory accesses initiated by certain Intel<sup>®</sup> SGX instruction leaf functions such as ECREATE, EADD, EDBGRD, EDBGWR, ELDU/ELDB, EWB, EREMOVE, EENTER, and ERESUME to EPC pages are called Indirect Enclave Accesses (Indirect EA). Table 38-1 lists additional details of the indirect EA of SGX1 and SGX2 extensions.

Direct EAs and Indirect EAs together are called Enclave Accesses (EAs).

Any memory access that is not an Enclave Access is called a non-enclave access.

## 38.3 ACCESS-CONTROL REQUIREMENTS

Enclave accesses have the following access-control attributes:

* All memory accesses must conform to segmentation and paging protection mechanisms.

* Code fetches from inside an enclave to a linear address outside that enclave result in a #GP(0) exception.

* Shadow-stack-load or shadow-stack-store from inside an enclave to a linear address outside that enclave results in a #GP(0) exception.

* Non-enclave accesses to EPC memory result in undefined behavior. EPC memory is protected as described in Section 38.4 and Section 38.5 on such accesses.

* EPC pages of page types PT_REG, PT_TCS, and PT_TRIM must be mapped to ELRANGE at the linear address specified when the EPC page was allocated to the enclave using ENCLS[EADD] or ENCLS[EAUG] leaf functions. Enclave accesses through other linear address result in a #PF with the PFEC.SGX bit set.

Vol. 3D 38-1

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

* Direct EAs to any EPC pages must conform to the currently defined security attributes for that EPC page in the EPCM. These attributes may be defined at enclave creation time (EADD) or when the enclave sets them using SGX2 instructions. The failure of these checks results in a #PF with the PFEC.SGX bit set.
    

    — Target page must belong to the currently executing enclave.
    

    — Data may be written to an EPC page if the EPCM allow write access.
    

    — Data may be read from an EPC page if the EPCM allow read access.
    

    — Instruction fetches from an EPC page are allowed if the EPCM allows execute access.
    

    — Shadow-stack-load from an EPC page and shadow-stack-store to an EPC page are allowed only if the page type is PT_SS_FIRST or PT_SS_REST.
    

    — Data writes that are not shadow-stack-store are not allowed if the EPCM page type is PT_SS_FIRST or PT_SS_REST.
    

    — Target page must not have a restricted page type<sup>1</sup> (PT_SECS, PT_TCS, PT_VA, or PT_TRIM).
    

    — The EPC page must not be BLOCKED.
    

    — The EPC page must not be PENDING.
    

    — The EPC page must not be MODIFIED.

# 38.4 SEGMENT-BASED ACCESS CONTROL

Intel SGX architecture does not modify the segment checks performed by a logical processor. All memory accesses arising from a logical processor in protected mode (including enclave access) are subject to segmentation checks with the applicable segment register.

To ensure that outside entities do not modify the enclave's logical-to-linear address translation in an unexpected fashion, ENCLU[EENTER] and ENCLU[ERESUME] check that CS, DS, ES, and SS, if usable (i.e., not null), have segment base value of zero. A non-zero segment base value for these registers results in a #GP(0).

On enclave entry either via EENTER or ERESUME, the processor saves the contents of the external FS and GS registers, and loads these registers with values stored in the TCS at build time to enable the enclave’s use of these registers for accessing the thread-local storage inside the enclave. On EEXIT and AEX, the contents at time of entry are restored. On AEX, the values of FS and GS are saved in the SSA frame. On ERESUME, FS and GS are restored from the SSA frame. The details of these operations can be found in the descriptions of EENTER, ERESUME, EEXIT, and AEX flows.

# 38.5 PAGE-BASED ACCESS CONTROL

## 38.5.1 Access-control for Accesses that Originate from Non-SGX Instructions

Intel SGX builds on the processor's paging mechanism to provide page-granular access-control for enclave pages. Enclave pages are designed to be accessible only from inside the currently executing enclave if they belong to that enclave. In addition, enclave accesses must conform to the access control requirements described in Section 38.3. or through certain Intel SGX instructions. Attempts to execute, read, or write to linear addresses mapped to EPC pages when not inside an enclave will result in the processor altering the access to preserve the confidentiality and integrity of the enclave. The exact behavior may be different between implementations.

## 38.5.2 Memory Accesses that Split Across ELRANGE

Memory data accesses are allowed to split across ELRANGE (i.e., a part of the access is inside ELRANGE and a part of the access is outside ELRANGE) while the processor is inside an enclave. If an access splits across ELRANGE, the

<sup>1.</sup>EPCM may allow write, read or execute access only for pages with page type PT_REG.

38-2 Vol. 3D

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

processor splits the access into two sub-accesses (one inside ELRANGE and the other outside ELRANGE), and each access is evaluated. A code-fetch access that splits across ELRANGE results in a #GP due to the portion that lies outside of the ELRANGE.

## 38.5.3 Implicit vs. Explicit Accesses

Memory accesses originating from Intel SGX instruction leaf functions are categorized as either explicit accesses or implicit accesses. Table 38-1 lists the implicit and explicit memory accesses made by Intel SGX leaf functions.

### 38.5.3.1 Explicit Accesses

Accesses to memory locations provided as explicit operands to Intel SGX instruction leaf functions, or their linked data structures are called explicit accesses.

Explicit accesses are always made using logical addresses. These accesses are subject to segmentation, paging, extended paging, and APIC-virtualization checks, and trigger any faults/exit associated with these checks when the access is made.

The interaction of explicit memory accesses with data breakpoints is leaf-function-specific, and is documented in Section 43.3.4.

### 38.5.3.2 Implicit Accesses

Accesses to data structures whose physical addresses are cached by the processor are called implicit accesses. These addresses are not passed as operands of the instruction but are implied by use of the instruction.

These accesses do not trigger any access-control faults/exits or data breakpoints. Table 38-1 lists memory objects that Intel SGX instruction leaf functions access either by explicit access or implicit access. The addresses of explicit access objects are passed via register operands with the second through fourth column of Table 38-1 matching implicitly encoded registers RBX, RCX, RDX.

Physical addresses used in different implicit accesses are cached via different instructions and for different durations. The physical address of SECS associated with each EPC page is cached at the time the page is added to the enclave via ENCLS[EADD] or ENCLS[EAUG], or when the page is loaded to EPC via ENCLS[ELDB] or ENCLS[ELDU]. This binding is severed when the corresponding page is removed from the EPC via ENCLS[EREMOVE] or ENCLS[EWB]. Physical addresses of TCS and SSA pages are cached at the time of most-recent enclave entry. Exit from an enclave (ENCLU[EEXIT] or AEX) flushes this caching. Details of Asynchronous Enclave Exit is described in Chapter 40.

The physical addresses that are cached for use by implicit accesses are derived from logical (or linear) addresses after checks such as segmentation, paging, EPT, and APIC virtualization checks. These checks may trigger exceptions or VM exits. Note, however, that such exception or VM exits may not occur after a physical address is cached and used for an implicit access.

Table 38-1. List of Implicit and Explicit Memory Access by Intel® SGX Enclave Instructions

<table>
  <thead>
    <tr>
        <th>Instr. Leaf</th>
        <th>Enum.</th>
        <th>Explicit 1</th>
        <th>Explicit 2</th>
        <th>Explicit 3</th>
        <th>Implicit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EACCEPT</td>
        <td>SGX2</td>
        <td>SECINFO</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EACCEPTCOPY</td>
        <td>SGX2</td>
        <td>SECINFO</td>
        <td>EPCPAGE (Src)</td>
        <td>EPCPAGE (Dst)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EADD</td>
        <td>SGX1</td>
        <td>PAGEINFO and linked structures</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>EAUG</td>
        <td>SGX2</td>
        <td>PAGEINFO and linked structures</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EBLOCK</td>
        <td>SGX1</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>ECREATE</td>
        <td>SGX1</td>
        <td>PAGEINFO and linked structures</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>EDBGRD</td>
        <td>SGX1</td>
        <td>EPCADDR</td>
        <td>Destination</td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EDBGWR</td>
        <td>SGX1</td>
        <td>EPCADDR</td>
        <td>Source</td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EENTER</td>
        <td>SGX1</td>
        <td>TCS and linked SSA</td>
        <td> </td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EEXIT</td>
        <td>SGX1</td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>SECS, TCS</td>
    </tr>
  </tbody>
</table>

Vol. 3D 38-3
<page_number>38-3</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

Table 38-1. List of Implicit and Explicit Memory Access by Intel® SGX Enclave Instructions (Contd.)

<table>
  <thead>
    <tr>
        <th>Instr. Leaf</th>
        <th>Enum.</th>
        <th>Explicit 1</th>
        <th>Explicit 2</th>
        <th>Explicit 3</th>
        <th>Implicit</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EEXTEND</td>
        <td>SGX1</td>
        <td>SECS</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>EGETKEY</td>
        <td>SGX1</td>
        <td>KEYREQUEST</td>
        <td>KEY</td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EINIT</td>
        <td>SGX1</td>
        <td>SIGSTRUCT</td>
        <td>SECS</td>
        <td>EINITTOKEN</td>
        <td> </td>
    </tr>
    <tr>
        <td>ELDB/ELDU</td>
        <td>SGX1</td>
        <td>PAGEINFO and linked structures, PCMD</td>
        <td>EPCPAGE</td>
        <td>VAPAGE</td>
        <td> </td>
    </tr>
    <tr>
        <td>EMODPE</td>
        <td>SGX2</td>
        <td>SECINFO</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>EMODPR</td>
        <td>SGX2</td>
        <td>SECINFO</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EMODT</td>
        <td>SGX2</td>
        <td>SECINFO</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EPA</td>
        <td>SGX1</td>
        <td>EPCADDR</td>
        <td> </td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>EREMOVE</td>
        <td>SGX1</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>EREPORT</td>
        <td>SGX1</td>
        <td>TARGETINFO</td>
        <td>REPORTDATA</td>
        <td>OUTPUTDATA</td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>ERESUME</td>
        <td>SGX1</td>
        <td>TCS and linked SSA</td>
        <td> </td>
        <td> </td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>ETRACK</td>
        <td>SGX1</td>
        <td>EPCPAGE</td>
        <td> </td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td>EWB</td>
        <td>SGX1</td>
        <td>PAGEINFO and linked structures, PCMD</td>
        <td>EPCPAGE</td>
        <td>VAPAGE</td>
        <td>SECS</td>
    </tr>
    <tr>
        <td>Asynchronous Enclave Exit*</td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td> </td>
        <td>SECS, TCS, SSA</td>
    </tr>
    <tr>
        <td colspan="6">\*Details of Asynchronous Enclave Exit (AEX) is described in Section 40.4</td>
    </tr>
  </tbody>
</table>

# 38.6 INTEL® SGX DATA STRUCTURES OVERVIEW

Enclave operation is managed via a collection of data structures. Many of the top-level data structures contain sub-structures. The top-level data structures relate to parameters that may be used in enclave setup/maintenance, by Intel SGX instructions, or AEX event. The top-level data structures are:

* SGX Enclave Control Structure (SECS)

* Thread Control Structure (TCS)

* State Save Area (SSA)

* Page Information (PAGEINFO)

* Security Information (SECINFO)

* Paging Crypto MetaData (PCMD)

* Enclave Signature Structure (SIGSTRUCT)

* EINIT Token Structure (EINITTOKEN)

* Report Structure (REPORT)

* Report Target Info (TARGETINFO)

* Key Request (KEYREQUEST)

* Version Array (VA)

* Enclave Page Cache Map (EPCM)

Details of the top-level data structures and associated sub-structures are listed in Section 38.7 through Section 38.20.

# 38.7 SGX ENCLAVE CONTROL STRUCTURE (SECS)

The SECS data structure requires 4K-Bytes alignment.

38-4 Vol. 3D
<page_number>38-4</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

## Table 38-2. Layout of SGX Enclave Control Structure (SECS)

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>SIZE</td>
        <td>0</td>
        <td>8</td>
        <td>Size of enclave in bytes; must be power of 2.</td>
    </tr>
    <tr>
        <td>BASEADDR</td>
        <td>8</td>
        <td>8</td>
        <td>Enclave Base Linear Address must be naturally aligned to size.</td>
    </tr>
    <tr>
        <td>SSAFRAMESIZE</td>
        <td>16</td>
        <td>4</td>
        <td>Size of one SSA frame in pages, including XSAVE, pad, GPR, and MISC (if CPUID.12H.00H:EBX != 0).</td>
    </tr>
    <tr>
        <td>MISCSELECT</td>
        <td>20</td>
        <td>4</td>
        <td>Bit vector specifying which extended features are saved to the MISC region (see Section 38.7.2) of the SSA frame when an AEX occurs.</td>
    </tr>
    <tr>
        <td>CET_LEG_BITMAP_OFFSET</td>
        <td>24</td>
        <td>8</td>
        <td>Page aligned offset of legacy code page bitmap from enclave base. Software is expected to program this offset such that the entire bitmap resides in the ELRANGE when legacy compatibility mode for indirect branch tracking is enabled. However this is not enforced by the hardware.<br/>This field exists when CPUID.07H.00H:EDX.CET_IBT[20] is enumerated as 1, else it is reserved.</td>
    </tr>
    <tr>
        <td>CET_ATTRIBUTES</td>
        <td>32</td>
        <td>1</td>
        <td>CET feature attributes of the enclave; see Table 38-5. This field exists when CPUID.12H.01H:EAX[6] is enumerated as 1, else it is reserved.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>33</td>
        <td>15</td>
        <td> </td>
    </tr>
    <tr>
        <td>ATTRIBUTES</td>
        <td>48</td>
        <td>16</td>
        <td>Attributes of the Enclave, see Table 38-3.</td>
    </tr>
    <tr>
        <td>MRENCLAVE</td>
        <td>64</td>
        <td>32</td>
        <td>Measurement Register of enclave build process. See SIGSTRUCT for format.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>96</td>
        <td>32</td>
        <td> </td>
    </tr>
    <tr>
        <td>MRSIGNER</td>
        <td>128</td>
        <td>32</td>
        <td>Measurement Register extended with the public key that verified the enclave. See SIGSTRUCT for format.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>160</td>
        <td>32</td>
        <td> </td>
    </tr>
    <tr>
        <td>CONFIGID</td>
        <td>192</td>
        <td>64</td>
        <td>Post EINIT configuration identity.</td>
    </tr>
    <tr>
        <td>ISVPRODID</td>
        <td>256</td>
        <td>2</td>
        <td>Product ID of enclave.</td>
    </tr>
    <tr>
        <td>ISVSVN</td>
        <td>258</td>
        <td>2</td>
        <td>Security version number (SVN) of the enclave.</td>
    </tr>
    <tr>
        <td>CONFIGSVN</td>
        <td>260</td>
        <td>2</td>
        <td>Post EINIT configuration security version number (SVN).</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>262</td>
        <td>3834</td>
        <td>The RESERVED field consists of the following:<br/>* EID: An 8 byte Enclave Identifier. Its location is implementation specific.<br/>* PAD: A 352 bytes padding pattern from the Signature (used for key derivation strings). It’s location is implementation specific.<br/>* ISVFAMILYID: A 16 byte value assigned to identify the family of products the enclave belongs to.<br/>* ISVEXTPRODID: A 16 byte value assigned to identify the product identity of the enclave.<br/>* The remaining 3226 bytes are reserved area.<br/>The entire 3834 byte field must be cleared prior to executing ECREATE.</td>
    </tr>
  </tbody>
</table>

## 38.7.1 ATTRIBUTES

The ATTRIBUTES data structure is comprised of bit-granular fields that are used in the SECS, the REPORT and the KEYREQUEST structures. CPUID.12H.01H enumerates a bitmap of permitted 1-setting of bits in ATTRIBUTES.

## Table 38-3. Layout of ATTRIBUTES Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>INIT</td>
        <td>0</td>
        <td>This bit indicates if the enclave has been initialized by EINIT. It must be cleared when loaded as part of ECREATE. For EREPORT instruction, TARGET_INFO.ATTRIBUTES[ENIT] must always be 1 to match the state after EINIT has initialized the enclave.</td>
    </tr>
    <tr>
        <td>DEBUG</td>
        <td>1</td>
        <td>If 1, the enclave permit debugger to read and write enclave data using EDBGRD and EDBGWR.</td>
    </tr>
  </tbody>
</table>

<page_number>Vol. 3D 38-5</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

Table 38-3. Layout of ATTRIBUTES Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MODE64BIT</td>
        <td>2</td>
        <td>Enclave runs in 64-bit mode.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>3</td>
        <td>Must be Zero.</td>
    </tr>
    <tr>
        <td>PROVISIONKEY</td>
        <td>4</td>
        <td>Provisioning Key is available from EGETKEY.</td>
    </tr>
    <tr>
        <td>EINITTOKEN_KEY</td>
        <td>5</td>
        <td>EINIT token key is available from EGETKEY.</td>
    </tr>
    <tr>
        <td>CET</td>
        <td>6</td>
        <td>Enable CET attributes. When CPUID.12H.01H:EAX[6] is 0 this bit is reserved and must be 0.</td>
    </tr>
    <tr>
        <td>KSS</td>
        <td>7</td>
        <td>Key Separation and Sharing Enabled.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>9:8</td>
        <td>Must be zero.</td>
    </tr>
    <tr>
        <td>AEXNOTIFY</td>
        <td>10</td>
        <td>The bit indicates that threads within the enclave may receive AEX notifications.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>63:11</td>
        <td>Must be zero.</td>
    </tr>
    <tr>
        <td>XFRM</td>
        <td>127:64</td>
        <td>XSAVE Feature Request Mask. See Section 42.7.</td>
    </tr>
  </tbody>
</table>

## 38.7.2 SECS.MISCSELECT Field

CPUID.12H.00H:EBX[31:0] enumerates which extended information that the processor can save into the MISC region of SSA when an AEX occurs. An enclave writer can specify via SIGSTRUCT how to set the SECS.MISCSELECT field. The bit vector of MISCSELECT selects which extended information is to be saved in the MISC region of the SSA frame when an AEX is generated. The bit vector definition of extended information is listed in Table 38-4.

If CPUID.12H.00H:EBX[31:0] = 0, SECS.MISCSELECT field must be all zeros.

The SECS.MISCSELECT field determines the size of MISC region of the SSA frame, see Section 38.9.2.

Table 38-4. Bit Vector Layout of MISCSELECT Field of Extended Information

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EXINFO</td>
        <td>0</td>
        <td>Report information about page fault and general protection exception that occurred inside an enclave.</td>
    </tr>
    <tr>
        <td>CPINFO</td>
        <td>1</td>
        <td>Report information about control protection exception that occurred inside an enclave. When CPUID.12H.00H:EBX[1] is 0, this bit is reserved.</td>
    </tr>
    <tr>
        <td>Reserved</td>
        <td>31:2</td>
        <td>Reserved (0).</td>
    </tr>
  </tbody>
</table>

## 38.7.3 SECS.CET_ATTRIBUTES Field

The SECS.CET_ATTRIBUTES field can be used by the enclave writer to enable various CET attributes in an enclave. This field exists when CPUID.12H.01H:EAX[6] is enumerated as 1. Bits 1:0 are defined when CPUID.07H.00H:ECX.CET_SS is 1, and bits 5:2 are defined when CPUID.07H.00H:EDX.CET_IBT is 1.

Table 38-5. Bit Vector Layout of CET_ATTRIBUTES Field of Extended Information

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>SH_STK_EN</td>
        <td>0</td>
        <td>When set to 1, enable shadow stacks.</td>
    </tr>
    <tr>
        <td>WR_SHSTK_EN</td>
        <td>1</td>
        <td>When set to 1, enables the WRSS{D,Q}W instructions.</td>
    </tr>
    <tr>
        <td>ENDBR_EN</td>
        <td>2</td>
        <td>When set to 1, enables indirect branch tracking.</td>
    </tr>
    <tr>
        <td>LEG_IW_EN</td>
        <td>3</td>
        <td>Enable legacy compatibility treatment for indirect branch tracking.</td>
    </tr>
    <tr>
        <td>NO_TRACK_EN</td>
        <td>4</td>
        <td>When set to 1, enables use of no-track prefix for indirect branch tracking.</td>
    </tr>
    <tr>
        <td>SUPPRESS_DIS</td>
        <td>5</td>
        <td>When set to 1, disables suppression of CET indirect branch tracking on legacy compatibility.</td>
    </tr>
    <tr>
        <td>Reserved</td>
        <td>7:6</td>
        <td>Reserved (0).</td>
    </tr>
  </tbody>
</table>

<page_number>38-6</page_number> Vol. 3D

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

# 38.8 THREAD CONTROL STRUCTURE (TCS)

Each executing thread in the enclave is associated with a Thread Control Structure. It requires 4K-Bytes alignment.

Table 38-6. Layout of Thread Control Structure (TCS)

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>STAGE</td>
        <td>0</td>
        <td>8</td>
        <td>Enclave execution state of the thread controlled by this TCS. A value of 0 indicates that this TCS is available for enclave entry. A value of 1 indicates that a logical processor is currently executing an enclave in the context of this TCS.</td>
    </tr>
    <tr>
        <td>FLAGS</td>
        <td>8</td>
        <td>8</td>
        <td>The thread’s execution flags (see Section 38.8.1).</td>
    </tr>
    <tr>
        <td>OSSA</td>
        <td>16</td>
        <td>8</td>
        <td>Offset of the base of the State Save Area stack, relative to the enclave base. Must be page aligned.</td>
    </tr>
    <tr>
        <td>CSSA</td>
        <td>24</td>
        <td>4</td>
        <td>Current slot index of an SSA frame, cleared by EADD and EACCEPT.</td>
    </tr>
    <tr>
        <td>NSSA</td>
        <td>28</td>
        <td>4</td>
        <td>Number of available slots for SSA frames.</td>
    </tr>
    <tr>
        <td>OENTRY</td>
        <td>32</td>
        <td>8</td>
        <td>Offset in enclave to which control is transferred on EENTER relative to the base of the enclave.</td>
    </tr>
    <tr>
        <td>AEP</td>
        <td>40</td>
        <td>8</td>
        <td>The value of the Asynchronous Exit Pointer that was saved at EENTER time.</td>
    </tr>
    <tr>
        <td>OFSBASE</td>
        <td>48</td>
        <td>8</td>
        <td>Offset to add to the base address of the enclave for producing the base address of FS segment inside the enclave. Must be page aligned.</td>
    </tr>
    <tr>
        <td>OGSBASE</td>
        <td>56</td>
        <td>8</td>
        <td>Offset to add to the base address of the enclave for producing the base address of GS segment inside the enclave. Must be page aligned.</td>
    </tr>
    <tr>
        <td>FSLIMIT</td>
        <td>64</td>
        <td>4</td>
        <td>Size to become the new FS limit in 32-bit mode.</td>
    </tr>
    <tr>
        <td>GSLIMIT</td>
        <td>68</td>
        <td>4</td>
        <td>Size to become the new GS limit in 32-bit mode.</td>
    </tr>
    <tr>
        <td>OCETSSA</td>
        <td>72</td>
        <td>8</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, this field provides the offset of the CET state save area from enclave base. When CPUID.12H.01H:EAX[6] is 0, this field is reserved and must be 0.</td>
    </tr>
    <tr>
        <td>PREVSSP</td>
        <td>80</td>
        <td>8</td>
        <td>When CPUID.07H.00H:ECX.CET_SS is 1, this field records the SSP at the time of AEX or EEXIT; used to setup SSP on entry. When CPUID.07H.00H:ECX.CET_SS is 0, this field is reserved and must be 0.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>88</td>
        <td>4008</td>
        <td>Must be zero.</td>
    </tr>
  </tbody>
</table>

## 38.8.1 TCS.FLAGS

Table 38-7. Layout of TCS.FLAGS Field

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>DBGOPTIN</td>
        <td>0</td>
        <td>If set, allows debugging features (single-stepping, breakpoints, etc.) to be enabled and active while executing in the enclave on this TCS. Hardware clears this bit on EADD. A debugger may later modify it if the enclave’s ATTRIBUTES.DEBUG is set.</td>
    </tr>
    <tr>
        <td>AEXNOTIFY</td>
        <td>1</td>
        <td>A thread that enters the enclave cannot receive AEX notifications unless this flag is set to 1.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>63:2</td>
        <td>Must be zero.</td>
    </tr>
  </tbody>
</table>

## 38.8.2 State Save Area Offset (OSSA)

The OSSA points to a stack of State Save Area (SSA) frames (see Section 38.9) used to save the processor state when an interrupt or exception occurs while executing in the enclave.

Vol. 3D <page_number>38-7</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

## 38.8.3 Current State Save Area Frame (CSSA)

CSSA is the index of the current SSA frame that will be used by the processor to determine where to save the processor state on an interrupt or exception that occurs while executing in the enclave. It is an index into the array of frames addressed by OSSA. CSSA is incremented on an AEX and decremented on an ERESUME.

## 38.8.4 Number of State Save Area Frames (NSSA)

NSSA specifies the number of SSA frames available for this TCS. There must be at least one available SSA frame when EENTER-ing the enclave or the EENTER will fail.

## 38.9 STATE SAVE AREA (SSA) FRAME

When an AEX occurs while running in an enclave, the architectural state is saved in the thread’s current SSA frame, which is pointed to by TCS.CSSA. An SSA frame must be page aligned, and contains the following regions:

* The XSAVE region starts at the base of the SSA frame, this region contains extended feature register state in an XSAVE/FXSAVE-compatible non-compacted format.

* A Pad region: software may choose to maintain a pad region separating the XSAVE region and the MISC region. Software choose the size of the pad region according to the sizes of the MISC and GPRSGX regions.

* The GPRSGX region. The GPRSGX region is the last region of an SSA frame (see Table 38-8). This is used to hold the processor general purpose registers (RAX ... R15), the RIP, the outside RSP and RBP, RFLAGS, and the AEX information.

* The MISC region (If CPUID.12H.00H:EBX[31:0] != 0). The MISC region is adjacent to the GRPSGX region, and may contain zero or more components of extended information that would be saved when an AEX occurs. If the MISC region is absent, the region between the GPRSGX and XSAVE regions is the pad region that software can use. If the MISC region is present, the region between the MISC and XSAVE regions is the pad region that software can use. See additional details in Section 38.9.2.

Table 38-8. Top-to-Bottom Layout of an SSA Frame

<table>
  <thead>
    <tr>
        <th>Region</th>
        <th>Offset (Byte)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>XSAVE</td>
        <td>0</td>
        <td>Calculate using CPUID leaf 0DH information</td>
        <td>The size of XSAVE region in SSA is derived from the enclave’s support of the collection of processor extended states that would be managed by XSAVE. The enablement of those processor extended state components in conjunction with CPUID.0DH information determines the XSAVE region size in SSA.</td>
    </tr>
    <tr>
        <td>Pad</td>
        <td>End of XSAVE region</td>
        <td>Chosen by enclave writer</td>
        <td>Ensure the end of GPRSGX region is aligned to the end of a 4KB page.</td>
    </tr>
    <tr>
        <td>MISC</td>
        <td>base of GPRSGX - sizeof(MISC)</td>
        <td>Calculate from highest set bit of SECS.MISCSELECT</td>
        <td>See Section 38.9.2.</td>
    </tr>
    <tr>
        <td>GPRSGX</td>
        <td>SSAFRAMESIZE - 184</td>
        <td>184</td>
        <td>See Table 38-9 for layout of the GPRSGX region.</td>
    </tr>
  </tbody>
</table>

## 38.9.1 GPRSGX Region

The layout of the GPRSGX region is shown in Table 38-9.

Table 38-9. Layout of GPRSGX Portion of the State Save Area

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>RAX</td>
        <td>0</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>RCX</td>
        <td>8</td>
        <td>8</td>
        <td> </td>
    </tr>
  </tbody>
</table>

38-8 Vol. 3D

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

Table 38-9. Layout of GPRSGX Portion of the State Save Area (Contd.)

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>RDX</td>
        <td>16</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>RBX</td>
        <td>24</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>RSP</td>
        <td>32</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>RBP</td>
        <td>40</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>RSI</td>
        <td>48</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>RDI</td>
        <td>56</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>R8</td>
        <td>64</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>R9</td>
        <td>72</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>R10</td>
        <td>80</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>R11</td>
        <td>88</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>R12</td>
        <td>96</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>R13</td>
        <td>104</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>R14</td>
        <td>112</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>R15</td>
        <td>120</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>RFLAGS</td>
        <td>128</td>
        <td>8</td>
        <td>Flag register.</td>
    </tr>
    <tr>
        <td>RIP</td>
        <td>136</td>
        <td>8</td>
        <td>Instruction pointer.</td>
    </tr>
    <tr>
        <td>URSP</td>
        <td>144</td>
        <td>8</td>
        <td>Non-Enclave (outside) stack pointer. Saved by EENTER, restored on AEX.</td>
    </tr>
    <tr>
        <td>URBP</td>
        <td>152</td>
        <td>8</td>
        <td>Non-Enclave (outside) RBP pointer. Saved by EENTER, restored on AEX.</td>
    </tr>
    <tr>
        <td>EXITINFO</td>
        <td>160</td>
        <td>4</td>
        <td>Contains information about exceptions that cause AEXs, which might be<br/>needed by enclave software (see Section 38.9.1.1).</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>164</td>
        <td>3</td>
        <td> </td>
    </tr>
    <tr>
        <td>AEXNOTIFY</td>
        <td>167</td>
        <td>1</td>
        <td>Bit 0: This bit allows enclave software to dynamically enable/disable AEX noti-<br/>fications. An enclave thread cannot receive AEX notifications unless this bit is<br/>set to 1 in the thread’s current SSA frame.<br/>All other bits are reserved.</td>
    </tr>
    <tr>
        <td>FSBASE</td>
        <td>168</td>
        <td>8</td>
        <td>FS BASE.</td>
    </tr>
    <tr>
        <td>GSBASE</td>
        <td>176</td>
        <td>8</td>
        <td>GS BASE.</td>
    </tr>
  </tbody>
</table>

# 38.9.1.1 EXITINFO

EXITINFO contains the information used to report exit reasons to software inside the enclave. It is a 4 byte field laid out as in Table 38-10. The VALID bit is set only for the exceptions conditions which are reported inside an enclave. See Table 38-11 for which exceptions are reported inside the enclave. If the exception condition is not one reported inside the enclave then VECTOR and EXIT_TYPE are cleared.

When a higher priority event, such as SMI, and a pending debug exception occur at the same time when executing inside an enclave, the higher priority event has precedence. As an example for an SMI, the SSA exit info is zero. The debug exception will be delivered upon return from the SMI. In such cases, the EXITINFO field will not contain the information of a debug exception.

Table 38-10. Layout of EXITINFO Field

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>VECTOR</td>
        <td>7:0</td>
        <td>Exception number of exceptions reported inside enclave.</td>
    </tr>
    <tr>
        <td>EXIT_TYPE</td>
        <td>10:8</td>
        <td>011b: Hardware exceptions.<br/>110b: Software exceptions.<br/>Other values: Reserved.</td>
    </tr>
  </tbody>
</table>

Vol. 3D 38-9

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

Table 38-10. Layout of EXITINFO Field

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>RESERVED</td>
        <td>30:11</td>
        <td>Reserved as zero.</td>
    </tr>
    <tr>
        <td>VALID</td>
        <td>31</td>
        <td>0: unsupported exceptions.<br/>1: Supported exceptions. Includes two categories:<br/>* Unconditionally supported exceptions: #DE, #DB, #BP, #BR, #UD, #MF, #AC, #XM.<br/>* Conditionally supported exception:<br/>— #PF, #GP if SECS.MISCSELECT.EXINFO = 1.<br/>— #CP if SECS.MISCSELECT.CPINFO = 1.</td>
    </tr>
  </tbody>
</table>

## 38.9.1.2 VECTOR Field Definition

Table 38-11 contains the VECTOR field. This field contains information about some exceptions which occur inside the enclave. These vector values are the same as the values that would be used when vectoring into regular exception handlers. All values not shown are not reported inside an enclave.

Table 38-11. Exception Vectors

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Vector #</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>#DE</td>
        <td>0</td>
        <td>Divider exception.</td>
    </tr>
    <tr>
        <td>#DB</td>
        <td>1</td>
        <td>Debug exception.</td>
    </tr>
    <tr>
        <td>#BP</td>
        <td>3</td>
        <td>Breakpoint exception.</td>
    </tr>
    <tr>
        <td>#BR</td>
        <td>5</td>
        <td>Bound range exceeded exception.</td>
    </tr>
    <tr>
        <td>#UD</td>
        <td>6</td>
        <td>Invalid opcode exception.</td>
    </tr>
    <tr>
        <td>#GP</td>
        <td>13</td>
        <td>General protection exception. Only reported if SECS.MISCSELECT.EXINFO = 1.</td>
    </tr>
    <tr>
        <td>#PF</td>
        <td>14</td>
        <td>Page fault exception. Only reported if SECS.MISCSELECT.EXINFO = 1.</td>
    </tr>
    <tr>
        <td>#MF</td>
        <td>16</td>
        <td>x87 FPU floating-point error.</td>
    </tr>
    <tr>
        <td>#AC</td>
        <td>17</td>
        <td>Alignment check exceptions.</td>
    </tr>
    <tr>
        <td>#XM</td>
        <td>19</td>
        <td>SIMD floating-point exceptions.</td>
    </tr>
    <tr>
        <td>#CP</td>
        <td>21</td>
        <td>Control protection exception. Only reported if SECS.MISCSELECT.CPINFO = 1.</td>
    </tr>
  </tbody>
</table>

## 38.9.2 MISC Region

The layout of the MISC region is shown in Table 38-12. The number of components that the processor supports in the MISC region corresponds to the bits of CPUID.12H.00H:EBX[31:0] set to 1. Each set bit in CPUID.12H.00H:EBX[31:0] has a defined size for the corresponding component, as shown in Table 38-12. Enclave writers needs to do the following:

* Decide which MISC region components will be supported for the enclave.

* Allocate an SSA frame large enough to hold the components chosen above.

* Instruct each enclave builder software to set the appropriate bits in SECS.MISCSELECT.

The first component, EXINFO, starts next to the GPRSGX region. Additional components in the MISC region grow in ascending order within the MISC region towards the XSAVE region.

The size of the MISC region is calculated as follows:

* If CPUID.12H.00H:EBX[31:0] = 0, MISC region is not supported.

* If CPUID.12H.00H:EBX[31:0] != 0, the size of MISC region is derived from sum of the highest bit set in SECS.MISCSELECT and the size of the MISC component corresponding to that bit. Offset and size information of currently defined MISC components are listed in Table 38-12. For example, if the highest bit set in SECS.MISCSELECT is bit 0, the MISC region offset is OFFSET(GPRSGX)-16 and size is 16 bytes.

<page_number>38-10</page_number> Vol. 3D

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

* The processor saves a MISC component i in the MISC region if and only if SECS.MISCSELECT[i] is 1.

Table 38-12. Layout of MISC region of the State Save Area

<table>
  <thead>
    <tr>
        <th>MISC Components</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EXINFO</td>
        <td>Offset(GPRSGX) – 16</td>
        <td>16</td>
        <td>If CPUID.12H.00H:EBX[0] = 1, exception information on #GP or #PF that occurred inside an enclave can be written to the EXINFO structure if specified by SECS.MISCSELECT[0] = 1.<br/>If CPUID.12H.00H:EBX[1] = 1, exception information on #CP that occurred inside an enclave can be written to the EXINFO structure if specified by SECS.MISCSELECT[1] = 1.</td>
    </tr>
    <tr>
        <td>Future Extension</td>
        <td>Below EXINFO</td>
        <td>TBD</td>
        <td>Reserved. (Zero size if CPUID.12H.00H:EBX[31:1] = 0).</td>
    </tr>
  </tbody>
</table>

## 38.9.2.1 EXINFO Structure

Table 38-13 contains the layout of the EXINFO structure that provides additional information.

Table 38-13. Layout of EXINFO Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MADDR</td>
        <td>0</td>
        <td>8</td>
        <td>If #PF: contains the page fault linear address that caused a page fault.<br/>If #GP: the field is cleared.<br/>If #CP: the field is cleared.</td>
    </tr>
    <tr>
        <td>ERRCD</td>
        <td>8</td>
        <td>4</td>
        <td>Exception error code for either #GP or #PF.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>12</td>
        <td>4</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## 38.9.2.2 Page Fault Error Code

A page-fault error code may be reported in EXINFO.ERRCD. The format of the error code is given in Figure 5-12, "Page-Fault Error Code."

Page faults that would report an error code clearing the U/S bit (indicating a supervisor-mode access) are not reported in EXINFO.

## 38.10 CET STATE SAVE AREA FRAME

The CET state save area consists of an array of CET state save frames. The number of CET state save frames is equal to the TCS.NSSA. The current CET SSA frame is indicated by TCS.CSSA. The offset of the CET state save area is specified by TCS.OCETSSA.

Table 38-14. Layout of CET State Save Area Frame

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Offset (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>SSP</td>
        <td>0</td>
        <td>8</td>
        <td>Shadow Stack Pointer.<br/>This field is reserved when CPUID.07H.00H:ECX.CET_SS is 0.</td>
    </tr>
    <tr>
        <td>IB_TRACK_STATE</td>
        <td>8</td>
        <td>8</td>
        <td>Indirect branch tracker state:<br/>Bit 0: SUPPRESS – suppressed(1), tracking(0)<br/>Bit 1: TRACKER - IDLE (0), WAIT_FOR_ENDBRANCH (1)<br/>Bits 63:2 – Reserved<br/>This field is reserved when CPUID.07H.00H:EDX.CET_IBT is 0.</td>
    </tr>
  </tbody>
</table>

Vol. 3D 38-11
<page_number>38-11</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

# 38.11 PAGE INFORMATION (PAGEINFO)

PAGEINFO is an architectural data structure that is used as a parameter to the EPC-management instructions. It requires 32-Byte alignment.

Table 38-15. Layout of PAGEINFO Data Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>LINADDR</td>
        <td>0</td>
        <td>8</td>
        <td>Enclave linear address.</td>
    </tr>
    <tr>
        <td>SRCPGE</td>
        <td>8</td>
        <td>8</td>
        <td>Effective address of the page where contents are located.</td>
    </tr>
    <tr>
        <td>SECINFO/PCMD</td>
        <td>16</td>
        <td>8</td>
        <td>Effective address of the SECINFO or PCMD (for ELDU, ELDB, EWB) structure for the page.</td>
    </tr>
    <tr>
        <td>SECS</td>
        <td>24</td>
        <td>8</td>
        <td>Effective address of EPC slot that currently contains the SECS.</td>
    </tr>
  </tbody>
</table>

# 38.12 SECURITY INFORMATION (SECINFO)

The SECINFO data structure holds meta-data about an enclave page.

Table 38-16. Layout of SECINFO Data Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>FLAGS</td>
        <td>0</td>
        <td>8</td>
        <td>Flags describing the state of the enclave page.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>8</td>
        <td>56</td>
        <td>Must be zero.</td>
    </tr>
  </tbody>
</table>

## 38.12.1 SECINFO.FLAGS

The SECINFO.FLAGS are a set of fields describing the properties of an enclave page.

Table 38-17. Layout of SECINFO.FLAGS Field

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>R</td>
        <td>0</td>
        <td>If 1 indicates that the page can be read from inside the enclave; otherwise the page cannot be read from inside the enclave.</td>
    </tr>
    <tr>
        <td>W</td>
        <td>1</td>
        <td>If 1 indicates that the page can be written from inside the enclave; otherwise the page cannot be written from inside the enclave.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>2</td>
        <td>If 1 indicates that the page can be executed from inside the enclave; otherwise the page cannot be executed from inside the enclave.</td>
    </tr>
    <tr>
        <td>PENDING</td>
        <td>3</td>
        <td>If 1 indicates that the page is in the PENDING state; otherwise the page is not in the PENDING state.</td>
    </tr>
    <tr>
        <td>MODIFIED</td>
        <td>4</td>
        <td>If 1 indicates that the page is in the MODIFIED state; otherwise the page is not in the MODIFIED state.</td>
    </tr>
    <tr>
        <td>PR</td>
        <td>5</td>
        <td>If 1 indicates that a permission restriction operation on the page is in progress, otherwise a permission restriction operation is not in progress.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>7:6</td>
        <td>Must be zero.</td>
    </tr>
    <tr>
        <td>PAGE_TYPE</td>
        <td>15:8</td>
        <td>The type of page that the SECINFO is associated with.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>63:16</td>
        <td>Must be zero.</td>
    </tr>
  </tbody>
</table>

## 38.12.2 PAGE_TYPE Field Definition

The SECINFO flags and EPC flags contain bits indicating the type of page.

38-12 Vol. 3D
<page_number>38-12</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

Table 38-18. Supported PAGE_TYPE

<table>
  <thead>
    <tr>
        <th>TYPE</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>PT_SECS</td>
        <td>0</td>
        <td>Page is an SECS.</td>
    </tr>
    <tr>
        <td>PT_TCS</td>
        <td>1</td>
        <td>Page is a TCS.</td>
    </tr>
    <tr>
        <td>PT_REG</td>
        <td>2</td>
        <td>Page is a regular page.</td>
    </tr>
    <tr>
        <td>PT_VA</td>
        <td>3</td>
        <td>Page is a Version Array.</td>
    </tr>
    <tr>
        <td>PT_TRIM</td>
        <td>4</td>
        <td>Page is in trimmed state.</td>
    </tr>
    <tr>
        <td>PT_SS_FIRST</td>
        <td>5</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, Page is first page of a shadow stack. When CPUID.12H.01H:EAX[6] is 0, this value is reserved.</td>
    </tr>
    <tr>
        <td>PT_SS_REST</td>
        <td>6</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, Page is not first page of a shadow stack. When CPUID.12H.01H:EAX[6] is 0, this value is reserved.</td>
    </tr>
    <tr>
        <td> </td>
        <td>All others</td>
        <td>Reserved.</td>
    </tr>
  </tbody>
</table>

# 38.13 PAGING CRYPTO METADATA (PCMD)

The PCMD structure is used to keep track of crypto meta-data associated with a paged-out page. Combined with PAGEINFO, it provides enough information for the processor to verify, decrypt, and reload a paged-out EPC page. The size of the PCMD structure (128 bytes) is architectural.

EWB calculates the Message Authentication Code (MAC) value and writes out the PCMD. ELDB/U reads the fields and checks the MAC.

The format of PCMD is as follows:

Table 38-19. Layout of PCMD Data Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>SECINFO</td>
        <td>0</td>
        <td>64</td>
        <td>Flags describing the state of the enclave page; R/W by software.</td>
    </tr>
    <tr>
        <td>ENCLAVEID</td>
        <td>64</td>
        <td>8</td>
        <td>Enclave Identifier used to establish a cryptographic binding between paged-out page and the enclave.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>72</td>
        <td>40</td>
        <td>Must be zero.</td>
    </tr>
    <tr>
        <td>MAC</td>
        <td>112</td>
        <td>16</td>
        <td>Message Authentication Code for the page, page meta-data and reserved field.</td>
    </tr>
  </tbody>
</table>

# 38.14 ENCLAVE SIGNATURE STRUCTURE (SIGSTRUCT)

SIGSTRUCT is a structure created and signed by the enclave developer that contains information about the enclave. SIGSTRUCT is processed by the EINIT leaf function to verify that the enclave was properly built.

SIGSTRUCT includes ENCLAVEHASH as SHA256 digest, as defined in FIPS PUB 180-4. The digests are byte strings of length 32. Each of the 8 HASH dwords is stored in little-endian order.

SIGSTRUCT includes four 3072-bit integers (MODULUS, SIGNATURE, Q1, Q2). Each such integer is represented as a byte strings of length 384, with the most significant byte at the position “offset + 383”, and the least significant byte at position “offset”.

The (3072-bit integer) SIGNATURE should be an RSA signature, where: a) the RSA modulus (MODULUS) is a 3072-bit integer; b) the public exponent is set to 3; c) the signing procedure uses the EMSA-PKCS1-v1.5 format with DER encoding of the “DigestInfo” value as specified in of PKCS#1 v2.1/RFC 3447.

The 3072-bit integers Q1 and Q2 are defined by:

$$ q1 = floor(Signature^2 / Modulus); $$

$$ q2 = floor((Signature^3 - q1 * Signature * Modulus) / Modulus); $$

Vol. 3D 38-13
<page_number>38-13</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

# SIGSTRUCT must be page aligned

In column 5 of Table 38-20, ‘Y’ indicates that this field should be included in the signature generated by the developer.

Table 38-20. Layout of Enclave Signature Structure (SIGSTRUCT)

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
        <th>Signed</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>HEADER</td>
        <td>0</td>
        <td>16</td>
        <td>Must be byte stream<br/>06000000E10000000000010000000000H</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>VENDOR</td>
        <td>16</td>
        <td>4</td>
        <td>Intel Enclave: 00008086H<br/>Non-Intel Enclave: 00000000H</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>DATE</td>
        <td>20</td>
        <td>4</td>
        <td>Build date is yyyymmdd in hex:<br/>yyyy=4 digit year, mm=1-12, dd=1-31</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>HEADER2</td>
        <td>24</td>
        <td>16</td>
        <td>Must be byte stream<br/>01010000600000006000000001000000H</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>SWDEFINED</td>
        <td>40</td>
        <td>4</td>
        <td>Available for software use.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>44</td>
        <td>84</td>
        <td>Must be zero.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>MODULUS</td>
        <td>128</td>
        <td>384</td>
        <td>Module Public Key (keylength = 3072 bits).</td>
        <td>N</td>
    </tr>
    <tr>
        <td>EXPONENT</td>
        <td>512</td>
        <td>4</td>
        <td>RSA Exponent = 3.</td>
        <td>N</td>
    </tr>
    <tr>
        <td>SIGNATURE</td>
        <td>516</td>
        <td>384</td>
        <td>Signature over Header and Body.</td>
        <td>N</td>
    </tr>
    <tr>
        <td>MISCSELECT<sup>1</sup></td>
        <td>900</td>
        <td>4</td>
        <td>Bit vector specifying Extended SSA frame feature set to be used.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>MISCMASK</td>
        <td>904</td>
        <td>4</td>
        <td>Bit vector mask of MISCSELECT to enforce.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>CET_ATTRIBUTES</td>
        <td>908</td>
        <td>1</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, this field provides the Enclave CET attributes that must be set. When CPUID.12H.01H:EAX[6] is 0, this field is reserved and must be 0.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>CET_ATTRIBUTES_MASK</td>
        <td>909</td>
        <td>1</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, this field provides the Mask of CET attributes to enforce. When CPUID.12H.01H:EAX[6] is 0, this field is reserved and must be 0.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>910</td>
        <td>2</td>
        <td>Must be zero.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>ISVFAMILYID</td>
        <td>912</td>
        <td>16</td>
        <td>ISV assigned Product Family ID.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>ATTRIBUTES</td>
        <td>928</td>
        <td>16</td>
        <td>Enclave Attributes that must be set.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>ATTRIBUTEMASK</td>
        <td>944</td>
        <td>16</td>
        <td>Mask of Attributes to enforce.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>ENCLAVEHASH</td>
        <td>960</td>
        <td>32</td>
        <td>MRENCLAVE of enclave this structure applies to.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>992</td>
        <td>16</td>
        <td>Must be zero.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>ISVEXTPRODID</td>
        <td>1008</td>
        <td>16</td>
        <td>ISV assigned extended Product ID.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>ISVPRODID</td>
        <td>1024</td>
        <td>2</td>
        <td>ISV assigned Product ID.</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>ISVSVN</td>
        <td>1026</td>
        <td>2</td>
        <td>ISV assigned SVN (security version number).</td>
        <td>Y</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>1028</td>
        <td>12</td>
        <td>Must be zero.</td>
        <td>N</td>
    </tr>
    <tr>
        <td>Q1</td>
        <td>1040</td>
        <td>384</td>
        <td>Q1 value for RSA Signature Verification.</td>
        <td>N</td>
    </tr>
    <tr>
        <td>Q2</td>
        <td>1424</td>
        <td>384</td>
        <td>Q2 value for RSA Signature Verification.</td>
        <td>N</td>
    </tr>
  </tbody>
</table>

NOTES:

1. If CPUID.12H.00H:EBX[31:0] = 0, MISCSELECT must be 0.

38-14 Vol. 3D
<page_number>38-14</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

# 38.15 EINIT TOKEN STRUCTURE (EINITTOKEN)

The EINIT token is used by EINIT to verify that the enclave is permitted to launch. EINIT token is generated by an enclave in possession of the EINITTOKEN key (the Launch Enclave).

EINIT token must be 512-Byte aligned.

Table 38-21. Layout of EINIT Token (EINITTOKEN)

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>MACed</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Valid</td>
        <td>0</td>
        <td>4</td>
        <td>Y</td>
        <td>Bit 0: 1: Valid; 0: Invalid.<br/>All other bits reserved.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>4</td>
        <td>44</td>
        <td>Y</td>
        <td>Must be zero.</td>
    </tr>
    <tr>
        <td>ATTRIBUTES</td>
        <td>48</td>
        <td>16</td>
        <td>Y</td>
        <td>ATTRIBUTES of the Enclave.</td>
    </tr>
    <tr>
        <td>MRENCLAVE</td>
        <td>64</td>
        <td>32</td>
        <td>Y</td>
        <td>MRENCLAVE of the Enclave.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>96</td>
        <td>32</td>
        <td>Y</td>
        <td>Reserved.</td>
    </tr>
    <tr>
        <td>MRSIGNER</td>
        <td>128</td>
        <td>32</td>
        <td>Y</td>
        <td>MRSIGNER of the Enclave.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>160</td>
        <td>32</td>
        <td>Y</td>
        <td>Reserved.</td>
    </tr>
    <tr>
        <td>CPUSVNLE</td>
        <td>192</td>
        <td>16</td>
        <td>N</td>
        <td>Launch Enclave’s CPUSVN.</td>
    </tr>
    <tr>
        <td>ISVPRODIDLE</td>
        <td>208</td>
        <td>02</td>
        <td>N</td>
        <td>Launch Enclave’s ISVPRODID.</td>
    </tr>
    <tr>
        <td>ISVSVNLE</td>
        <td>210</td>
        <td>02</td>
        <td>N</td>
        <td>Launch Enclave’s ISVSVN.</td>
    </tr>
    <tr>
        <td>CET_MASKED_AT TRIBUTES_LE</td>
        <td>212</td>
        <td>1</td>
        <td>N</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, this field provides the Launch enclaves masked CET attributes. This should be set to LE’s CET_ATTRIBUTES masked with CET_ATTRIBUTES_MASK of the LE’s KEYREQUEST. When CPUID.12H.01H:EAX[6] is 0, this field is reserved.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>213</td>
        <td>23</td>
        <td>N</td>
        <td>Reserved.</td>
    </tr>
    <tr>
        <td>MASKEDMISCSEL ECTLE</td>
        <td>236</td>
        <td>4</td>
        <td> </td>
        <td>Launch Enclave’s MASKEDMISCSELECT: set by the LE to the resolved MISCSELECT value, used by EGETKEY (after applying KEYREQUEST’s masking).</td>
    </tr>
    <tr>
        <td>MASKEDATTRIBU TESLE</td>
        <td>240</td>
        <td>16</td>
        <td>N</td>
        <td>Launch Enclave’s MASKEDATTRIBUTES: This should be set to the LE’s ATTRIBUTES masked with ATTRIBUTEMASK of the LE’s KEYREQUEST.</td>
    </tr>
    <tr>
        <td>KEYID</td>
        <td>256</td>
        <td>32</td>
        <td>N</td>
        <td>Value for key wear-out protection.</td>
    </tr>
    <tr>
        <td>MAC</td>
        <td>288</td>
        <td>16</td>
        <td>N</td>
        <td>Message Authentication Code on EINITTOKEN using EINITTOKEN_KEY.</td>
    </tr>
  </tbody>
</table>

# 38.16 REPORT (REPORT)

The REPORT structure is the output of the EREPORT instruction, and must be 512-Byte aligned.

Table 38-22. Layout of REPORT

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CPUSVN</td>
        <td>0</td>
        <td>16</td>
        <td>The security version number of the processor.</td>
    </tr>
    <tr>
        <td>MISCSELECT</td>
        <td>16</td>
        <td>4</td>
        <td>Bit vector specifying which extended features are saved to the MISC region of the SSA frame when an AEX occurs.</td>
    </tr>
    <tr>
        <td>CET_ATTRIBUTES</td>
        <td>20</td>
        <td>1</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, this field reports the CET_ATTRIBUTES of the Enclave. When CPUID.12H.01H:EAX[6] is 0, this field is reserved and must be 0.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>21</td>
        <td>11</td>
        <td>Zero.</td>
    </tr>
    <tr>
        <td>ISVEXTNPRODID</td>
        <td>32</td>
        <td>16</td>
        <td>The value of SECS.ISVEXTPRODID.</td>
    </tr>
    <tr>
        <td>ATTRIBUTES</td>
        <td>48</td>
        <td>16</td>
        <td>ATTRIBUTES of the Enclave. See Section 38.7.1.</td>
    </tr>
  </tbody>
</table>

Vol. 3D 38-15
<page_number>38-15</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

Table 38-22. Layout of REPORT (Contd.)

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MRENCLAVE</td>
        <td>64</td>
        <td>32</td>
        <td>The value of SECS.MRENCLAVE.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>96</td>
        <td>32</td>
        <td>Zero.</td>
    </tr>
    <tr>
        <td>MRSIGNER</td>
        <td>128</td>
        <td>32</td>
        <td>The value of SECS.MRSIGNER.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>160</td>
        <td>32</td>
        <td>Zero.</td>
    </tr>
    <tr>
        <td>CONFIGID</td>
        <td>192</td>
        <td>64</td>
        <td>Value provided by SW to identify enclave's post EINIT configuration.</td>
    </tr>
    <tr>
        <td>ISVPRODID</td>
        <td>256</td>
        <td>2</td>
        <td>Product ID of enclave.</td>
    </tr>
    <tr>
        <td>ISVSVN</td>
        <td>258</td>
        <td>2</td>
        <td>Security version number (SVN) of the enclave.</td>
    </tr>
    <tr>
        <td>CONFIGSVN</td>
        <td>260</td>
        <td>2</td>
        <td>Value provided by SW to indicate expected SVN of enclave's post EINIT configuration.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>262</td>
        <td>42</td>
        <td>Zero.</td>
    </tr>
    <tr>
        <td>ISVFAMILYID</td>
        <td>304</td>
        <td>16</td>
        <td>The value of SECS.ISVFAMILYID.</td>
    </tr>
    <tr>
        <td>REPORTDATA</td>
        <td>320</td>
        <td>64</td>
        <td>Data provided by the user and protected by the REPORT's MAC, see Section 38.16.1.</td>
    </tr>
    <tr>
        <td>KEYID</td>
        <td>384</td>
        <td>32</td>
        <td>Value for key wear-out protection.</td>
    </tr>
    <tr>
        <td>MAC</td>
        <td>416</td>
        <td>16</td>
        <td>Message Authentication Code on the report using report key.</td>
    </tr>
  </tbody>
</table>

## 38.16.1 REPORTDATA

REPORTDATA is a 64-Byte data structure that is provided by the enclave and included in the REPORT. It can be used to securely pass information from the enclave to the target enclave.

## 38.17 REPORT TARGET INFO (TARGETINFO)

This structure is an input parameter to the EREPORT leaf function. The address of TARGETINFO is specified as an effective address in RBX. It is used to identify the target enclave which will be able to cryptographically verify the REPORT structure returned by EREPORT. TARGETINFO must be 512-Byte aligned.

Table 38-23. Layout of TARGETINFO Data Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MEASUREMENT</td>
        <td>0</td>
        <td>32</td>
        <td>The MRENCLAVE of the target enclave.</td>
    </tr>
    <tr>
        <td>ATTRIBUTES</td>
        <td>32</td>
        <td>16</td>
        <td>The ATTRIBUTES field of the target enclave.</td>
    </tr>
    <tr>
        <td>CET_ATTRIBUTES</td>
        <td>48</td>
        <td>1</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, this field provides the CET_ATTRIBUTES field of the target enclave. When CPUID.12H.01H:EAX[6] is 0, this field is reserved.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>49</td>
        <td>1</td>
        <td>Must be zero.</td>
    </tr>
    <tr>
        <td>CONFIGSVN</td>
        <td>50</td>
        <td>2</td>
        <td>CONFIGSVN of the target enclave.</td>
    </tr>
    <tr>
        <td>MISCSELECT</td>
        <td>52</td>
        <td>4</td>
        <td>The MISCSELECT of the target enclave.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>56</td>
        <td>8</td>
        <td>Must be zero.</td>
    </tr>
    <tr>
        <td>CONFIGID</td>
        <td>64</td>
        <td>64</td>
        <td>CONFIGID of target enclave.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>128</td>
        <td>384</td>
        <td>Must be zero.</td>
    </tr>
  </tbody>
</table>

38-16 Vol. 3D
<page_number>38-16</page_number>

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

# 38.18 KEY REQUEST (KEYREQUEST)

This structure is an input parameter to the EGETKEY leaf function. It is passed in as an effective address in RBX and must be 512-Byte aligned. It is used for selecting the appropriate key and any additional parameters required in the derivation of that key.

Table 38-24. Layout of KEYREQUEST Data Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>KEYNAME</td>
        <td>0</td>
        <td>2</td>
        <td>Identifies the Key Required.</td>
    </tr>
    <tr>
        <td>KEYPOLICY</td>
        <td>2</td>
        <td>2</td>
        <td>Identifies which inputs are required to be used in the key derivation.</td>
    </tr>
    <tr>
        <td>ISVSVN</td>
        <td>4</td>
        <td>2</td>
        <td>The ISV security version number that will be used in the key derivation.</td>
    </tr>
    <tr>
        <td>CET_ATTRIBUTES<br/>_MASK</td>
        <td>6</td>
        <td>1</td>
        <td>When CPUID.12H.01H:EAX[6] is 1, this field provides a mask that defines which CET_ATTRIBUTES bits will be included in key derivation. When CPUID.12H.01H:EAX[6] is 0, then this field is reserved and must be 0.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>7</td>
        <td>1</td>
        <td>Must be zero.</td>
    </tr>
    <tr>
        <td>CPUSVN</td>
        <td>8</td>
        <td>16</td>
        <td>The security version number of the processor used in the key derivation.</td>
    </tr>
    <tr>
        <td>ATTRIBUTEMASK</td>
        <td>24</td>
        <td>16</td>
        <td>A mask defining which ATTRIBUTES bits will be included in key derivation.</td>
    </tr>
    <tr>
        <td>KEYID</td>
        <td>40</td>
        <td>32</td>
        <td>Value for key wear-out protection.</td>
    </tr>
    <tr>
        <td>MISCMASK</td>
        <td>72</td>
        <td>4</td>
        <td>A mask defining which MISCSELECT bits will be included in key derivation.</td>
    </tr>
    <tr>
        <td>CONFIGSVN</td>
        <td>76</td>
        <td>2</td>
        <td>Identifies which enclave Configuration’s Security Version should be used in key derivation.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>78</td>
        <td>434</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## 38.18.1 KEY REQUEST KeyNames

Table 38-25. Supported KEYName Values

<table>
  <thead>
    <tr>
        <th>Key Name</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EINITTOKEN_KEY</td>
        <td>0</td>
        <td>EINIT_TOKEN key</td>
    </tr>
    <tr>
        <td>PROVISION_KEY</td>
        <td>1</td>
        <td>Provisioning Key</td>
    </tr>
    <tr>
        <td>PROVISION_SEAL_KEY</td>
        <td>2</td>
        <td>Provisioning Seal Key</td>
    </tr>
    <tr>
        <td>REPORT_KEY</td>
        <td>3</td>
        <td>Report Key</td>
    </tr>
    <tr>
        <td>SEAL_KEY</td>
        <td>4</td>
        <td>Seal Key</td>
    </tr>
    <tr>
        <td colspan="2">All others</td>
        <td>Reserved</td>
    </tr>
  </tbody>
</table>

## 38.18.2 Key Request Policy Structure

Table 38-26. Layout of KEYPOLICY Field

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>MRENCLAVE</td>
        <td>0</td>
        <td>If 1, derive key using the enclave’s MRENCLAVE measurement register.</td>
    </tr>
    <tr>
        <td>MRSIGNER</td>
        <td>1</td>
        <td>If 1, derive key using the enclave’s MRSIGNER measurement register.</td>
    </tr>
    <tr>
        <td>NOISVPRODID</td>
        <td>2</td>
        <td>If 1, derive key WITHOUT using the enclave’ ISVPRODID value.</td>
    </tr>
    <tr>
        <td>CONFIGID</td>
        <td>3</td>
        <td>If 1, derive key using the enclave’s CONFIGID value.</td>
    </tr>
    <tr>
        <td>ISVFAMILYID</td>
        <td>4</td>
        <td>If 1, derive key using the enclave ISVFAMILYID value.</td>
    </tr>
  </tbody>
</table>

Vol. 3D 38-17

ENCLAVE ACCESS CONTROL AND DATA STRUCTURES

Table 38-26. Layout of KEYPOLICY Field

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Bit Position</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ISVEXTPRODID</td>
        <td>5</td>
        <td>If 1, derive key using enclave’s ISVEXTPRODID value.</td>
    </tr>
    <tr>
        <td>RESERVED</td>
        <td>15:6</td>
        <td>Must be zero.</td>
    </tr>
  </tbody>
</table>

## 38.19 VERSION ARRAY (VA)

In order to securely store the versions of evicted EPC pages, Intel SGX defines a special EPC page type called a Version Array (VA). Each VA page contains 512 slots, each of which can contain an 8-byte version number for a page evicted from the EPC. When an EPC page is evicted, software chooses an empty slot in a VA page; this slot receives the unique version number of the page being evicted. When the EPC page is reloaded, there must be a VA slot that must hold the version of the page. If the page is successfully reloaded, the version in the VA slot is cleared.

VA pages can be evicted, just like any other EPC page. When evicting a VA page, a version slot in some other VA page must be used to hold the version for the VA being evicted. A Version Array Page must be 4K-Bytes aligned.

Table 38-27. Layout of Version Array Data Structure

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>OFFSET (Bytes)</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Slot 0</td>
        <td>0</td>
        <td>8</td>
        <td>Version Slot 0</td>
    </tr>
    <tr>
        <td>Slot 1</td>
        <td>8</td>
        <td>8</td>
        <td>Version Slot 1</td>
    </tr>
    <tr>
        <td colspan="4">...</td>
    </tr>
    <tr>
        <td>Slot 511</td>
        <td>4088</td>
        <td>8</td>
        <td>Version Slot 511</td>
    </tr>
  </tbody>
</table>

## 38.20 ENCLAVE PAGE CACHE MAP (EPCM)

EPCM is a secure structure used by the processor to track the contents of the EPC. The EPCM holds exactly one entry for each page that is currently loaded into the EPC. EPCM is not accessible by software, and the layout of EPCM fields is implementation specific.

Table 38-28. Content of an Enclave Page Cache Map Entry

<table>
  <thead>
    <tr>
        <th>Field</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>VALID</td>
        <td>Indicates whether the EPCM entry is valid.</td>
    </tr>
    <tr>
        <td>R</td>
        <td>Read access; indicates whether enclave accesses for reads are allowed from the EPC page referenced by this entry.</td>
    </tr>
    <tr>
        <td>W</td>
        <td>Write access; indicates whether enclave accesses for writes are allowed to the EPC page referenced by this entry.</td>
    </tr>
    <tr>
        <td>X</td>
        <td>Execute access; indicates whether enclave accesses for instruction fetches are allowed from the EPC page referenced by this entry.</td>
    </tr>
    <tr>
        <td>PT</td>
        <td>EPCM page type (PT_SECS, PT_TCS, PT_REG, PT_VA, PT_TRIM, PT_SS_FIRST, PT_SS_REST).</td>
    </tr>
    <tr>
        <td>ENCLAVESECS</td>
        <td>SECS identifier of the enclave to which the EPC page belongs.</td>
    </tr>
    <tr>
        <td>ENCLAVEADDRESS</td>
        <td>Linear enclave address of the EPC page.</td>
    </tr>
    <tr>
        <td>BLOCKED</td>
        <td>Indicates whether the EPC page is in the blocked state.</td>
    </tr>
    <tr>
        <td>PENDING</td>
        <td>Indicates whether the EPC page is in the pending state.</td>
    </tr>
    <tr>
        <td>MODIFIED</td>
        <td>Indicates whether the EPC page is in the modified state.</td>
    </tr>
    <tr>
        <td>PR</td>
        <td>Indicates whether the EPC page is in a permission restriction state.</td>
    </tr>
  </tbody>
</table>

<page_number>38-18</page_number> Vol. 3D

ENCLAVE OPERATION

# CHAPTER 39
# ENCLAVE OPERATION

The following aspects of enclave operation are described in this chapter:

* Enclave creation: Includes loading code and data from outside of enclave into the EPC and establishing the enclave entity.

* Adding pages and measuring the enclave.

* Initialization of an enclave: Finalizes the cryptographic log and establishes the enclave identity and sealing identity.

* Enclave entry and exiting including:

    - Controlled entry and exit.

    - Asynchronous Enclave Exit (AEX) and resuming execution after an AEX.

## 39.1 CONSTRUCTING AN ENCLAVE

Figure 39-1 illustrates a typical Enclave memory layout.

```mermaid
graph TD
    subgraph OS_Context [OS Context]
        SECS[SECS]
    end

    subgraph Application_Context [Application Context]
        subgraph Enclave_Memory [Enclave Memory]
            subgraph Thread_Data_Group [Thread Data]
                Thread_Data[Thread Data]
                TCS[TCS]
            end
            Global_Data[Global Data]
            Code[Code]
        end
    end

    SECS --- OS_Context
    Enclave_Memory --- Application_Context
    Thread_Data_Group -.-> Replicated[Replicated once per thread]
    
    Base_Size[Base + Size] --> Enclave_Memory
    Base[Base] --> Enclave_Memory
    
    Enclave_Range[Enclave {Base, Size}]
```

Figure 39-1. Enclave Memory Layout

The enclave creation, commitment of memory resources, and finalizing the enclave’s identity with measurement comprises multiple phases. This process can be illustrated by the following exemplary steps:

1. The application hands over the enclave content along with additional information required by the enclave creation API to the enclave creation service running at privilege level 0.

2. The enclave creation service running at privilege level 0 uses the ECREATE leaf function to set up the initial environment, specifying base address and size of the enclave. This address range, the ELRANGE, is part of the application's address space. This reserves the memory range. The enclave will now reside in this address

Vol. 3D 39-1

ENCLAVE OPERATION

region. ECREATE also allocates an Enclave Page Cache (EPC) page for the SGX Enclave Control Structure (SECS). Note that this page is not required to be a part of the enclave linear address space and is not required to be mapped into the process.

3. The enclave creation service uses the EADD leaf function to commit EPC pages to the enclave, and use EEXTEND to measure the committed memory content of the enclave. For each page to be added to the enclave:

* Use EADD to add the new page to the enclave.

* If the enclave developer requires measurement of the page as a proof for the content, use EEXTEND to add a measurement for 256 bytes of the page. Repeat this operation until the entire page is measured.

4. The enclave creation service uses the EINIT leaf function to complete the enclave creation process and finalize the enclave measurement to establish the enclave identity. Until an EINIT is executed, the enclave is not permitted to execute any enclave code (i.e., entering the enclave by executing EENTER would result in a fault).

## 39.1.1 ECREATE

The ECREATE leaf function sets up the initial environment for the enclave by reading an SGX Enclave Control Structure (SECS) that contains the enclave's address range (ELRANGE) as defined by BASEADDR and SIZE, the ATTRIBUTES and MISCSELECT bitmaps, and the SSAFRAMESIZE. It then securely stores this information in an Enclave Page Cache (EPC) page. ELRANGE is part of the application's address space. ECREATE also initializes a cryptographic log of the enclave's build process.

## 39.1.2 EADD and EEXTEND Interaction

Once the SECS has been created, enclave pages can be added to the enclave via EADD. This involves converting a free EPC page into either a PT_REG or a PT_TCS page.

When EADD is invoked, the processor will update the EPCM entry with the type of page (PT_REG or PT_TCS), the linear address used by the enclave to access the page, and the enclave access permissions for the page. It associates the page to the SECS provided as input. The EPCM entry information is used by hardware to manage access control to the page. EADD records EPCM information in the cryptographic log stored in the SECS and copies 4 KBytes of data from unprotected memory outside the EPC to the allocated EPC page.

System software is responsible for selecting a free EPC page. System software is also responsible for providing the type of page to be added, the attributes of the page, the contents of the page, and the SECS (enclave) to which the page is to be added as requested by the application. Incorrect data would lead to a failure of EADD or to an incorrect cryptographic log and a failure at EINIT time.

After a page has been added to an enclave, software can measure a 256 byte region as determined by the developer by invoking EEXTEND. Thus to measure an entire 4KB page, system software must execute EEXTEND 16 times. Each invocation of EEXTEND adds to the cryptographic log information about which region is being measured and the measurement of the section.

Entries in the cryptographic log define the measurement of the enclave and are critical in gaining assurance that the enclave was correctly constructed by the untrusted system software.

## 39.1.3 EINIT Interaction

Once system software has completed the process of adding and measuring pages, the enclave needs to be initialized by the EINIT leaf function. After an enclave is initialized, EADD and EEXTEND are disabled for that enclave (An attempt to execute EADD/EEXTEND to enclave after enclave initialization will result in a fault). The initialization process finalizes the cryptographic log and establishes the **enclave identity** and **sealing identity** used by EGETKEY and EREPORT.

A cryptographic hash of the log is stored as the **enclave identity**. Correct construction of the enclave results in the cryptographic hash matching the one built by the enclave owner and included as the ENCLAVEHASH field of SIGSTRUCT. The **enclave identity** provided by the EREPORT leaf function can be verified by a remote party.

<page_number>39-2</page_number> Vol. 3D

ENCLAVE OPERATION

The EINIT leaf function checks the EINIT token to validate that the enclave has been enabled on this platform. If the enclave is not correctly constructed, or the EINIT token is not valid for the platform, or SIGSTRUCT isn't properly signed, then EINIT will fail. See the EINIT leaf function for details on the error reporting.

The **enclave identity** is a cryptographic hash that reflects the enclave attributes and MISCSELECT value, content of the enclave, the order in which it was built, the addresses it occupies in memory, the security attributes, and access right permissions of each page. The **enclave identity** is established by the EINIT leaf function.

The **sealing identity** is managed by a sealing authority represented by the hash of the public key used to sign the SIGSTRUCT structure processed by EINIT. The sealing authority assigns a product ID (ISVPRODID) and security version number (ISVSVN) to a particular enclave identity.

EINIT establishes the sealing identity using the following steps:

1. Verifies that SIGSTRUCT is properly signed using the public key enclosed in the SIGSTRUCT.

2. Checks that the measurement of the enclave matches the measurement of the enclave specified in SIGSTRUCT.

3. Checks that the enclave’s attributes and MISCSELECT values are compatible with those specified in SIGSTRUCT.

4. Finalizes the measurement of the enclave and records the **sealing identity** (the sealing authority, product id and security version number) and **enclave identity** in the SECS.

5. Sets the ATTRIBUTES.INIT bit for the enclave.

## 39.1.4 Intel® SGX Launch Control Configuration

Intel® SGX Launch Control is a set of controls that govern the creation of enclaves. Before the EINIT leaf function will successfully initialize an enclave, a designated Launch Enclave must create an EINITTOKEN for that enclave. Launch Enclaves have SECS.ATTRIBUTES.EINITTOKEN_KEY = 1, granting them access to the EINITTOKEN_KEY from the EGETKEY leaf function. EINITTOKEN_KEY must be used by the Launch Enclave when computing EINITTOKEN.MAC, the Message Authentication Code of the EINITTOKEN.

The hash of the public key used to sign the SIGSTRUCT of the Launch Enclave must equal the value in the IA32_SGXLEPUBKEYHASH MSRs. Only Launch Enclaves are allowed to launch without a valid token.

The IA32_SGXLEPUBKEYHASH MSRs are provided to designate the platform’s Launch Enclave. IA32_SGXLEPUBKEYHASH defaults to digest of Intel’s launch enclave signing key after reset.

IA32_FEATURE_CONTROL bit 17 controls the permissions on the IA32_SGXLEPUBKEYHASH MSRs when CPUID.12H.00H:EAX[0] = 1. If IA32_FEATURE_CONTROL is locked with bit 17 set, IA32_SGXLEPUBKEYHASH MSRs are reconfigurable (writeable). If either IA32_FEATURE_CONTROL is not locked or bit 17 is clear, the MSRs are read only. By leaving these MSRs writable, system SW or a VMM can support a plurality of Launch Enclaves for hosting multiple execution environments. See Table 43.2.2 for more details.

## 39.2 ENCLAVE ENTRY AND EXITING

### 39.2.1 Controlled Entry and Exit

The EENTER leaf function is the method to enter the enclave under program control. To execute EENTER, software must supply an address of a TCS that is part of the enclave to be entered. The TCS holds the location inside the enclave to transfer control to and a pointer to the SSA frame inside the enclave that an AEX should store the register state to.

When a logical processor enters an enclave, the TCS is considered busy until the logical processors exits the enclave. An attempt to enter an enclave through a busy TCS results in a fault. Intel® SGX allows an enclave builder to define multiple TCSs, thereby providing support for multithreaded enclaves.

Software must also supply to EENTER the Asynchronous Exit Pointer (AEP) parameter. AEP is an address external to the enclave which an exception handler will return to using IRET. Typically the location would contain the ERESUME instruction. ERESUME transfers control back to the enclave, to the address retrieved from the enclave thread’s saved state.

EENTER performs the following operations:

Vol. 3D 39-3

ENCLAVE OPERATION

1. Check that TCS is not busy and flush all cached linear-to-physical mappings.

2. Change the mode of operation to be in enclave mode.

3. Save the old RSP, RBP for later restore on AEX (Software is responsible for setting up the new RSP, RBP to be used inside enclave).

4. Save XCR0 and replace it with the XFRM value for the enclave.

5. Check if software wishes to debug (applicable to a debuggable enclave):

    — If not debugging, then configure hardware so the enclave appears as a single instruction.

    — If debugging, then configure hardware to allow traps, breakpoints, and single steps inside the enclave.

6. Set the TCS as busy.

7. Transfer control from outside enclave to predetermined location inside the enclave specified by the TCS.

The EEXIT leaf function is the method of leaving the enclave under program control. EEXIT receives the target address outside of the enclave that the enclave wishes to transfer control to. It is the responsibility of enclave software to erase any secret from the registers prior to invoking EEXIT. To allow enclave software to easily perform an external function call and re-enter the enclave (using EEXIT and EENTER leaf functions), EEXIT returns the value of the AEP that was used when the enclave was entered.

EEXIT performs the following operations:

1. Clear enclave mode and flush all cached linear-to-physical mappings.

2. Mark TCS as not busy.

3. Transfer control from inside the enclave to a location on the outside specified as parameter to the EEXIT leaf function.

## 39.2.2 Asynchronous Enclave Exit (AEX)

Asynchronous and synchronous events, such as exceptions, interrupts, traps, SMIs, and VM exits may occur while executing inside an enclave. These events are referred to as Enclave Exiting Events (EEE). Upon an EEE, the processor state is securely saved inside the enclave (in the thread’s current SSA frame) and then replaced by a synthetic state to prevent leakage of secrets. The process of securely saving state and establishing the synthetic state is called an Asynchronous Enclave Exit (AEX). Details of AEX is described in Chapter 40, “Enclave Exiting Events.”

As part of most EEEs, the AEP is pushed onto the stack as the location of the eventing address. This is the location where control will return to after executing the IRET. The ERESUME leaf function can be executed from that point to reenter the enclave and resume execution from the interrupted point.

After AEX has completed, the logical processor is no longer in enclave mode and the exiting event is processed normally. Any new events that occur after the AEX has completed are treated as having occurred outside the enclave (e.g., a #PF in dispatching to an interrupt handler).

## 39.2.3 Resuming Execution After AEX

After system software has serviced the event that caused the logical processor to exit an enclave, the logical processor can continue enclave execution using ERESUME. ERESUME restores processor state and returns control to where execution was interrupted.

If the cause of the exit was an exception or a fault and was not resolved, the event will be triggered again if the enclave is re-entered using ERESUME. For example, if an enclave performs a divide by 0 operation, executing ERESUME will cause the enclave to attempt to re-execute the faulting instruction and result in another divide by 0 exception. Intel<sup>®</sup> SGX provides the means for an enclave developer to handle enclave exceptions from within the enclave. Software can enter the enclave at a different location and invoke the exception handler within the enclave by executing the EENTER leaf function. The exception handler within the enclave can read the fault information from the SSA frame and attempt to resolve the faulting condition or simply return and indicate to software that the enclave should be terminated (e.g., using EEXIT).

39-4 Vol. 3D

ENCLAVE OPERATION

## 39.2.3.1 ERESUME Interaction

ERESUME restores registers depending on the mode of the enclave (32 or 64 bit).

* In 32-bit mode (IA32_EFER.LMA = 0 || CS.L = 0), the low 32-bits of the legacy registers (EAX, EBX, ECX, EDX, ESP, EBP, ESI, EDI, EIP, and EFLAGS) are restored from the thread’s GPR area of the current SSA frame. Neither the upper 32 bits of the legacy registers nor the 64-bit registers (R8 … R15) are loaded.

* In 64-bit mode (IA32_EFER.LMA = 1 && CS.L = 1), all 64 bits of the general processor registers (RAX, RBX, RCX, RDX, RSP, RBP, RSI, RDI, R8 … R15, RIP, and RFLAGS) are loaded.

Extended features specified by SECS.ATTRIBUTES.XFRM are restored from the XSAVE area of the current SSA frame. The layout of the x87 area depends on the current values of IA32_EFER.LMA and CS.L:

* IA32_EFER.LMA = 0 || CS.L = 0

— 32-bit load in the same format that XSAVE/FXSAVE uses with these values.

* IA32_EFER.LMA = 1 && CS.L = 1

— 64-bit load in the same format that XSAVE/FXSAVE uses with these values as if REX.W = 1.

## 39.2.3.2 Asynchronous Enclave Exit Notify and EDECCSSA

Asynchronous Enclave Exit Notify (AEX-Notify) is an extension to Intel SGX that allows Intel SGX enclaves to be notified after an asynchronous enclave exit (AEX) has occurred. EDECCSSA is a new Intel SGX user leaf function (ENCLU[EDECCSSA]) that can facilitate AEX notification handling, as well as software exception handling. This section provides information about changes to the Intel SGX architecture that support AEX-Notify and ENCLU[EDECCSSA].

### NOTE

On some platforms, AEX-Notify and the EDECCSSA user leaf function may be enumerated by CPUID following a microcode update.

The following list summarizes the additions to existing Intel SGX data structures to support AEX-Notify:

* SECS.ATTRIBUTES.AEXNOTIFY: This enclave supports AEX-Notify.

* TCS.FLAGS.AEXNOTIFY: This enclave thread may receive AEX notifications.

* SSA.GPRSGX.AEXNOTIFY: Enclave-writable byte that allows enclave software to dynamically enable/disable AEX notifications.

An AEX notification is delivered by ENCLU[ERESUME] when the following conditions are met:

1. TCS.FLAGS.AEXNOTIFY is set.

2. TCS.CSSA (the current slot index of an SSA frame) is greater than zero.

3. TCS.SSA[TCS.CSSA-1].GPRSGX.AEXNOTIFY[0] is set.

Note that AEX increments TCS.CSSA, and ENCLU[ERESUME] decrements TCS.CSSA, except when an AEX notification is delivered. Instead of decrementing TCS.CSSA and restoring state from the SSA, ENCLU[ERESUME] delivers an AEX notification by behaving as ENCLU[EENTER]. Implications of this behavior include:

* The enclave thread is resumed at EnclaveBase + TCS.OENTRY.

* EAX contains the (non-decremented) value of TCS.CSSA.

* RCX contains the address of the IP following ENCLU[ERESUME].

* The architectural state saved by the most recent AEX is preserved in TCS.SSA[TCS.CSSA-1].

The enclave thread can return to the previous SSA context by invoking ENCLU[EDECCSSA], which decrements TCS.CSSA.

Vol. 3D 39-5

ENCLAVE OPERATION

# 39.3 CALLING ENCLAVE PROCEDURES

## 39.3.1 Calling Convention

In standard call conventions subroutine parameters are generally pushed onto the stack. The called routine, being aware of its own stack layout, knows how to find parameters based on compile-time-computable offsets from the SP or BP register (depending on runtime conventions used by the compiler).

Because of the stack switch when calling an enclave, stack-located parameters cannot be found in this manner. Entering the enclave requires a modified parameter passing convention.

For example, the caller might push parameters onto the untrusted stack and then pass a pointer to those parameters in RAX to the enclave software. The exact choice of calling conventions is up to the writer of the edge routines; be those routines hand-coded or compiler generated.

## 39.3.2 Register Preservation

As with most systems, it is the responsibility of the callee to preserve all registers except that used for returning a value. This is consistent with conventional usage and tends to optimize the number of register save/restore operations that need be performed. It has the additional security result that it ensures that data is scrubbed from any registers that were used by enclave to temporarily contain secrets.

## 39.3.3 Returning to Caller

No registers are modified during EEXIT. It is the responsibility of software to remove secrets in registers before executing EEXIT.

# 39.4 INTEL® SGX KEY AND ATTESTATION

## 39.4.1 Enclave Measurement and Identification

During the enclave build process, two “measurements” are taken of each enclave and are stored in two 256-bit Measurement Registers (MR): MRENCLAVE and MRSIGNER. MRENCLAVE represents the enclave's contents and build process. MRSIGNER represents the entity that signed the enclave's SIGSTRUCT.

The values of the Measurement Registers are included in attestations to identify the enclave to remote parties. The MRs are also included in most keys, binding keys to enclaves with specific MRs.

### 39.4.1.1 MRENCLAVE

MRENCLAVE is a unique 256 bit value that identifies the code and data that was loaded into the enclave during the initial launch. It is computed as a SHA256 hash that is initialized by the ECREATE leaf function. EADD and EEXTEND leaf functions record information about each page and the content of those pages. The EINIT leaf function finalizes the hash, which is stored in SECS.MRENCLAVE. Any tampering with the build process, contents of a page, page permissions, etc will result in a different MRENCLAVE value.

Figure 39-2 illustrates a simplified flow of changes to the MRENCLAVE register when building an enclave:

* Enclave creation with ECREATE.

* Copying a non-enclave source page into the EPC of an un-initialized enclave with EADD.

* Updating twice of the MRENCLAVE after modifying the enclave’s page content, i.e., EEXTEND twice.

* Finalizing the enclave build with EINIT.

Details on specific values inserted in the hash are available in the individual instruction definitions.

39-6 Vol. 3D
<page_number>39-6</page_number>

ENCLAVE OPERATION

```mermaid
graph TD
    subgraph ECREATE_Section [" "]
        SHA_INIT[SHA_INIT] --> MRENCLAVE_1[MRENCLAVE]
        ECREATE[ECREATE]
    end

    subgraph EADD_Section [" "]
        Page_Metadata[Page Metadata] --> SHA_UPDATE_1[SHA_UPDATE]
        SHA_UPDATE_1 --> MRENCLAVE_2[MRENCLAVE]
        EADD[EADD]
    end

    subgraph EEXTEND_1_Section [" "]
        Data_Chunk_1[Data Chunk 1] --> SHA_UPDATE_2[SHA_UPDATE]
        Chunk_1_Metadata[Chunk 1 Metadata] --> SHA_UPDATE_2
        SHA_UPDATE_2 --> MRENCLAVE_3[MRENCLAVE]
        EEXTEND_1[EEXTEND]
    end

    subgraph EEXTEND_2_Section [" "]
        Data_Chunk_2[Data Chunk 2] --> SHA_UPDATE_3[SHA_UPDATE]
        Chunk_2_Metadata[Chunk 2 Metadata] --> SHA_UPDATE_3
        SHA_UPDATE_3 --> MRENCLAVE_4[MRENCLAVE]
        EEXTEND_2[EEXTEND]
    end

    subgraph EINIT_Section [" "]
        SHA_FINAL[SHA_FINAL] --> MRENCLAVE_5[MRENCLAVE]
        EINIT[EINIT]
    end

    SHA_INIT -.-> SHA_UPDATE_1
    SHA_UPDATE_1 -.-> SHA_UPDATE_2
    SHA_UPDATE_2 -.-> SHA_UPDATE_3
    SHA_UPDATE_3 -.-> SHA_FINAL
```

Figure 39-2. Measurement Flow of Enclave Build Process

### 39.4.1.2 MRSIGNER

Each enclave is signed using a 3072 bit RSA key. The signature is stored in the SIGSTRUCT. In the SIGSTRUCT, the enclave's signer also assigns a product ID (ISVPRODID) and a security version (ISVSVN) to the enclave. MRSIGNER is the SHA-256 hash of the signer's public key. For platforms that support Key Separation and Sharing (CPUID.12H.01H:EAX.KSS[7]) the SIGSTRUCT can additionally specify an 16 byte extended product ID (ISVEXTPRODID), and a 16 byte family ID (ISVFAMILYID).

In attestation, MRSIGNER can be used to allow software to approve of an enclave based on the author rather than maintaining a list of MRENCLAVEs. It is used in key derivation to allow software to create a lineage of an application. By signing multiple enclaves with the same key, the enclaves will share the same keys and data. Combined with security version numbering, the author can release multiple versions of an application which can access keys for previous versions, but not future versions of that application.

### 39.4.1.3 CONFIGID

For platforms that support enhancements for key separation and sharing (CPUID.12H.01H:EAX.KSS[7]) when the enclave is created the platform can additionally provide 32-byte configuration identifier (CONFIGID). How this value is used is dependent on the enclave but it is intended to allow enclave creators to indicate what additional content may be accepted by the enclave post-initialization.

## 39.4.2 Security Version Numbers (SVN)

Intel® SGX supports a versioning system that allows the signer to identify different versions of the same software released by an author. The security version is independent of the functional version an author uses and is intended to specify security equivalence. Multiple releases with functional enhancements may all share the same SVN if they all have the same security properties or posture. Each enclave has an SVN and the underlying hardware has an SVN.

The SVNs are attested to in EREPORT and are included in the derivation of most keys, thus providing separation between data for older/newer versions.

Vol. 3D 39-7

ENCLAVE OPERATION

## 39.4.2.1 Enclave Security Version

In the SIGSTRUCT, the MRSIGNER is associated with a 16-bit Product ID (ISVPRODID) and a 16 bit integer SVN (ISVSVN). Together they define a specific group of versions of a specific product. Most keys, including the Seal Key, can be bound to this pair.

To support upgrading from one release to another, EGETKEY will return keys corresponding to any value less than or equal to the software's ISVSVN.

## 39.4.2.2 Hardware Security Version

CPUSVN is a 128 bit value that reflects the microcode update version and authenticated code modules supported by the processor. Unlike ISVSVN, CPUSVN is not an integer and cannot be compared mathematically. Not all values are valid CPUSVNs.

Software must ensure that the CPUSVN provided to EGETKEY is valid. EREPORT will return the CPUSVN of the current environment. Software can execute EREPORT with TARGETINFO set to zeros to retrieve a CPUSVN from REPORTDATA. Software can access keys for a CPUSVN recorded previously, provided that each of the elements reflected in CPUSVN are the same or have been upgraded.

## 39.4.2.3 CONFIGID Security Version

The CONFIGID field can be used to contain the hash of a signing key for verifying the additional content. In this case, similar to the relationship between MRSIGNER and ISVSVN, CONFIGID needs a CONFIGID Security Version Number. CONFIGIDSVN can be specified at the same time as CONFIGID.

## 39.4.3 Keys

Intel<sup>®</sup> SGX provides software with access to keys unique to each processor and rooted in HW keys inserted into the processor during manufacturing.

Each enclave requests keys using the EGETKEY leaf function. The key is based on enclave parameters such as measurement, the enclave signing key, security attributes of the enclave, and the Hardware Security version of the processor itself. A full list of parameter options is specified in the KEYREQUEST structure, see details in Section 38.18.

By deriving keys using enclave properties, SGX guarantees that if two enclaves call EGETKEY, they will receive a unique key only accessible by the respective enclave. It also guarantees that the enclave will receive the same key on every future execution of EGETKEY. Some parameters are optional or configurable by software. For example, a Seal key can be based on the signer of the enclave, resulting in a key available to multiple enclaves signed by the same party.

The EGETKEY leaf function provides several key types. Each key is specific to the processor, CPUSVN, and the enclave that executed EGETKEY. The EGETKEY instruction definition details how each of these keys is derived, see Table 41-62. Additionally,

* SEAL Key: The Seal key is a general purpose key for the enclave to use to protect secrets. Typical uses of the Seal key are encrypting and calculating MAC of secrets on disk. There are 2 types of Seal Key described in Section 39.4.3.1.

* REPORT Key: This key is used to compute the MAC on the REPORT structure. The EREPORT leaf function is used to compute this MAC, and destination enclave uses the Report key to verify the MAC. The software usage flow is detailed in Section 39.4.3.2.

* EINITTOKEN_KEY: This key is used by Launch Enclaves to compute the MAC on EINITTOKENs. These tokens are then verified in the EINIT leaf function. The key is only available to enclaves with ATTRIBUTE.EINITTOKEN_KEY set to 1.

* PROVISIONING Key and PROVISIONING SEAL Key: These keys are used by attestation key provisioning software to prove to remote parties that the processor is genuine and identify the currently executing TCB. These keys are only available to enclaves with ATTRIBUTE.PROVISIONKEY set to 1.

39-8 Vol. 3D
<page_number>39-8</page_number>

ENCLAVE OPERATION

## 39.4.3.1 Sealing Enclave Data

Enclaves can protect persistent data using Seal keys to provide encryption and/or integrity protection. EGETKEY provides two types of Seal keys specified in KEYREQUEST.KEYPOLICY field: MRENCLAVE-based key and MRSIGNER-based key.

The MRENCLAVE-based keys are available only to enclave instances sharing the same MRENCLAVE. If a new version of the enclave is released, the Seal keys will be different. Retrieving previous data requires additional software support.

The MRSIGNER-based keys are bound to the 3 tuple (MRSIGNER, ISVPRODID, ISVSVN). These keys are available to any enclave with the same MRSIGNER and ISVPRODID and an ISVSVN equal to or greater than the key in questions. This is valuable for allowing new versions of the same software to retrieve keys created before an upgrade.

For platforms that support enhancements for key separation and sharing (CPUID.12H.01H:EAX.KSS[7]) four additional key policies for seal key derivation are provided. These add the ISVEXTPRODID, ISVFAMILYID, and CONFIGID/CONFIGSVN to the key derivation. Additionally, there is a policy to remove ISVPRODID from a key derivation to create a shared between different products that share the same MRSIGNER.

## 39.4.3.2 Using REPORTs for Local Attestation

Intel SGX provides a means for enclaves to securely identify one another, this is referred to as "Local Attestation". SGX provides a hardware assertion, REPORT that contains calling enclaves Attributes, Measurements and User supplied data (described in detail in Section 38.16). Figure 39-3 shows the basic flow of information.

1. The source enclave determines the identity of the target enclave to populate TARGETINFO.

2. The source enclave calls EREPORT instruction to generate a REPORT structure. The EREPORT instruction conducts the following:

- Populates the REPORT with identify information about the calling enclave.

- Derives the Report Key that is returned when the target enclave executes the EGETKEY. TARGETINFO provides information about the target.

- Computes a MAC over the REPORT using derived target enclave Report Key.

3. Non-enclave software copies the REPORT from source to destination.

4. The target enclave executes the EGETKEY instruction to request its REPORT key, which is the same key used by EREPORT at the source.

5. The target enclave verifies the MAC and can then inspect the REPORT to identify the source.

```mermaid
graph TD
    subgraph Source_Enclave [Source Enclave]
        direction TB
        TARGETINFO[TARGETINFO]
        EREPORT[EREPORT(Symmetric Key)]
    end

    subgraph Destination_Enclave [Destination Enclave]
        direction TB
        EGETKEY[EGETKEYREPORT KEY]
        Verify[Verify REPORT(Symmetric Key)]
    end

    TARGETINFO --> EREPORT
    EREPORT --> REPORT(REPORT)
    REPORT --> Verify
    EGETKEY --> Verify

    style TARGETINFO fill:#FFFF00,stroke:#333,stroke-width:1px
    style EREPORT fill:#D3D3D3,stroke:#333,stroke-width:1px
    style REPORT fill:#90EE90,stroke:#333,stroke-width:1px
    style EGETKEY fill:#D3D3D3,stroke:#333,stroke-width:1px
    style Verify fill:#FFFF00,stroke:#333,stroke-width:1px
    style Source_Enclave fill:none,stroke:#333,stroke-dasharray: 5 5
    style Destination_Enclave fill:none,stroke:#333,stroke-dasharray: 5 5
```

Figure 39-3. SGX Local Attestation

Vol. 3D 39-9

ENCLAVE OPERATION

# 39.5 EPC AND MANAGEMENT OF EPC PAGES

EPC layout is implementation specific, and is enumerated through CPUID. EPC is typically configured by BIOS at system boot time.

## 39.5.1 EPC Implementation

EPC must be properly protected against attacks. One example of EPC implementation could use a Memory Encryption Engine (MEE). An MEE provides a cost-effective mechanism of creating cryptographically protected volatile storage using platform DRAM. These units provide integrity, replay, and confidentiality protection. Details are implementation specific.

## 39.5.2 OS Management of EPC Pages

The EPC is a finite resource. SGX1 (i.e., CPUID.12H.00H:EAX.SGX1 = 1 but CPUID.12H.00H:EAX.SGX2 = 0) provides the EPC manager with leaf functions to manage this resource and properly swap pages out of and into the EPC. For that, the EPC manager would need to keep track of all EPC entries, type and state, context affiliation, and SECS affiliation.

Enclave pages that are candidates for eviction should be moved to BLOCKED state using EBLOCK instruction that ensures no new cached virtual to physical address mappings can be created by attempts to reference a BLOCKED page.

Before evicting blocked pages, EPC manager should execute ETRACK leaf function on that enclave and ensure that there are no stale cached virtual to physical address mappings for the blocked pages remain on any thread on the platform.

After removing all stale translations from blocked pages, system software should use the EWB leaf function for securely evicting pages out of the EPC. EWB encrypts a page in the EPC, writes it to unprotected memory, and invalidates the copy in EPC. In addition, EWB also creates a cryptographic MAC (PCMD.MAC) of the page and stores it in unprotected memory. A page can be reloaded back to the processor only if the data and MAC match. To ensure that only the latest version of the evicted page can be loaded back, the version of the evicted page is stored securely in a Version Array (VA) in EPC.

SGX1 includes two instructions for reloading pages that have been evicted by system software: ELDU and ELDB. The difference between the two instructions is the value of the paging state at the end of the instruction. ELDU results in a page being reloaded and set to an UNBLOCKED state, while ELDB results in a page loaded to a BLOCKED state.

ELDB is intended for use by a Virtual Machine Monitor (VMM). When a VMM reloads an evicted page, it needs to restore it to the correct state of the page (BLOCKED vs. UNBLOCKED) as it existed at the time the page was evicted. Based on the state of the page at eviction, the VMM chooses either ELDB or ELDU.

### 39.5.2.1 Enhancement to Managing EPC Pages

On processors supporting SGX2 (i.e., CPUID.12H.00H:EAX.SGX2 = 1), the EPC manager can manage EPC resources (while enclave is running) with more flexibility provided by the SGX2 leaf functions. The additional flexibility is described in Section 39.5.7 through Section 39.5.11.

## 39.5.3 Eviction of Enclave Pages

Intel SGX paging is optimized to allow the Operating System (OS) to evict multiple pages out of the EPC under a single synchronization.

The suggested flow for evicting a list of pages from the EPC is:

1. For each page to be evicted from the EPC:

    a. Select an empty slot in a Version Array (VA) page.

        * If no empty VA page slots exist, create a new VA page using the EPA leaf function.

<page_number>39-10</page_number> Vol. 3D

ENCLAVE OPERATION

b. Remove linear-address to physical-address mapping from the enclave context’s mapping tables (page table and EPT tables).

c. Execute the EBLOCK leaf function for the target page. This sets the target page state to BLOCKED. At this point no new mappings of the page will be created. So any access which does not have the mapping cached in the TLB will generate a #PF.

2. For each enclave containing pages selected in step 1:

— Execute an ETRACK leaf function pointing to that enclave’s SECS. This initiates the tracking process that ensures that all caching of linear-address to physical-address translations for the blocked pages is cleared.

3. For all logical processors executing in processes (OS) or guests (VMM) that contain the enclaves selected in step 1:

— Issue an IPI (inter-processor interrupt) to those threads. This causes those logical processors to asynchronously exit any enclaves they might be in, and as a result flush cached linear-address to physical-address translations that might hold stale translations to blocked pages. There is no need for additional measures such as performing a “TLB shootdown”.

4. After enclaves exit, allow logical processors to resume normal operation, including enclave re-entry as the tracking logic keeps track of the activity.

5. For each page to be evicted:

— Evict the page using the EWB leaf function with parameters include the effective-address pointer to the EPC page, the VA slot, a 4K byte buffer to hold the encrypted page contents, and a 128 byte buffer to hold page metadata. The last three elements are tied together cryptographically and must be used to later reload the page.

At this point, system software has the only copy of each page data encrypted with its page metadata in main memory.

# 39.5.4 Loading an Enclave Page

To reload a previously evicted page, system software needs four elements: the VA slot used when the page was evicted, a buffer containing the encrypted page contents, a buffer containing the page metadata, and the parent SECS to associate this page with. If the VA page or the parent SECS are not already in the EPC, they must be reloaded first.

1. Execute ELDB/ELDU (depending on the desired BLOCKED state for the page), passing as parameters: the EPC page linear address, the VA slot, the encrypted page, and the page metadata.

2. Create a mapping in the enclave context’s mapping tables (page tables and EPT tables) to allow the application to access that page (OS: system page table; VMM: EPT).

The ELDB/ELDU instruction marks the VA slot empty so that the page cannot be replayed at a later date.

# 39.5.5 Eviction of an SECS Page

The eviction of an SECS page is similar to the eviction of an enclave page. The only difference is that an SECS page cannot be evicted until all other pages belonging to the enclave have been evicted. Since all other pages have been evicted, there will be no threads executing inside the enclave and tracking with ETRACK isn’t necessary. When reloading an enclave, the SECS page must be reloaded before all other constituent pages.

1. Ensure all pages are evicted from enclave.

2. Select an empty slot in a Version Array page.

— If no VA page exists with an empty slot, create a new one using the EPA function leaf.

3. Evict the page using the EWB leaf function with parameters include the effective-address pointer to the EPC page, the VA slot, a 4K byte buffer to hold the encrypted page contents and a 128 byte buffer to hold page metadata. The last three elements are tied together cryptographically and must be used to later reload the page.

Vol. 3D 39-11

ENCLAVE OPERATION

## 39.5.6 Eviction of a Version Array Page

VA pages do not belong to any enclave and tracking with ETRACK isn’t necessary. When evicting the VA page, a slot in a different VA page must be specified in order to provide versioning of the evicted VA page.

1. Select a slot in a Version Array page other than the page being evicted.

    — If no VA page exists with an empty slot, create a new one using the EPA leaf function.

2. Evict the page using the EWB leaf function with parameters include the effective-address pointer to the EPC page, the VA slot, a 4K byte buffer to hold the encrypted page contents, and a 128 byte buffer to hold page metadata. The last three elements are tied together cryptographically and must be used to later reload the page.

## 39.5.7 Allocating a Regular Page

On processors that support SGX2, allocating a new page to an already initialized enclave is accomplished by invoking the EAUG leaf function. Typically, the enclave requests that the OS allocates a new page at a particular location within the enclave’s address space. Once allocated, the page remains in a pending state until the enclave executes the corresponding EACCEPT leaf function to accept the new page into the enclave. Page allocation operations may be batched to improve efficiency.

The typical process for allocating a regular page is as follows:

1. Enclave requests additional memory from OS when the current allocation becomes insufficient.

2. The OS invokes the EAUG leaf function to add a new memory page to the enclave.

    a. EAUG may only be called on a free EPC page.

    b. Successful completion of the EAUG instruction places the target page in the VALID and PENDING state.

    c. All dynamically created pages have the type PT_REG and content of all zeros.

3. The OS maps the page in the enclave context's mapping tables.

4. The enclave issues an EACCEPT instruction, which verifies the page’s attributes and clears the PENDING state. At that point the page becomes accessible for normal enclave use.

## 39.5.8 Allocating a TCS Page

On processors that support SGX2, allocating a new TCS page to an already initialized enclave is a two-step process. First the OS allocates a regular page with a call to EAUG. This page must then be accepted and initialized by the enclave to which it belongs. Once the page has been initialized with appropriate values for a TCS page, the enclave requests the OS to change the page’s type to PT_TCS. This change must also be accepted. As with allocating a regular page, TCS allocation operations may be batched.

A typical process for allocating a TCS page is as follows:

1. Enclave requests an additional page from the OS.

2. The OS invokes EAUG to add a new regular memory page to the enclave.

    a. EAUG may only be called on a free EPC page.

    b. Successful completion of the EAUG instruction places the target page in the VALID and PENDING state.

3. The OS maps the page in the enclave context's mapping tables.

4. The enclave issues an EACCEPT instruction, at which point the page becomes accessible for normal enclave use.

5. The enclave initializes the contents of the new page.

6. The enclave requests that the OS convert the page from type PT_REG to PT_TCS.

7. OS issues an EMODT instruction on the page.

    a. The parameters to EMODT indicate that the regular page should be converted into a TCS.

39-12 Vol. 3D

ENCLAVE OPERATION

b. EMODT forces all access rights to a page to be removed because TCS pages may not be accessed by enclave code.

8. The enclave issues an EACCEPT instruction to confirm the requested modification.

# 39.5.9 Trimming a Page

On processors that support SGX2, Intel SGX supports the trimming of an enclave page as a special case of EMODT. Trimming allows an enclave to actively participate in the process of removing a page from the enclave (deallocation) by splitting the process into first removing it from the enclave's access and then removing it from the EPC using the EREMOVE leaf function. The page type PT_TRIM indicates that a page has been trimmed from the enclave's address space and that the page is no longer accessible to enclave software. Modifications to a page in the PT_TRIM state are not permitted; the page must be removed and then reallocated by the OS before the enclave may use the page again. Page deallocation operations may be batched to improve efficiency.

The typical process for trimming a page from an enclave is as follows:

1. Enclave signals OS that a particular page is no longer in use.

2. OS invokes the EMODT leaf function on the page, requesting that the page's type be changed to PT_TRIM.

* a. SECS and VA pages cannot be trimmed in this way, so the initial type of the page must be PT_REG or PT_TCS.

* b. EMODT may only be called on valid enclave pages.

3. OS invokes the ETRACK leaf function on the enclave containing the page to track removal the TLB addresses from all the processors.

4. Issue an IPI (inter-processor interrupt) to flush the stale linear-address to physical-address translations for all logical processors executing in processes that contain the enclave.

5. Enclave issues an EACCEPT leaf function.

6. The OS may now permanently remove the page from the EPC (by issuing EREMOVE).

# 39.5.10 Restricting the EPCM Permissions of a Page

On processors that support SGX2, restricting the EPCM permissions associated with an enclave page is accomplished using the EMODPR leaf function. This operation requires the cooperation of the OS to flush stale entries to the page and to update the page-table permissions of the page to match. Permissions restriction operations may be batched.

The typical process for restricting the permissions of an enclave page is as follows:

1. Enclave requests that the OS to restrict the permissions of an EPC page.

2. OS performs permission restriction, flushing cached linear-address to physical-address translations, and page-table modifications.

* a. Invokes the EMODPR leaf function to restrict permissions (EMODPR may only be called on VALID pages).

* b. Invokes the ETRACK leaf function on the enclave containing the page to track removal of the TLB addresses from all the processor.

* c. Issue an IPI (inter-processor interrupt) to flush the stale linear-address to physical-address translations for all logical processors executing in processes that contain the enclave.

* d. Sends IPIs to trigger enclave thread exit and TLB shootdown.

* e. OS informs the Enclave that all logical processors should now see the new restricted permissions.

3. Enclave invokes the EACCEPT leaf function.

* a. Enclave may access the page throughout the entire process.

* b. Successful call to EACCEPT guarantees that no stale cached linear-address to physical-address translations are present.

Vol. 3D 39-13
<page_number>39-13</page_number>

ENCLAVE OPERATION

## 39.5.11 Extending the EPCM Permissions of a Page

On processors that support SGX2, extending the EPCM permissions associated with an enclave page is accomplished directly by the enclave using the EMODPE leaf function. After performing the EPCM permission extension, the enclave requests the OS to update the page table permissions to match the extended permission. Security wise, permission extension does not require enclave threads to leave the enclave as TLBs with stale references to the more restrictive permissions will be flushed on demand, but to allow forward progress, an OS needs to be aware that an application might signal a page fault.

The typical process for extending the permissions of an enclave page is as follows:

1. Enclave invokes EMODPE to extend the EPCM permissions associated with an EPC page (EMODPE may only be called on VALID pages).

2. Enclave requests that OS update the page tables to match the new EPCM permissions.

3. Enclave code resumes.
    

    a. If cached linear-address to physical-address translations are present to the more restrictive permissions, the enclave thread will page fault. The SGX2-aware OS will see that the page tables permit the access and resume the thread, which can now successfully access the page because exiting cleared the TLB.
    

    b. If cached linear-address to physical-address translations are not present, access to the page with the new permissions will succeed without an enclave exit.

## 39.6 CHANGES TO INSTRUCTION BEHAVIOR INSIDE AN ENCLAVE

This section covers instructions whose behavior changes when executed in enclave mode.

### 39.6.1 Illegal Instructions

The instructions listed in Table 39-1 are ring 3 instructions which become illegal when executed inside an enclave. Executing these instructions inside an enclave will generate an exception.

The first row of Table 39-1 enumerates instructions that may cause a VM exit for VMM emulation. Since a VMM cannot emulate enclave execution, execution of any of these instructions inside an enclave results in an invalid-opcode exception (#UD) and no VM exit.

The second row of Table 39-1 enumerates I/O instructions that may cause a fault or a VM exit for emulation. Again, enclave execution cannot be emulated, so execution of any of these instructions inside an enclave results in #UD.

The third row of Table 39-1 enumerates instructions that load descriptors from the GDT or the LDT or that change privilege level. The former class is disallowed because enclave software should not depend on the contents of the descriptor tables and the latter because enclave execution must be entirely with CPL = 3. Again, execution of any of these instructions inside an enclave results in #UD.

The fourth row of Table 39-1 enumerates instructions that provide access to kernel information from user mode and can be used to aid kernel exploits from within enclave. Execution of any of these instructions inside an enclave results in #UD.

Table 39-1. Illegal Instructions Inside an Enclave

<table>
  <thead>
    <tr>
        <th>Instructions</th>
        <th>Result</th>
        <th>Comment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CPUID, GETSEC, RDPMC, SGDT, SIDT, SLDT, STR, VMCALL, VMFUNC</td>
        <td>#UD</td>
        <td>Might cause VM exit.</td>
    </tr>
    <tr>
        <td>IN, INS/INSB/INSW/INSD, OUT, OUTS/OUTSB/OUTSW/OUTSD</td>
        <td>#UD</td>
        <td>I/O fault may not safely recover. May require emulation.</td>
    </tr>
    <tr>
        <td>Far call, Far jump, Far Ret, INT n/INTO, IRET, LDS/LES/LFS/LGS/LSS, MOV to DS/ES/SS/FS/GS, POP DS/ES/SS/FS/GS, SYSCALL, SYSENTER</td>
        <td>#UD</td>
        <td>Access segment register could change privilege level.</td>
    </tr>
    <tr>
        <td>SMSW</td>
        <td>#UD</td>
        <td>Might provide access to kernel information.</td>
    </tr>
    <tr>
        <td>ENCLU[EENTER], ENCLU[ERESUME]</td>
        <td>#GP</td>
        <td>Cannot enter an enclave from within an enclave.</td>
    </tr>
  </tbody>
</table>

<page_number>39-14</page_number> Vol. 3D

ENCLAVE OPERATION

RDTSC and RDTSCP are legal inside an enclave for processors that support SGX2 (subject to the value of CR4.TSD). For processors which support SGX1 but not SGX2, RDTSC and RDTSCP will cause #UD.

RDTSC and RDTSCP instructions may cause a VM exit when inside an enclave.

Software developers must take into account that the RDTSC/RDTSCP results are not immune to influences by other software, e.g., the TSC can be manipulated by software outside the enclave.

## 39.6.2 RDRAND and RDSEED Instructions

These instructions may cause a VM exit if the “RDRAND exiting” VM-execution control is 1. Unlike other instructions that can cause VM exits, these instructions are legal inside an enclave. As noted in Section 30.1 of the Intel<sup>®</sup> 64 and IA-32 Architectures Software Developer’s Manual, Volume 3C, any VM exit originating on an instruction boundary inside an enclave sets bit 27 of the exit-reason field of the VMCS. If a VMM receives a VM exit due to an attempt to execute either of these instructions determines (by that bit) that the execution was inside an enclave, it can do either of two things. It can clear the “RDRAND exiting” VM-execution control and execute VMRESUME; this will result in the enclave executing RDRAND or RDSEED again, and this time a VM exit will not occur. Alternatively, the VMM might choose to discontinue execution of this virtual machine.

**NOTE**

It is expected that VMMs that virtualize Intel SGX will not set “RDRAND exiting” to 1.

## 39.6.3 PAUSE Instruction

The PAUSE instruction may cause a VM exit from an enclave if the “PAUSE exiting” VM-execution control is 1. Unlike other instructions that can cause VM exits, the PAUSE instruction is legal inside an enclave. If a VMM receives a VM exit due to the 1-setting of “PAUSE exiting”, it can do either of two things. It can clear the “PAUSE exiting” VM-execution control and execute VMRESUME; this will result in the enclave executing PAUSE again, but this time a VM exit will not occur. Alternatively, the VMM might choose to discontinue execution of this virtual machine.

The PAUSE instruction may also cause a VM exit outside of an enclave if the “PAUSE-loop exiting” VM-execution control is 1, but as the “PAUSE-loop exiting” control is ignored at CPL > 0 (see Section 28.1.3), VM exit from an enclave due to the 1-setting of “PAUSE-LOOP exiting” will never occur.

**NOTE**

It is expected that VMMs that virtualize Intel SGX will not set “PAUSE exiting” to 1.

## 39.6.4 Executions of INT1 and INT3 Inside an Enclave

The INT1 and INT3 instructions are legal inside an enclave, however, their behavior inside an enclave differs from that outside an enclave. See Section 43.4.1 for details.

## 39.6.5 INVD Handling when Enclaves Are Enabled

Once processor reserved memory protections are activated (see Section 39.5), any execution of INVD will result in a #GP(0).

Vol. 3D 39-15

ENCLAVE OPERATION

39-16 Vol. 3D

ENCLAVE EXITING EVENTS

# CHAPTER 40
# ENCLAVE EXITING EVENTS

Certain events, such as exceptions and interrupts, incident to (but asynchronous with) enclave execution may cause control to transition outside of enclave mode. (Most of these also cause a change of privilege level.) To protect the integrity and security of the enclave, the processor will exit the enclave (and enclave mode) before invoking the handler for such an event. For that reason, such events are called **enclave-exiting events (EEE)**; EEEs include external interrupts, non-maskable interrupts, system-management interrupts, exceptions, and VM exits.

The process of leaving an enclave in response to an EEE is called an **asynchronous enclave exit (AEX)**. To protect the secrecy of the enclave, an AEX saves the state of certain registers within enclave memory and then loads those registers with fixed values called **synthetic state**.

## 40.1 COMPATIBLE SWITCH TO THE EXITING STACK OF AEX

AEXs load registers with a pre-determined synthetic state. These registers may be later pushed onto the appropriate stack in a form as defined by the enclave-exiting event. To allow enclave execution to resume after the invoking handler has processed the enclave exiting event, the asynchronous enclave exit loads the address of trampoline code outside of the enclave into RIP. This trampoline code eventually returns to the enclave by means of an ENCLU(ERESUME) leaf function. Prior to exiting the enclave the RSP and RBP registers are restored to their values prior to enclave entry.

The stack to be used is chosen using the same rules as for non-SGX mode:

* If there is a privilege level change, the stack will be the one associated with the new ring.

* If there is no privilege level change, the current application stack is used.

* If the IA-32e IST mechanism is used, the exit stack is chosen using that method.

```mermaid
graph TD
    subgraph Enclave_Memory
        TCS[TCS]
        CSSA[CSSA]
        AEP_TCS[AEP]
        
        subgraph SSA_Frames
            Next_SSA[Next SSA Frame]
            Current_SSA[Current SSA Frame]
            uRSP_Next[uRSP]
            uRSP_Current[uRSP]
        end
    end

    subgraph Synthetic_State
        ENCLU_ERESUME[ENCLU[ERESUME]]
        TCS_LA[TCS LA]
        AEP_SYN[AEP]
        RAX[RAX]
        RBX[RBX]
        RCX[RCX]
    end

    subgraph Exit_Stack
        SS[SS]
        RSP_STACK[RSP]
        RFLAGS[RFLAGS]
        CS[CS]
        RIP[RIP]
        Error_Code[Error Code optional]
    end

    subgraph uRTS
        Trampoline[Per-Thread Trampoline in uRTS]
        ERESUME_FUNC[ENCLU[ERESUME]]
    end

    RSP_REG[RSP]

    %% Connections
    CSSA --> Next_SSA
    uRSP_Next --> Exit_Stack
    uRSP_Current --> Exit_Stack
    AEP_TCS --> Trampoline
    Trampoline --> ERESUME_FUNC
    RSP_REG --> Error_Code
    Error_Code --> RSP_After[RSP after pushes]
```

Figure 40-1. Exit Stack Just After Interrupt with Stack Switch

Vol. 3D 40-1

ENCLAVE EXITING EVENTS

In all cases, the choice of exit stack and the information pushed onto it is consistent with non-SGX operation. Figure 40-1 shows the Application and Exiting Stacks after an exit with a stack switch. An exit without a stack switch uses the Application Stack. The ERESUME leaf index value is placed into RAX, the TCS pointer is placed in RBX and the AEP (see below) is placed into RCX to facilitate resuming the enclave after the exit.

Upon an AEX, the AEP (Asynchronous Exit Pointer) is loaded into the RIP. The AEP points to a trampoline code sequence which includes the ERESUME instruction that is later used to reenter the enclave.

The following bits of RFLAGS are cleared before RFLAGS is pushed onto the exit stack: CF, PF, AF, ZF, SF, OF, RF. The remaining bits are left unchanged.

# 40.2 STATE SAVING BY AEX

The State Save Area holds the processor state at the time of an AEX. To allow handling events within the enclave and re-entering it after an AEX, the SSA can be a stack of multiple SSA frames as illustrated in Figure 40-2.

Diagram of the SSA Stack and TCS structure showing the relationship between SECS.SSAFRAMESIZE and the SSA frames (GPR, MISC, XSAVE) and how TCS fields (NSSA, CSSA, OSSA) point to the stack.

Figure 40-2. The SSA Stack

The location of the SSA frames to be used is controlled by the following variables in the TCS and the SECS:

*   **Size of a frame in the State Save Area (SECS.SSAFRAMESIZE):** This defines the number of 4-KByte pages in a single frame in the State Save Area. The SSA frame size must be large enough to hold the GPR state, the XSAVE state, and the MISC state.

*   **Base address of the enclave (SECS.BASEADDR):** This defines the enclave's base linear address from which the offset to the base of the SSA stack is calculated.

*   **Number of State Save Area Slots (TCS.NSSA):** This defines the total number of slots (frames) in the State Save Area stack.

*   **Current State Save Area Slot (TCS.CSSA):** This defines the slot to use on the next exit.

*   **State Save Area Offset (TCS.OSSA):** This defines the offset of the base address of a set of State Save Area slots from the enclave’s base address.

When an AEX occurs, hardware selects the SSA frame to use by examining TCS.CSSA. Processor state is saved into the SSA frame (see Section 40.4) and loaded with a synthetic state (as described in Section 40.3.1) to avoid leaking secrets, RSP and RBP are restored to their values prior to enclave entry, and TCS.CSSA is incremented. As will be described later, if an exception takes the last slot, it will not be possible to reenter the enclave to handle the

40-2 Vol. 3D
<page_number>40-2</page_number>

ENCLAVE EXITING EVENTS

exception from within the enclave. A subsequent ERESUME restores the processor state from the current SSA frame and frees the SSA frame.

The format of the XSAVE section of SSA is identical to the format used by the XSAVE/XRSTOR instructions. On EENTER, CSSA must be less than NSSA, ensuring that there is at least one State Save Area slot available for exits. If there is no free SSA frame when executing EENTER, the entry will fail.

# 40.3 SYNTHETIC STATE ON ASYNCHRONOUS ENCLAVE EXIT

## 40.3.1 Processor Synthetic State on Asynchronous Enclave Exit

Table 40-1 shows the synthetic state loaded on AEX. The values shown are the lower 32 bits when the processor is in 32 bit mode and 64 bits when the processor is in 64 bit mode.

Table 40-1. GPR, x87 Synthetic States on Asynchronous Enclave Exit

<table>
  <thead>
    <tr>
        <th>Register</th>
        <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>RAX</td>
        <td>3 (ENCLU[3] is ERESUME).</td>
    </tr>
    <tr>
        <td>RBX</td>
        <td>Pointer to TCS of interrupted enclave thread.</td>
    </tr>
    <tr>
        <td>RCX</td>
        <td>AEP of interrupted enclave thread.</td>
    </tr>
    <tr>
        <td>RDX, RSI, RDI</td>
        <td>0.</td>
    </tr>
    <tr>
        <td>RSP</td>
        <td>Restored from SSA.uRSP.</td>
    </tr>
    <tr>
        <td>RBP</td>
        <td>Restored from SSA.uRBP.</td>
    </tr>
    <tr>
        <td>R8-R15</td>
        <td>0 in 64-bit mode; unchanged in 32-bit mode.</td>
    </tr>
    <tr>
        <td>RIP</td>
        <td>AEP of interrupted enclave thread.</td>
    </tr>
    <tr>
        <td>RFLAGS</td>
        <td>CF, PF, AF, ZF, SF, OF, RF bits are cleared. All other bits are left unchanged.</td>
    </tr>
    <tr>
        <td>x87/SSE State</td>
        <td>Unless otherwise listed here, all x87 and SSE state are set to the INIT state. The INIT state is the state that would be loaded by the XRSTOR instruction with bits 1:0 both set in the requested feature bitmask (RFBM), and both clear in XSTATE_BV the XSAVE header.</td>
    </tr>
    <tr>
        <td>FCW</td>
        <td>On #MF exception: set to 037EH. On all other exits: set to 037FH.</td>
    </tr>
    <tr>
        <td>FSW</td>
        <td>On #MF exception: set to 8081H. On all other exits: set to 0H.</td>
    </tr>
    <tr>
        <td>MXCSR</td>
        <td>On #XM exception: set to 1F01H. On all other exits: set to 1FB0H.</td>
    </tr>
    <tr>
        <td>CR2</td>
        <td>If the event that caused the AEX is a #PF, and the #PF does not directly cause a VM exit, then the low 12 bits are cleared.<br/>If the #PF leads directly to a VM exit, CR2 is not updated (usual IA behavior).<br/>Note: The low 12 bits are not cleared if a #PF is encountered during the delivery of the EEE that caused the AEX. This is because the #PF was not the EEE.</td>
    </tr>
    <tr>
        <td>FS, GS</td>
        <td>Restored to values as of most recent EENTER/ERESUME.</td>
    </tr>
  </tbody>
</table>

## 40.3.2 Synthetic State for Extended Features

When CR4.OSXSAVE = 1, extended features (those controlled by XCR0[63:2]) are set to their respective INIT states when this corresponding bit of SECS.XFRM is set. The INIT state is the state that would be loaded by the XRSTOR instruction had the instruction mask and the XSTATE_BV field of the XSAVE header each contained the value XFRM. (When the AEX occurs in 32-bit mode, those features that do not exist in 32-bit mode are unchanged.)

Vol. 3D 40-3

ENCLAVE EXITING EVENTS

## 40.3.3 Synthetic State for MISC Features

State represented by SECS.MISCSELECT might also be overridden by synthetic state after it has been saved into the SSA. State represented by MISCSELECT[0] is not overridden but if the exiting event is a page fault then lower 12 bits of CR2 are cleared.

## 40.4 AEX FLOW

On Enclave Exiting Events (interrupts, exceptions, VM exits or SMIs), the processor state is securely saved inside the enclave, a synthetic state is loaded and the enclave is exited. The EEE then proceeds in the usual exit-defined fashion. The following sections describes the details of an AEX:

1. The exact processor state saved into the current SSA frame depends on whether the enclave is a 32-bit or a 64-bit enclave. In 32-bit mode (IA32_EFER.LMA = 0 || CS.L = 0), the low 32 bits of the legacy registers (EAX, EBX, ECX, EDX, ESP, EBP, ESI, EDI, EIP, and EFLAGS) are stored. The upper 32 bits of the legacy registers and the 64-bit registers (R8 ... R15) are not stored.

   In 64-bit mode (IA32_EFER.LMA = 1 && CS.L = 1), all 64 bits of the general processor registers (RAX, RBX, RCX, RDX, RSP, RBP, RSI, RDI, R8 ... R15, RIP, and RFLAGS) are stored.

   The state of those extended features specified by SECS.ATTRIBUTES.XFRM are stored into the XSAVE area of the current SSA frame. The layout of the x87 and XMM portions (the 1<sup>st</sup> 512 bytes) depends on the current values of IA32_EFER.LMA and CS.L:

   If IA32_EFER.LMA = 0 || CS.L = 0, the same format (32-bit) that XSAVE/FXSAVE uses with these values.

   If IA32_EFER.LMA = 1 && CS.L = 1, the same format (64-bit) that XSAVE/FXSAVE uses with these values when REX.W = 1.

   The cause of the AEX is saved in the EXITINFO field. See Table 38-10 for details and values of the various fields.

   The state of those miscellaneous features (see Section 38.7.2) specified by SECS.MISCSELECT are stored into the MISC area of the current SSA frame.

   If CET was enabled in the enclave, then the CET state of the enclave is saved in the CET state save area. If shadow stacks were enabled in the enclave, then the SSP is also saved into the TCS.PREVSSP field.

2. Synthetic state is created for a number of processor registers to present an opaque view of the enclave state. Table 40-1 shows the values for GPRs, x87, SSE, FS, GS, Debug, and performance monitoring on AEX. The synthetic state for other extended features (those controlled by XCR0[62:2]) is set to their respective INIT states when their corresponding bit of SECS.ATTRIBUTES.XFRM is set. The INIT state is that state as defined by the behavior of the XRSTOR instruction when HEADER.XSTATE_BV[n] is 0. Synthetic state of those miscellaneous features specified by SECS.MISCSELECT depends on the miscellaneous feature. There is no synthetic state required for the miscellaneous state controlled by SECS.MISCSELECT[0].

3. Any code and data breakpoints that were suppressed at the time of enclave entry are unsuppressed when exiting the enclave.

4. RFLAGS.TF is set to the value that it had at the time of the most recent enclave entry (except for the situation that the entry was opt-in for debug; see Section 43.2). In the SSA, RFLAGS.TF is set to 0.

5. RFLAGS.RF is set to 0 in the synthetic state. In the SSA, the value saved is the same as what would have been saved on stack in the non-SGX case (architectural value of RF). Thus, AEXs due to interrupts, traps, and code breakpoints save RF unmodified into SSA, while AEXs due to other faults save RF as 1 in the SSA.

   If the event causing AEX happened on intermediate iteration of a REP-prefixed instruction, then RF=1 is saved on SSA, irrespective of its priority.

6. Any performance monitoring activity (including PEBS) or profiling activity (LBR, Tracing using Intel PT) on the exiting thread that was suppressed due to the enclave entry on that thread is unsuppressed. Any counting that had been demoted from AnyThread counting to MyThread counting (on one logical processor) is promoted back to AnyThread counting.

7. The CET state of the enclosing application is restored to the state at the time of the most recent enclave entry, and if CET indirect branch tracking was enabled then the indirect branch tracker is unsuppressed and moved to the WAIT_FOR_ENDBRANCH state.

40-4 Vol. 3D

ENCLAVE EXITING EVENTS

## 40.4.1 AEX Operational Detail

### Temp Variables in AEX Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_RIP</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of instruction at which to resume execution on ERESUME.</td>
    </tr>
    <tr>
        <td>TMP_MODE64</td>
        <td>binary</td>
        <td>1</td>
        <td>((IA32_EFER.LMA = 1) &amp;&amp; (CS.L = 1)).</td>
    </tr>
    <tr>
        <td>TMP_BRANCH_RECORD</td>
        <td>LBR Record</td>
        <td>2x64</td>
        <td>From/To address to be pushed onto LBR stack.</td>
    </tr>
  </tbody>
</table>

The pseudo code in this section describes the internal operations that are executed when an AEX occurs in enclave mode. These operations occur just before the normal interrupt or exception processing occurs.

(\* Save RIP for later use \*)

TMP_RIP = Linear Address of Resume RIP

(\* Is the processor in 64-bit mode? \*)

TMP_MODE64 := ((IA32_EFER.LMA = 1) && (CS.L = 1));

(\* Save all registers, When saving EFLAGS, the TF bit is set to 0 and
the RF bit is set to what would have been saved on stack in the non-SGX case \*)

IF (TMP_MODE64 = 0)

THEN

  Save EAX, EBX, ECX, EDX, ESP, EBP, ESI, EDI, EFLAGS, EIP into the current SSA frame using
CR_GPR_PA; (\* see Table 41-4 for list of CREGs used to describe internal operation within Intel SGX \*)

  SSA.RFLAGS.TF := 0;

ELSE (\* TMP_MODE64 = 1 \*)

  Save RAX, RBX, RCX, RDX, RSP, RBP, RSI, RDI, R8-R15, RFLAGS, RIP into the current SSA frame using
CR_GPR_PA;

  SSA.RFLAGS.TF := 0;

FI;

Save FS and GS BASE into SSA using CR_GPR_PA;

(\* store XSAVE state into the current SSA frame's XSAVE area using the physical addresses
that were determined and cached at enclave entry time with CR_XSAVE_PAGE_i. \*)

For each XSAVE state i defined by (SECS.ATTRIBUTES.XFRM[i] = 1, destination address cached in
CR_XSAVE_PAGE_i)

  SSA.XSAVE.i := XSAVE_STATE_i;

(\* Clear bytes 8 to 23 of XSAVE_HEADER, i.e., the next 16 bytes after XHEADER_BV \*)

CR_XSAVE_PAGE_0.XHEADER_BV[191:64] := 0;

(\* Clear bits in XHEADER_BV[63:0] that are not enabled in ATTRIBUTES.XFRM \*)

CR_XSAVE_PAGE_0.XHEADER_BV[63:0] :=

  CR_XSAVE_PAGE_0.XHEADER_BV[63:0] & SECS(CR_ACTIVE_SECS).ATTRIBUTES.XFRM;

  Apply synthetic state to GPRs, RFLAGS, extended features, etc.

(\* Restore the RSP and RBP from the current SSA frame's GPR area using the physical address
that was determined and cached at enclave entry time with CR_GPR_PA. \*)

RSP := CR_GPR_PA.URSP;

RBP := CR_GPR_PA.URBP;

AEX Operational Detail <page_number>40-5</page_number> Vol. 3D

ENCLAVE EXITING EVENTS

```
(* Restore the FS and GS *)
FS.selector := CR_SAVE_FS.selector;
FS.base := CR_SAVE_FS.base;
FS.limit := CR_SAVE_FS.limit;
FS.access_rights := CR_SAVE_FS.access_rights;
GS.selector := CR_SAVE_GS.selector;
GS.base := CR_SAVE_GS.base;
GS.limit := CR_SAVE_GS.limit;
GS.access_rights := CR_SAVE_GS.access_rights;

(* Examine exception code and update enclave internal states*)
exception_code := Exception or interrupt vector;

(* Indicate the exit reason in SSA *)
IF (exception_code = (#DE OR #DB OR #BP OR #BR OR #UD OR #MF OR #AC OR #XM ))
    THEN
        CR_GPR_PA.EXITINFO.VECTOR := exception_code;
        IF (exception_code = #BP)
            THEN CR_GPR_PA.EXITINFO.EXIT_TYPE := 6;
            ELSE CR_GPR_PA.EXITINFO.EXIT_TYPE := 3;
        FI;
        CR_GPR_PA.EXITINFO.VALID := 1;
ELSE IF (SECS.MISCSELECT[0] is set (* Check SECS.MISCSELECT using CR_ACTIVE_SECS *)
        AND (exception_code is #GP OR (exception_code is #PF AND PFEC.U/S = 1)))
    THEN
        CR_GPR_PA.EXITINFO.VECTOR := exception_code;
        CR_GPR_PA.EXITINFO.EXIT_TYPE := 3;
        IF (exception_code is #PF)
            THEN
                SSA.MISC.EXINFO. MADDR := CR2;
                SSA.MISC.EXINFO.ERRCD := PFEC; (* Page-Fault Exception Error Code *)
                SSA.MISC.EXINFO.RESERVED := 0;
        ELSE
            SSA.MISC.EXINFO. MADDR := 0;
            SSA.MISC.EXINFO.ERRCD := GPEC; (* General Protection Exception Error Code *)
            SSA.MISC.EXINFO.RESERVED := 0;
        FI;
        CR_GPR_PA.EXITINFO.VALID := 1;
ELSE IF (SECS.MISCSELECT[1] is set AND exception_code is #CP) (* Check SECS.MISCSELECT using
        CR_ACTIVE_SECS *)
    THEN
        CR_GPR_PA.EXITINFO.VECTOR := exception_code;
        CR_GPR_PA.EXITINFO.EXIT_TYPE := 3;
        CR_GPR_PA.EXITINFO.VALID := 1;
        SSA.MISC.EXINFO. MADDR := 0;
        SSA.MISC.EXINFO.ERRCD := CPEC; (* Control Protection Exception Error Code *)
        SSA.MISC.EXINFO.RESERVED := 0;
ELSE
    SSA.MISC.EXINFO.MADDR := 0;
    SSA.MISC.EXINFO.ERRCD := 0;
    SSA.MISC.EXINFO.RESERVED := 0;
    CR_GPR_PA.EXITINFO.VECTOR := 0;
    CR_GPR_PA.EXITINFO.EXIT_TYPE := 0;
```

40-6 Vol. 3D

AEX Operational Detail

ENCLAVE EXITING EVENTS

```
      CR_GPR_PA.EXITINFO.VALID := 0;
FI;

(* Execution will resume at the AEP *)
RIP := CR_TCS_PA.AEP;

(* Set EAX to the ERESUME leaf index *)
EAX := 3;

(* Put the TCS LA into RBX for later use by ERESUME *)
RBX := CR_TCS_LA;

(* Put the AEP into RCX for later use by ERESUME *)
RCX := CR_TCS_PA.AEP;

(* Increment the SSA frame # *)
CR_TCS_PA.CSSA := CR_TCS_PA.CSSA + 1;

(* Restore XCR0 if needed *)
IF (CR4.OSXSAVE = 1)
      THEN XCR0 := CR_SAVE_XCR0; FI;

Un-suppress all code breakpoints that are outside ELRANGE

IF (CPUID.12H.01H:EAX[6]= 1)
      THEN
            IF (CR4.CET == 1 AND IA32_U_CET.SH_STK_EN == 1)
                  THEN
                        CR_CET_SAVE_AREA_PA.SSP := SSP;
                        CR_TCS_PA.PREVSSP := SSP;
            FI;
            IF (CR4.CET == 1 AND IA32_U_CET.ENDBR_EN == 1)
                  THEN
                        CR_CET_SAVE_AREA_PA.TRACKER := IA32_U_CET.TRACKER;
                        CR_CET_SAVE_AREA_PA.SUPPRESS := IA32_U_CET.SUPPRESS;
            FI;
FI;
IF ((CPUID.07H.00H:EDX.CET_IBT = 1) OR (CPUID.07H.00H:ECX.CET_SS = 1)
      THEN
            (* restore enclosing applications CET state *)
            IA32_U_CET := CR_SAVE_IA32_U_CET;

IF (CPUID.07H.00H:ECX.CET_SS)
            SSP := CR_SAVE_SSP; FI;

      (* If indirect branch tracking enabled for enclosing application *)
      (* then move the tracker to wait_for_endbranch *)
      IF (CR4.CET == 1 AND IA32_U_CET.ENDBR_EN == 1)
            THEN
                  IA32_U_CET.TRACKER := WAIT_FOR_ENDBRANCH;
                  IA32_U_CET.SUPPRESS := 0;
      FI;
FI;
```

AEX Operational Detail

<page_number>40-7</page_number> Vol. 3D

# ENCLAVE EXITING EVENTS

```
(* Update the thread context to show not in enclave mode *)
CR_ENCLAVE_MODE := 0;

(* Assure consistent translations. *)
Flush linear context including TLBs and paging-structure caches

IF (CR_DBGOPTIN = 0)
    THEN
        Un-suppress all breakpoints that overlap ELRANGE
        (* Clear suppressed breakpoint matches *)
        Restore suppressed breakpoint matches
        (* Restore TF *)
        RFLAGS.TF := CR_SAVE_TF;
        Un-suppress monitor trap flag;
        Un-suppress branch recording facilities;
        Un-suppress all suppressed performance monitoring activity;
        Promote any sibling-thread counters that were demoted from AnyThread to MyThread during enclave
entry back to AnyThread;
FI;

IF the “monitor trap flag” VM-execution control is 1
    THEN Pend MTF VM Exit at the end of exit; FI;

(* Clear low 12 bits of CR2 on #PF *)
IF (Exception code is #PF)
    THEN CR2 := CR2 & ~0xFFF; FI;

(* end_of_flow *)
(* Execution continues with normal event processing. *)
```

<page_number>40-8</page_number> Vol. 3D

AEX Operational Detail

INTEL® SGX INSTRUCTION REFERENCES

# CHAPTER 41
# INTEL® SGX INSTRUCTION REFERENCES

This chapter describes the supervisor and user level instructions provided by Intel® Software Guard Extensions (Intel® SGX). In general, various functionality is encoded as leaf functions within the ENCLS (supervisor) and ENCLU (user) instruction mnemonics. Different leaf functions are encoded by specifying an input value in the EAX register of the respective instruction mnemonic.

## 41.1 INTEL® SGX INSTRUCTION SYNTAX AND OPERATION

ENCLS and ENCLU instruction mnemonics for all leaf functions are covered in this section.

For all instructions, the value of CS.D is ignored; addresses and operands are 64 bits in 64-bit mode and are otherwise 32 bits. Aside from EAX specifying the leaf number as input, each instruction leaf may require all or some subset of the RBX/RCX/RDX as input parameters. Some leaf functions may return data or status information in one or more of the general purpose registers.

### 41.1.1 ENCLS Register Usage Summary

Table 41-1 summarizes the implicit register usage of supervisor mode enclave instructions.

Table 41-1. Register Usage of Privileged Enclave Instruction Leaf Functions

<table>
  <thead>
    <tr>
        <th>Instr. Leaf</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
        <th>RDX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ECREATE</td>
        <td>00H (In)</td>
        <td>PAGEINFO (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EADD</td>
        <td>01H (In)</td>
        <td>PAGEINFO (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EINIT</td>
        <td>02H (In)</td>
        <td>SIGSTRUCT (In, EA)</td>
        <td>SECS (In, EA)</td>
        <td>EINITTOKEN (In, EA)</td>
    </tr>
    <tr>
        <td>EREMOVE</td>
        <td>03H (In)</td>
        <td> </td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EDBGRD</td>
        <td>04H (In)</td>
        <td>Result Data (Out)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EDBGWR</td>
        <td>05H (In)</td>
        <td>Source Data (In)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EEXTEND</td>
        <td>06H (In)</td>
        <td>SECS (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>ELDB</td>
        <td>07H (In)</td>
        <td>PAGEINFO (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td>VERSION (In, EA)</td>
    </tr>
    <tr>
        <td>ELDU</td>
        <td>08H (In)</td>
        <td>PAGEINFO (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td>VERSION (In, EA)</td>
    </tr>
    <tr>
        <td>EBLOCK</td>
        <td>09H (In)</td>
        <td> </td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EPA</td>
        <td>0AH (In)</td>
        <td>PT_VA (In)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EWB</td>
        <td>0BH (In)</td>
        <td>PAGEINFO (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td>VERSION (In, EA)</td>
    </tr>
    <tr>
        <td>ETRACK</td>
        <td>0CH (In)</td>
        <td> </td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EAUG</td>
        <td>0DH (In)</td>
        <td>PAGEINFO (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EMODPR</td>
        <td>0EH (In)</td>
        <td>SECINFO (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EMODT</td>
        <td>0FH (In)</td>
        <td>SECINFO (In, EA)</td>
        <td>EPCPAGE (In, EA)</td>
        <td> </td>
    </tr>
    <tr>
        <td>EUPDATESVN</td>
        <td>018H (In)</td>
        <td> </td>
        <td> </td>
        <td> </td>
    </tr>
    <tr>
        <td colspan="5">EA: Effective Address</td>
    </tr>
  </tbody>
</table>

### 41.1.2 ENCLU Register Usage Summary

Table 41-2 summarizes the implicit register usage of user mode enclave instructions.

Vol. 3D 41-1

INTEL® SGX INSTRUCTION REFERENCES

Table 41-2. Register Usage of Unprivileged Enclave Instruction Leaf Functions

<table>
  <thead>
    <tr>
      <th>Instr. LeafEAX</th>
      <th></th>
      <th>RBXRCXRDX</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>EREPORT00H</td>
      <td>(In)TARGETINFO</td>
      <td>(In, EA)REPORTDATA</td>
      <td></td>
      <td>(In, EA)OUTPUTDATA (In, EA)</td>
    </tr>
    <tr>
      <td>EGETKEY01H</td>
      <td>(In)KEYREQUEST</td>
      <td>(In, EA)KEY</td>
      <td>(In, EA)</td>
      <td></td>
    </tr>
    <tr>
      <td>EENTER02H</td>
      <td>(In)TCS</td>
      <td>(In, EA)AEP</td>
      <td>(In, EA)</td>
      <td></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td>RBX.CSSA (Out)Return</td>
      <td>(Out, EA)</td>
      <td></td>
    </tr>
    <tr>
      <td>ERESUME03H</td>
      <td>(In)TCS</td>
      <td>(In, EA)AEP</td>
      <td>(In, EA)</td>
      <td></td>
    </tr>
    <tr>
      <td>EEXIT04H</td>
      <td>(In)Target</td>
      <td>(In, EA)Current</td>
      <td>AEP (Out)</td>
      <td></td>
    </tr>
    <tr>
      <td>EACCEPT05H</td>
      <td>(In)SECINFO</td>
      <td>(In, EA)EPCPAGE</td>
      <td>(In, EA)</td>
      <td></td>
    </tr>
    <tr>
      <td>EMODPE06H</td>
      <td>(In)SECINFO</td>
      <td>(In, EA)EPCPAGE</td>
      <td>(In, EA)</td>
      <td></td>
    </tr>
    <tr>
      <td>EACCEPTCOPY07H</td>
      <td>(In)SECINFO</td>
      <td>(In, EA)EPCPAGE</td>
      <td>(In, EA)EPCPAGE</td>
      <td>(In, EA)</td>
    </tr>
    <tr>
      <td>EVERIFYREPORT208H</td>
      <td>(In)</td>
      <td>REPORTMACSTRUCT<sup>1</sup> (In, EA)</td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td>EDECCSSA09H</td>
      <td>(In)</td>
      <td></td>
      <td></td>
      <td></td>
    </tr>
    <tr>
      <td colspan="5">EA: Effective Address</td>
    </tr>
    <tr>
      <td colspan="5">NOTES:</td>
    </tr>
  </tbody>
</table>

1. More details about REPORTMACSTRUCT can be found in Section “Report MAC Structure (REPORTMAC-STRUCT)” of the Intel® Architecture Instruction Set Extensions and Future Features Programming Reference.

## 41.1.3 Information and Error Codes

Information and error codes are reported by various instruction leaf functions to show an abnormal termination of the instruction or provide information which may be useful to the developer. Table 41-3 shows the various codes and the instruction which generated the code. Details of the meaning of the code is provided in the individual instruction.

Table 41-3. Error or Information Codes for Intel® SGX Instructions

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Value</th>
        <th>Returned By</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>0</td>
        <td> </td>
    </tr>
    <tr>
        <td>SGX_INVALID_SIG_STRUCT</td>
        <td>1</td>
        <td>EINIT</td>
    </tr>
    <tr>
        <td>SGX_INVALID_ATTRIBUTE</td>
        <td>2</td>
        <td>EINIT, EGETKEY</td>
    </tr>
    <tr>
        <td>SGX_BLKSTATE</td>
        <td>3</td>
        <td>EBLOCK</td>
    </tr>
    <tr>
        <td>SGX_INVALID_MEASUREMENT</td>
        <td>4</td>
        <td>EINIT</td>
    </tr>
    <tr>
        <td>SGX_NOTBLOCKABLE</td>
        <td>5</td>
        <td>EBLOCK</td>
    </tr>
    <tr>
        <td>SGX_PG_INVLD</td>
        <td>6</td>
        <td>EBLOCK</td>
    </tr>
    <tr>
        <td>SGX_EPC_PAGE_CONFLICT</td>
        <td>7</td>
        <td>EBLOCK, EMODPR, EMODT, EUPDATESVN</td>
    </tr>
    <tr>
        <td>SGX_INVALID_SIGNATURE</td>
        <td>8</td>
        <td>EINIT</td>
    </tr>
    <tr>
        <td>SGX_MAC_COMPARE_FAIL</td>
        <td>9</td>
        <td>ELDB, ELDU</td>
    </tr>
    <tr>
        <td>SGX_PAGE_NOT_BLOCKED</td>
        <td>10</td>
        <td>EWB</td>
    </tr>
    <tr>
        <td>SGX_NOT_TRACKED</td>
        <td>11</td>
        <td>EWB, EACCEPT</td>
    </tr>
    <tr>
        <td>SGX_VA_SLOT_OCCUPIED</td>
        <td>12</td>
        <td>EWB</td>
    </tr>
    <tr>
        <td>SGX_CHILD_PRESENT</td>
        <td>13</td>
        <td>EWB, EREMOVE</td>
    </tr>
    <tr>
        <td>SGX_ENCLAVE_ACT</td>
        <td>14</td>
        <td>EREMOVE</td>
    </tr>
    <tr>
        <td>SGX_ENTRYEPOCH_LOCKED</td>
        <td>15</td>
        <td>EBLOCK</td>
    </tr>
  </tbody>
</table>

41-2 Vol. 3D

INTEL® SGX INSTRUCTION REFERENCES

Table 41-3. Error or Information Codes for Intel® SGX Instructions

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Value</th>
        <th>Returned By</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>SGX_INVALID_EINITTOKEN</td>
        <td>16</td>
        <td>EINIT</td>
    </tr>
    <tr>
        <td>SGX_PREV_TRK_INCMPL</td>
        <td>17</td>
        <td>ETRACK</td>
    </tr>
    <tr>
        <td>SGX_PG_IS_SECS</td>
        <td>18</td>
        <td>EBLOCK</td>
    </tr>
    <tr>
        <td>SGX_PAGE_ATTRIBUTES_MISMATCH</td>
        <td>19</td>
        <td>EACCEPT, EACCEPTCOPY</td>
    </tr>
    <tr>
        <td>SGX_PAGE_NOT_MODIFIABLE</td>
        <td>20</td>
        <td>EMODPR, EMODT</td>
    </tr>
    <tr>
        <td>SGX_PAGE_NOT_DEBUGGABLE</td>
        <td>21</td>
        <td>EDBGRD, EDBGWR</td>
    </tr>
    <tr>
        <td>SGX_INVALID_REPORTMACSTRUCT</td>
        <td>28</td>
        <td>EVERIFYREPORT2</td>
    </tr>
    <tr>
        <td>SGX_INSUFFICIENT_ENTROPY</td>
        <td>29</td>
        <td>EUPDATESVN</td>
    </tr>
    <tr>
        <td>SGX_EPC_NOT_READY</td>
        <td>30</td>
        <td>EUPDATESVN</td>
    </tr>
    <tr>
        <td>SGX_NO_UPDATE</td>
        <td>31</td>
        <td>EUPDATESVN</td>
    </tr>
    <tr>
        <td>SGX_INVALID_CPUSVN</td>
        <td>32</td>
        <td>EINIT, EGETKEY, EVERIFYREPORT2</td>
    </tr>
    <tr>
        <td>SGX_INVALID_ISVSVN</td>
        <td>64</td>
        <td>EGETKEY</td>
    </tr>
    <tr>
        <td>SGX_UNMASKED_EVENT</td>
        <td>128</td>
        <td>EINIT</td>
    </tr>
    <tr>
        <td>SGX_INVALID_KEYNAME</td>
        <td>256</td>
        <td>EGETKEY</td>
    </tr>
  </tbody>
</table>

## 41.1.4 Internal CREGs

The CREGs as shown in Table 5-4 are hardware specific registers used in this document to indicate values kept by the processor. These values are used while executing in enclave mode or while executing an Intel SGX instruction. These registers are not software visible and are implementation specific. The values in Table 41-4 appear at various places in the pseudo-code of this document. They are used to enhance understanding of the operations.

Table 41-4. List of Internal CREG

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Size (Bits)</th>
        <th>Scope</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CR_ENCLAVE_MODE</td>
        <td>1</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_DBGOPTIN</td>
        <td>1</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_TCS_LA</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_TCS_PA</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_ACTIVE_SECS</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_ELRANGE</td>
        <td>128</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SAVE_TF</td>
        <td>1</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SAVE_FS</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_GPR_PA</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_XSAVE_PAGE_n</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SAVE_DR7</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SAVE_PERF_GLOBAL_CTRL</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SAVE_DEBUGCTL</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SAVE_PEBS_ENABLE</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_CPUSVN</td>
        <td>128</td>
        <td>PACKAGE</td>
    </tr>
    <tr>
        <td>CR_SGXOWNEREPOCH</td>
        <td>128</td>
        <td>PACKAGE</td>
    </tr>
    <tr>
        <td>CR_SAVE_XCR0</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SGX_ATTRIBUTES_MASK</td>
        <td>128</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_PAGING_VERSION</td>
        <td>64</td>
        <td>PACKAGE</td>
    </tr>
  </tbody>
</table>

Vol. 3D 41-3

INTEL® SGX INSTRUCTION REFERENCES

Table 41-4. List of Internal CREG

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Size (Bits)</th>
        <th>Scope</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CR_VERSION_THRESHOLD</td>
        <td>64</td>
        <td>PACKAGE</td>
    </tr>
    <tr>
        <td>CR_NEXT_EID</td>
        <td>64</td>
        <td>PACKAGE</td>
    </tr>
    <tr>
        <td>CR_BASE_PK</td>
        <td>128</td>
        <td>PACKAGE</td>
    </tr>
    <tr>
        <td>CR_SEAL_FUSES</td>
        <td>128</td>
        <td>PACKAGE</td>
    </tr>
    <tr>
        <td>CR_CET_SAVE_AREA_PA</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_ENCLAVE_SS_TOKEN_PA</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SAVE_IA32_U_CET</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_SAVE_SSP</td>
        <td>64</td>
        <td>LP</td>
    </tr>
    <tr>
        <td>CR_REPORT_MAC_KEY</td>
        <td>256</td>
        <td>PLATFORM</td>
    </tr>
  </tbody>
</table>

# 41.1.5 Concurrent Operation Restrictions

Under certain conditions, Intel SGX disallows certain leaf functions from operating concurrently. Listed below are some examples of concurrency that are not allowed.

* For example, Intel SGX disallows the following leafs to concurrently operate on the same EPC page.

  — ECREATE, EADD, and EREMOVE are not allowed to operate on the same EPC page concurrently with themselves.

  — EADD, EEXTEND, and EINIT leaves are not allowed to operate on the same SECS concurrently.

* Intel SGX disallows the EREMOVE leaf from removing pages from an enclave that is in use.

* Intel SGX disallows entry (EENTER and ERESUME) to an enclave while a page from that enclave is being removed.

When disallowed operation is detected, a leaf function may do one of the following:

* Return an SGX_EPC_PAGE_CONFLICT error code in RAX.

* Cause a #GP(0) exception.

To prevent such exceptions, software must serialize leaf functions or prevent these leaf functions from accessing the same EPC page.

## 41.1.5.1 Concurrency Tables of Intel® SGX Instructions

The tables below detail the concurrent operation restrictions of all SGX leaf functions. For each leaf function, the table has a separate line for each of the EPC pages the leaf function accesses.

For each such EPC page, the base concurrency requirements are detailed as follows:

* **Exclusive Access** means that no other leaf function that requires either shared or exclusive access to the same EPC page may be executed concurrently. For example, EADD requires an exclusive access to the target page it accesses.

* **Shared Access** means that no other leaf function that requires an exclusive access to the same EPC page may be executed concurrently. Other leaf functions that require shared access may run concurrently. For example, EADD requires a shared access to the SECS page it accesses.

* **Concurrent Access** means that any other leaf function that requires any access to the same EPC page may be executed concurrently. For example, EGETKEY has no concurrency requirements for the KEYREQUEST page.

In addition to the base concurrency requirements, additional concurrency requirements are listed, which apply only to specific sets of leaf functions. For example, there are additional requirements that apply for EADD, EXTEND, and EINIT. EADD and EEXTEND can't execute concurrently on the same SECS page.

The tables also detail the leaf function's behavior when a conflict happens, i.e., a concurrency requirement is not met. In this case, the leaf function may return an SGX_EPC_PAGE_CONFLICT error code in RAX, or it may cause an exception.

41-4 Vol. 3D

INTEL® SGX INSTRUCTION REFERENCES

Table 41-5. Base Concurrency Restrictions

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th colspan="2" rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EACCEPT</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECINFO</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="3">EACCEPTCOPY</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>Source</td>
        <td>[DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECINFO</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">EADD</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECS</td>
        <td>[DS:RBX]PAGEINFO.<br/>SECS</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td rowspan="2">EAUG</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECS</td>
        <td>[DS:RBX]PAGEINFO.<br/>SECS</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>EBLOCK</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Shared</td>
        <td>SGX_EPC_PAGE_CONFLICT</td>
    </tr>
    <tr>
        <td>ECREATE</td>
        <td>SECS</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>EDBGRD</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>EDBGWR</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>EENTER</td>
        <td>TCS</td>
        <td>[DS:RBX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>EEXIT</td>
        <td> </td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">EEXTEND</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECS</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">EGETKEY</td>
        <td>KEYREQUEST</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>OUTPUTDATA</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>EINIT</td>
        <td>SECS</td>
        <td>[DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td rowspan="3">ELDB/ELDU</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>VA</td>
        <td>[DS:RDX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECS</td>
        <td>[DS:RBX]PAGEINFO.<br/>SECS</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td rowspan="2">EMODPE</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECINFO</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>EMODPR</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>EMODT</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>SGX_EPC_PAGE_CONFLICT</td>
    </tr>
    <tr>
        <td>EPA</td>
        <td>VA</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>EREMOVE</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td rowspan="3">EREPORT</td>
        <td>TARGETINFO</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>REPORTDATA</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>OUTPUTDATA</td>
        <td>[DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>ERESUME</td>
        <td>TCS</td>
        <td>[DS:RBX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>ETRACK</td>
        <td>SECS</td>
        <td>[DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

Vol. 3D 41-5

INTEL® SGX INSTRUCTION REFERENCES

Table 41-5. Base Concurrency Restrictions

<table>
  <thead>
    <tr>
<th>Leaf</th>
<th colspan="2">Parameter</th>
<th colspan="4">Base Concurrency Restrictions</th>
    </tr>
    <tr>
<th>Access</th>
<th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<td rowspan="2">EWB</td>
<td>Source</td>
<td>[DS:RCX]</td>
<td>Exclusive</td>
<td>#GP</td>
<td colspan="2"></td>
    </tr>
    <tr>
<td>VA</td>
<td>[DS:RDX]</td>
<td>Shared</td>
<td>#GP</td>
<td colspan="2"></td>
    </tr>
    <tr>
<td>EVERIFYREPORT2</td>
<td>REPORTMACSTRUCT</td>
<td>[DS:RBX]</td>
<td>Concurrent</td>
<td> </td>
<td colspan="2"></td>
    </tr>
  </tbody>
</table>

Table 41-6. Additional Concurrency Restrictions

<table>
  <thead>
    <tr>
<th>Leaf</th>
<th colspan="2">Parameter</th>
<th colspan="12">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
<th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
<th colspan="2">vs. EADD, EEXTEND, EINIT</th>
<th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
<th>Access</th>
<th>On Conflict</th>
<th>Access</th>
<th>On Conflict</th>
<th>Access</th>
<th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
<td rowspan="2">EACCEPT</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Exclusive</td>
<td>#GP</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>SECINFO</td>
<td>[DS:RBX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td rowspan="3">EACCEPTCOPY</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Exclusive</td>
<td>#GP</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>Source</td>
<td>[DS:RDX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>SECINFO</td>
<td>[DS:RBX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td rowspan="2">EADD</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>SECS</td>
<td>[DS:RBX]PAGEINFO.SECS</td>
<td>Concurrent</td>
<td> </td>
<td>Exclusive</td>
<td>#GP</td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td rowspan="2">EAUG</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>SECS</td>
<td>[DS:RBX]PAGEINFO.SECS</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>EBLOCK</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>ECREATE</td>
<td>SECS</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>EDBGRD</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>EDBGWR</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>EENTER</td>
<td>TCS</td>
<td>[DS:RBX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>EEXIT</td>
<td> </td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td rowspan="2">EEXTEND</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>SECS</td>
<td>[DS:RBX]</td>
<td>Concurrent</td>
<td> </td>
<td>Exclusive</td>
<td>#GP</td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td rowspan="2">EGETKEY</td>
<td>KEYREQUEST</td>
<td>[DS:RBX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>OUTPUTDATA</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>EINIT</td>
<td>SECS</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Exclusive</td>
<td>#GP</td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td rowspan="3">ELDB/ELDU</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>VA</td>
<td>[DS:RDX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>SECS</td>
<td>[DS:RBX]PAGEINFO.SECS</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td rowspan="2">EMODPE</td>
<td>Target</td>
<td>[DS:RCX]</td>
<td>Exclusive</td>
<td>#GP</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
    <tr>
<td>SECINFO</td>
<td>[DS:RBX]</td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td>Concurrent</td>
<td> </td>
<td colspan="6"></td>
    </tr>
  </tbody>
</table>

41-6 Vol. 3D

INTEL® SGX INSTRUCTION REFERENCES

Table 41-6. Additional Concurrency Restrictions

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th colspan="2" rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EMODPR</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>SGX_EPC_<br/>PAGE_CON<br/>FLICT</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>EMODT</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Exclusive</td>
        <td>SGX_EPC_<br/>PAGE_CON<br/>FLICT</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>EPA</td>
        <td>VA</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>EREMOVE</td>
        <td>Target</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="3">EREPORT</td>
        <td>TARGETINFO</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>REPORTDATA</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>OUTPUTDATA</td>
        <td>[DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>ERESUME</td>
        <td>TCS</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>ETRACK</td>
        <td>SECS</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Exclusive</td>
        <td>SGX_EPC_<br/>PAGE_CON<br/>FLICT</td>
    </tr>
    <tr>
        <td>EUPDATESVN</td>
        <td>EPCM</td>
        <td> </td>
        <td>Exclusive</td>
        <td>SGX_EPC_<br/>PAGE_CON<br/>FLICT</td>
        <td>Exclusive</td>
        <td>SGX_EPC_<br/>PAGE_C<br/>ONFLICT</td>
        <td>Exclusive</td>
        <td>SGX_EPC_<br/>PAGE_CON<br/>FLICT</td>
    </tr>
    <tr>
        <td>EVERIFYREPORT2</td>
        <td>REPORTMACSTRUCT</td>
        <td>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td rowspan="2">EWB</td>
        <td>Source</td>
        <td>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>VA</td>
        <td>[DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

# 41.2 INTEL® SGX INSTRUCTION REFERENCE

Vol. 3D 41-7

INTEL® SGX INSTRUCTION REFERENCES

# ENCLS—Execute an Enclave System Function of Specified Leaf Number

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>NP 0F 01 CF ENCLS</td>
        <td>ZO</td>
        <td>V/V</td>
        <td>NA</td>
        <td>This instruction is used to execute privileged Intel SGX leaf functions that are used for managing and debugging the enclaves.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>Operand 1</th>
        <th>Operand 2</th>
        <th>Operand 3</th>
        <th>Implicit Register Operands</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ZO</td>
        <td>NA</td>
        <td>NA</td>
        <td>NA</td>
        <td>See Section 41.3</td>
    </tr>
  </tbody>
</table>

## Description

The ENCLS instruction invokes the specified privileged Intel SGX leaf function for managing and debugging enclaves. Software specifies the leaf function by setting the appropriate value in the register EAX as input. The registers RBX, RCX, and RDX have leaf-specific purpose, and may act as input, as output, or may be unused. In 64-bit mode, the instruction ignores upper 32 bits of the RAX register.

The ENCLS instruction produces an invalid-opcode exception (#UD) if CR0.PE = 0 or RFLAGS.VM = 1, or if it is executed in system-management mode (SMM). Additionally, any attempt to execute the instruction when CPL > 0 results in #UD. The instruction produces a general-protection exception (#GP) if CR0.PG = 0 or if an attempt is made to invoke an undefined leaf function.

In VMX non-root operation, execution of ENCLS may cause a VM exit if the “enable ENCLS exiting” VM-execution control is 1. In this case, execution of individual leaf functions of ENCLS is governed by the ENCLS-exiting bitmap field in the VMCS. Each bit in that field corresponds to the index of an ENCLS leaf function (as provided in EAX).

Software in VMX root operation can thus intercept the invocation of various ENCLS leaf functions in VMX non-root operation by setting the “enable ENCLS exiting” VM-execution control and setting the corresponding bits in the ENCLS-exiting bitmap.

Addresses and operands are 32 bits outside 64-bit mode (IA32_EFER.LMA = 0 || CS.L = 0) and are 64 bits in 64-bit mode (IA32_EFER.LMA = 1 || CS.L = 1). CS.D value has no impact on address calculation. The DS segment is used to create linear addresses.

Segment override prefixes and address-size override prefixes are ignored, as is the REX prefix in 64-bit mode.

## Operation

IF TSX_ACTIVE
    THEN GOTO TSX_ABORT_PROCESSING; FI;

IF CR0.PE = 0 or RFLAGS.VM = 1 or in SMM or CPUID.12H.00H:EAX.SGX1 = 0
    THEN #UD; FI;

IF (CPL > 0)
    THEN #UD; FI;

IF in VMX non-root operation and the “enable ENCLS exiting” VM-execution control is 1
    THEN
        IF EAX < 63 and ENCLS_exiting_bitmap[EAX] = 1 or EAX > 62 and ENCLS_exiting_bitmap[63] = 1
            THEN VM exit;
        FI;
FI;

IF IA32_FEATURE_CONTROL.LOCK = 0 or IA32_FEATURE_CONTROL.SGX_ENABLE = 0
    THEN #GP(0); FI;

IF (EAX is an invalid leaf number)
    THEN #GP(0); FI;

41-8 Vol. 3D ENCLS—Execute an Enclave System Function of Specified Leaf Number

INTEL® SGX INSTRUCTION REFERENCES

IF CR0.PG = 0
    THEN #GP(0); FI;

(* DS must not be an expanded down segment *)
IF not in 64-bit mode and DS.Type is expand-down data
    THEN #GP(0); FI;

Jump to leaf specific flow

## Flags Affected

See individual leaf functions

## Protected Mode Exceptions

* **#UD**
    - If any of the LOCK/66H/REP/VEX prefixes are used.
    - If current privilege level is not 0.
    - If CPUID.12H.00H:EAX.SGX1[0] = 0.
    - If logical processor is in SMM.
* **#GP(0)**
    - If IA32_FEATURE_CONTROL.LOCK = 0.
    - If IA32_FEATURE_CONTROL.SGX_ENABLE = 0.
    - If input value in EAX encodes an unsupported leaf.
    - If data segment expand down.
    - If CR0.PG=0.

## Real-Address Mode Exceptions

* **#UD**
    - ENCLS is not recognized in real mode.

## Virtual-8086 Mode Exceptions

* **#UD**
    - ENCLS is not recognized in virtual-8086 mode.

## Compatibility Mode Exceptions

Same exceptions as in protected mode.

## 64-Bit Mode Exceptions

* **#UD**
    - If any of the LOCK/66H/REP/VEX prefixes are used.
    - If current privilege level is not 0.
    - If CPUID.12H.00H:EAX.SGX1[0] = 0.
    - If logical processor is in SMM.
* **#GP(0)**
    - If IA32_FEATURE_CONTROL.LOCK = 0.
    - If IA32_FEATURE_CONTROL.SGX_ENABLE = 0.
    - If input value in EAX encodes an unsupported leaf.

ENCLS—Execute an Enclave System Function of Specified Leaf Number Vol. 3D 41-9

INTEL® SGX INSTRUCTION REFERENCES

# ENCLU—Execute an Enclave User Function of Specified Leaf Number

<table>
  <thead>
    <tr>
        <th>Opcode/Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>NP 0F 01 D7<br/>ENCLU</td>
        <td>ZO</td>
        <td>V/V</td>
        <td>NA</td>
        <td>This instruction is used to execute non-privileged Intel SGX leaf functions.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>Operand 1</th>
        <th>Operand 2</th>
        <th>Operand 3</th>
        <th>Implicit Register Operands</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ZO</td>
        <td>NA</td>
        <td>NA</td>
        <td>NA</td>
        <td>See Section 41.4</td>
    </tr>
  </tbody>
</table>

## Description

The ENCLU instruction invokes the specified non-privileged Intel SGX leaf functions. Software specifies the leaf function by setting the appropriate value in the register EAX as input. The registers RBX, RCX, and RDX have leaf-specific purpose, and may act as input, as output, or may be unused. In 64-bit mode, the instruction ignores upper 32 bits of the RAX register.

The ENCLU instruction produces an invalid-opcode exception (#UD) if CR0.PE = 0 or RFLAGS.VM = 1, or if it is executed in system-management mode (SMM). Additionally, any attempt to execute this instruction when CPL < 3 results in #UD. The instruction produces a general-protection exception (#GP) if either CR0.PG or CR0.NE is 0, or if an attempt is made to invoke an undefined leaf function. The ENCLU instruction produces a device not available exception (#NM) if CR0.TS = 1.

Addresses and operands are 32 bits outside 64-bit mode (IA32_EFER.LMA = 0 or CS.L = 0) and are 64 bits in 64-bit mode (IA32_EFER.LMA = 1 and CS.L = 1). CS.D value has no impact on address calculation. The DS segment is used to create linear addresses.

Segment override prefixes and address-size override prefixes are ignored, as is the REX prefix in 64-bit mode.

## Operation

IN_64BIT_MODE := 0;

IF TSX_ACTIVE

    THEN GOTO TSX_ABORT_PROCESSING; FI;

(\* If enclosing app has CET indirect branch tracking enabled then if it is not ERESUME leaf cause a #CP fault \*)

(\* If the ERESUME is not successful it will leave tracker in WAIT_FOR_ENDBRANCH \*)

TRACKER = (CPL == 3) ? IA32_U_CET.TRACKER : IA32_S_CET.TRACKER

IF EndbranchEnabledAndNotSuppressed(CPL) and TRACKER = WAIT_FOR_ENDBRANCH and

(EAX != ERESUME or CR0.TS or (in SMM) or (CPUID.12H.00H:EAX.SGX1 = 0) or (CPL < 3))

    THEN

        Handle CET State machine violation     (\* see Section 18.3.6, “Legacy Compatibility Treatment,” in the Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1. \*)

FI;

IF CR0.PE= 0 or RFLAGS.VM = 1 or in SMM or CPUID.12H.00H:EAX.SGX1 = 0

    THEN #UD; FI;

IF CR0.TS = 1

    THEN #NM; FI;

IF CPL < 3

    THEN #UD; FI;

IF IA32_FEATURE_CONTROL.LOCK = 0 or IA32_FEATURE_CONTROL.SGX_ENABLE = 0

    THEN #GP(0); FI;

41-10 Vol. 3D

ENCLU—Execute an Enclave User Function of Specified Leaf Number

INTEL® SGX INSTRUCTION REFERENCES

IF EAX is invalid leaf number
THEN #GP(0); FI;

IF CR0.PG = 0 or CR0.NE = 0
THEN #GP(0); FI;

IN_64BIT_MODE := IA32_EFER.LMA AND CS.L ? 1 : 0;
(* Check not in 16-bit mode and DS is not a 16-bit segment *)
IF not in 64-bit mode and CS.D = 0
THEN #GP(0); FI;

IF CR_ENCLAVE_MODE = 1 and (EAX = 2 or EAX = 3) (* EENTER or ERESUME are not allowed inside enclaves *)
THEN #GP(0); FI;

IF (CR_ENCLAVE_MODE = 0 and (EAX ≠ 2 and EAX ≠ 3))
(* Only EENTER or ERESUME are allowed outside enclaves *)
THEN #GP(0); FI;

Jump to leaf specific flow

## Flags Affected

See individual leaf functions

## Protected Mode Exceptions

<table>
    <tr>
        <td>#UD</td>
        <td>If any of the LOCK/66H/REP/VEX prefixes are used.</td>
    </tr>
    <tr>
        <td></td>
        <td>If current privilege level is not 3.</td>
    </tr>
    <tr>
        <td></td>
        <td>If CPUID.12H.00H:EAX.SGX1[0] = 0.</td>
    </tr>
    <tr>
        <td></td>
        <td>If logical processor is in SMM.</td>
    </tr>
    <tr>
        <td>#GP(0)</td>
        <td>If IA32_FEATURE_CONTROL.LOCK = 0.</td>
    </tr>
    <tr>
        <td></td>
        <td>If IA32_FEATURE_CONTROL.SGX_ENABLE = 0.</td>
    </tr>
    <tr>
        <td></td>
        <td>If input value in EAX encodes an unsupported leaf.</td>
    </tr>
    <tr>
        <td></td>
        <td>If input value in EAX encodes EENTER/ERESUME and ENCLAVE_MODE = 1.</td>
    </tr>
    <tr>
        <td></td>
        <td>If input value in EAX encodes EGETKEY/EREPORT/EEXIT/EACCEPT/EACCEPTCOPY/EMODPE and ENCLAVE_MODE = 0.</td>
    </tr>
    <tr>
        <td></td>
        <td>If operating in 16-bit mode.</td>
    </tr>
    <tr>
        <td></td>
        <td>If data segment is in 16-bit mode.</td>
    </tr>
    <tr>
        <td></td>
        <td>If CR0.PG = 0 or CR0.NE= 0.</td>
    </tr>
    <tr>
        <td>#NM</td>
        <td>If CR0.TS = 1.</td>
    </tr>
</table>

## Real-Address Mode Exceptions

<table>
    <tr>
        <td>#UD</td>
        <td>ENCLS is not recognized in real mode.</td>
    </tr>
</table>

## Virtual-8086 Mode Exceptions

<table>
    <tr>
        <td>#UD</td>
        <td>ENCLS is not recognized in virtual-8086 mode.</td>
    </tr>
</table>

## Compatibility Mode Exceptions

Same exceptions as in protected mode.

ENCLU—Execute an Enclave User Function of Specified Leaf Number

Vol. 3D 41-11

INTEL® SGX INSTRUCTION REFERENCES

**64-Bit Mode Exceptions**

* #UD
    - If any of the LOCK/66H/REP/VEX prefixes are used.
    - If current privilege level is not 3.
    - If CPUID.12H.00H:EAX.SGX1[0] = 0.
    - If logical processor is in SMM.
* #GP(0)
    - If IA32_FEATURE_CONTROL.LOCK = 0.
    - If IA32_FEATURE_CONTROL.SGX_ENABLE = 0.
    - If input value in EAX encodes an unsupported leaf.
    - If input value in EAX encodes EENTER/ERESUME and ENCLAVE_MODE = 1.
    - If input value in EAX encodes EGETKEY/EREPORT/EEXIT/EACCEPT/EACCEPTCOPY/EMODPE and ENCLAVE_MODE = 0.
    - If CR0.NE = 0.
* #NM
    - If CR0.TS = 1.

# 41.3 INTEL® SGX SYSTEM LEAF FUNCTION REFERENCE

Leaf functions available with the ENCLS instruction mnemonic are covered in this section. In general, each instruction leaf requires EAX to specify the leaf function index and/or additional implicit registers specifying leaf-specific input parameters. An instruction operand encoding table provides details of each implicit register usage and associated input/output semantics.

In many cases, an input parameter specifies an effective address associated with a memory object inside or outside the EPC, the memory addressing semantics of these memory objects are also summarized in a separate table.

<page_number>41-12</page_number> Vol. 3D

ENCLU—Execute an Enclave User Function of Specified Leaf Number

INTEL® SGX INSTRUCTION REFERENCES

# EADD—Add a Page to an Uninitialized Enclave

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 01H ENCLS[EADD]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function adds a page to an uninitialized enclave.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EADD (In)</td>
        <td>Address of a PAGEINFO (In)</td>
        <td>Address of the destination EPC page (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function copies a source page from non-enclave memory into the EPC, associates the EPC page with an SECS page residing in the EPC, and stores the linear address and security attributes in EPCM. As part of the association, the enclave offset and the security attributes are measured and extended into the SECS.MRENCLAVE. This instruction can only be executed when current privilege level is 0.

RBX contains the effective address of a PAGEINFO structure while RCX contains the effective address of an EPC page. The table below provides additional information on the memory parameter of EADD leaf function.

## EADD Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>PAGEINFO</th>
        <th>PAGEINFO.SECS</th>
        <th>PAGEINFO.SRCPGE</th>
        <th>PAGEINFO.SECINFO</th>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Non Enclave</td>
        <td>Read/Write access permitted by Enclave</td>
        <td>Read access permitted by Non Enclave</td>
        <td>Read access permitted by Non Enclave</td>
        <td>Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

## EADD Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>The operands are not properly aligned.</td>
        <td>Unsupported security attributes are set.</td>
    </tr>
    <tr>
        <td>Refers to an invalid SECS.</td>
        <td>Reference is made to an SECS that is locked by another thread.</td>
    </tr>
    <tr>
        <td>The EPC page is locked by another thread.</td>
        <td>RCX does not contain an effective address of an EPC page.</td>
    </tr>
    <tr>
        <td>The EPC page is already valid.</td>
        <td>If security attributes specifies a TCS and the source page specifies unsupported TCS values or fields.</td>
    </tr>
    <tr>
        <td>The SECS has been initialized.</td>
        <td>The specified enclave offset is outside of the enclave address space.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

Table 41-7. Base Concurrency Restrictions of EADD

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EADD</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECS [DS:RBX]PAGEINFO.SECS</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

EADD—Add a Page to an Uninitialized Enclave

Vol. 3D 41-13

INTEL® SGX INSTRUCTION REFERENCES

Table 41-8. Additional Concurrency Restrictions of EADD

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EADD</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECS [DS:RBX]PAGE-INFO.SECS</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Exclusive</td>
        <td>#GP</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

## Temp Variables in EADD Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SRCPGE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of the source page.</td>
    </tr>
    <tr>
        <td>TMP_SECS</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of the SECS destination page.</td>
    </tr>
    <tr>
        <td>TMP_SECINFO</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of an SECINFO structure which contains security attributes of the page to be added.</td>
    </tr>
    <tr>
        <td>SCRATCH_SECINFO</td>
        <td>SECINFO</td>
        <td>512</td>
        <td>Scratch storage for holding the contents of DS:TMP_SECINFO.</td>
    </tr>
    <tr>
        <td>TMP_LINADDR</td>
        <td>Unsigned Integer</td>
        <td>64</td>
        <td>Holds the linear address to be stored in the EPCM and used to calculate TMP_ENCLAVEOFFSET.</td>
    </tr>
    <tr>
        <td>TMP_ENCLAVEOFFSET</td>
        <td>Enclave Offset</td>
        <td>64</td>
        <td>The page displacement from the enclave base address.</td>
    </tr>
    <tr>
        <td>TMPUPDATEFIELD</td>
        <td>SHA256 Buffer</td>
        <td>512</td>
        <td>Buffer used to hold data being added to TMP_SECS.MRENCLAVE.</td>
    </tr>
  </tbody>
</table>

IF (DS:RBX is not 32Byte Aligned)
  THEN #GP(0); FI;

IF (DS:RCX is not 4KByte Aligned)
  THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
  THEN #PF(DS:RCX); FI;

TMP_SRCPGE := DS:RBX.SRCPGE;
TMP_SECS := DS:RBX.SECS;
TMP_SECINFO := DS:RBX.SECINFO;
TMP_LINADDR := DS:RBX.LINADDR;

IF (DS:TMP_SRCPGE is not 4KByte aligned or DS:TMP_SECS is not 4KByte aligned or
  DS:TMP_SECINFO is not 64Byte aligned or TMP_LINADDR is not 4KByte aligned)
  THEN #GP(0); FI;

IF (DS:TMP_SECS does not resolve within an EPC)
  THEN #PF(DS:TMP_SECS); FI;

SCRATCH_SECINFO := DS:TMP_SECINFO;

(\* Check for misconfigured SECINFO flags\*)
IF (SCRATCH_SECINFO reserved fields are not zero or

41-14 Vol. 3D
EADD—Add a Page to an Uninitialized Enclave

INTEL® SGX INSTRUCTION REFERENCES

! (SCRATCH_SECINFO.FLAGS.PT is PT_REG or SCRATCH_SECINFO.FLAGS.PT is PT_TCS or
(SCRATCH_SECINFO.FLAGS.PT is PT_SS_FIRST and CPUID.12H.01H:EAX[6] = 1) or
(SCRATCH_SECINFO.FLAGS.PT is PT_SS_REST and CPUID.12H.01H:EAX[6] = 1)) )
THEN #GP(0); FI;

(\* If PT_SS_FIRST/PT_SS_REST page types are requested then CR4.CET must be 1 \*)
IF ( (SCRATCH_SECINFO.FLAGS.PT is PT_SS_FIRST OR
SCRATCH_SECINFO.FLAGS.PT is PT_SS_REST) AND CR4.CET == 0)
THEN #GP(0); FI;

(\* Check the EPC page for concurrency \*)
IF (EPC page is not available for EADD)
THEN
#GP(0); FI;

IF (EPCM(DS:RCX).VALID ≠ 0)
THEN #PF(DS:RCX); FI;

(\* Check the SECS for concurrency \*)
IF (SECS is not available for EADD)
THEN #GP(0); FI;

IF (EPCM(DS:TMP_SECS).VALID = 0 or EPCM(DS:TMP_SECS).PT ≠ PT_SECS)
THEN #PF(DS:TMP_SECS); FI;

(\* Copy 4KBytes from source page to EPC page\*)
DS:RCX[32767:0] := DS:TMP_SRCPGE[32767:0];

CASE (SCRATCH_SECINFO.FLAGS.PT)

PT_TCS:
IF (DS:RCX.RESERVED ≠ 0) #GP(0); FI;
IF ( (DS:TMP_SECS.ATTRIBUTES.MODE64BIT = 0) and
((DS:TCS.FSLIMIT & 0FFFH ≠ 0FFFH) or (DS:TCS.GSLIMIT & 0FFFH ≠ 0FFFH) )) #GP(0); FI;
(\* Ensure TCS.PREVSSP is zero \*)
IF (CPUID.07H.00H:ECX.CET_SS = 1) and (DS:RCX.PREVSSP != 0) #GP(0); FI;
BREAK;
PT_REG:
IF (SCRATCH_SECINFO.FLAGS.W = 1 and SCRATCH_SECINFO.FLAGS.R = 0) #GP(0); FI;
BREAK;
PT_SS_FIRST:
PT_SS_REST:
(\* SS pages cannot be created on first or last page of ELRANGE \*)
IF ( TMP_LINADDR = DS:TMP_SECS.BASEADDR or TMP_LINADDR = (DS:TMP_SECS.BASEADDR + DS:TMP_SECS.SIZE - 0x1000) )
THEN #GP(0); FI;
IF ( DS:RCX[4087:0] != 0 ) #GP(0); FI;
IF (SCRATCH_SECINFO.FLAGS.PT == PT_SS_FIRST)
THEN
(\* Check that valid RSTORSSP token exists \*)
IF ( DS:RCX[4095:4088] != ((TMP_LINADDR + 0x1000) | DS:TMP_SECS.ATTRIBUTES.MODE64BIT) ) #GP(0); FI;
ELSE
(\* Check the 8 bytes are zero \*)
IF ( DS:RCX[4095:4088] != 0 ) #GP(0); FI;
FI;

EADD—Add a Page to an Uninitialized Enclave <page_number>Vol. 3D 41-15</page_number>

INTEL® SGX INSTRUCTION REFERENCES

```
    IF (SCRATCH_SECINFO.FLAGS.W = 0 OR SCRATCH_SECINFO.FLAGS.R = 0 OR
    SCRATCH_SECINFO.FLAGS.X = 1) #GP(0); FI;
        BREAK;
ESAC;

(* Check the enclave offset is within the enclave linear address space *)
IF (TMP_LINADDR < DS:TMP_SECS.BASEADDR or TMP_LINADDR ≥ DS:TMP_SECS.BASEADDR + DS:TMP_SECS.SIZE)
    THEN #GP(0); FI;

(* Check concurrency of measurement resource*)
IF (Measurement being updated)
    THEN #GP(0); FI;

(* Check if the enclave to which the page will be added is already in Initialized state *)
IF (DS:TMP_SECS already initialized)
    THEN #GP(0); FI;

(* For TCS pages, force EPCM.rwx bits to 0 and no debug access *)
IF (SCRATCH_SECINFO.FLAGS.PT = PT_TCS)
    THEN
        SCRATCH_SECINFO.FLAGS.R := 0;
        SCRATCH_SECINFO.FLAGS.W := 0;
        SCRATCH_SECINFO.FLAGS.X := 0;
        (DS:RCX).FLAGS.DBGOPTIN := 0; // force TCS.FLAGS.DBGOPTIN off
        DS:RCX.CSSA := 0;
        DS:RCX.AEP := 0;
        DS:RCX.STATE := 0;
FI;

(* Add enclave offset and security attributes to MRENCLAVE *)
TMP_ENCLAVEOFFSET := TMP_LINADDR - DS:TMP_SECS.BASEADDR;
TMPUPDATEFIELD[63:0] := 0000000044444145H; // “EADD”
TMPUPDATEFIELD[127:64] := TMP_ENCLAVEOFFSET;
TMPUPDATEFIELD[511:128] := SCRATCH_SECINFO[375:0]; // 48 bytes
DS:TMP_SECS.MRENCLAVE := SHA256UPDATE(DS:TMP_SECS.MRENCLAVE, TMPUPDATEFIELD)
INC enclave’s MRENCLAVE update counter;

(* Add enclave offset and security attributes to MRENCLAVE *)
EPCM(DS:RCX).R := SCRATCH_SECINFO.FLAGS.R;
EPCM(DS:RCX).W := SCRATCH_SECINFO.FLAGS.W;
EPCM(DS:RCX).X := SCRATCH_SECINFO.FLAGS.X;
EPCM(DS:RCX).PT := SCRATCH_SECINFO.FLAGS.PT;
EPCM(DS:RCX).ENCLAVEADDRESS := TMP_LINADDR;

(* associate the EPCPAGE with the SECS by storing the SECS identifier of DS:TMP_SECS *)
Update EPCM(DS:RCX) SECS identifier to reference DS:TMP_SECS identifier;

(* Set EPCM entry fields *)
EPCM(DS:RCX).BLOCKED := 0;
EPCM(DS:RCX).PENDING := 0;
EPCM(DS:RCX).MODIFIED := 0;
EPCM(DS:RCX).VALID := 1;
```

<page_number>41-16</page_number> Vol. 3D

EADD—Add a Page to an Uninitialized Enclave

INTEL® SGX INSTRUCTION REFERENCES

## Flags Affected

None

## Protected Mode Exceptions

**#GP(0)**
* If a memory operand effective address is outside the DS segment limit.
* If a memory operand is not properly aligned.
* If an enclave memory operand is outside of the EPC.
* If an enclave memory operand is the wrong type.
* If a memory operand is locked.
* If the enclave is initialized.
* If the enclave's MRENCLAVE is locked.
* If the TCS page reserved bits are set.
* If the TCS page PREVSSP field is not zero.
* If the PT_SS_REST or PT_SS_REST page is the first or last page in the enclave.
* If the PT_SS_FIRST or PT_SS_REST page is not initialized correctly.

**#PF(error code)**
* If a page fault occurs in accessing memory operands.
* If the EPC page is valid.

## 64-Bit Mode Exceptions

**#GP(0)**
* If a memory operand is non-canonical form.
* If a memory operand is not properly aligned.
* If an enclave memory operand is outside of the EPC.
* If an enclave memory operand is the wrong type.
* If a memory operand is locked.
* If the enclave is initialized.
* If the enclave's MRENCLAVE is locked.
* If the TCS page reserved bits are set.
* If the TCS page PREVSSP field is not zero.
* If the PT_SS_REST or PT_SS_REST page is the first or last page in the enclave.
* If the PT_SS_FIRST or PT_SS_REST page is not initialized correctly.

**#PF(error code)**
* If a page fault occurs in accessing memory operands.
* If the EPC page is valid.

EADD—Add a Page to an Uninitialized Enclave

Vol. 3D 41-17

INTEL® SGX INSTRUCTION REFERENCES

# EAUG—Add a Page to an Initialized Enclave

<table>
  <thead>
    <tr>
        <th>Opcode/Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 0DH ENCLS[EAUG]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX2</td>
        <td>This leaf function adds a page to an initialized enclave.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EAUG (In)</td>
        <td>Address of a PAGEINFO (In)</td>
        <td>Address of the destination EPC page (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function zeroes a page of EPC memory, associates the EPC page with an SECS page residing in the EPC, and stores the linear address and security attributes in the EPCM. As part of the association, the security attributes are configured to prevent access to the EPC page until a corresponding invocation of the EACCEPT leaf or EACCEPT-COPY leaf confirms the addition of the new page into the enclave. This instruction can only be executed when current privilege level is 0.

RBX contains the effective address of a PAGEINFO structure while RCX contains the effective address of an EPC page. The table below provides additional information on the memory parameter of the EAUG leaf function.

## EAUG Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>PAGEINFO</th>
        <th>PAGEINFO.SECS</th>
        <th>PAGEINFO.SRCPGE</th>
        <th>PAGEINFO.SECINFO</th>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Non Enclave</td>
        <td>Read/Write access permitted by Enclave</td>
        <td>Must be zero</td>
        <td>Read access permitted by Non Enclave</td>
        <td>Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

## EAUG Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>The operands are not properly aligned.</td>
        <td>Unsupported security attributes are set.</td>
    </tr>
    <tr>
        <td>Refers to an invalid SECS.</td>
        <td>Reference is made to an SECS that is locked by another thread.</td>
    </tr>
    <tr>
        <td>The EPC page is locked by another thread.</td>
        <td>RCX does not contain an effective address of an EPC page.</td>
    </tr>
    <tr>
        <td>The EPC page is already valid.</td>
        <td>The specified enclave offset is outside of the enclave address space.</td>
    </tr>
    <tr>
        <td colspan="2">The SECS has been initialized.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

### Table 41-9. Base Concurrency Restrictions of EAUG

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EAUG</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECS [DS:RBX]PAGEINFO.SECS</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

41-18Vol. 3D
EAUG—Add a Page to an Initialized Enclave

INTEL® SGX INSTRUCTION REFERENCES

## Table 41-10. Additional Concurrency Restrictions of EAUG

<table>
  <thead>
    <tr>
        <th colspan="2"> </th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EAUG</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECS [DS:RBX]PAGEINFO.SECS</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

### Temp Variables in EAUG Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SECS</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of the SECS destination page.</td>
    </tr>
    <tr>
        <td>TMP_SECINFO</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of an SECINFO structure which contains security attributes of the page to be added.</td>
    </tr>
    <tr>
        <td>SCRATCH_SECINFO</td>
        <td>SECINFO</td>
        <td>512</td>
        <td>Scratch storage for holding the contents of DS:TMP_SECINFO.</td>
    </tr>
    <tr>
        <td>TMP_LINADDR</td>
        <td>Unsigned Integer</td>
        <td>64</td>
        <td>Holds the linear address to be stored in the EPCM and used to calculate TMP_ENCLAVEOFFSET.</td>
    </tr>
  </tbody>
</table>

IF (DS:RBX is not 32Byte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

TMP_SECS := DS:RBX.SECS;
TMP_SECINFO := DS:RBX.SECINFO;
IF (DS:RBX.SECINFO is not 0)
    THEN
        IF (DS:TMP_SECINFO is not 64B aligned)
            THEN #GP(0); FI;
FI;

TMP_LINADDR := DS:RBX.LINADDR;

IF ( DS:TMP_SECS is not 4KByte aligned or TMP_LINADDR is not 4KByte aligned )
    THEN #GP(0); FI;

IF DS:RBX.SRCPAGE is not 0
    THEN #GP(0); FI;

IF (DS:TMP_SECS does not resolve within an EPC)
    THEN #PF(DS:TMP_SECS); FI;

(\* Check the EPC page for concurrency \*)

EAUG—Add a Page to an Initialized Enclave

<page_number>Vol. 3D 41-19</page_number>

INTEL® SGX INSTRUCTION REFERENCES

IF (EPC page is not available for EAUG)
    THEN
        #GP(0); FI;

IF (EPCM(DS:RCX).VALID ≠ 0)
    THEN #PF(DS:RCX); FI;

(\* copy SECINFO contents into a scratch SECINFO \*)
IF (DS:RBX.SECINFO is 0)
    THEN
        (\* allocate and initialize a new scratch SECINFO structure \*)
        SCRATCH_SECINFO.PT := PT_REG;
        SCRATCH_SECINFO.R := 1;
        SCRATCH_SECINFO.W := 1;
        SCRATCH_SECINFO.X := 0;
        << zero out remaining fields of SCRATCH_SECINFO >>
    ELSE
        (\* copy SECINFO contents into scratch SECINFO \*)
        SCRATCH_SECINFO := DS:TMP_SECINFO;
        (\* check SECINFO flags for misconfiguration \*)
        (\* reserved flags must be zero \*)
        (\* SECINFO.FLAGS.PT must either be PT_SS_FIRST, or PT_SS_REST \*)
        IF ( (SCRATCH_SECINFO reserved fields are not 0) or
CPUID.12H.01H:EAX[6] is 0) OR
            (SCRATCH_SECINFO.PT is not PT_SS_FIRST, or PT_SS_REST) OR
            ( (SCRATCH_SECINFO.FLAGS.R is 0) OR (SCRATCH_SECINFO.FLAGS.W is 0) OR (SCRATCH_SECINFO.FLAGS.X is 1) ) )
            THEN #GP(0); FI;
FI;
(\* Check if PT_SS_FIRST/PT_SS_REST page types are requested then CR4.CET must be 1 \*)
IF ( (SCRATCH_SECINFO.PT is PT_SS_FIRST OR SCRATCH_SECINFO.PT is PT_SS_REST) AND CR4.CET == 0 )
    THEN #GP(0); FI;

(\* Check the SECS for concurrency \*)
IF (SECS is not available for EAUG)
    THEN #GP(0); FI;

IF (EPCM(DS:TMP_SECS).VALID = 0 or EPCM(DS:TMP_SECS).PT ≠ PT_SECS)
    THEN #PF(DS:TMP_SECS); FI;

(\* Check if the enclave to which the page will be added is in the Initialized state \*)
IF (DS:TMP_SECS is not initialized)
    THEN #GP(0); FI;

(\* Check the enclave offset is within the enclave linear address space \*)
IF ( (TMP_LINADDR < DS:TMP_SECS.BASEADDR) or (TMP_LINADDR ≥ DS:TMP_SECS.BASEADDR + DS:TMP_SECS.SIZE) )
    THEN #GP(0); FI;

IF ( (SCRATCH_SECINFO.PT is PT_SS_FIRST OR SCRATCH_SECINFO.PT is PT_SS_REST) )
    THEN
        (\* SS pages cannot created on first or last page of ELRANGE \*)
        IF ( TMP_LINADDR == DS:TMP_SECS.BASEADDR OR
            TMP_LINADDR == (DS:TMP_SECS.BASEADDR + DS:TMP_SECS.SIZE - 0x1000) )
            THEN
                #GP(0); FI;

41-20 Vol. 3D EAUG—Add a Page to an Initialized Enclave

INTEL® SGX INSTRUCTION REFERENCES

FI;

```
(* Clear the content of EPC page*)
DS:RCX[32767:0] := 0;

IF (CPUID.07H.00H:ECX.CET_SS = 1)
    THEN
        (* set up shadow stack RSTORSSP token *)
        IF (SCRATCH_SECINFO.PT is PT_SS_FIRST)
        THEN
            DS:RCX[0xFF8] := (TMP_LINADDR + 0x1000) | TMP_SECS.ATTRIBUTES.MODE64BIT; FI;
FI;

(* Set EPCM security attributes *)
EPCM(DS:RCX).R := SCRATCH_SECINFO.FLAGS.R;
EPCM(DS:RCX).W := SCRATCH_SECINFO.FLAGS.W;
EPCM(DS:RCX).X := SCRATCH_SECINFO.FLAGS.X;
EPCM(DS:RCX).PT := SCRATCH_SECINFO.FLAGS.PT;
EPCM(DS:RCX).ENCLAVEADDRESS := TMP_LINADDR;
EPCM(DS:RCX).BLOCKED := 0;
EPCM(DS:RCX).PENDING := 1;
EPCM(DS:RCX).MODIFIED := 0;
EPCM(DS:RCX).PR := 0;

(* associate the EPCPAGE with the SECS by storing the SECS identifier of DS:TMP_SECS *)
Update EPCM(DS:RCX) SECS identifier to reference DS:TMP_SECS identifier;

(* Set EPCM valid fields *)
EPCM(DS:RCX).VALID := 1;
```

## Flags Affected

None

## Protected Mode Exceptions

<table>
    <tr>
        <td>#GP(0)</td>
        <td>If a memory operand effective address is outside the DS segment limit.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is not properly aligned.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is locked.</td>
    </tr>
    <tr>
        <td></td>
        <td>If the enclave is not initialized.</td>
    </tr>
    <tr>
        <td>#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
</table>

## 64-Bit Mode Exceptions

<table>
    <tr>
        <td>#GP(0)</td>
        <td>If a memory operand is non-canonical form.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is not properly aligned.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is locked.</td>
    </tr>
    <tr>
        <td></td>
        <td>If the enclave is not initialized.</td>
    </tr>
    <tr>
        <td>#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
</table>

EAUG—Add a Page to an Initialized Enclave

Vol. 3D 41-21

INTEL® SGX INSTRUCTION REFERENCES

# EBLOCK—Mark a page in EPC as Blocked

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 09H ENCLS[EBLOCK]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function marks a page in the EPC as blocked.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th colspan="2">RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EBLOCK (In)</td>
        <td>Return error code (Out)</td>
        <td>Effective address of the EPC page (In)</td>
    </tr>
  </tbody>
</table>

### Description

This leaf function causes an EPC page to be marked as BLOCKED. This instruction can only be executed when current privilege level is 0.

The content of RCX is an effective address of an EPC page. The DS segment is used to create linear address. Segment override is not supported.

An error code is returned in RAX.

The table below provides additional information on the memory parameter of EBLOCK leaf function.

## EBLOCK Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read/Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The error codes are:

Table 41-11. EBLOCK Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EBLOCK successful.</td>
    </tr>
    <tr>
        <td>SGX_BLKSTATE</td>
        <td>Page already blocked. This value is used to indicate to a VMM that the page was already in BLOCKED state as a result of EBLOCK and thus will need to be restored to this state when it is eventually reloaded (using ELDB).</td>
    </tr>
    <tr>
        <td>SGX_ENTRYEPOCH_LOCKED</td>
        <td>SECS locked for Entry Epoch update. This value indicates that an ETRACK is currently executing on the SECS. The EBLOCK should be reattempted.</td>
    </tr>
    <tr>
        <td>SGX_NOTBLOCKABLE</td>
        <td>Page type is not one which can be blocked.</td>
    </tr>
    <tr>
        <td>SGX_PG_INVLD</td>
        <td>Page is not valid and cannot be blocked.</td>
    </tr>
    <tr>
        <td>SGX_EPC_PAGE_CONFLICT</td>
        <td>Page is being written by EADD, EAUG, ECREATE, ELDU/B, EMODT, or EWB.</td>
    </tr>
  </tbody>
</table>

### Concurrency Restrictions

Table 41-12. Base Concurrency Restrictions of EBLOCK

<table>
  <thead>
    <tr>
        <th> </th>
        <th> </th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Leaf</th>
        <th>Parameter</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EBLOCK</td>
        <td>Target [DS:RCX]</td>
        <td>Shared</td>
        <td>SGX_EPC_PAGE_CONFLICT</td>
    </tr>
  </tbody>
</table>

41-22 Vol. 3D
EBLOCK—Mark a page in EPC as Blocked

INTEL® SGX INSTRUCTION REFERENCES

Table 41-13. Additional Concurrency Restrictions of EBLOCK

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EBLOCK</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

# Operation

Temp Variables in EBLOCK Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_BLKSTATE</td>
        <td>Integer</td>
        <td>64</td>
        <td>Page is already blocked.</td>
    </tr>
  </tbody>
</table>

```
IF (DS:RCX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

RFLAGS.ZF,CF,PF,AF,OF,SF := 0;
RAX := 0;

(* Check the EPC page for concurrency*)
IF (EPC page in use)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_EPC_PAGE_CONFLICT;
        GOTO DONE;
FI;

IF (EPCM(DS:RCX). VALID = 0)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_PG_INVLD;
        GOTO DONE;
FI;

IF ( (EPCM(DS:RCX).PT ≠ PT_REG) and (EPCM(DS:RCX).PT ≠ PT_TCS) and (EPCM(DS:RCX).PT ≠ PT_TRIM)
and EPCM(DS:RCX).PT ≠ PT_SS_FIRST) and (EPCM(DS:RCX).PT ≠ PT_SS_REST))
    THEN
        RFLAGS.CF := 1;
        IF (EPCM(DS:RCX).PT = PT_SECS)
            THEN RAX := SGX_PG_IS_SECS;
            ELSE RAX := SGX_NOTBLOCKABLE;
        FI;
        GOTO DONE;
FI;

(* Check if the page is already blocked and report blocked state *)
TMP_BLKSTATE := EPCM(DS:RCX).BLOCKED;
```

EBLOCK—Mark a page in EPC as Blocked <page_number>Vol. 3D 41-23</page_number>

INTEL® SGX INSTRUCTION REFERENCES

```
(* at this point, the page must be valid and PT_TCS or PT_REG or PT_TRIM*)
IF (TMP_BLKSTATE = 1)
    THEN
        RFLAGS.CF := 1;
        RAX := SGX_BLKSTATE;
    ELSE
        EPCM(DS:RCX).BLOCKED := 1
FI;
DONE:
```

## Flags Affected

Sets ZF if SECS is in use or invalid, otherwise cleared. Sets CF if page is BLOCKED or not blockable, otherwise cleared. Clears PF, AF, OF, SF.

## Protected Mode Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">#GP(0)</td>
        <td>If a memory operand effective address is outside the DS segment limit.</td>
    </tr>
    <tr>
        <td>If a memory operand is not properly aligned.</td>
    </tr>
    <tr>
        <td>If the specified EPC resource is in use.</td>
    </tr>
    <tr>
        <td rowspan="2">#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
    <tr>
        <td>If a memory operand is not an EPC page.</td>
    </tr>
  </tbody>
</table>

## 64-Bit Mode Exceptions

<table>
  <thead>
    <tr>
        <th>Exception</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">#GP(0)</td>
        <td>If a memory operand is non-canonical form.</td>
    </tr>
    <tr>
        <td>If a memory operand is not properly aligned.</td>
    </tr>
    <tr>
        <td>If the specified EPC resource is in use.</td>
    </tr>
    <tr>
        <td rowspan="2">#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
    <tr>
        <td>If a memory operand is not an EPC page.</td>
    </tr>
  </tbody>
</table>

<page_number>41-24</page_number> Vol. 3D EBLOCK—Mark a page in EPC as Blocked

INTEL® SGX INSTRUCTION REFERENCES

# ECREATE—Create an SECS page in the Enclave Page Cache

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 00H<br/>ENCLS[ECREATE]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function begins an enclave build by creating an SECS page in EPC.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>ECREATE (In)</td>
        <td>Address of a PAGEINFO (In)</td>
        <td>Address of the destination SECS page (In)</td>
    </tr>
  </tbody>
</table>

## Description

ENCLS[ECREATE] is the first instruction executed in the enclave build process. ECREATE copies an SECS structure outside the EPC into an SECS page inside the EPC. The internal structure of SECS is not accessible to software.

ECREATE will set up fields in the protected SECS and mark the page as valid inside the EPC. ECREATE initializes or checks unused fields.

Software sets the following fields in the source structure: SECS:BASEADDR, SECS:SIZE in bytes, ATTRIBUTES, CONFIGID, and CONFIGSVN. SECS:BASEADDR must be naturally aligned on an SECS.SIZE boundary. SECS.SIZE must be at least 2 pages (8192).

The source operand RBX contains an effective address of a PAGEINFO structure. PAGEINFO contains an effective address of a source SECS and an effective address of an SECINFO. The SECS field in PAGEINFO is not used.

The RCX register is the effective address of the destination SECS. It is an address of an empty slot in the EPC. The SECS structure must be page aligned. SECINFO flags must specify the page as an SECS page.

## ECREATE Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>PAGEINFO</th>
        <th>PAGEINFO.SRCPGE</th>
        <th>PAGEINFO.SECINFO</th>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Non Enclave</td>
        <td>Read access permitted by Non Enclave</td>
        <td>Read access permitted by Non Enclave</td>
        <td>Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

ECREATE will fault if the SECS target page is in use; already valid; outside the EPC. It will also fault if addresses are not aligned; unused PAGEINFO fields are not zero.

If the amount of space needed to store the SSA frame is greater than the amount specified in SECS.SSAFRAME-SIZE, a #GP(0) results. The amount of space needed for an SSA frame is computed based on DS:TMP\_-SECS.ATTRIBUTES.XFRM size. Details of computing the size can be found Section 42.7.

## Concurrency Restrictions

Table 41-14. Base Concurrency Restrictions of ECREATE

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ECREATE</td>
        <td>SECS [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

ECREATE—Create an SECS page in the Enclave Page Cache

Vol. 3D

41-25
<page_number>

41-25
</page_number>

INTEL® SGX INSTRUCTION REFERENCES

# Table 41-15. Additional Concurrency Restrictions of ECREATE

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY,<br/>EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ECREATE</td>
        <td>SECS [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

### Temp Variables in ECREATE Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SRCPGE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of the SECS source page.</td>
    </tr>
    <tr>
        <td>TMP_SECS</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of the SECS destination page.</td>
    </tr>
    <tr>
        <td>TMP_SECINFO</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of an SECINFO structure which contains security attributes of the SECS page to be added.</td>
    </tr>
    <tr>
        <td>TMP_XSIZE</td>
        <td>SSA Size</td>
        <td>64</td>
        <td>The size calculation of SSA frame.</td>
    </tr>
    <tr>
        <td>TMP_MISC_SIZE</td>
        <td>MISC Field Size</td>
        <td>64</td>
        <td>Size of the selected MISC field components.</td>
    </tr>
    <tr>
        <td>TMPUPDATEFIELD</td>
        <td>SHA256 Buffer</td>
        <td>512</td>
        <td>Buffer used to hold data being added to TMP_SECS.MRENCLAVE.</td>
    </tr>
  </tbody>
</table>

IF (DS:RBX is not 32Byte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

TMP_SRCPGE := DS:RBX.SRCPGE;
TMP_SECINFO := DS:RBX.SECINFO;

IF (DS:TMP_SRCPGE is not 4KByte aligned or DS:TMP_SECINFO is not 64Byte aligned)
    THEN #GP(0); FI;

IF (DS:RBX.LINADDR != 0 or DS:RBX.SECS ≠ 0)
    THEN #GP(0); FI;

(\* Check for misconfigured SECINFO flags\*)
IF (DS:TMP_SECINFO reserved fields are not zero or DS:TMP_SECINFO.FLAGS.PT ≠ PT_SECS)
    THEN #GP(0); FI;

TMP_SECS := RCX;

IF (EPC entry in use)
    THEN #GP(0); FI;

IF (EPCM(DS:RCX).VALID = 1)
    THEN #PF(DS:RCX); FI;

41-26 Vol. 3D <page_number>41-26</page_number> ECREATE—Create an SECS page in the Enclave Page Cache

INTEL® SGX INSTRUCTION REFERENCES

```
(* Copy 4KBytes from source page to EPC page*)
DS:RCX[32767:0] := DS:TMP_SRCPGE[32767:0];

(* Check lower 2 bits of XFRM are set *)
IF ( ( DS:TMP_SECS.ATTRIBUTES.XFRM BitwiseAND 03H) ≠ 03H)
    THEN #GP(0); FI;

IF (XFRM is illegal)
    THEN #GP(0); FI;

(* Check legality of CET_ATTRIBUTES *)
IF ((DS:TMP_SECS.ATTRIBUTES.CET = 0 and DS:TMP_SECS.CET_ATTRIBUTES ≠ 0) ||
    (DS:TMP_SECS.ATTRIBUTES.CET = 0 and DS:TMP_SECS.CET_LEG_BITMAP_OFFSET ≠ 0) ||
(CPUID.07H.00H:EDX.CET_IBT = 0 and DS:TMP_SECS.CET_LEG_BITMAP_OFFSET ≠ 0) ||
(CPUID.07H.00H:EDX.CET_IBT = 0 and DS:TMP_SECS.CET_ATTRIBUTES[5:2] ≠ 0) ||
(CPUID.07H.00H:ECX.CET_SS = 0 and DS:TMP_SECS.CET_ATTRIBUTES[1:0] ≠ 0) ||
    (DS:TMP_SECS.ATTRIBUTES.MODE64BIT = 1 and
    (DS:TMP_SECS.BASEADDR + DS:TMP_SECS.CET_LEG_BITMAP_OFFSET) not canonical) ||
    (DS:TMP_SECS.ATTRIBUTES.MODE64BIT = 0 and
    (DS:TMP_SECS.BASEADDR + DS:TMP_SECS.CET_LEG_BITMAP_OFFSET) & 0xFFFFFFFF00000000) ||
    (DS:TMP_SECS.CET_ATTRIBUTES.reserved fields not 0) or
    (DS:TMP_SECS.CET_LEG_BITMAP_OFFSET) is not page aligned))
    THEN
        #GP(0);
FI;

(* Make sure that the SECS does not have any unsupported MISCSELECT options*)
IF ( !(CPUID.12H.00H:EBX[31:0] & DS:TMP_SECS.MISCSELECT[31:0]) )
    THEN
        EPCM(DS:TMP_SECS).EntryLock.Release();
        #GP(0);
FI;

(* Compute size of MISC area *)
TMP_MISC_SIZE := compute_misc_region_size();

(* Compute the size required to save state of the enclave on async exit, see Section 42.7.2.2*)
TMP_XSIZE := compute_xsave_size(DS:TMP_SECS.ATTRIBUTES.XFRM) + GPR_SIZE + TMP_MISC_SIZE;

(* Ensure that the declared area is large enough to hold XSAVE and GPR stat *)
IF ( DS:TMP_SECS.SSAFRAMESIZE*4096 < TMP_XSIZE)
    THEN #GP(0); FI;

IF ( (DS:TMP_SECS.ATTRIBUTES.MODE64BIT = 1) and (DS:TMP_SECS.BASEADDR is not canonical) )
    THEN #GP(0); FI;

IF ( (DS:TMP_SECS.ATTRIBUTES.MODE64BIT = 0) and (DS:TMP_SECS.BASEADDR and 0FFFFFFFF00000000H) )
    THEN #GP(0); FI;

IF ( (DS:TMP_SECS.ATTRIBUTES.MODE64BIT = 0) and (DS:TMP_SECS.SIZE ≥ 2 ^ (CPUID.12H.00H:EDX[7:0]) ) )
    THEN #GP(0); FI;

IF ( (DS:TMP_SECS.ATTRIBUTES.MODE64BIT = 1) and (DS:TMP_SECS.SIZE ≥ 2 ^ (CPUID.12H.00H:EDX[15:8]) ) )
```

ECREATE—Create an SECS page in the Enclave Page Cache Vol. 3D 41-27

INTEL® SGX INSTRUCTION REFERENCES

THEN #GP(0); FI;

(\* Enclave size must be at least 8192 bytes and must be power of 2 in bytes\*)
IF (DS:TMP_SECS.SIZE < 8192 or popcnt(DS:TMP_SECS.SIZE) > 1)
THEN #GP(0); FI;

(\* Ensure base address of an enclave is aligned on size\*)
IF ( ( DS:TMP_SECS.BASEADDR and (DS:TMP_SECS.SIZE-1) ) )
THEN #GP(0); FI;

(\* Ensure the SECS does not have any unsupported attributes\*)
IF ( DS:TMP_SECS.ATTRIBUTES and (~CR_SGX_ATTRIBUTES_MASK) )
THEN #GP(0); FI;

IF ( DS:TMP_SECS reserved fields are not zero)
THEN #GP(0); FI;

(\* Verify that CONFIGID/CONFIGSVN are not set with attribute \*)
IF ( ((DS:TMP_SECS.CONFIGID ≠ 0) or (DS:TMP_SECS.CONFIGSVN ≠0)) AND (DS:TMP_SECS.ATTRIBUTES.KSS == 0 ))
THEN #GP(0); FI;

Clear DS:TMP_SECS to Uninitialized;
DS:TMP_SECS.MRENCLAVE := SHA256INITIALIZE(DS:TMP_SECS.MRENCLAVE);
DS:TMP_SECS.ISVSVN := 0;
DS:TMP_SECS.ISVPRODID := 0;

(\* Initialize hash updates etc\*)
Initialize enclave’s MRENCLAVE update counter;

(\* Add “ECREATE” string and SECS fields to MRENCLAVE \*)
TMPUPDATEFIELD[63:0] := 0045544145524345H; // “ECREATE”
TMPUPDATEFIELD[95:64] := DS:TMP_SECS.SSAFRAMESIZE;
TMPUPDATEFIELD[159:96] := DS:TMP_SECS.SIZE;
IF (CPUID.07H.00H:EDX.CET_IBT = 1)
THEN
TMPUPDATEFIELD[223:160] := DS:TMP_SECS.CET_LEG_BITMAP_OFFSET;
ELSE
TMPUPDATEFIELD[223:160] := 0;
FI;
TMPUPDATEFIELD[511:160] := 0;
DS:TMP_SECS.MRENCLAVE := SHA256UPDATE(DS:TMP_SECS.MRENCLAVE, TMPUPDATEFIELD)
INC enclave’s MRENCLAVE update counter;

(\* Set EID \*)
DS:TMP_SECS.EID := LockedXAdd(CR_NEXT_EID, 1);

(\* Set the EPCM entry, first create SECS identifier and store the identifier in EPCM \*)
EPCM(DS:TMP_SECS).PT := PT_SECS;
EPCM(DS:TMP_SECS).ENCLAVEADDRESS := 0;
EPCM(DS:TMP_SECS).R := 0;
EPCM(DS:TMP_SECS).W := 0;
EPCM(DS:TMP_SECS).X := 0;

(\* Set EPCM entry fields \*)

<page_number>41-28</page_number> Vol. 3D ECREATE—Create an SECS page in the Enclave Page Cache

INTEL® SGX INSTRUCTION REFERENCES

```
EPCM(DS:RCX).BLOCKED := 0;
EPCM(DS:RCX).PENDING := 0;
EPCM(DS:RCX).MODIFIED := 0;
EPCM(DS:RCX).PR := 0;
EPCM(DS:RCX).VALID := 1;
```

## Flags Affected

None

## Protected Mode Exceptions

**#GP(0)**
* If a memory operand effective address is outside the DS segment limit.
* If a memory operand is not properly aligned.
* If the reserved fields are not zero.
* If PAGEINFO.SECS is not zero.
* If PAGEINFO.LINADDR is not zero.
* If the SECS destination is locked.
* If SECS.SSAFRAMESIZE is insufficient.

**#PF(error code)**
* If a page fault occurs in accessing memory operands.
* If the SECS destination is outside the EPC.

## 64-Bit Mode Exceptions

**#GP(0)**
* If a memory address is non-canonical form.
* If a memory operand is not properly aligned.
* If the reserved fields are not zero.
* If PAGEINFO.SECS is not zero.
* If PAGEINFO.LINADDR is not zero.
* If the SECS destination is locked.
* If SECS.SSAFRAMESIZE is insufficient.

**#PF(error code)**
* If a page fault occurs in accessing memory operands.
* If the SECS destination is outside the EPC.

ECREATE—Create an SECS page in the Enclave Page Cache

Vol. 3D 41-29
<page_number>41-29</page_number>

INTEL® SGX INSTRUCTION REFERENCES

# EDBGRD—Read From a Debug Enclave

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 04H ENCLS[EDBGRD]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function reads a dword/quadword from a debug enclave.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th colspan="2">RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EDBGRD (In)</td>
        <td>Return error code (Out)</td>
        <td>Data read from a debug enclave (Out)</td>
        <td>Address of source memory in the EPC (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function copies a quadword/doubleword from an EPC page belonging to a debug enclave into the RBX register. Eight bytes are read in 64-bit mode, four bytes are read in non-64-bit modes. The size of data read cannot be overridden.

The effective address of the source location inside the EPC is provided in the register RCX.

## EDBGRD Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>EPCQW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The error codes are:

## Table 41-16. EDBGRD Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EDBGRD successful.</td>
    </tr>
    <tr>
        <td>SGX_PAGE_NOT_DEBUGGABLE</td>
        <td>The EPC page cannot be accessed because it is in the PENDING or MODIFIED state.</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

## EDBGRD Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>RCX points into a page that is an SECS.</td>
        <td>RCX does not resolve to a naturally aligned linear address.</td>
    </tr>
    <tr>
        <td>RCX points to a page that does not belong to an enclave that is in debug mode.</td>
        <td>RCX points to a location inside a TCS that is beyond the architectural size of the TCS (SGX_TCS_LIMIT).</td>
    </tr>
    <tr>
        <td>An operand causing any segment violation.</td>
        <td>May page fault.</td>
    </tr>
    <tr>
        <td colspan="2">CPL &gt; 0.</td>
    </tr>
  </tbody>
</table>

This instruction ignores the EPCM RWX attributes on the enclave page. Consequently, violation of EPCM RWX attributes via EDBGRD does not result in a #GP.

41-30 Vol. 3D
EDBGRD—Read From a Debug Enclave

INTEL® SGX INSTRUCTION REFERENCES

## Concurrency Restrictions

Table 41-17. Base Concurrency Restrictions of EDBGRD

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EDBGRD</td>
        <td>Target [DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

Table 41-18. Additional Concurrency Restrictions of EDBGRD

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EDBGRD</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

Temp Variables in EDBGRD Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_MODE64</td>
        <td>Binary</td>
        <td>1</td>
        <td>((IA32_EFER.LMA = 1) &amp;&amp; (CS.L = 1))</td>
    </tr>
    <tr>
        <td>TMP_SECS</td>
        <td> </td>
        <td>64</td>
        <td>Physical address of SECS of the enclave to which source operand belongs.</td>
    </tr>
  </tbody>
</table>

TMP_MODE64 := ((IA32_EFER.LMA = 1) && (CS.L = 1));

IF ( (TMP_MODE64 = 1) and (DS:RCX is not 8Byte Aligned) )

    THEN #GP(0); FI;

IF ( (TMP_MODE64 = 0) and (DS:RCX is not 4Byte Aligned) )

    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)

    THEN #PF(DS:RCX); FI;

(\* make sure no other Intel SGX instruction is accessing the same EPCM entry \*)

IF (Another instruction modifying the same EPCM entry is executing)

    THEN #GP(0); FI;

IF (EPCM(DS:RCX).VALID = 0)

    THEN #PF(DS:RCX); FI;

(\* make sure that DS:RCX (SOURCE) is pointing to a PT_REG or PT_TCS or PT_VA or PT_SS_FIRST or PT_SS_REST \*)

IF ( (EPCM(DS:RCX).PT ≠ PT_REG) and (EPCM(DS:RCX).PT ≠ PT_TCS) and (EPCM(DS:RCX).PT ≠ PT_VA)

and (EPCM(DS:RCX).PT ≠ PT_SS_FIRST) and (EPCM(DS:RCX).PT ≠ PT_SS_REST))

    THEN #PF(DS:RCX); FI;

(\* make sure that DS:RCX points to an accessible EPC page \*)

IF (EPCM(DS:RCX).PENDING is not 0 or (EPCM(DS:RCX).MODIFIED is not 0) )

    THEN

        RFLAGS.ZF := 1;

EDBGRD—Read From a Debug Enclave

<page_number>Vol. 3D 41-31</page_number>

INTEL® SGX INSTRUCTION REFERENCES

```
        RAX := SGX_PAGE_NOT_DEBUGGABLE;
        GOTO DONE;
FI;

(* If source is a TCS, then make sure that the offset into the page is not beyond the TCS size*)
IF ( ( EPCM(DS:RCX). PT = PT_TCS) and ((DS:RCX) & FFFH ≥ SGX_TCS_LIMIT) )
    THEN #GP(0); FI;

(* make sure the enclave owning the PT_REG or PT_TCS page allow debug *)
IF ( (EPCM(DS:RCX).PT = PT_REG) or (EPCM(DS:RCX).PT = PT_TCS) )
    THEN
        TMP_SECS := GET_SECS_ADDRESS;
        IF (TMP_SECS.ATTRIBUTES.DEBUG = 0)
            THEN #GP(0); FI;
        IF ( (TMP_MODE64 = 1) )
            THEN RBX[63:0] := (DS:RCX)[63:0];
            ELSE EBX[31:0] := (DS:RCX)[31:0];
        FI;
    ELSE
        TMP_64BIT_VAL[63:0] := (DS:RCX)[63:0] & (~07H); // Read contents from VA slot
        IF (TMP_MODE64 = 1)
            THEN
                IF (TMP_64BIT_VAL ≠ 0H)
                    THEN RBX[63:0] := 0FFFFFFFFFFFFFFFFH;
                    ELSE RBX[63:0] := 0H;
                FI;
            ELSE
                IF (TMP_64BIT_VAL ≠ 0H)
                    THEN EBX[31:0] := 0FFFFFFFFH;
                    ELSE EBX[31:0] := 0H;
                FI;
FI;

(* clear EAX and ZF to indicate successful completion *)
RAX := 0;
RFLAGS.ZF := 0;

DONE:
(* clear flags *)
RFLAGS.CF,PF,AF,OF,SF := 0;
```

## Flags Affected

ZF is set if the page is MODIFIED or PENDING; RAX contains the error code. Otherwise ZF is cleared and RAX is set to 0. CF, PF, AF, OF, SF are cleared.

## Protected Mode Exceptions

**#GP(0)** | If the address in RCS violates DS limit or access rights.
--- | ---
| If DS segment is unusable.
| If RCX points to a memory location not 4Byte-aligned.
| If the address in RCX points to a page belonging to a non-debug enclave.
| If the address in RCX points to a page which is not PT_TCS, PT_REG or PT_VA.
| If the address in RCX points to a location inside TCS that is beyond SGX_TCS_LIMIT.

<page_number>41-32</page_number> Vol. 3D

EDBGRD—Read From a Debug Enclave

INTEL® SGX INSTRUCTION REFERENCES

**#PF(error code)**:
* If a page fault occurs in accessing memory operands.
* If the address in RCX points to a non-EPC page.
* If the address in RCX points to an invalid EPC page.

## 64-Bit Mode Exceptions

**#GP(0)**:
* If RCX is non-canonical form.
* If RCX points to a memory location not 8Byte-aligned.
* If the address in RCX points to a page belonging to a non-debug enclave.
* If the address in RCX points to a page which is not PT_TCS, PT_REG or PT_VA.
* If the address in RCX points to a location inside TCS that is beyond SGX_TCS_LIMIT.

**#PF(error code)**:
* If a page fault occurs in accessing memory operands.
* If the address in RCX points to a non-EPC page.
* If the address in RCX points to an invalid EPC page.

EDBGRD—Read From a Debug Enclave Vol. 3D 41-33

INTEL® SGX INSTRUCTION REFERENCES

# EDBGWR—Write to a Debug Enclave

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 05H ENCLS[EDBGWR]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function writes a dword/quadword to a debug enclave.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th colspan="2">RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EDBGWR (In)</td>
        <td>Return error code (Out)</td>
        <td>Data to be written to a debug enclave (In)</td>
        <td>Address of Target memory in the EPC (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function copies the content in EBX/RBX to an EPC page belonging to a debug enclave. Eight bytes are written in 64-bit mode, four bytes are written in non-64-bit modes. The size of data cannot be overridden.

The effective address of the target location inside the EPC is provided in the register RCX.

## EDBGWR Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>EPCQW</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

## EDBGWR Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>RCX points into a page that is an SECS.</td>
        <td>RCX does not resolve to a naturally aligned linear address.</td>
    </tr>
    <tr>
        <td>RCX points to a page that does not belong to an enclave that is in debug mode.</td>
        <td>RCX points to a location inside a TCS that is not the FLAGS word.</td>
    </tr>
    <tr>
        <td>An operand causing any segment violation.</td>
        <td>May page fault.</td>
    </tr>
    <tr>
        <td colspan="2">CPL &gt; 0.</td>
    </tr>
  </tbody>
</table>

The error codes are:

## Table 41-19. EDBGWR Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EDBGWR successful.</td>
    </tr>
    <tr>
        <td>SGX_PAGE_NOT_DEBUGGABLE</td>
        <td>The EPC page cannot be accessed because it is in the PENDING or MODIFIED state.</td>
    </tr>
  </tbody>
</table>

This instruction ignores the EPCM RWX attributes on the enclave page. Consequently, violation of EPCM RWX attributes via EDBGRD does not result in a #GP.

41-34 Vol. 3D
EDBGWR—Write to a Debug Enclave

INTEL® SGX INSTRUCTION REFERENCES

## Concurrency Restrictions

### Table 41-20. Base Concurrency Restrictions of EDBGWR

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EDBGWR</td>
        <td>Target [DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

### Table 41-21. Additional Concurrency Restrictions of EDBGWR

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY,<br/>EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EDBGWR</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

### Temp Variables in EDBGWR Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_MODE64</td>
        <td>Binary</td>
        <td>1</td>
        <td>((IA32_EFER.LMA = 1) &amp;&amp; (CS.L = 1)).</td>
    </tr>
    <tr>
        <td>TMP_SECS</td>
        <td> </td>
        <td>64</td>
        <td>Physical address of SECS of the enclave to which source operand belongs.</td>
    </tr>
  </tbody>
</table>

TMP_MODE64 := ((IA32_EFER.LMA = 1) && (CS.L = 1));

IF ( (TMP_MODE64 = 1) and (DS:RCX is not 8Byte Aligned) )
  THEN #GP(0); FI;

IF ( (TMP_MODE64 = 0) and (DS:RCX is not 4Byte Aligned) )
  THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
  THEN #PF(DS:RCX); FI;

(\* make sure no other Intel SGX instruction is accessing the same EPCM entry \*)

IF (Another instruction modifying the same EPCM entry is executing)
  THEN #GP(0); FI;

IF (EPCM(DS:RCX).VALID = 0)
  THEN #PF(DS:RCX); FI;

(\* make sure that DS:RCX (DST) is pointing to a PT_REG or PT_TCS or PT_SS_FIRST or PT_SS_REST \*)

IF ( (EPCM(DS:RCX).PT ≠ PT_REG) and (EPCM(DS:RCX).PT ≠ PT_TCS)
  and (EPCM(DS:RCX).PT ≠ PT_SS_FIRST) and (EPCM(DS:RCX).PT ≠ PT_SS_REST))
  THEN #PF(DS:RCX); FI;

(\* make sure that DS:RCX points to an accessible EPC page \*)

IF ( (EPCM(DS:RCX).PENDING is not 0) or (EPCM(DS:RCS).MODIFIED is not 0) )
  THEN
    RFLAGS.ZF := 1;



Vol. 3D 41-35

EDBGWR—Write to a Debug Enclave

INTEL® SGX INSTRUCTION REFERENCES

```
    RAX := SGX_PAGE_NOT_DEBUGGABLE;
    GOTO DONE;
FI;

(* If destination is a TCS, then make sure that the offset into the page can only point to the FLAGS field*)
IF ( ( EPCM(DS:RCX). PT = PT_TCS) and ((DS:RCX) & FF8H ≠ offset_of_FLAGS & 0FF8H) )
    THEN #GP(0); FI;

(* Locate the SECS for the enclave to which the DS:RCX page belongs *)
TMP_SECS := GET_SECS_PHYS_ADDRESS(EPCM(DS:RCX).ENCLAVESECS);

(* make sure the enclave owning the PT_REG or PT_TCS page allow debug *)
IF (TMP_SECS.ATTRIBUTES.DEBUG = 0)
    THEN #GP(0); FI;

IF ( (TMP_MODE64 = 1) )
    THEN (DS:RCX)[63:0] := RBX[63:0];
    ELSE (DS:RCX)[31:0] := EBX[31:0];
FI;

(* clear EAX and ZF to indicate successful completion *)
RAX := 0;
RFLAGS.ZF := 0;

DONE:
(* clear flags *)
RFLAGS.CF,PF,AF,OF,SF := 0
```

## Flags Affected

ZF is set if the page is MODIFIED or PENDING; RAX contains the error code. Otherwise ZF is cleared and RAX is set to 0. CF, PF, AF, OF, SF are cleared.

## Protected Mode Exceptions

**#GP(0)**:
- If the address in RCS violates DS limit or access rights.
- If DS segment is unusable.
- If RCX points to a memory location not 4Byte-aligned.
- If the address in RCX points to a page belonging to a non-debug enclave.
- If the address in RCX points to a page which is not PT_TCS or PT_REG.
- If the address in RCX points to a location inside TCS that is not the FLAGS word.

**#PF(error code)**:
- If a page fault occurs in accessing memory operands.
- If the address in RCX points to a non-EPC page.
- If the address in RCX points to an invalid EPC page.

## 64-Bit Mode Exceptions

**#GP(0)**:
- If RCX is non-canonical form.
- If RCX points to a memory location not 8Byte-aligned.
- If the address in RCX points to a page belonging to a non-debug enclave.
- If the address in RCX points to a page which is not PT_TCS or PT_REG.
- If the address in RCX points to a location inside TCS that is not the FLAGS word.

41-36 Vol. 3D

EDBGWR—Write to a Debug Enclave

INTEL® SGX INSTRUCTION REFERENCES

#PF(error code) If a page fault occurs in accessing memory operands.
If the address in RCX points to a non-EPC page.
If the address in RCX points to an invalid EPC page.

EDBGWR—Write to a Debug Enclave <page_number>Vol. 3D 41-37</page_number>

INTEL® SGX INSTRUCTION REFERENCES

# EEXTEND—Extend Uninitialized Enclave Measurement by 256 Bytes

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 06H ENCLS[EEXTEND]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function measures 256 bytes of an uninitialized enclave page.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>EBX</th>
        <th>RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EEXTEND (In)</td>
        <td>Effective address of the SECS of the data chunk (In)</td>
        <td>Effective address of a 256-byte chunk in the EPC (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function updates the MRENCLAVE measurement register of an SECS with the measurement of an EXTEND string compromising of “EEXTEND” || ENCLAVEOFFSET || PADDING || 256 bytes of the enclave page. This instruction can only be executed when current privilege level is 0 and the enclave is uninitialized.

RBX contains the effective address of the SECS of the region to be measured. The address must be the same as the one used to add the page into the enclave.

RCX contains the effective address of the 256 byte region of an EPC page to be measured. The DS segment is used to create linear addresses. Segment override is not supported.

## EEXTEND Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>EPC[RCX]</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

## EEXTEND Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>RBX points to an address not 4KBytes aligned.</td>
        <td>RBX does not resolve to an SECS.</td>
    </tr>
    <tr>
        <td>RBX does not point to an SECS page.</td>
        <td>RBX does not point to the SECS page of the data chunk.</td>
    </tr>
    <tr>
        <td>RCX points to an address not 256B aligned.</td>
        <td>RCX points to an unused page or a SECS.</td>
    </tr>
    <tr>
        <td>RCX does not resolve in an EPC page.</td>
        <td>If SECS is locked.</td>
    </tr>
    <tr>
        <td>If the SECS is already initialized.</td>
        <td>May page fault.</td>
    </tr>
    <tr>
        <td colspan="2">CPL &gt; 0.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

### Table 41-22. Base Concurrency Restrictions of EEXTEND

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EEXTEND</td>
        <td>Target [DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECS [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

41-38 Vol. 3D

EEXTEND—Extend Uninitialized Enclave Measurement by 256 Bytes

INTEL® SGX INSTRUCTION REFERENCES

## Table 41-23. Additional Concurrency Restrictions of EEXTEND

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EEXTEND</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECS [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Exclusive</td>
        <td>#GP</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

### Temp Variables in EEXTEND Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SECS</td>
        <td> </td>
        <td>64</td>
        <td>Physical address of SECS of the enclave to which source operand belongs.</td>
    </tr>
    <tr>
        <td>TMP_ENCLAVEOFFSET</td>
        <td>Enclave Offset</td>
        <td>64</td>
        <td>The page displacement from the enclave base address.</td>
    </tr>
    <tr>
        <td>TMPUPDATEFIELD</td>
        <td>SHA256 Buffer</td>
        <td>512</td>
        <td>Buffer used to hold data being added to TMP_SECS.MRENCLAVE.</td>
    </tr>
  </tbody>
</table>

TMP_MODE64 := ((IA32_EFER.LMA = 1) && (CS.L = 1));

IF (DS:RBX is not 4096 Byte Aligned)

  THEN #GP(0); FI;

IF (DS:RBX does not resolve to an EPC page)

  THEN #PF(DS:RBX); FI;

IF (DS:RCX is not 256Byte Aligned)

  THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)

  THEN #PF(DS:RCX); FI;

(\* make sure no other Intel SGX instruction is accessing EPCM \*)

IF (Other instructions accessing EPCM)

  THEN #GP(0); FI;

IF (EPCM(DS:RCX). VALID = 0)

  THEN #PF(DS:RCX); FI;

(\* make sure that DS:RCX (DST) is pointing to a PT_REG or PT_TCS or PT_SS_FIRST or PT_SS_REST \*)

IF ( (EPCM(DS:RCX).PT ≠ PT_REG) and (EPCM(DS:RCX).PT ≠ PT_TCS)
and (EPCM(DS:RCX).PT ≠ PT_SS_FIRST) and (EPCM(DS:RCX).PT ≠ PT_SS_REST))

  THEN #PF(DS:RCX); FI;

TMP_SECS := Get_SECS_ADDRESS();

IF (DS:RBX does not resolve to TMP_SECS)

  THEN #GP(0); FI;

(\* make sure no other instruction is accessing MRENCLAVE or ATTRIBUTES.INIT \*)

IF ( (Other instruction accessing MRENCLAVE) or (Other instructions checking or updating the initialized state of the SECS))

EEXTEND—Extend Uninitialized Enclave Measurement by 256 Bytes
Vol. 3D 41-39

INTEL® SGX INSTRUCTION REFERENCES

THEN #GP(0); FI;

(* Calculate enclave offset *)

TMP_ENCLAVEOFFSET := EPCM(DS:RCX).ENCLAVEADDRESS - TMP_SECS.BASEADDR;

TMP_ENCLAVEOFFSET := TMP_ENCLAVEOFFSET + (DS:RCX & 0FFFH)

(* Add EEXTEND message and offset to MRENCLAVE *)

TMPUPDATEFIELD[63:0] := 00444E4554584545H; // “EEXTEND”

TMPUPDATEFIELD[127:64] := TMP_ENCLAVEOFFSET;

TMPUPDATEFIELD[511:128] := 0; // 48 bytes

TMP_SECS.MRENCLAVE := SHA256UPDATE(TMP_SECS.MRENCLAVE, TMPUPDATEFIELD)

INC enclave’s MRENCLAVE update counter;

(*Add 256 bytes to MRENCLAVE, 64 byte at a time *)

TMP_SECS.MRENCLAVE := SHA256UPDATE(TMP_SECS.MRENCLAVE, DS:RCX[511:0] );

TMP_SECS.MRENCLAVE := SHA256UPDATE(TMP_SECS.MRENCLAVE, DS:RCX[1023: 512] );

TMP_SECS.MRENCLAVE := SHA256UPDATE(TMP_SECS.MRENCLAVE, DS:RCX[1535: 1024] );

TMP_SECS.MRENCLAVE := SHA256UPDATE(TMP_SECS.MRENCLAVE, DS:RCX[2047: 1536] );

INC enclave’s MRENCLAVE update counter by 4;

## Flags Affected

None

## Protected Mode Exceptions

#GP(0)

If the address in RBX is outside the DS segment limit.

If RBX points to an SECS page which is not the SECS of the data chunk.

If the address in RCX is outside the DS segment limit.

If RCX points to a memory location not 256Byte-aligned.

If another instruction is accessing MRENCLAVE.

If another instruction is checking or updating the SECS.

If the enclave is already initialized.

#PF(error code)

If a page fault occurs in accessing memory operands.

If the address in RBX points to a non-EPC page.

If the address in RCX points to a page which is not PT_TCS or PT_REG.

If the address in RCX points to a non-EPC page.

If the address in RCX points to an invalid EPC page.

## 64-Bit Mode Exceptions

#GP(0)

If RBX is non-canonical form.

If RBX points to an SECS page which is not the SECS of the data chunk.

If RCX is non-canonical form.

If RCX points to a memory location not 256 Byte-aligned.

If another instruction is accessing MRENCLAVE.

If another instruction is checking or updating the SECS.

If the enclave is already initialized.

#PF(error code)

If a page fault occurs in accessing memory operands.

If the address in RBX points to a non-EPC page.

If the address in RCX points to a page which is not PT_TCS or PT_REG.

If the address in RCX points to a non-EPC page.

If the address in RCX points to an invalid EPC page.

<page_number>41-40</page_number> Vol. 3D

EEXTEND—Extend Uninitialized Enclave Measurement by 256 Bytes

INTEL® SGX INSTRUCTION REFERENCES

# EINIT—Initialize an Enclave for Execution

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 02H ENCLS[EINIT]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function initializes the enclave and makes it ready to execute enclave code.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th colspan="2">EAX</th>
        <th>RBX</th>
        <th>RCX</th>
        <th>RDX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EINIT (In)</td>
        <td>Error code (Out)</td>
        <td>Address of SIGSTRUCT (In)</td>
        <td>Address of SECS (In)</td>
        <td>Address of EINITTOKEN (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function is the final instruction executed in the enclave build process. After EINIT, the MRENCLAVE measurement is complete, and the enclave is ready to start user code execution using the EENTER instruction.

EINIT takes the effective address of a SIGSTRUCT and EINITTOKEN. The SIGSTRUCT describes the enclave including MRENCLAVE, ATTRIBUTES, ISVSVN, a 3072 bit RSA key, and a signature using the included key. SIGSTRUCT must be populated with two values, q1 and q2. These are calculated using the formulas shown below:

q1 = floor(Signature<sup>2</sup> / Modulus);

q2 = floor((Signature<sup>3</sup> - q1 * Signature * Modulus) / Modulus);

The EINITTOKEN contains the MRENCLAVE, MRSIGNER, and ATTRIBUTES. These values must match the corresponding values in the SECS. If the EINITTOKEN was created with a debug launch key, the enclave must be in debug mode as well.

```mermaid
graph TD
    subgraph SIGSTRUCT
        S1[Signature]
        S2[PubKey]
        S3[ATTRIBUTESATTRIBUTEMASK]
        S4[MRENCLAVE]
    end

    subgraph EINITTOKEN
        T1[MRSIGNER]
        T2[ATTRIBUTESMRENCLAVE]
    end

    subgraph SECS
        SEC1[SECS]
    end

    subgraph ENCLAVE
        E1[ENCLAVE]
        E2[EPC]
    end

    Verify[Verify] --> S1
    S2 --> Hashed[Hashed]
    Hashed --> MRSIGNER_OUT[MRSIGNER]
    S3 --> Check1[Check]
    S4 --> Check1
    Check1 --> MRSIGNER_OUT
    
    DS_RBX[DS:RBX] --> SIGSTRUCT
    DS_RDX[DS:RDX] --> EINITTOKEN
    DS_RCX[DS:RCX] --> SECS
    
    EINIT[EINIT] --> SIGSTRUCT
    EINIT --> EINITTOKEN
    EINIT --> SECS
    
    T1 --> Check2{If VALID=1, Check}
    Check2 --> MRSIGNER_OUT
    
    T2 --> Check3{If VALID=1, Check}
    Check3 --> Copy[Copy]
    
    SEC1 --> Check4[Check]
    Check4 --> Copy
    
    Copy --> ATTR_MREN[ATTRIBUTESMRENCLAVE]
    
    ENCLAVE --> Check4
```

Figure 41-1. Relationships Between SECS, SIGSTRUCT, and EINITTOKEN

EINIT—Initialize an Enclave for Execution

Vol. 3D 41-41

INTEL® SGX INSTRUCTION REFERENCES

## EINIT Memory Parameter Semantics
<table>
  <thead>
    <tr>
        <th>SIGSTRUCT</th>
        <th>SECS</th>
        <th>EINITTOKEN</th>
    </tr>
    <tr>
        <th>Access by non-Enclave</th>
        <th>Read/Write access by Enclave</th>
        <th>Access by non-Enclave</th>
    </tr>
  </thead>
</table>

EINIT performs the following steps, which can be seen in Figure 41-1:

1. Validates that SIGSTRUCT is signed using the enclosed public key.

2. Checks that the completed computation of SECS.MRENCLAVE equals SIGSTRUCT.HASHENCLAVE.

3. Checks that no controlled ATTRIBUTES bits are set in SIGSTRUCT.ATTRIBUTES unless the SHA256 digest of SIGSTRUCT.MODULUS equals IA32_SGX_LEPUBKEYHASH.

4. Checks that the result of bitwise and-ing SIGSTRUCT.ATTRIBUTEMASK with SIGSTRUCT.ATTRIBUTES equals the result of bitwise and-ing SIGSTRUCT.ATTRIBUTEMASK with SECS.ATTRIBUTES.

5. If EINITTOKEN.VALID is 0, checks that the SHA256 digest of SIGSTRUCT.MODULUS equals IA32_SGX_LEPUBKEYHASH.

6. If EINITTOKEN.VALID is 1, checks the validity of EINITTOKEN.

7. If EINITTOKEN.VALID is 1, checks that EINITTOKEN.MRENCLAVE equals SECS.MRENCLAVE.

8. If EINITTOKEN.VALID is 1 and EINITTOKEN.ATTRIBUTES.DEBUG is 1, SECS.ATTRIBUTES.DEBUG must be 1.

9. Commits SECS.MRENCLAVE, and sets SECS.MRSIGNER, SECS.ISVSVN, and SECS.ISVPRODID based on SIGSTRUCT.

10. Update the SECS as Initialized.

Periodically, EINIT polls for certain asynchronous events. If such an event is detected, it completes with failure code (ZF=1 and RAX = SGX_UNMASKED_EVENT), and RIP is incremented to point to the next instruction. These events includes external interrupts, non-maskable interrupts, system-management interrupts, machine checks, INIT signals, and the VMX-preemption timer. EINIT does not fail if the pending event is inhibited (e.g., external interrupts could be inhibited due to blocking by MOV SS blocking or by STI).

The following bits in RFLAGS are cleared: CF, PF, AF, OF, and SF. When the instruction completes with an error, RFLAGS.ZF is set to 1, and the corresponding error bit is set in RAX. If no error occurs, RFLAGS.ZF is cleared and RAX is set to 0.

The error codes are:

Table 41-24. EINIT Return Value in RAX
<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EINIT successful.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_SIG_STRUCT</td>
        <td>If SIGSTRUCT contained an invalid value.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_ATTRIBUTE</td>
        <td>If SIGSTRUCT contains an unauthorized attributes mask.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_MEASUREMENT</td>
        <td>If SIGSTRUCT contains an incorrect measurement.<br/>If EINITTOKEN contains an incorrect measurement.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_SIGNATURE</td>
        <td>If signature does not validate with enclosed public key.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_LICENSE</td>
        <td>If license is invalid.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_CPUSVN</td>
        <td>If license SVN is unsupported.</td>
    </tr>
    <tr>
        <td>SGX_UNMASKED_EVENT</td>
        <td>If an unmasked event is received before the instruction completes its operation.</td>
    </tr>
  </tbody>
</table>

<page_number>41-42</page_number> Vol. 3D EINIT—Initialize an Enclave for Execution

INTEL® SGX INSTRUCTION REFERENCES

## Concurrency Restrictions

Table 41-25. Base Concurrency Restrictions of EINIT

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EINIT</td>
        <td>SECS [DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

Table 41-26. Additional Concurrency Restrictions of ENIT

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EINIT</td>
        <td>SECS [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Exclusive</td>
        <td>#GP</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

### Temp Variables in EINIT Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SIG</td>
        <td>SIGSTRUCT</td>
        <td>1808Bytes</td>
        <td>Temp space for SIGSTRUCT.</td>
    </tr>
    <tr>
        <td>TMP_TOKEN</td>
        <td>EINITTOKEN</td>
        <td>304Bytes</td>
        <td>Temp space for EINITTOKEN.</td>
    </tr>
    <tr>
        <td>TMP_MRENCLAVE</td>
        <td> </td>
        <td>32Bytes</td>
        <td>Temp space for calculating MRENCLAVE.</td>
    </tr>
    <tr>
        <td>TMP_MRSIGNER</td>
        <td> </td>
        <td>32Bytes</td>
        <td>Temp space for calculating MRSIGNER.</td>
    </tr>
    <tr>
        <td>CONTROLLED_ATTRIBUTES</td>
        <td>ATTRIBUTES</td>
        <td>16Bytes</td>
        <td>Constant mask of all ATTRIBUTE bits that can only be set for authorized enclaves.</td>
    </tr>
    <tr>
        <td>TMP_KEYDEPENDENCIES</td>
        <td>Buffer</td>
        <td>224Bytes</td>
        <td>Temp space for key derivation.</td>
    </tr>
    <tr>
        <td>TMP_EINITTOKENKEY</td>
        <td> </td>
        <td>16Bytes</td>
        <td>Temp space for the derived EINITTOKEN Key.</td>
    </tr>
    <tr>
        <td>TMP_SIG_PADDING</td>
        <td>PKCS Padding Buffer</td>
        <td>352Bytes</td>
        <td>The value of the top 352 bytes from the computation of Signature<sup>3</sup> modulo MRSIGNER.</td>
    </tr>
  </tbody>
</table>

(\* make sure SIGSTRUCT and SECS are aligned \*)
IF ( (DS:RBX is not 4KByte Aligned) or (DS:RCX is not 4KByte Aligned) )
    THEN #GP(0); FI;

(\* make sure the EINITTOKEN is aligned \*)
IF (DS:RDX is not 512Byte Aligned)
    THEN #GP(0); FI;

(\* make sure the SECS is inside the EPC \*)
IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

TMP_SIG[14463:0] := DS:RBX[14463:0]; // 1808 bytes
TMP_TOKEN[2423:0] := DS:RDX[2423:0]; // 304 bytes



Vol. 3D 41-43

EINIT—Initialize an Enclave for Execution

INTEL® SGX INSTRUCTION REFERENCES

```
(* Verify SIGSTRUCT Header. *)
IF ( (TMP_SIG.HEADER ≠ 06000000E10000000000010000000000h) or
   ((TMP_SIG.VENDOR ≠ 0) and (TMP_SIG.VENDOR ≠ 00008086h) ) or
   (TMP_SIG HEADER2 ≠ 01010000600000006000000001000000h) or
   (TMP_SIG.EXPONENT ≠ 00000003h) or (Reserved space is not 0’s) )
   THEN
     RFLAGS.ZF := 1;
     RAX := SGX_INVALID_SIG_STRUCT;
     GOTO EXIT;
FI;

(* Open “Event Window” Check for Interrupts. Verify signature using embedded public key, q1, and q2. Save upper 352 bytes of the
PKCS1.5 encoded message into the TMP_SIG_PADDING*)
IF (interrupt was pending) THEN
   RFLAGS.ZF := 1;
   RAX := SGX_UNMASKED_EVENT;
   GOTO EXIT;
FI
IF (signature failed to verify) THEN
   RFLAGS.ZF := 1;
   RAX := SGX_INVALID_SIGNATURE;
   GOTO EXIT;
FI;
(*Close “Event Window” *)

(* make sure no other Intel SGX instruction is modifying SECS*)
IF (Other instructions modifying SECS)
   THEN #GP(0); FI;

IF ( (EPCM(DS:RCX). VALID = 0) or (EPCM(DS:RCX).PT ≠ PT_SECS) )
   THEN #PF(DS:RCX); FI;

(* Verify ISVFAMILYID is not used on an enclave with KSS disabled *)
IF ((TMP_SIG.ISVFAMILYID != 0) AND (DS:RCX.ATTRIBUTES.KSS == 0))
   THEN
    RFLAGS.ZF := 1;
    RAX := SGX_INVALID_SIG_STRUCT;
    GOTO EXIT;
FI;

(* make sure no other instruction is accessing MRENCLAVE or ATTRIBUTES.INIT *)
IF ( (Other instruction modifying MRENCLAVE) or (Other instructions modifying the SECS’s Initialized state))
   THEN #GP(0); FI;

(* Calculate finalized version of MRENCLAVE *)
(* SHA256 algorithm requires one last update that compresses the length of the hashed message into the output SHA256 digest *)
TMP_ENCLAVE := SHA256FINAL( (DS:RCX).MRENCLAVE, enclave’s MRENCLAVE update count *512);

(* Verify MRENCLAVE from SIGSTRUCT *)
IF (TMP_SIG.ENCLAVEHASH ≠ TMP_MRENCLAVE)
   RFLAGS.ZF := 1;
   RAX := SGX_INVALID_MEASUREMENT;
   GOTO EXIT;
FI;
```

<page_number>41-44</page_number> Vol. 3D EINIT—Initialize an Enclave for Execution

INTEL® SGX INSTRUCTION REFERENCES

```
TMP_MRSIGNER := SHA256(TMP_SIG.MODULUS)

(* if controlled ATTRIBUTES are set, SIGSTRUCT must be signed using an authorized key *)
CONTROLLED_ATTRIBUTES := 0000000000000020H;
IF ( ( (DS:RCX.ATTRIBUTES & CONTROLLED_ATTRIBUTES) ≠ 0) and (TMP_MRSIGNER ≠ IA32_SGXLEPUBKEYHASH) )
   RFLAGS.ZF := 1;
   RAX := SGX_INVALID_ATTRIBUTE;
   GOTO EXIT;
FI;

(* Verify SIGSTRUCT.ATTRIBUTE requirements are met *)
IF ( (DS:RCX.ATTRIBUTES & TMP_SIG.ATTRIBUTEMASK) ≠ (TMP_SIG.ATTRIBUTE & TMP_SIG.ATTRIBUTEMASK) )
   RFLAGS.ZF := 1;
   RAX := SGX_INVALID_ATTRIBUTE;
   GOTO EXIT;
FI;

( *Verify SIGSTRUCT.MISCSELECT requirements are met *)
IF ( (DS:RCX.MISCSELECT & TMP_SIG.MISCMASK) ≠ (TMP_SIG.MISCSELECT & TMP_SIG.MISCMASK) )
   THEN
      RFLAGS.ZF := 1;
      RAX := SGX_INVALID_ATTRIBUTE;
      GOTO EXIT
FI;

IF (CPUID.12H.01H:EAX[6] = 1)
   IF ( DS:RCX.CET_ATTRIBUTES & TMP_SIG.CET_ATTRIBUTES_MASK ≠ TMP_SIG.CET_ATTRIBUTES &
   TMP_SIG.CET_ATTRIB-UTES_MASK )
      THEN
         RFLAGS.ZF := 1;
         RAX := SGX_INVALID_ATTRIBUTE;
         GOTO EXIT
   FI;
FI;

(* If EINITTOKEN.VALID[0] is 0, verify the enclave is signed by an authorized key *)
IF (TMP_TOKEN.VALID[0] = 0)
   IF (TMP_MRSIGNER ≠ IA32_SGXLEPUBKEYHASH)
      RFLAGS.ZF := 1;
      RAX := SGX_INVALID_EINITTOKEN;
      GOTO EXIT;
   FI;
   GOTO COMMIT;
FI;

(* Debug Launch Enclave cannot launch Production Enclaves *)
IF ( (DS:RDX.MASKEDATTRIBUTESLE.DEBUG = 1) and (DS:RCX.ATTRIBUTES.DEBUG = 0) )
   RFLAGS.ZF := 1;
   RAX := SGX_INVALID_EINITTOKEN;
   GOTO EXIT;
FI;
```

EINIT—Initialize an Enclave for Execution

Vol. 3D 41-45

INTEL® SGX INSTRUCTION REFERENCES

```
(* Check reserve space in EINIT token includes reserved regions and upper bits in valid field *)
IF (TMP_TOKEN reserved space is not clear)
   RFLAGS.ZF := 1;
   RAX := SGX_INVALID_EINITTOKEN;
   GOTO EXIT;
FI;

(* EINIT token must not have been created by a configuration beyond the current CPU configuration *)
IF (TMP_TOKEN.CPUSVN must not be a configuration beyond CR_CPUSVN)
   RFLAGS.ZF := 1;
   RAX := SGX_INVALID_CPUSVN;
   GOTO EXIT;
FI;

(* Derive Launch key used to calculate EINITTOKEN.MAC *)
HARDCODED_PKCS1_5_PADDING[15:0] := 0100H;
HARDCODED_PKCS1_5_PADDING[2655:16] := SignExtend330Byte(-1); // 330 bytes of 0FFH
HARDCODED_PKCS1_5_PADDING[2815:2656] := 2004000501020403650148866009060D30313000H;

TMP_KEYDEPENDENCIES.KEYNAME := EINITTOKEN_KEY;
TMP_KEYDEPENDENCIES.ISVFAMILYID := 0;
TMP_KEYDEPENDENCIES.ISVEXTPRODID := 0;
TMP_KEYDEPENDENCIES.ISVPRODID := TMP_TOKEN.ISVPRODIDLE;
TMP_KEYDEPENDENCIES.ISVSVN := TMP_TOKEN.ISVSVNLE;
TMP_KEYDEPENDENCIES.SGXOWNEREPOCH := CR_SGXOWNEREPOCH;
TMP_KEYDEPENDENCIES.ATTRIBUTES := TMP_TOKEN.MASKEDATTRIBUTESLE;
TMP_KEYDEPENDENCIES.ATTRIBUTESMASK := 0;
TMP_KEYDEPENDENCIES.MRENCLAVE := 0;
TMP_KEYDEPENDENCIES.MRSIGNER := IA32_SGXLEPUBKEYHASH;
TMP_KEYDEPENDENCIES.KEYID := TMP_TOKEN.KEYID;
TMP_KEYDEPENDENCIES.SEAL_KEY_FUSES := CR_SEAL_FUSES;
TMP_KEYDEPENDENCIES.CPUSVN := TMP_TOKEN.CPUSVNLE;
TMP_KEYDEPENDENCIES.MISCSELECT := TMP_TOKEN.MASKEDMISCSELECTLE;
TMP_KEYDEPENDENCIES.MISCMASK := 0;
TMP_KEYDEPENDENCIES.PADDING := HARDCODED_PKCS1_5_PADDING;
TMP_KEYDEPENDENCIES.KEYPOLICY := 0;
TMP_KEYDEPENDENCIES.CONFIGID := 0;
TMP_KEYDEPENDENCIES.CONFIGSVN := 0;
IF (CPUID.12H.01H:EAX[6] = 1))
   TMP_KEYDEPENDENCIES.CET_ATTRIBUTES := TMP_TOKEN.CET_MASKED_ATTRIBUTES_LE;
   TMP_KEYDEPENDENCIES.CET_ATTRIBUTES_MASK := 0;
FI;

(* Calculate the derived key*)
TMP_EINITTOKENKEY := derivekey(TMP_KEYDEPENDENCIES);

(* Verify EINITTOKEN was generated using this CPU’s Launch key and that it has not been modified since issuing by the Launch
Enclave. Only 192 bytes of EINITTOKEN are CMACed *)
IF (TMP_TOKEN.MAC ≠ CMAC(TMP_EINITTOKENKEY, TMP_TOKEN[1535:0] ) )
   RFLAGS.ZF := 1;
   RAX := SGX_INVALID_EINITTOKEN;
   GOTO EXIT;
FI;
```

<page_number>41-46</page_number> Vol. 3D EINIT—Initialize an Enclave for Execution

INTEL® SGX INSTRUCTION REFERENCES

```
(* Verify EINITTOKEN (RDX) is for this enclave *)
IF ( (TMP_TOKEN.MRENCLAVE ≠ TMP_MRENCLAVE) or (TMP_TOKEN.MRSIGNER ≠ TMP_MRSIGNER) )
    RFLAGS.ZF := 1;
    RAX := SGX_INVALID_MEASUREMENT;
    GOTO EXIT;
FI;

(* Verify ATTRIBUTES in EINITTOKEN are the same as the enclave’s *)
IF (TMP_TOKEN.ATTRIBUTES ≠ DS:RCX.ATTRIBUTES)
    RFLAGS.ZF := 1;
    RAX := SGX_INVALID_EINIT_ATTRIBUTE;
    GOTO EXIT;
FI;
```

COMMIT:

```
(* Commit changes to the SECS; Set ISVPRODID, ISVSVN, MRSIGNER, INIT ATTRIBUTE fields in SECS (RCX) *)
DS:RCX.MRENCLAVE := TMP_MRENCLAVE;
(* MRSIGNER stores a SHA256 in little endian implemented natively on x86 *)
```

DS:RCX.MRSIGNER := TMP_MRSIGNER;

DS:RCX.ISVEXTPRODID := TMP_SIG.ISVEXTPRODID;

DS:RCX.ISVPRODID := TMP_SIG.ISVPRODID;

DS:RCX.ISVSVN := TMP_SIG.ISVSVN;

```
DS:RCX.ISVFAMILYID := TMP_SIG.ISVFAMILYID;
DS:RCX.PADDING := TMP_SIG_PADDING;

(* Mark the SECS as initialized *)
Update DS:RCX to initialized;

(* Set RAX and ZF for success*)
    RFLAGS.ZF := 0;
    RAX := 0;
```

EXIT:

RFLAGS.CF,PF,AF,OF,SF := 0;

## Flags Affected

ZF is cleared if successful, otherwise ZF is set and RAX contains the error code. CF, PF, AF, OF, SF are cleared.

## Protected Mode Exceptions

* **#GP(0)**:
    

    - If a memory operand is not properly aligned.
    

    - If another instruction is modifying the SECS.
    

    - If the enclave is already initialized.
    

    - If the SECS.MRENCLAVE is in use.

* **#PF(error code)**:
    

    - If a page fault occurs in accessing memory operands.
    

    - If RCX does not resolve in an EPC page.
    

    - If the memory address is not a valid, uninitialized SECS.

## 64-Bit Mode Exceptions

* **#GP(0)**:
    

    - If a memory operand is not properly aligned.
    

    - If another instruction is modifying the SECS.
    

    - If the enclave is already initialized.
    

    - If the SECS.MRENCLAVE is in use.

EINIT—Initialize an Enclave for Execution

Vol. 3D 41-47
<page_number>41-47</page_number>

INTEL® SGX INSTRUCTION REFERENCES

**#PF(error code)**
If a page fault occurs in accessing memory operands.
If RCX does not resolve in an EPC page.
If the memory address is not a valid, uninitialized SECS.

41-48 Vol. 3D EINIT—Initialize an Enclave for Execution

INTEL® SGX INSTRUCTION REFERENCES

# ELDB/ELDU—Load an EPC Page and Mark its State

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 07H ENCLS[ELDB]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function loads, verifies an EPC page and marks the page as blocked.</td>
    </tr>
    <tr>
        <td>EAX = 08H ENCLS[ELDU]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function loads, verifies an EPC page and marks the page as unblocked.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th rowspan="2">Op/En</th>
        <th colspan="2">EAX</th>
        <th>RBX</th>
        <th>RCX</th>
        <th>RDX</th>
    </tr>
    <tr>
        <th>ELDB/ELDU (In)</th>
        <th>Return error code (Out)</th>
        <th>Address of the PAGEINFO (In)</th>
        <th>Address of the EPC page (In)</th>
        <th>Address of the version-array slot (In)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>ELDB/ELDU (In)</td>
        <td>Return error code (Out)</td>
        <td>Address of the PAGEINFO (In)</td>
        <td>Address of the EPC page (In)</td>
        <td>Address of the version-array slot (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function copies a page from regular main memory to the EPC. As part of the copying process, the page is cryptographically authenticated and decrypted. This instruction can only be executed when current privilege level is 0.

The ELDB leaf function sets the BLOCK bit in the EPCM entry for the destination page in the EPC after copying. The ELDU leaf function clears the BLOCK bit in the EPCM entry for the destination page in the EPC after copying.

RBX contains the effective address of a PAGEINFO structure; RCX contains the effective address of the destination EPC page; RDX holds the effective address of the version array slot that holds the version of the page.

The table below provides additional information on the memory parameter of ELDB/ELDU leaf functions.

## ELDB/ELDU Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>PAGEINFO</th>
        <th>PAGEINFO.SRCPGE</th>
        <th>PAGEINFO.PCMD</th>
        <th>PAGEINFO.SECS</th>
        <th>EPCPAGE</th>
        <th>Version-Array Slot</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Non-enclave read access</td>
        <td>Non-enclave read access</td>
        <td>Non-enclave read access</td>
        <td>Enclave read/write access</td>
        <td>Read/Write access permitted by Enclave</td>
        <td>Read/Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The error codes are:

Table 41-27. ELDB/ELDU Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>ELDB/ELDU successful.</td>
    </tr>
    <tr>
        <td>SGX_MAC_COMPARE_FAIL</td>
        <td>If the MAC check fails.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

Table 41-28. Base Concurrency Restrictions of ELDB/ELDU

<table>
  <thead><tr><th rowspan="2">Leaf</th><th rowspan="2">Parameter</th><th>Base Concurrency Restrictions</th></tr><tr><th>Access</th><th>On Conflict</th></tr></thead>
  <tbody>
    <tr>
        <td rowspan="3">ELDB/ELDU</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>VA [DS:RDX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECS [DS:RBX]PAGEINFO.SECS</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

ELDB/ELDU—Load an EPC Page and Mark its State

Vol. 3D 41-49

INTEL® SGX INSTRUCTION REFERENCES

Table 41-29. Additional Concurrency Restrictions of ELDB/ELDU

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">ELDB/ELDU</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>VA [DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECS [DS:RBX]PAGEINFO.SECS</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

Temp Variables in ELDB/ELDU Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SRCPGE</td>
        <td>Memory page</td>
        <td>4KBytes</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_SECS</td>
        <td>Memory page</td>
        <td>4KBytes</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_PCMD</td>
        <td>PCMD</td>
        <td>128 Bytes</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_HEADER</td>
        <td>MACHEADER</td>
        <td>128 Bytes</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_VER</td>
        <td>UINT64</td>
        <td>64</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_MAC</td>
        <td>UINT128</td>
        <td>128</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_PK</td>
        <td>UINT128</td>
        <td>128</td>
        <td>Page encryption/MAC key.</td>
    </tr>
    <tr>
        <td>SCRATCH_PCMD</td>
        <td>PCMD</td>
        <td>128 Bytes</td>
        <td> </td>
    </tr>
  </tbody>
</table>

(* Check PAGEINFO and EPCPAGE alignment *)
IF ( (DS:RBX is not 32Byte Aligned) or (DS:RCX is not 4KByte Aligned) )
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

(* Check VASLOT alignment *)
IF (DS:RDX is not 8Byte aligned)
    THEN #GP(0); FI;

IF (DS:RDX does not resolve within an EPC)
    THEN #PF(DS:RDX); FI;

TMP_SRCPGE := DS:RBX.SRCPGE;
TMP_SECS := DS:RBX.SECS;
TMP_PCMD := DS:RBX.PCMD;

(* Check alignment of PAGEINFO (RBX) linked parameters. Note: PCMD pointer is overlaid on top of PAGEINFO.SECINFO field *)
IF ( (DS:TMP_PCMD is not 128Byte aligned) or (DS:TMP_SRCPGE is not 4KByte aligned) )
    THEN #GP(0); FI;

(* Check concurrency of EPC by other Intel SGX instructions *)
IF (other instructions accessing EPC)

41-50 Vol. 3D
<page_number>41-50</page_number>

ELDB/ELDU—Load an EPC Page and Mark its State

INTEL® SGX INSTRUCTION REFERENCES

THEN
    #GP(0); FI;

(* Check concurrency of EPC and VASLOT by other Intel SGX instructions *)
IF (Other instructions modifying VA slot)
    THEN
        #GP(0); FI;

(* Verify EPCM attributes of EPC page, VA, and SECS *)
IF (EPCM(DS:RCX).VALID = 1)
    THEN #PF(DS:RCX); FI;

IF ( (EPCM(DS:RDX & ~0FFFH).VALID = 0) or (EPCM(DS:RDX & ~0FFFH).PT ≠ PT_VA) )
    THEN #PF(DS:RDX); FI;

(* Copy PCMD into scratch buffer *)
SCRATCH_PCMD[1023: 0] := DS:TMP_PCMD[1023:0];

(* Zero out TMP_HEADER*)
TMP_HEADER[sizeof(TMP_HEADER)-1: 0] := 0;

TMP_HEADER.SECINFO := SCRATCH_PCMD.SECINFO;
TMP_HEADER.RSVD := SCRATCH_PCMD.RSVD;
TMP_HEADER.LINADDR := DS:RBX.LINADDR;

(* Verify various attributes of SECS parameter *)
IF ( (TMP_HEADER.SECINFO.FLAGS.PT = PT_REG) or (TMP_HEADER.SECINFO.FLAGS.PT = PT_TCS) or
    (TMP_HEADER.SECINFO.FLAGS.PT = PT_TRIM) or
    (TMP_HEADER.SECINFO.FLAGS.PT = PT_SS_FIRST and CPUID.12H.01H:EAX[6] = 1) or
    (TMP_HEADER.SECINFO.FLAGS.PT = PT_SS_REST and CPUID.12H.01H:EAX[6] = 1))
    THEN
        IF ( DS:TMP_SECS is not 4KByte aligned)
            THEN #GP(0) FI;
        IF (DS:TMP_SECS does not resolve within an EPC)
            THEN #PF(DS:TMP_SECS) FI;
        IF (Another instruction is currently modifying the SECS)
            THEN
                #GP(0); FI;
        TMP_HEADER.EID := DS:TMP_SECS.EID;
    ELSE
        (* TMP_HEADER.SECINFO.FLAGS.PT is PT_SECS or PT_VA which do not have a parent SECS, and hence no EID binding *)
        TMP_HEADER.EID := 0;
        IF (DS:TMP_SECS ≠ 0)
            THEN #GP(0) FI;
FI;

(* Copy 4KBytes SRCPGE to secure location *)
DS:RCX[32767: 0] := DS:TMP_SRCPGE[32767: 0];
TMP_VER := DS:RDX[63:0];

(* Decrypt and MAC page. AES_GCM_DEC has 2 outputs, {plain text, MAC} *)
(* Parameters for AES_GCM_DEC {Key, Counter, ..} *)
{DS:RCX, TMP_MAC} := AES_GCM_DEC(CR_BASE_PK, TMP_VER << 32, TMP_HEADER, 128, DS:RCX, 4096);

ELDB/ELDU—Load an EPC Page and Mark its State <page_number>Vol. 3D 41-51</page_number>

INTEL® SGX INSTRUCTION REFERENCES

```
IF ( (TMP_MAC ≠ DS:TMP_PCMD.MAC) )
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_MAC_COMPARE_FAIL;
        GOTO ERROR_EXIT;
FI;

(* Clear VA Slot *)
DS:RDX := 0

(* Commit EPCM changes *)
EPCM(DS:RCX).PT := TMP_HEADER.SECINFO.FLAGS.PT;
EPCM(DS:RCX).RWX := TMP_HEADER.SECINFO.FLAGS.RWX;
EPCM(DS:RCX).PENDING := TMP_HEADER.SECINFO.FLAGS.PENDING;
EPCM(DS:RCX).MODIFIED := TMP_HEADER.SECINFO.FLAGS.MODIFIED;
EPCM(DS:RCX).PR := TMP_HEADER.SECINFO.FLAGS.PR;
EPCM(DS:RCX).ENCLAVEADDRESS := TMP_HEADER.LINADDR;

IF ( (EAX = 07H) and (TMP_HEADER.SECINFO.FLAGS.PT is NOT PT_SECS or PT_VA) )
    THEN
        EPCM(DS:RCX).BLOCKED := 1;
    ELSE
        EPCM(DS:RCX).BLOCKED := 0;
FI;

EPCM(DS:RCX). VALID := 1;

RAX := 0;
RFLAGS.ZF := 0;

ERROR_EXIT:
RFLAGS.CF,PF,AF,OF,SF := 0;
```

## Flags Affected

Sets ZF if unsuccessful, otherwise cleared and RAX returns error code. Clears CF, PF, AF, OF, SF.

## Protected Mode Exceptions

* **#GP(0)**:
    - If a memory operand effective address is outside the DS segment limit.
    - If a memory operand is not properly aligned.
    - If the instruction’s EPC resource is in use by others.
    - If the instruction fails to verify MAC.
    - If the version-array slot is in use.
    - If the parameters fail consistency checks.
* **#PF(error code)**:
    - If a page fault occurs in accessing memory operands.
    - If a memory operand expected to be in EPC does not resolve to an EPC page.
    - If one of the EPC memory operands has incorrect page type.
    - If the destination EPC page is already valid.

## 64-Bit Mode Exceptions

* **#GP(0)**:
    - If a memory operand is non-canonical form.
    - If a memory operand is not properly aligned.
    - If the instruction’s EPC resource is in use by others.

41-52 Vol. 3D

ELDB/ELDU—Load an EPC Page and Mark its State

INTEL® SGX INSTRUCTION REFERENCES

<table>
  <tbody>
    <tr>
        <td> </td>
        <td>If the instruction fails to verify MAC.</td>
    </tr>
    <tr>
        <td> </td>
        <td>If the version-array slot is in use.</td>
    </tr>
    <tr>
        <td> </td>
        <td>If the parameters fail consistency checks.</td>
    </tr>
    <tr>
        <td>#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
    <tr>
        <td> </td>
        <td>If a memory operand expected to be in EPC does not resolve to an EPC page.</td>
    </tr>
    <tr>
        <td> </td>
        <td>If one of the EPC memory operands has incorrect page type.</td>
    </tr>
    <tr>
        <td> </td>
        <td>If the destination EPC page is already valid.</td>
    </tr>
  </tbody>
</table>

ELDB/ELDU—Load an EPC Page and Mark its State Vol. 3D 41-53

INTEL® SGX INSTRUCTION REFERENCES

# EMODPR—Restrict the Permissions of an EPC Page

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 0EH ENCLS[EMODPR]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX2</td>
        <td>This leaf function restricts the access rights associated with a EPC page in an initialized enclave.</td>
    </tr>
  </tbody>
</table>

### Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th colspan="2">RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EMODPR (In)</td>
        <td>Return Error Code (Out)</td>
        <td>Address of a SECINFO (In)</td>
        <td>Address of the destination EPC page (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function restricts the access rights associated with an EPC page in an initialized enclave. THE RWX bits of the SECINFO parameter are treated as a permissions mask; supplying a value that does not restrict the page permissions will have no effect. This instruction can only be executed when current privilege level is 0.

RBX contains the effective address of a SECINFO structure while RCX contains the effective address of an EPC page. The table below provides additional information on the memory parameter of the EMODPR leaf function.

### EMODPR Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>SECINFO</th>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Non Enclave</td>
        <td>Read/Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

### EMODPR Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>The operands are not properly aligned.</td>
        <td>If unsupported security attributes are set.</td>
    </tr>
    <tr>
        <td>The Enclave is not initialized.</td>
        <td>SECS is locked by another thread.</td>
    </tr>
    <tr>
        <td>The EPC page is locked by another thread.</td>
        <td>RCX does not contain an effective address of an EPC page in the running enclave.</td>
    </tr>
    <tr>
        <td colspan="2">The EPC page is not valid.</td>
    </tr>
  </tbody>
</table>

The error codes are:

### Table 41-30. EMODPR Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EMODPR successful.</td>
    </tr>
    <tr>
        <td>SGX_PAGE_NOT_MODIFIABLE</td>
        <td>The EPC page cannot be modified because it is in the PENDING or MODIFIED state.</td>
    </tr>
    <tr>
        <td>SGX_EPC_PAGE_CONFLICT</td>
        <td>Page is being written by EADD, EAUG, ECREATE, ELDU/B, EMODT, or EWB.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

### Table 41-31. Base Concurrency Restrictions of EMODPR

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EMODPR</td>
        <td>Target [DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

41-54 Vol. 3D
<page_number>41-54</page_number>

EMODPR—Restrict the Permissions of an EPC Page

INTEL® SGX INSTRUCTION REFERENCES

Table 41-32. Additional Concurrency Restrictions of EMODPR

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EMODPR</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>SGX_EP_C_PAGE_CONFLICT</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

Temp Variables in EMODPR Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SECS</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Physical address of SECS to which EPC operand belongs.</td>
    </tr>
    <tr>
        <td>SCRATCH_SECINFO</td>
        <td>SECINFO</td>
        <td>512</td>
        <td>Scratch storage for holding the contents of DS:RBX.</td>
    </tr>
  </tbody>
</table>

```
IF (DS:RBX is not 64Byte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

SCRATCH_SECINFO := DS:RBX;

(* Check for misconfigured SECINFO flags*)
IF ( (SCRATCH_SECINFO reserved fields are not zero ) or
    (SCRATCH_SECINFO.FLAGS.R is 0 and SCRATCH_SECINFO.FLAGS.W is not 0) )
    THEN #GP(0); FI;

(* Check concurrency with SGX1 or SGX2 instructions on the EPC page *)
IF (SGX1 or other SGX2 instructions accessing EPC page)
    THEN #GP(0); FI;

IF (EPCM(DS:RCX).VALID is 0 )
    THEN #PF(DS:RCX); FI;

(* Check the EPC page for concurrency *)
IF (EPC page in use by another SGX2 instruction)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_EPC_PAGE_CONFLICT;
        GOTO DONE;
FI;

IF (EPCM(DS:RCX).PENDING is not 0 or (EPCM(DS:RCX).MODIFIED is not 0) )
    THEN
        RFLAGS.ZF := 1;
```

EMODPR—Restrict the Permissions of an EPC Page

Vol. 3D 41-55

INTEL® SGX INSTRUCTION REFERENCES

```
        RAX := SGX_PAGE_NOT_MODIFIABLE;
        GOTO DONE;
FI;

IF (EPCM(DS:RCX).PT is not PT_REG)
    THEN #PF(DS:RCX); FI;

TMP_SECS := GET_SECS_ADDRESS

IF (TMP_SECS.ATTRIBUTES.INIT = 0)
    THEN #GP(0); FI;

(* Set the PR bit to indicate that permission restriction is in progress *)
EPCM(DS:RCX).PR := 1;

(* Update EPCM permissions *)
EPCM(DS:RCX).R := EPCM(DS:RCX).R & SCRATCH_SECINFO.FLAGS.R;
EPCM(DS:RCX).W := EPCM(DS:RCX).W & SCRATCH_SECINFO.FLAGS.W;
EPCM(DS:RCX).X := EPCM(DS:RCX).X & SCRATCH_SECINFO.FLAGS.X;

RFLAGS.ZF := 0;
RAX := 0;

DONE:
RFLAGS.CF,PF,AF,OF,SF := 0;
```

## Flags Affected

Sets ZF if page is not modifiable or if other SGX2 instructions are executing concurrently, otherwise cleared. Clears CF, PF, AF, OF, SF.

## Protected Mode Exceptions

* **#GP(0)**:
    - If a memory operand effective address is outside the DS segment limit.
    - If a memory operand is not properly aligned.
    - If a memory operand is locked.
* **#PF(error code)**:
    - If a page fault occurs in accessing memory operands.
    - If a memory operand is not an EPC page.

## 64-Bit Mode Exceptions

* **#GP(0)**:
    - If a memory operand is non-canonical form.
    - If a memory operand is not properly aligned.
    - If a memory operand is locked.
* **#PF(error code)**:
    - If a page fault occurs in accessing memory operands.
    - If a memory operand is not an EPC page.

<page_number>41-56</page_number> Vol. 3D

EMODPR—Restrict the Permissions of an EPC Page

INTEL® SGX INSTRUCTION REFERENCES

# EMODT—Change the Type of an EPC Page

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 0FH ENCLS[EMODT]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX2</td>
        <td>This leaf function changes the type of an existing EPC page.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th colspan="2">RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EMODT (In)</td>
        <td>Return Error Code (Out)</td>
        <td>Address of a SECINFO (In)</td>
        <td>Address of the destination EPC page (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function modifies the type of an EPC page. The security attributes are configured to prevent access to the EPC page at its new type until a corresponding invocation of the EACCEPT leaf confirms the modification. This instruction can only be executed when current privilege level is 0.

RBX contains the effective address of a SECINFO structure while RCX contains the effective address of an EPC page. The table below provides additional information on the memory parameter of the EMODT leaf function.

## EMODT Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>SECINFO</th>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Non Enclave</td>
        <td>Read/Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

## EMODT Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>The operands are not properly aligned.</td>
        <td>If unsupported security attributes are set.</td>
    </tr>
    <tr>
        <td>The Enclave is not initialized.</td>
        <td>SECS is locked by another thread.</td>
    </tr>
    <tr>
        <td>The EPC page is locked by another thread.</td>
        <td>RCX does not contain an effective address of an EPC page in the running enclave.</td>
    </tr>
    <tr>
        <td colspan="2">The EPC page is not valid.</td>
    </tr>
  </tbody>
</table>

The error codes are:

## Table 41-33. EMODT Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EMODT successful.</td>
    </tr>
    <tr>
        <td>SGX_PAGE_NOT_MODIFIABLE</td>
        <td>The EPC page cannot be modified because it is in the PENDING or MODIFIED state.</td>
    </tr>
    <tr>
        <td>SGX_EPC_PAGE_CONFLICT</td>
        <td>Page is being written by EADD, EAUG, ECREATE, ELDU/B, EMODPR, or EWB.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

## Table 41-34. Base Concurrency Restrictions of EMODT

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EMODT</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>SGX_EPC_PAGE_CONFLICT</td>
    </tr>
  </tbody>
</table>

EMODT—Change the Type of an EPC Page

<page_number>Vol. 3D 41-57</page_number>

INTEL® SGX INSTRUCTION REFERENCES

## Table 41-35. Additional Concurrency Restrictions of EMODT

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EMODT</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>SGX_EPC_PAGE_CONFLICT</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

### Operation

### Temp Variables in EMODT Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SECS</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Physical address of SECS to which EPC operand belongs.</td>
    </tr>
    <tr>
        <td>SCRATCH_SECINFO</td>
        <td>SECINFO</td>
        <td>512</td>
        <td>Scratch storage for holding the contents of DS:RBX.</td>
    </tr>
  </tbody>
</table>

IF (DS:RBX is not 64Byte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

SCRATCH_SECINFO := DS:RBX;

(\* Check for misconfigured SECINFO flags\*)
IF ( (SCRATCH_SECINFO reserved fields are not zero ) or
    !(SCRATCH_SECINFO.FLAGS.PT is PT_TCS or SCRATCH_SECINFO.FLAGS.PT is PT_TRIM) )
    THEN #GP(0); FI;

(\* Check concurrency with SGX1 instructions on the EPC page \*)
IF (other SGX1 instructions accessing EPC page)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_EPC_PAGE_CONFLICT;
        GOTO DONE;
FI;

IF (EPCM(DS:RCX).VALID is 0)
    THEN #PF(DS:RCX); FI;

(\* Check the EPC page for concurrency \*)
IF (EPC page in use by another SGX2 instruction)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_EPC_PAGE_CONFLICT;
        GOTO DONE;
FI;

<page_number>41-58</page_number> Vol. 3D EMODT—Change the Type of an EPC Page

INTEL® SGX INSTRUCTION REFERENCES

```
IF (!(EPCM(DS:RCX).PT is PT_REG or
    ((EPCM(DS:RCX).PT is PT_TCS or PT_SS_FIRST or PT_SS_REST) and SCRATCH_SECINFO.FLAGS.PT is PT_TRIM)))
        THEN #PF(DS:RCX); FI;
```

```
IF (EPCM(DS:RCX).PENDING is not 0 or (EPCM(DS:RCX).MODIFIED is not 0) )
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_PAGE_NOT_MODIFIABLE;
        GOTO DONE;
FI;
```

TMP_SECS := GET_SECS_ADDRESS

```
IF (TMP_SECS.ATTRIBUTES.INIT = 0)
    THEN #GP(0); FI;
```

```
(* Update EPCM fields *)
EPCM(DS:RCX).PR := 0;
EPCM(DS:RCX).MODIFIED := 1;
EPCM(DS:RCX).R := 0;
EPCM(DS:RCX).W := 0;
EPCM(DS:RCX).X := 0;
EPCM(DS:RCX).PT := SCRATCH_SECINFO.FLAGS.PT;
```

RFLAGS.ZF := 0;
RAX := 0;

DONE:

RFLAGS.CF,PF,AF,OF,SF := 0;

## Flags Affected

Sets ZF if page is not modifiable or if other SGX2 instructions are executing concurrently, otherwise cleared. Clears CF, PF, AF, OF, SF.

## Protected Mode Exceptions

**#GP(0)**: If a memory operand effective address is outside the DS segment limit.

* If a memory operand is not properly aligned.

* If a memory operand is locked.

**#PF(error code)**: If a page fault occurs in accessing memory operands.

* If a memory operand is not an EPC page.

## 64-Bit Mode Exceptions

**#GP(0)**: If a memory operand is non-canonical form.

* If a memory operand is not properly aligned.

* If a memory operand is locked.

**#PF(error code)**: If a page fault occurs in accessing memory operands.

* If a memory operand is not an EPC page.

EMODT—Change the Type of an EPC Page Vol. 3D 41-59

INTEL® SGX INSTRUCTION REFERENCES

# EPA—Add Version Array

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 0AH ENCLS[EPA]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function adds a Version Array to the EPC.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EPA (In)</td>
        <td>PT_VA (In, Constant)</td>
        <td>Effective address of the EPC page (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function creates an empty version array in the EPC page whose logical address is given by DS:RCX, and sets up EPCM attributes for that page. At the time of execution of this instruction, the register RBX must be set to PT_VA.

The table below provides additional information on the memory parameter of EPA leaf function.

## EPA Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

### Table 41-36. Base Concurrency Restrictions of EPA

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EPA</td>
        <td>VA [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

### Table 41-37. Additional Concurrency Restrictions of EPA

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EPA</td>
        <td>VA [DS:RCX]</td>
        <td>Concurrent</td>
        <td>L</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

IF (RBX ≠ PT_VA or DS:RCX is not 4KByte Aligned)
  THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
  THEN #PF(DS:RCX); FI;

(\* Check concurrency with other Intel SGX instructions \*)
IF (Other Intel SGX instructions accessing the page)
  THEN
    #GP(0); FI;

41-60 Vol. 3D
<page_number>41-60</page_number>

EPA—Add Version Array

INTEL® SGX INSTRUCTION REFERENCES

(* Check EPC page must be empty *)

IF (EPCM(DS:RCX). VALID ≠ 0)

    THEN #PF(DS:RCX); FI;

(* Clears EPC page *)

DS:RCX[32767:0] := 0;

EPCM(DS:RCX).PT := PT_VA;
EPCM(DS:RCX).ENCLAVEADDRESS := 0;
EPCM(DS:RCX).BLOCKED := 0;
EPCM(DS:RCX).PENDING := 0;
EPCM(DS:RCX).MODIFIED := 0;
EPCM(DS:RCX).PR := 0;
EPCM(DS:RCX).RWX := 0;
EPCM(DS:RCX).VALID := 1;

## Flags Affected

None

## Protected Mode Exceptions

**#GP(0)**
- If a memory operand effective address is outside the DS segment limit.
- If a memory operand is not properly aligned.
- If another Intel SGX instruction is accessing the EPC page.
- If RBX is not set to PT_VA.

**#PF(error code)**
- If a page fault occurs in accessing memory operands.
- If a memory operand is not an EPC page.
- If the EPC page is valid.

## 64-Bit Mode Exceptions

**#GP(0)**
- If a memory operand is non-canonical form.
- If a memory operand is not properly aligned.
- If another Intel SGX instruction is accessing the EPC page.
- If RBX is not set to PT_VA.

**#PF(error code)**
- If a page fault occurs in accessing memory operands.
- If a memory operand is not an EPC page.
- If the EPC page is valid.

EPA—Add Version Array

Vol. 3D 41-61

INTEL® SGX INSTRUCTION REFERENCES

## EREMOVE—Remove a page from the EPC

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 03H ENCLS[EREMOVE]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function removes a page from the EPC.</td>
    </tr>
  </tbody>
</table>

### Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th colspan="2">RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EREMOVE (In)</td>
        <td>Return error code (Out)</td>
        <td>Effective address of the EPC page (In)</td>
    </tr>
  </tbody>
</table>

### Description

This leaf function causes an EPC page to be un-associated with its SECS and be marked as unused. This instruction leaf can only be executed when the current privilege level is 0.

The content of RCX is an effective address of an EPC page. The DS segment is used to create linear address. Segment override is not supported.

The instruction fails if the operand is not properly aligned or does not refer to an EPC page or the page is in use by another thread, or other threads are running in the enclave to which the page belongs. In addition the instruction fails if the operand refers to an SECS with associations.

### EREMOVE Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

### EREMOVE Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>The memory operand is not properly aligned.</td>
        <td>The memory operand does not resolve in an EPC page.</td>
    </tr>
    <tr>
        <td>Refers to an invalid SECS.</td>
        <td>Refers to an EPC page that is locked by another thread.</td>
    </tr>
    <tr>
        <td>Another Intel SGX instruction is accessing the EPC page.</td>
        <td>RCX does not contain an effective address of an EPC page.</td>
    </tr>
    <tr>
        <td colspan="2">the EPC page refers to an SECS with associations.</td>
    </tr>
  </tbody>
</table>

The error codes are:

### Table 41-38. EREMOVE Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EREMOVE successful.</td>
    </tr>
    <tr>
        <td>SGX_CHILD_PRESENT</td>
        <td>If the SECS still have enclave pages loaded into EPC.</td>
    </tr>
    <tr>
        <td>SGX_ENCLAVE_ACT</td>
        <td>If there are still logical processors executing inside the enclave.</td>
    </tr>
  </tbody>
</table>

41-62 Vol. 3D

EREMOVE—Remove a page from the EPC

INTEL® SGX INSTRUCTION REFERENCES

## Concurrency Restrictions

## Table 41-39. Base Concurrency Restrictions of EREMOVE

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EREMOVE</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

## Table 41-40. Additional Concurrency Restrictions of EREMOVE

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY,<br/>EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EREMOVE</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

## Temp Variables in EREMOVE Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SECS</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Effective address of the SECS destination page.</td>
    </tr>
  </tbody>
</table>

```
IF (DS:RCX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX does not resolve to an EPC page)
    THEN #PF(DS:RCX); FI;

TMP_SECS := Get_SECS_ADDRESS();

(* Check the EPC page for concurrency *)
IF (EPC page being referenced by another Intel SGX instruction)
    THEN
        #GP(0); FI;

(* if DS:RCX is already unused, nothing to do*)
IF ( (EPCM(DS:RCX).VALID = 0) or (EPCM(DS:RCX).PT = PT_TRIM AND EPCM(DS:RCX).MODIFIED = 0))
    THEN GOTO DONE;
FI;

IF ( (EPCM(DS:RCX).PT = PT_VA) OR
    ((EPCM(DS:RCX).PT = PT_TRIM) AND (EPCM(DS:RCX).MODIFIED = 0)) )
    THEN
        EPCM(DS:RCX).VALID := 0;
        GOTO DONE;
FI;

IF (EPCM(DS:RCX).PT = PT_SECS)
    THEN
        IF (DS:RCX has an EPC page associated with it)
            THEN
```

EREMOVE—Remove a page from the EPC <page_number>Vol. 3D 41-63</page_number>

INTEL® SGX INSTRUCTION REFERENCES

```
               RFLAGS.ZF := 1;
               RAX := SGX_CHILD_PRESENT;
               GOTO ERROR_EXIT;
     FI;
     EPCM(DS:RCX).VALID := 0;
     GOTO DONE;
FI;
```

```
IF (Other threads active using SECS)
   THEN
     RFLAGS.ZF := 1;
     RAX := SGX_ENCLAVE_ACT;
     GOTO ERROR_EXIT;
FI;
```

```
IF ( (EPCM(DS:RCX).PT is PT_REG) or (EPCM(DS:RCX).PT is PT_TCS) or (EPCM(DS:RCX).PT is PT_TRIM) or
(EPCM(DS:RCX).PT is PT_SS_FIRST) or (EPCM(DS:RCX).PT is PT_SS_REST))
   THEN
     EPCM(DS:RCX).VALID := 0;
     GOTO DONE;
FI;
```

DONE:

RAX := 0;
RFLAGS.ZF := 0;

ERROR_EXIT:

RFLAGS.CF,PF,AF,OF,SF := 0;

## Flags Affected

Sets ZF if unsuccessful, otherwise cleared and RAX returns error code. Clears CF, PF, AF, OF, SF.

## Protected Mode Exceptions

**#GP(0)** If a memory operand effective address is outside the DS segment limit.

If a memory operand is not properly aligned.

If another Intel SGX instruction is accessing the page.

**#PF(error code)** If a page fault occurs in accessing memory operands.

If the memory operand is not an EPC page.

## 64-Bit Mode Exceptions

**#GP(0)** If the memory operand is non-canonical form.

If a memory operand is not properly aligned.

If another Intel SGX instruction is accessing the page.

**#PF(error code)** If a page fault occurs in accessing memory operands.

If the memory operand is not an EPC page.

<page_number>41-64</page_number> Vol. 3D

EREMOVE—Remove a page from the EPC

INTEL® SGX INSTRUCTION REFERENCES

# ETRACK—Activates EBLOCK Checks

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 0CH ENCLS[ETRACK]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function activates EBLOCK checks.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th colspan="2">RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>ETRACK (In)</td>
        <td>Return error code (Out)</td>
        <td>Pointer to the SECS of the EPC page (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function provides the mechanism for hardware to track that software has completed the required TLB address clears successfully. The instruction can only be executed when the current privilege level is 0.

The content of RCX is an effective address of an EPC page.

The table below provides additional information on the memory parameter of ETRACK leaf function.

## ETRACK Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read/Write access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The error codes are:

## Table 41-41. ETRACK Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>ETRACK successful.</td>
    </tr>
    <tr>
        <td>SGX_PREV_TRK_INCMPL</td>
        <td>All processors did not complete the previous shoot-down sequence.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

## Table 41-42. Base Concurrency Restrictions of ETRACK

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ETRACK</td>
        <td>SECS [DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

## Table 41-43. Additional Concurrency Restrictions of ETRACK

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ETRACK</td>
        <td>SECS [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Exclusive</td>
        <td>SGX_EP- C_PAGE_CON- FLICT</td>
    </tr>
  </tbody>
</table>

ETRACK—Activates EBLOCK Checks <page_number>Vol. 3D 41-65</page_number>

INTEL® SGX INSTRUCTION REFERENCES

## Operation

```
IF (DS:RCX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

(* Check concurrency with other Intel SGX instructions *)
IF (Other Intel SGX instructions using tracking facility on this SECS)
    THEN
        #GP(0); FI;

IF (EPCM(DS:RCX). VALID = 0)
    THEN #PF(DS:RCX); FI;

IF (EPCM(DS:RCX).PT ≠ PT_SECS)
    THEN #PF(DS:RCX); FI;

(* All processors must have completed the previous tracking cycle*)
IF ( (DS:RCX).TRACKING ≠ 0) )
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_PREV_TRK_INCMPL;
        GOTO DONE;
    ELSE
        RAX := 0;
        RFLAGS.ZF := 0;
FI;

DONE:
RFLAGS.CF,PF,AF,OF,SF := 0;
```

## Flags Affected

Sets ZF if SECS is in use or invalid, otherwise cleared. Clears CF, PF, AF, OF, SF.

## Protected Mode Exceptions

**#GP(0)**: If a memory operand effective address is outside the DS segment limit.
If a memory operand is not properly aligned.
If another thread is concurrently using the tracking facility on this SECS.
**#PF(error code)**: If a page fault occurs in accessing memory operands.
If a memory operand is not an EPC page.

## 64-Bit Mode Exceptions

**#GP(0)**: If a memory operand is non-canonical form.
If a memory operand is not properly aligned.
If the specified EPC resource is in use.
**#PF(error code)**: If a page fault occurs in accessing memory operands.
If a memory operand is not an EPC page.

41-66 Vol. 3D

ETRACK—Activates EBLOCK Checks

INTEL® SGX INSTRUCTION REFERENCES

# EUPDATESVN—Update CR_CPUSVN

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 18H ENCLS[EUPDATESVN]</td>
        <td>None</td>
        <td>V/V</td>
        <td>Bit 10</td>
        <td>This leaf function updates the CR_CPUSVN if microcode has been updated and EPC is ready.</td>
    </tr>
  </tbody>
</table>

## Description

If EPC is ready for SVN update, this leaf function updates CR_CPUSVN to the currently loaded microcode update SVN and generates new cryptographic assets. The EPC is ready when no page in the EPC is valid. EREMOVE should be used to mark all pages as unused.

It is the responsibility of system software to ensure that no other thread is executing or attempts to execute any ENCLS leaf while executing EUPDATESVN. Concurrency violations between EUPDATESVN and some ENCLS leaves may cause the ENCLS leaf to generate #GP(0) in ways unexpected to legacy software. System software should also prevent unnecessary software from having access to EUPDATESVN. For example, enable ENCLS exiting should be used to prevent VMs that are not part of the management system software from using EUPDATESVN.

The EUPDATESVN leaf function fails if an ENCLS instruction is in progress on any thread, the EPC is not ready for an update, or there is insufficient entropy in the random number generator. The ZF flag will be set to indicate an error and a code returned in RAX. If EUPDATESVN was successful but CR_CPUSVN was already up to date, the CF flag will be set and RAX will indicate that no update occurred.

If insufficient entropy causes a failure, software should repeat the instruction.

The error codes are:

## Table 41-44. EUPDATESVN Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>0</td>
        <td>EUPDATESVN successful.</td>
    </tr>
    <tr>
        <td>SGX_EPC_PAGE_CONFLICT</td>
        <td>7</td>
        <td>An instruction concurrency rule was violated.</td>
    </tr>
    <tr>
        <td>SGX_INSUFFICIENT_ENTROPY</td>
        <td>29</td>
        <td>RNG contains insufficient entropy.</td>
    </tr>
    <tr>
        <td>SGX_EPC_NOT_READY</td>
        <td>30</td>
        <td>EPC is not ready for SVN update.</td>
    </tr>
    <tr>
        <td>SGX_NO_UPDATE</td>
        <td>31</td>
        <td>EUPDATESVN was successful, but CR_CPUSVN was not updated because the current SVN is older than CR_CPUSVN.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

## Table 41-45. Base Concurrency Restrictions of EUPDATESVN

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EUPDATESVN</td>
        <td>Exclusive</td>
        <td>SGX_EPC_PAGE_CONFLICT</td>
    </tr>
  </tbody>
</table>

## Table 41-46. Additional Concurrency Restrictions of EUPDATESVN

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th colspan="2">Additional Concurrency Restrictions<br/>vs. EADD, EAUG, ECREATE, ELDB, EPA, EREMOVE, EWB</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EUPDATESVN</td>
        <td>Exclusive</td>
        <td>SGX_EPC_PAGE_CONFLICT</td>
    </tr>
  </tbody>
</table>

EUPDATESVN—Update CR_CPUSVN <page_number>Vol. 3D 41-67</page_number>

INTEL® SGX INSTRUCTION REFERENCES

# Operation

## Temp Variables in EUPDATESVN Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_CPUSVN</td>
        <td>CPUSVN</td>
        <td>16</td>
        <td>Temporary copy of CR_CPUSVN prior to update.</td>
    </tr>
    <tr>
        <td>TMP_KEY</td>
        <td>Key</td>
        <td>16</td>
        <td>Temporary copy of new paging key.</td>
    </tr>
  </tbody>
</table>

RFLAGS.ZF,CF,PF,AF,OF,SF := 0;

RAX := 0;

IF (Other logical processor is executing an SGX instruction that accesses EPC) THEN
  RFLAGS.ZF := 1
  RAX := SGX_EPC_PAGE_CONFLICT;
  GOTO ERROR_EXIT;
FI

(\* Verify EPC is ready \*)
IF (the EPC contains any valid pages) THEN
  RFLAGS.ZF := 1;
  RAX := SGX_EPC_NOT_READY;
  GOTO ERROR_EXIT;
FI

(\* Refresh paging key \*)
TMP_KEY = (\* Generate a 128-bit cryptographically random number \*)
IF (insufficient entropy available) THEN
  RFLAGS.ZF := 1;
  RAX := SGX_INSUFFICIENT_ENTROPY;
  GOTO ERROR_EXIT;
FI

(\* Commit \*)
TMP_CPUSVN := CR_CPUSVN;

(\* Update CR_CPUSVN to reflect current microcode update SVN \*)

(\* Determine if info status is needed \*)
IF (TMP_CPUSVN = CR_CPUSVN) THEN
  RFLAGS.CF := 1;
  RAX := SGX_NO_UPDATE;
ELSE
  CR_BASE_PK := TMP_KEY[127:0];
FI

ERROR_EXIT:

# Flags Affected

ZF is set if an error occurs; otherwise, cleared.

CF is set when the instruction is completed successfully and no SVN update was needed.

PF, AF, OF, and SF are cleared.

41-68 Vol. 3D <page_number>41-68</page_number> EUPDATESVN—Update CR_CPUSVN

INTEL® SGX INSTRUCTION REFERENCES

# EWB—Invalidate an EPC Page and Write out to Main Memory

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 0BH ENCLS[EWB]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function invalidates an EPC page and writes it out to main memory.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th colspan="2">EAX</th>
        <th>RBX</th>
        <th>RCX</th>
        <th>RDX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EWB (In)</td>
        <td>Error code (Out)</td>
        <td>Address of an PAGEINFO (In)</td>
        <td>Address of the EPC page (In)</td>
        <td>Address of a VA slot (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function copies a page from the EPC to regular main memory. As part of the copying process, the page is cryptographically protected. This instruction can only be executed when current privilege level is 0.

The table below provides additional information on the memory parameter of EPA leaf function.

## EWB Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>PAGEINFO</th>
        <th>PAGEINFO.SRCPGE</th>
        <th>PAGEINFO.PCMD</th>
        <th>EPCPAGE</th>
        <th>VASLOT</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Non-EPC R/W access</td>
        <td>Non-EPC R/W access</td>
        <td>Non-EPC R/W access</td>
        <td>EPC R/W access</td>
        <td>EPC R/W access</td>
    </tr>
  </tbody>
</table>

The error codes are:

## Table 41-47. EWB Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EWB successful.</td>
    </tr>
    <tr>
        <td>SGX_PAGE_NOT_BLOCKED</td>
        <td>If page is not marked as blocked.</td>
    </tr>
    <tr>
        <td>SGX_NOT_TRACKED</td>
        <td>If EWB is racing with ETRACK instruction.</td>
    </tr>
    <tr>
        <td>SGX_VA_SLOT_OCCUPIED</td>
        <td>Version array slot contained valid entry.</td>
    </tr>
    <tr>
        <td>SGX_CHILD_PRESENT</td>
        <td>Child page present while attempting to page out enclave.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

### Table 41-48. Base Concurrency Restrictions of EWB

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EWB</td>
        <td>Source [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>VA [DS:RDX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

### Table 41-49. Additional Concurrency Restrictions of EWB

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EWB</td>
        <td>Source [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>VA [DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Exclusive</td>
        <td> </td>
    </tr>
  </tbody>
</table>

EWB—Invalidate an EPC Page and Write out to Main Memory Vol. 3D <page_number>41-69</page_number>

INTEL® SGX INSTRUCTION REFERENCES

## Operation

### Temp Variables in EWB Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bytes)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SRCPGE</td>
        <td>Memory page</td>
        <td>4096</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_PCMD</td>
        <td>PCMD</td>
        <td>128</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_SECS</td>
        <td>SECS</td>
        <td>4096</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_BPEPOCH</td>
        <td>UINT64</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_BPREFCOUNT</td>
        <td>UINT64</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_HEADER</td>
        <td>MAC Header</td>
        <td>128</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_PCMD_ENCLAVEID</td>
        <td>UINT64</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_VER</td>
        <td>UINT64</td>
        <td>8</td>
        <td> </td>
    </tr>
    <tr>
        <td>TMP_PK</td>
        <td>UINT128</td>
        <td>16</td>
        <td> </td>
    </tr>
  </tbody>
</table>

IF ( (DS:RBX is not 32Byte Aligned) or (DS:RCX is not 4KByte Aligned) )

  THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)

  THEN #PF(DS:RCX); FI;

IF (DS:RDX is not 8Byte Aligned)

  THEN #GP(0); FI;

IF (DS:RDX does not resolve within an EPC)

  THEN #PF(DS:RDX); FI;

(\* EPCPAGE and VASLOT should not resolve to the same EPC page\*)

IF (DS:RCX and DS:RDX resolve to the same EPC page)

  THEN #GP(0); FI;

TMP_SRCPGE := DS:RBX.SRCPGE;

(\* Note PAGEINFO.PCMD is overlaid on top of PAGEINFO.SECINFO \*)

TMP_PCMD := DS:RBX.PCMD;

If (DS:RBX.LINADDR ≠ 0) OR (DS:RBX.SECS ≠ 0)

  THEN #GP(0); FI;

IF ( (DS:TMP_PCMD is not 128Byte Aligned) or (DS:TMP_SRCPGE is not 4KByte Aligned) )

  THEN #GP(0); FI;

(\* Check for concurrent Intel SGX instruction access to the page \*)

IF (Other Intel SGX instruction is accessing page)

  THEN

    #GP(0); FI;

(\*Check if the VA Page is being removed or changed\*)

IF (VA Page is being modified)

  THEN #GP(0); FI;

41-70 Vol. 3D <page_number>41-70</page_number> EWB—Invalidate an EPC Page and Write out to Main Memory

INTEL® SGX INSTRUCTION REFERENCES

```
(* Verify that EPCPAGE and VASLOT page are valid EPC pages and DS:RDX is VA *)
IF (EPCM(DS:RCX).VALID = 0)
    THEN #PF(DS:RCX); FI;

IF ( (EPCM(DS:RDX & ~0FFFH).VALID = 0) or (EPCM(DS:RDX & ~FFFH).PT is not PT_VA) )
    THEN #PF(DS:RDX); FI;

(* Perform page-type-specific exception checks *)
IF ( (EPCM(DS:RCX).PT is PT_REG) or (EPCM(DS:RCX).PT is PT_TCS) or (EPCM(DS:RCX).PT is PT_TRIM ) or
(EPCM(DS:RCX).PT is PT_SS_FIRST ) or (EPCM(DS:RCX).PT is PT_SS_REST))
    THEN
        TMP_SECS = Obtain SECS through EPCM(DS:RCX)
        (* Check that EBLOCK has occurred correctly *)
        IF (EBLOCK is not correct)
            THEN #GP(0); FI;
FI;

RFLAGS.ZF,CF,PF,AF,OF,SF := 0;
RAX := 0;

(* Zero out TMP_HEADER*)
TMP_HEADER[ sizeof(TMP_HEADER) - 1 : 0] := 0;

(* Perform page-type-specific checks *)
IF ( (EPCM(DS:RCX).PT is PT_REG) or (EPCM(DS:RCX).PT is PT_TCS) or (EPCM(DS:RCX).PT is PT_TRIM )or
(EPCM(DS:RCX).PT is PT_SS_FIRST ) or (EPCM(DS:RCX).PT is PT_SS_REST))
    THEN
        (* check to see if the page is evictable *)
        IF (EPCM(DS:RCX).BLOCKED = 0)
            THEN
                RAX := SGX_PAGE_NOT_BLOCKED;
                RFLAGS.ZF := 1;
                GOTO ERROR_EXIT;
        FI;
        (* Check if tracking done correctly *)
        IF (Tracking not correct)
            THEN
                RAX := SGX_NOT_TRACKED;
                RFLAGS.ZF := 1;
                GOTO ERROR_EXIT;
        FI;

        (* Obtain EID to establish cryptographic binding between the paged-out page and the enclave *)
        TMP_HEADER.EID := TMP_SECS.EID;

        (* Obtain EID as an enclave handle for software *)
        TMP_PCMD_ENCLAVEID := TMP_SECS.EID;
ELSE IF (EPCM(DS:RCX).PT is PT_SECS)
    (*check that there are no child pages inside the enclave *)
    IF (DS:RCX has an EPC page associated with it)
        THEN
            RAX := SGX_CHILD_PRESENT;
            RFLAGS.ZF := 1;
            GOTO ERROR_EXIT;
```

EWB—Invalidate an EPC Page and Write out to Main Memory Vol. 3D 41-71

INTEL® SGX INSTRUCTION REFERENCES

```
    FI:
        TMP_HEADER.EID := 0;
        (* Obtain EID as an enclave handle for software *)
        TMP_PCMD_ENCLAVEID := (DS:RCX).EID;
    ELSE IF (EPCM(DS:RCX).PT is PT_VA)
        TMP_HEADER.EID := 0; // Zero is not a special value
        (* No enclave handle for VA pages*)
        TMP_PCMD_ENCLAVEID := 0;
FI;
```

```
TMP_HEADER.LINADDR := EPCM(DS:RCX).ENCLAVEADDRESS;
TMP_HEADER.SECINFO.FLAGS.PT := EPCM(DS:RCX).PT;
TMP_HEADER.SECINFO.FLAGS.RWX := EPCM(DS:RCX).RWX;
TMP_HEADER.SECINFO.FLAGS.PENDING := EPCM(DS:RCX).PENDING;
TMP_HEADER.SECINFO.FLAGS.MODIFIED := EPCM(DS:RCX).MODIFIED;
TMP_HEADER.SECINFO.FLAGS.PR := EPCM(DS:RCX).PR;
```

```
(* Encrypt the page, DS:RCX could be encrypted in place. AES-GCM produces 2 values, {ciphertext, MAC}. *)
(* AES-GCM input parameters: key, GCM Counter, MAC_HDR, MAC_HDR_SIZE, SRC, SRC_SIZE)*)
{DS:TMP_SRCPGE, DS:TMP_PCMD.MAC} := AES_GCM_ENC(CR_BASE_PK), (TMP_VER << 32),
    TMP_HEADER, 128, DS:RCX, 4096);
```

```
(* Write the output *)
Zero out DS:TMP_PCMD.SECINFO
DS:TMP_PCMD.SECINFO.FLAGS.PT := EPCM(DS:RCX).PT;
DS:TMP_PCMD.SECINFO.FLAGS.RWX := EPCM(DS:RCX).RWX;
DS:TMP_PCMD.SECINFO.FLAGS.PENDING := EPCM(DS:RCX).PENDING;
DS:TMP_PCMD.SECINFO.FLAGS.MODIFIED := EPCM(DS:RCX).MODIFIED;
DS:TMP_PCMD.SECINFO.FLAGS.PR := EPCM(DS:RCX).PR;
DS:TMP_PCMD.RESERVED := 0;
DS:TMP_PCMD.ENCLAVEID := TMP_PCMD_ENCLAVEID;
DS:RBX.LINADDR := EPCM(DS:RCX).ENCLAVEADDRESS;
```

```
(*Check if version array slot was empty *)
IF ([DS.RDX])
    THEN
        RAX := SGX_VA_SLOT_OCCUPIED
        RFLAGS.CF := 1;
FI;
```

```
(* Write version to Version Array slot *)
[DS.RDX] := TMP_VER;
```

```
(* Free up EPCM Entry *)
EPCM.(DS:RCX).VALID := 0;
ERROR_EXIT:
```

### Flags Affected

ZF is set if page is not blocked, not tracked, or a child is present. Otherwise cleared.
CF is set if VA slot is previously occupied, Otherwise cleared.

### Protected Mode Exceptions

**#GP(0)** If a memory operand effective address is outside the DS segment limit.

<page_number>41-72</page_number> Vol. 3D EWB—Invalidate an EPC Page and Write out to Main Memory

INTEL® SGX INSTRUCTION REFERENCES

* 

 If a memory operand is not properly aligned.
* 

 If the EPC page and VASLOT resolve to the same EPC page.
* 

 If another Intel SGX instruction is concurrently accessing either the target EPC, VA, or SECS pages.
* 

 If the tracking resource is in use.
* 

 If the EPC page or the version array page is invalid.
* 

 If the parameters fail consistency checks.
* 

 **#PF(error code)** If a page fault occurs in accessing memory operands.
* 

 If a memory operand is not an EPC page.
* 

 If one of the EPC memory operands has incorrect page type.

## 64-Bit Mode Exceptions

* 

 **#GP(0)** If a memory operand is non-canonical form.
* 

 If a memory operand is not properly aligned.
* 

 If the EPC page and VASLOT resolve to the same EPC page.
* 

 If another Intel SGX instruction is concurrently accessing either the target EPC, VA, or SECS pages.
* 

 If the tracking resource is in use.
* 

 If the EPC page or the version array page in invalid.
* 

 If the parameters fail consistency checks.
* 

 **#PF(error code)** If a page fault occurs in accessing memory operands.
* 

 If a memory operand is not an EPC page.
* 

 If one of the EPC memory operands has incorrect page type.

# 41.4 INTEL® SGX USER LEAF FUNCTION REFERENCE

Leaf functions available with the ENCLU instruction mnemonic are covered in this section. In general, each instruction leaf requires EAX to specify the leaf function index and/or additional registers specifying leaf-specific input parameters. An instruction operand encoding table provides details of the implicitly-encoded register usage and associated input/output semantics.

In many cases, an input parameter specifies an effective address associated with a memory object inside or outside the EPC, the memory addressing semantics of these memory objects are also summarized in a separate table.

EWB—Invalidate an EPC Page and Write out to Main Memory

Vol. 3D 41-73
<page_number>41-73</page_number>

INTEL® SGX INSTRUCTION REFERENCES

# EACCEPT—Accept Changes to an EPC Page

<table>
  <thead>
    <tr>
        <th>Opcode/Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 05H ENCLU[EACCEPT]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX2</td>
        <td>This leaf function accepts changes made by system software to an EPC page in the running enclave.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th colspan="2">RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EACCEPT (In)</td>
        <td>Return Error Code (Out)</td>
        <td>Address of a SECINFO (In)</td>
        <td>Address of the destination EPC page (In)</td>
    </tr>
  </tbody>
</table>

### Description

This leaf function accepts changes to a page in the running enclave by verifying that the security attributes specified in the SECINFO match the security attributes of the page in the EPCM. This instruction leaf can only be executed when inside the enclave.

RBX contains the effective address of a SECINFO structure while RCX contains the effective address of an EPC page. The table below provides additional information on the memory parameter of the EACCEPT leaf function.

### EACCEPT Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>SECINFO</th>
        <th>EPCPAGE (Destination)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Non Enclave</td>
        <td>Read access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

### EACCEPT Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>The operands are not properly aligned.</td>
        <td>RBX does not contain an effective address in an EPC page in the running enclave.</td>
    </tr>
    <tr>
        <td>The EPC page is locked by another thread.</td>
        <td>RCX does not contain an effective address of an EPC page in the running enclave.</td>
    </tr>
    <tr>
        <td>The EPC page is not valid.</td>
        <td>Page type is PT_REG and MODIFIED bit is 0.</td>
    </tr>
    <tr>
        <td>SECINFO contains an invalid request.</td>
        <td>Page type is PT_TCS or PT_TRIM and PENDING bit is 0 and MODIFIED bit is 1.</td>
    </tr>
    <tr>
        <td colspan="2">If security attributes of the SECINFO page make the page inaccessible.</td>
    </tr>
  </tbody>
</table>

The error codes are:

### Table 41-50. EACCEPT Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EACCEPT successful.</td>
    </tr>
    <tr>
        <td>SGX_PAGE_ATTRIBUTES_MISMATCH</td>
        <td>The attributes of the target EPC page do not match the expected values.</td>
    </tr>
    <tr>
        <td>SGX_NOT_TRACKED</td>
        <td>The OS did not complete an ETRACK on the target page.</td>
    </tr>
  </tbody>
</table>

<page_number>41-74</page_number> Vol. 3D

EACCEPT—Accept Changes to an EPC Page

INTEL® SGX INSTRUCTION REFERENCES

## Concurrency Restrictions

### Table 41-51. Base Concurrency Restrictions of EACCEPT

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EACCEPT</td>
        <td>Target [DS:RCX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
    <tr>
        <td>SECINFO [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

### Table 41-52. Additional Concurrency Restrictions of EACCEPT

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EACCEPT</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECINFO [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

### Temp Variables in EACCEPT Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SECS</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Physical address of SECS to which EPC operands belongs.</td>
    </tr>
    <tr>
        <td>SCRATCH_SECINFO</td>
        <td>SECINFO</td>
        <td>512</td>
        <td>Scratch storage for holding the contents of DS:RBX.</td>
    </tr>
  </tbody>
</table>

IF (DS:RBX is not 64Byte Aligned)

  THEN #GP(0); FI;

IF (DS:RBX is not within CR_ELRANGE)

  THEN #GP(0); FI;

IF (DS:RBX does not resolve within an EPC)
  THEN #PF(DS:RBX); FI;

IF ( (EPCM(DS:RBX &~FFFH).VALID = 0) or (EPCM(DS:RBX &~FFFH).R = 0) or (EPCM(DS:RBX &~FFFH).PENDING ≠ 0) or
  (EPCM(DS:RBX &~FFFH).MODIFIED ≠ 0) or (EPCM(DS:RBX &~FFFH).BLOCKED ≠ 0) or
  (EPCM(DS:RBX &~FFFH).PT ≠ PT_REG) or (EPCM(DS:RBX &~FFFH).ENCLAVESECS ≠ CR_ACTIVE_SECS) or
  (EPCM(DS:RBX &~FFFH).ENCLAVEADDRESS ≠ (DS:RBX & FFFH)) )
  THEN #PF(DS:RBX); FI;

(\* Copy 64 bytes of contents \*)
SCRATCH_SECINFO := DS:RBX;

(\* Check for misconfigured SECINFO flags\*)
IF (SCRATCH_SECINFO reserved fields are not zero )
  THEN #GP(0); FI;

IF (DS:RCX is not 4KByte Aligned)

  THEN #GP(0); FI;

EACCEPT—Accept Changes to an EPC Page <page_number>Vol. 3D 41-75</page_number>

INTEL® SGX INSTRUCTION REFERENCES

```
IF (DS:RCX is not within CR_ELRANGE)
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

(* Check that the combination of requested PT, PENDING, and MODIFIED is legal *)
IF (CPUID.12H.01H:EAX[6] = 0 )
    THEN
        IF (NOT (((SCRATCH_SECINFO.FLAGS.PT is PT_REG) and
            ((SCRATCH_SECINFO.FLAGS.PR is 1) or
            (SCRATCH_SECINFO.FLAGS.PENDING is 1)) and
            (SCRATCH_SECINFO.FLAGS.MODIFIED is 0)) or
            ((SCRATCH_SECINFO.FLAGS.PT is PT_TCS or PT_TRIM) and
            (SCRATCH_SECINFO.FLAGS.PR is 0) and
            (SCRATCH_SECINFO.FLAGS.PENDING is 0) and
            (SCRATCH_SECINFO.FLAGS.MODIFIED is 1) )))
            THEN #GP(0); FI
    ELSE
        IF (NOT (((SCRATCH_SECINFO.FLAGS.PT is PT_REG) AND
            ((SCRATCH_SECINFO.FLAGS.PR is 1) OR
            (SCRATCH_SECINFO.FLAGS.PENDING is 1)) AND
            (SCRATCH_SECINFO.FLAGS.MODIFIED is 0)) OR
            ((SCRATCH_SECINFO.FLAGS.PT is PT_TCS OR PT_TRIM) AND
            (SCRATCH_SECINFO.FLAGS.PENDING is 0) AND
            (SCRATCH_SECINFO.FLAGS.MODIFIED is 1) AND
            (SCRATCH_SECINFO.FLAGS.PR is 0)) OR
            ((SCRATCH_SECINFO.FLAGS.PT is PT_SS_FIRST or PT_SS_REST) AND
            (SCRATCH_SECINFO.FLAGS.PENDING is 1) AND
            (SCRATCH_SECINFO.FLAGS.MODIFIED is 0) AND
            (SCRATCH_SECINFO.FLAGS.PR is 0))))
            THEN #GP(0); FI;
FI;

(* Check security attributes of the destination EPC page *)
IF ( (EPCM(DS:RCX).VALID is 0) or (EPCM(DS:RCX).BLOCKED is not 0) or
((EPCM(DS:RCX).PT is not PT_REG) and (EPCM(DS:RCX).PT is not PT_TCS) and (EPCM(DS:RCX).PT is not PT_TRIM)
and (EPCM(DS:RCX).PT is not PT_SS_FIRST) and (EPCM(DS:RCX).PT is not PT_SS_REST)) or
(EPCM(DS:RCX).ENCLAVESECS ≠ CR_ACTIVE_SECS))
    THEN #PF((DS:RCX); FI;

(* Check the destination EPC page for concurrency *)
IF ( EPC page in use )
    THEN #GP(0); FI;

(* Re-Check security attributes of the destination EPC page *)
IF ( (EPCM(DS:RCX).VALID is 0) or (EPCM(DS:RCX).ENCLAVESECS ≠ CR_ACTIVE_SECS) )
    THEN #PF(DS:RCX); FI;

(* Verify that accept request matches current EPC page settings *)
IF ( (EPCM(DS:RCX).ENCLAVEADDRESS ≠ DS:RCX) or (EPCM(DS:RCX).PENDING ≠ SCRATCH_SECINFO.FLAGS.PENDING) or
    (EPCM(DS:RCX).MODIFIED ≠ SCRATCH_SECINFO.FLAGS.MODIFIED) or (EPCM(DS:RCX).R ≠ SCRATCH_SECINFO.FLAGS.R) or
    (EPCM(DS:RCX).W ≠ SCRATCH_SECINFO.FLAGS.W) or (EPCM(DS:RCX).X ≠ SCRATCH_SECINFO.FLAGS.X) or
    (EPCM(DS:RCX).PT ≠ SCRATCH_SECINFO.FLAGS.PT) )
```

<page_number>41-76</page_number> Vol. 3D EACCEPT—Accept Changes to an EPC Page

INTEL® SGX INSTRUCTION REFERENCES

```
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_PAGE_ATTRIBUTES_MISMATCH;
        GOTO DONE;
FI;
(* Check that all required threads have left enclave *)
IF (Tracking not correct)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_NOT_TRACKED;
        GOTO DONE;
FI;

(* Get pointer to the SECS to which the EPC page belongs *)
TMP_SECS = << Obtain physical address of SECS through EPCM(DS:RCX)>>
(* For TCS pages, perform additional checks *)
IF (SCRATCH_SECINFO.FLAGS.PT = PT_TCS)
    THEN
        IF (DS:RCX.RESERVED ≠ 0) #GP(0); FI;

    (* Check that TCS.FLAGS.DBGOPTIN, TCS stack, and TCS status are correctly initialized *)
    (* check that TCS.PREVSSP is 0 *)
IF ( ((DS:RCX).FLAGS.DBGOPTIN is not 0) or ((DS:RCX).CSSA ≥ (DS:RCX).NSSA) or ((DS:RCX).AEP is not 0) or ((DS:RCX).STATE is not 0) or
((CPUID.07H.00H:ECX.CET_SS = 1) AND ((DS:RCX).PREVSSP != 0)))
        THEN #GP(0); FI;

    (* Check consistency of FS & GS Limit *)
    IF ( (TMP_SECS.ATTRIBUTES.MODE64BIT is 0) and ((DS:RCX.FSLIMIT & FFFH ≠ FFFH) or (DS:RCX.GSLIMIT & FFFH ≠ FFFH)) )
        THEN #GP(0); FI;
FI;

(* Clear PENDING/MODIFIED flags to mark accept operation complete *)
EPCM(DS:RCX).PENDING := 0;
EPCM(DS:RCX).MODIFIED := 0;
EPCM(DS:RCX).PR := 0;

(* Clear EAX and ZF to indicate successful completion *)
RFLAGS.ZF := 0;
RAX := 0;

DONE:
RFLAGS.CF,PF,AF,OF,SF := 0;
```

### Flags Affected

Sets ZF if page cannot be accepted, otherwise cleared. Clears CF, PF, AF, OF, SF

EACCEPT—Accept Changes to an EPC Page

Vol. 3D 41-77

INTEL® SGX INSTRUCTION REFERENCES

## Protected Mode Exceptions

**#GP(0)**
* If executed outside an enclave.
* If a memory operand effective address is outside the DS segment limit.
* If a memory operand is not properly aligned.
* If a memory operand is locked.

**#PF(error code)**
* If a page fault occurs in accessing memory operands.
* If a memory operand is not an EPC page.
* If EPC page has incorrect page type or security attributes.

## 64-Bit Mode Exceptions

**#GP(0)**
* If executed outside an enclave.
* If a memory operand is non-canonical form.
* If a memory operand is not properly aligned.
* If a memory operand is locked.

**#PF(error code)**
* If a page fault occurs in accessing memory operands.
* If a memory operand is not an EPC page.
* If EPC page has incorrect page type or security attributes.

<page_number>41-78</page_number> Vol. 3D

EACCEPT—Accept Changes to an EPC Page

INTEL® SGX INSTRUCTION REFERENCES

# EACCEPTCOPY—Initialize a Pending Page

<table>
  <thead>
    <tr>
        <th>Opcode/<br/>Instruction</th>
        <th>Op/En</th>
        <th>64/32<br/>bit Mode<br/>Support</th>
        <th>CPUID<br/>Feature<br/>Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 07H<br/>ENCLU[EACCEPTCOPY]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX2</td>
        <td>This leaf function initializes a dynamically allocated EPC page from another page in the EPC.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
        <th colspan="2">RDX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EACCEPTCOPY (In)</td>
        <td>Return Error Code<br/>(Out)</td>
        <td>Address of a SECINFO (In)</td>
        <td>Address of the destina-<br/>tion EPC page (In)</td>
        <td>Address of the<br/>source EPC page (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function copies the contents of an existing EPC page into an uninitialized EPC page (created by EAUG). After initialization, the instruction may also modify the access rights associated with the destination EPC page. This instruction leaf can only be executed when inside the enclave.

RBX contains the effective address of a SECINFO structure while RCX and RDX each contain the effective address of an EPC page. The table below provides additional information on the memory parameter of the EACCEPTCOPY leaf function.

## EACCEPTCOPY Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>SECINFO</th>
        <th>EPCPAGE (Destination)</th>
        <th>EPCPAGE (Source)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Non Enclave</td>
        <td>Read/Write access permitted by Enclave</td>
        <td>Read access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

## EACCEPTCOPY Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>The operands are not properly aligned.</td>
        <td>If security attributes of the SECINFO page make the page inaccessible.</td>
    </tr>
    <tr>
        <td>The EPC page is locked by another thread.</td>
        <td>If security attributes of the source EPC page make the page inaccessible.</td>
    </tr>
    <tr>
        <td>The EPC page is not valid.</td>
        <td>RBX does not contain an effective address in an EPC page in the running enclave.</td>
    </tr>
    <tr>
        <td>SECINFO contains an invalid request.</td>
        <td>RCX/RDX does not contain an effective address of an EPC page in the running enclave.</td>
    </tr>
  </tbody>
</table>

The error codes are:

### Table 41-53. EACCEPTCOPY Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>EACCEPTCOPY successful.</td>
    </tr>
    <tr>
        <td>SGX_PAGE_ATTRIBUTES_MISMATCH</td>
        <td>The attributes of the target EPC page do not match the expected values.</td>
    </tr>
  </tbody>
</table>

EACCEPTCOPY—Initialize a Pending Page <page_number>Vol. 3D 41-79</page_number>

INTEL® SGX INSTRUCTION REFERENCES

## Concurrency Restrictions

Table 41-54. Base Concurrency Restrictions of EACCEPTCOPY

<table>
  <thead><tr><th rowspan="2">Leaf</th><th rowspan="2">Parameter</th><th>Base Concurrency Restrictions</th></tr><tr><th>Access</th><th>On Conflict</th></tr></thead>
  <tbody>
    <tr>
        <td rowspan="3">EACCEPTCOPY</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>Source [DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECINFO [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

Table 41-55. Additional Concurrency Restrictions of EACCEPTCOPY

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">EACCEPTCOPY</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>Source [DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECINFO [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

Temp Variables in EACCEPTCOPY Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>SCRATCH_SECINFO</td>
        <td>SECINFO</td>
        <td>512</td>
        <td>Scratch storage for holding the contents of DS:RBX.</td>
    </tr>
  </tbody>
</table>

IF (DS:RBX is not 64Byte Aligned)
  THEN #GP(0); FI;

IF ( (DS:RCX is not 4KByte Aligned) or (DS:RDX is not 4KByte Aligned) )
  THEN #GP(0); FI;

IF ((DS:RBX is not within CR_ELRANGE) or (DS:RCX is not within CR_ELRANGE) or (DS:RDX is not within CR_ELRANGE))
  THEN #GP(0); FI;

IF (DS:RBX does not resolve within an EPC)
  THEN #PF(DS:RBX); FI;

IF (DS:RCX does not resolve within an EPC)
  THEN #PF(DS:RCX); FI;

IF (DS:RDX does not resolve within an EPC)
  THEN #PF(DS:RDX); FI;

IF ( (EPCM(DS:RBX &~FFFH).VALID = 0) or (EPCM(DS:RBX &~FFFH).R = 0) or (EPCM(DS:RBX &~FFFH).PENDING ≠ 0) or
  (EPCM(DS:RBX &~FFFH).MODIFIED ≠ 0) or (EPCM(DS:RBX &~FFFH).BLOCKED ≠ 0) or (EPCM(DS:RBX &~FFFH).PT ≠ PT_REG) or
  (EPCM(DS:RBX &~FFFH).ENCLAVESECS ≠ CR_ACTIVE_SECS) or
  (EPCM(DS:RBX &~FFFH).ENCLAVEADDRESS ≠ DS:RBX) )
  THEN #PF(DS:RBX); FI;

41-80 Vol. 3D

EACCEPTCOPY—Initialize a Pending Page

INTEL® SGX INSTRUCTION REFERENCES

```
(* Copy 64 bytes of contents *)
SCRATCH_SECINFO := DS:RBX;

(* Check for misconfigured SECINFO flags*)
IF ( (SCRATCH_SECINFO reserved fields are not zero ) or (SCRATCH_SECINFO.FLAGS.R=0) AND(SCRATCH_SECINFO.FLAGS.W≠0 ) or
   (SCRATCH_SECINFO.FLAGS.PT is not PT_REG) )
   THEN #GP(0); FI;

(* Check security attributes of the source EPC page *)
IF ( (EPCM(DS:RDX).VALID = 0) or (EPCM(DS:RCX).R = 0) or (EPCM(DS:RDX).PENDING ≠ 0) or (EPCM(DS:RDX).MODIFIED ≠ 0) or
   (EPCM(DS:RDX).BLOCKED ≠ 0) or (EPCM(DS:RDX).PT ≠ PT_REG) or (EPCM(DS:RDX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or
   (EPCM(DS:RDX).ENCLAVEADDRESS ≠ DS:RDX))
   THEN #PF(DS:RDX); FI;

(* Check security attributes of the destination EPC page *)
IF ( (EPCM(DS:RCX).VALID = 0) or (EPCM(DS:RCX).PENDING ≠ 1) or (EPCM(DS:RCX).MODIFIED ≠ 0) or
   (EPCM(DS:RDX).BLOCKED ≠ 0) or (EPCM(DS:RCX).PT ≠ PT_REG) or (EPCM(DS:RCX).ENCLAVESECS ≠ CR_ACTIVE_SECS) )
   THEN
     RFLAGS.ZF := 1;
     RAX := SGX_PAGE_ATTRIBUTES_MISMATCH;
     GOTO DONE;
FI;

(* Check the destination EPC page for concurrency *)
IF (destination EPC page in use )
   THEN #GP(0); FI;

(* Re-Check security attributes of the destination EPC page *)
IF ( (EPCM(DS:RCX).VALID = 0) or (EPCM(DS:RCX).PENDING ≠ 1) or (EPCM(DS:RCX).MODIFIED ≠ 0) or
   (EPCM(DS:RCX).R ≠ 1) or (EPCM(DS:RCX).W ≠ 1) or (EPCM(DS:RCX).X ≠ 0) or
   (EPCM(DS:RCX).PT ≠ SCRATCH_SECINFO.FLAGS.PT) or (EPCM(DS:RCX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or
   (EPCM(DS:RCX).ENCLAVEADDRESS ≠ DS:RCX))
   THEN
     RFLAGS.ZF := 1;
     RAX := SGX_PAGE_ATTRIBUTES_MISMATCH;
     GOTO DONE;
FI;

(* Copy 4KBbytes form the source to destination EPC page*)
DS:RCX[32767:0] := DS:RDX[32767:0];

(* Update EPCM permissions *)
EPCM(DS:RCX).R := SCRATCH_SECINFO.FLAGS.R;
EPCM(DS:RCX).W := SCRATCH_SECINFO.FLAGS.W;
EPCM(DS:RCX).X := SCRATCH_SECINFO.FLAGS.X;
EPCM(DS:RCX).PENDING := 0;

RFLAGS.ZF := 0;
RAX := 0;

DONE:
RFLAGS.CF,PF,AF,OF,SF := 0;
```

EACCEPTCOPY—Initialize a Pending Page

Vol. 3D 41-81

INTEL® SGX INSTRUCTION REFERENCES

## Flags Affected

Sets ZF if page is not modifiable, otherwise cleared. Clears CF, PF, AF, OF, SF.

## Protected Mode Exceptions

<table>
    <tr>
        <td>#GP(0)</td>
        <td>If executed outside an enclave.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand effective address is outside the DS segment limit.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is not properly aligned.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is locked.</td>
    </tr>
    <tr>
        <td>#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is not an EPC page.</td>
    </tr>
    <tr>
        <td></td>
        <td>If EPC page has incorrect page type or security attributes.</td>
    </tr>
</table>

## 64-Bit Mode Exceptions

<table>
    <tr>
        <td>#GP(0)</td>
        <td>If executed outside an enclave.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is non-canonical form.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is not properly aligned.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is locked.</td>
    </tr>
    <tr>
        <td>#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
    <tr>
        <td></td>
        <td>If a memory operand is not an EPC page.</td>
    </tr>
    <tr>
        <td></td>
        <td>If EPC page has incorrect page type or security attributes.</td>
    </tr>
</table>

41-82 Vol. 3D <page_number>41-82</page_number> EACCEPTCOPY—Initialize a Pending Page

INTEL® SGX INSTRUCTION REFERENCES

# EDECCSSA—Decrements TCS.CSSA

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 09H ENCLU[EDECCSSA]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>EDECCSSA</td>
        <td>This leaf function decrements TCS.CSSA.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EDECCSSA (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function changes the current SSA frame by decrementing TCS.CSSA for the current enclave thread. If the enclave has enabled CET shadow stacks or indirect branch tracking, then EDECCSSA also changes the current CET state save frame. This instruction leaf can only be executed inside an enclave.

## EDECCSSA Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>TCS</th>
    </tr>
    <tr>
        <th>Read/Write access by Enclave</th>
    </tr>
  </thead>
</table>

The instruction faults if any of the following:

## EDECCSSA Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>TCS.CSSA is 0.</td>
        <td>TCS is not valid or available or locked.</td>
    </tr>
    <tr>
        <td colspan="2">The SSA frame is not valid or in use.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

### Table 41-56. Base Concurrency Restrictions of EDECCSSA

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EDECCSSA</td>
        <td>TCS [CR_TCS_PA]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

### Table 41-57. Additional Concurrency Restrictions of EDECCSSA

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EDECCSSA</td>
        <td>TCS [CR_TCS_PA]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

EDECCSSA—Decrements TCS.CSSA

Vol. 3D 41-83
<page_number>41-83</page_number>

INTEL® SGX INSTRUCTION REFERENCES

# Operation

## Temp Variables in EDECCSSA Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_SSA</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of current SSA frame.</td>
    </tr>
    <tr>
        <td>TMP_XSIZE</td>
        <td>Integer</td>
        <td>64</td>
        <td>Size of XSAVE area based on SECS.ATTRIBUTES.XFRM.</td>
    </tr>
    <tr>
        <td>TMP_SSA_PAGE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Pointer used to iterate over the SSA pages in the target frame.</td>
    </tr>
    <tr>
        <td>TMP_GPR</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of the GPR area within the target SSA frame.</td>
    </tr>
    <tr>
        <td>TMP_XSAVE_PAGE_PA_n</td>
        <td>Physical Address</td>
        <td>32/64</td>
        <td>Physical address of the nth page within the target SSA frame.</td>
    </tr>
    <tr>
        <td>TMP_CET_SAVE_AREA</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of the current CET save area.</td>
    </tr>
    <tr>
        <td>TMP_CET_SAVE_PAGE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of the current CET save area page.</td>
    </tr>
  </tbody>
</table>

(\* Check concurrency of TCS operation \*)
IF (Other Intel SGX instructions are operating on TCS)
  THEN #GP(0); FI;

IF (CR_TCS_PA.CSSA = 0)
  THEN #GP(0); FI;

(\* Compute linear address of SSA frame \*)
TMP_SSA := CR_TCS_PA.OSSA + CR_ACTIVE_SECS.BASEADDR + 4096 * CR_ACTIVE_SECS.SSAFRAMESIZE * (CR_TCS_PA.CSSA - 1);
TMP_XSIZE := compute_XSAVE_frame_size(CR_ACTIVE_SECS.ATTRIBUTES.XFRM);

FOR EACH TMP_SSA_PAGE = TMP_SSA to TMP_SSA + TMP_XSIZE
  (\* Check page is read/write accessible \*)
  Check that DS:TMP_SSA_PAGE is read/write accessible;
  If a fault occurs, release locks, abort and deliver that fault;
  IF (DS:TMP_SSA_PAGE does not resolve to EPC page)
    THEN #PF(DS:TMP_SSA_PAGE); FI;
  IF (EPCM(DS:TMP_SSA_PAGE).VALID = 0)
    THEN #PF(DS:TMP_SSA_PAGE); FI;
  IF (EPCM(DS:TMP_SSA_PAGE).BLOCKED = 1)
    THEN #PF(DS:TMP_SSA_PAGE); FI;
  IF ((EPCM(DS:TMP_SSA_PAGE).PENDING = 1) or (EPCM(DS:TMP_SSA_PAGE_.MODIFIED = 1))
    THEN #PF(DS:TMP_SSA_PAGE); FI;
  IF ( ( EPCM(DS:TMP_SSA_PAGE).ENCLAVEADDRESS ≠ DS:TMPSSA_PAGE) or
  (EPCM(DS:TMP_SSA_PAGE).PT ≠ PT_REG) or
  (EPCM(DS:TMP_SSA_PAGE).ENCLAVESECS ≠ EPCM(CR_TCS_PA).ENCLAVESECS) or
  (EPCM(DS:TMP_SSA_PAGE).R = 0) or (EPCM(DS:TMP_SSA_PAGE).W = 0))
    THEN #PF(DS:TMP_SSA_PAGE); FI;
  TMP_XSAVE_PAGE_PA_n := Physical_Address(DS:TMP_SSA_PAGE);
ENDFOR

(\* Compute address of GPR area\*)
TMP_GPR := TMP_SSA + 4096 * CR_ACTIVE_SECS.SSAFRAMESIZE - sizeof(GPRSGX_AREA);

<page_number>41-84</page_number> Vol. 3D

EDECCSSA—Decrements TCS.CSSA

INTEL® SGX INSTRUCTION REFERENCES

Check that DS:TMP_SSA_PAGE is read/write accessible;
If a fault occurs, release locks, abort and deliver that fault;
IF (DS:TMP_GPR does not resolve to EPC page)
    THEN #PF(DS:TMP_GPR); FI;
IF (EPCM(DS:TMP_GPR).VALID = 0)
    THEN #PF(DS:TMP_GPR); FI;
IF (EPCM(DS:TMP_GPR).BLOCKED = 1)
    THEN #PF(DS:TMP_GPR); FI;
IF ((EPCM(DS:TMP_GPR).PENDING = 1) or (EPCM(DS:TMP_GPR).MODIFIED = 1))
    THEN #PF(DS:TMP_GPR); FI;
IF ( ( EPCM(DS:TMP_GPR).ENCLAVEADDRESS ≠ DS:TMP_GPR) or
    (EPCM(DS:TMP_GPR).PT ≠ PT_REG) or
    (EPCM(DS:TMP_GPR).ENCLAVESECS ≠ EPCM(CR_TCS_PA).ENCLAVESECS) or
    (EPCM(DS:TMP_GPR).R = 0) or (EPCM(DS:TMP_GPR).W = 0) )
    THEN #PF(DS:TMP_GPR); FI;

IF (TMP_MODE64 = 0)
    THEN
        IF (TMP_GPR + (sizeof(GPRSGX_AREA) -1) is not in DS segment)
            THEN #GP(0); FI;
FI;

IF (CPUID.12H.01H:EAX[6] = 1)
    THEN
        IF ((CR_ACTIVE_SECS.CET_ATTRIBUTES.SH_STK_EN == 1) OR (CR_ACTIVE_SECS.CET_ATTRIBUTES.ENDBR_EN == 1))
            THEN
                (\* Compute linear address of what will become new CET state save area and cache its PA \*)
                TMP_CET_SAVE_AREA := CR_TCS_PA.OCETSSA + CR_ACTIVE_SECS.BASEADDR + (CR_TCS_PA.CSSA - 1) * 16;
                TMP_CET_SAVE_PAGE := TMP_CET_SAVE_AREA & ~0xFFF;
                Check the TMP_CET_SAVE_PAGE page is read/write accessible
                If fault occurs release locks, abort and deliver fault

                (\* read the EPCM VALID, PENDING, MODIFIED, BLOCKED and PT fields atomically \*)
                IF ((DS:TMP_CET_SAVE_PAGE Does NOT RESOLVE TO EPC PAGE) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).VALID = 0) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).PENDING = 1) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).MODIFIED = 1) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).BLOCKED = 1) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).R = 0) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).W = 0) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).ENCLAVEADDRESS ≠ DS:TMP_CET_SAVE_PAGE) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).PT ≠ PT_SS_REST) OR
                (EPCM(DS:TMP_CET_SAVE_PAGE).ENCLAVESECS ≠ EPCM(CR_TCS_PA).ENCLAVESECS))
                THEN #PF(DS:TMP_CET_SAVE_PAGE); FI;
        FI;
FI;

(\* At this point, the instruction is guaranteed to complete \*)
CR_TCS_PA.CSSA := CR_TCS_PA.CSSA - 1;

CR_GPR_PA := Physical_Address(DS:TMP_GPR);

FOR EACH TMP_XSAVE_PAGE_n
    CR_XSAVE_PAGE_n := TMP_XSAVE_PAGE_PA_n;

EDECCSSA—Decrements TCS.CSSA Vol. 3D 41-85

INTEL® SGX INSTRUCTION REFERENCES

ENDFOR

```
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN
        IF ((TMP_SECS.CET_ATTRIBUTES.SH_STK_EN == 1) OR
        (TMP_SECS.CET_ATTRIBUTES.ENDBR_EN == 1))
            THEN
                CR_CET_SAVE_AREA_PA := Physical_Address(DS:TMP_CET_SAVE_AREA);
        FI;
FI;
```

## Flags Affected

None

## Protected Mode Exceptions

**#GP(0)** If executed outside an enclave.
If CR_TCS_PA.CSSA = 0.
**#PF(error code)** If a page fault occurs in accessing memory.
If one or more pages of the target SSA frame are not readable/writable, or do not resolve to a valid PT_REG EPC page.
If CET is enabled for the enclave and the target CET SSA frame is not readable/writable, or does not resolve to a valid PT_REG EPC page.

## 64-Bit Mode Exceptions

**#GP(0)** If executed outside an enclave.
If CR_TCS_PA.CSSA = 0.
**#PF(error code)** If a page fault occurs in accessing memory.
If one or more pages of the target SSA frame are not readable/writable, or do not resolve to a valid PT_REG EPC page.
If CET is enabled for the enclave and the target CET SSA frame is not readable/writable, or does not resolve to a valid PT_REG EPC page.

41-86 Vol. 3D

EDECCSSA—Decrements TCS.CSSA

INTEL® SGX INSTRUCTION REFERENCES

# EENTER—Enters an Enclave

<table>
  <thead>
    <tr>
        <th>Opcode/Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 02H<br/>ENCLU[EENTER]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function is used to enter an enclave.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
    <tr>
        <th rowspan="2">IR</th>
        <th>EENTER (In)</th>
        <th>Address of a TCS (In)</th>
        <th>Address of AEP (In)</th>
    </tr>
    <tr>
        <th>Content of RBX.CSSA (Out)</th>
        <th> </th>
        <th>Address of IP following EENTER (Out)</th>
    </tr>
  </thead>
</table>

## Description

The ENCLU[EENTER] instruction transfers execution to an enclave. At the end of the instruction, the logical processor is executing in enclave mode at the RIP computed as EnclaveBase + TCS.OENTRY. If the target address is not within the CS segment (32-bit) or is not canonical (64-bit), a #GP(0) results.

## EENTER Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>TCS</th>
    </tr>
    <tr>
        <th>Enclave access</th>
    </tr>
  </thead>
</table>

EENTER is a serializing instruction. The instruction faults if any of the following occurs:

<table>
  <tbody>
    <tr>
        <td>Address in RBX is not properly aligned.</td>
        <td>Any TCS.FLAGS’s must-be-zero bit is not zero.</td>
    </tr>
    <tr>
        <td>TCS pointed to by RBX is not valid or available or locked.</td>
        <td>Current 32/64 mode does not match the enclave mode in SECS.ATTRIBUTES.MODE64.</td>
    </tr>
    <tr>
        <td>The SECS is in use.</td>
        <td>Either of TCS-specified FS and GS segment is not a subsets of the current DS segment.</td>
    </tr>
    <tr>
        <td>Any one of DS, ES, CS, SS is not zero.</td>
        <td>If XSAVE available, CR4.OSXSAVE = 0, but SECS.ATTRIBUTES.XFRM ≠ 3.</td>
    </tr>
    <tr>
        <td>CR4.OSFXSR ≠ 1.</td>
        <td>If CR4.OSXSAVE = 1, SECS.ATTRIBUTES.XFRM is not a subset of XCR0.</td>
    </tr>
    <tr>
        <td colspan="2">If SECS.ATTRIBUTES.AEXNOTIFY ≠ TCS.FLAGS.AEXNOTIFY and TCS.FLAGS.DBGOPTIN = 0.</td>
    </tr>
  </tbody>
</table>

The following operations are performed by EENTER:

* RSP and RBP are saved in the current SSA frame on EENTER and are automatically restored on EEXIT or interrupt.

* The AEP contained in RCX is stored into the TCS for use by AEXs. FS and GS (including hidden portions) are saved and new values are constructed using TCS.OFSBASE/GSBASE (32 and 64-bit mode) and TCS.OFSLIMIT/GSLIMIT (32-bit mode only). The resulting segments must be a subset of the DS segment.

* If CR4.OSXSAVE == 1, XCR0 is saved and replaced by SECS.ATTRIBUTES.XFRM. The effect of RFLAGS.TF depends on whether the enclave entry is opt-in or opt-out (see Section 43.1.2):

    - On opt-out entry, TF is saved and cleared (it is restored on EEXIT or AEX). Any attempt to set TF via a POPF instruction while inside the enclave clears TF (see Section 43.2.5).

    - On opt-in entry, a single-step debug exception is pended on the instruction boundary immediately after EENTER (see Section 43.2.2).

EENTER—Enters an Enclave

<page_number>Vol. 3D 41-87</page_number>

INTEL® SGX INSTRUCTION REFERENCES

* All code breakpoints that do not overlap with ELRANGE are also suppressed. If the entry is an opt-out entry, all code and data breakpoints that overlap with the ELRANGE are suppressed.

* On opt-out entry, a number of performance monitoring counters and behaviors are modified or suppressed (see Section 43.2.3):

  — All performance monitoring activity on the current thread is suppressed except for incrementing and firing of FIXED_CTR1 and FIXED_CTR2.

  — PEBS is suppressed.

  — AnyThread counting on other threads is demoted to MyThread mode and IA32_PERF_GLOBAL_STATUS[60] on that thread is set

  — If the opt-out entry on a hardware thread results in suppression of any performance monitoring, then the processor sets IA32_PERF_GLOBAL_STATUS[60] and IA32_PERF_GLOBAL_STATUS[63].

## Concurrency Restrictions

Table 41-58. Base Concurrency Restrictions of EENTER

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EENTER</td>
        <td>TCS [DS:RBX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

Table 41-59. Additional Concurrency Restrictions of EENTER

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EENTER</td>
        <td>TCS [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

Temp Variables in EENTER Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_FSBASE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Proposed base address for FS segment.</td>
    </tr>
    <tr>
        <td>TMP_GSBASE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Proposed base address for FS segment.</td>
    </tr>
    <tr>
        <td>TMP_FSLIMIT</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Highest legal address in proposed FS segment.</td>
    </tr>
    <tr>
        <td>TMP_GSLIMIT</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Highest legal address in proposed GS segment.</td>
    </tr>
    <tr>
        <td>TMP_XSIZE</td>
        <td>integer</td>
        <td>64</td>
        <td>Size of XSAVE area based on SECS.ATTRIBUTES.XFRM.</td>
    </tr>
    <tr>
        <td>TMP_SSA_PAGE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Pointer used to iterate over the SSA pages in the current frame.</td>
    </tr>
    <tr>
        <td>TMP_GPR</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of the GPR area within the current SSA frame.</td>
    </tr>
  </tbody>
</table>

```
TMP_MODE64 := ((IA32_EFER.LMA = 1) && (CS.L = 1));

(* Make sure DS is usable, expand up *)
IF (TMP_MODE64 = 0 and (DS not usable or DS[bits 11:9] != 001B))
    THEN #GP(0); FI;

(* Check that CS, SS, DS, ES.base is 0 *)
IF (TMP_MODE64 = 0)
    THEN
```

<page_number>41-88</page_number> Vol. 3D

EENTER—Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

```
    IF(CS.base ≠ 0 or DS.base ≠ 0) #GP(0); FI;
    IF(ES usable and ES.base ≠ 0) #GP(0); FI;
    IF(SS usable and SS.base ≠ 0) #GP(0); FI;
    IF(SS usable and SS.B = 0) #GP(0); FI;
FI;

IF (DS:RBX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RBX does not resolve within an EPC)
    THEN #PF(DS:RBX); FI;

(* Check AEP is canonical*)
IF (TMP_MODE64 = 1 and (CS:RCX is not canonical) )
    THEN #GP(0); FI;

(* Check concurrency of TCS operation*)
IF (Other Intel SGX instructions are operating on TCS)
    THEN #GP(0); FI;

(* TCS verification *)
IF (EPCM(DS:RBX).VALID = 0)
    THEN #PF(DS:RBX); FI;

IF (EPCM(DS:RBX).BLOCKED = 1)
    THEN #PF(DS:RBX); FI;

IF ( (EPCM(DS:RBX).ENCLAVEADDRESS ≠ DS:RBX) or (EPCM(DS:RBX).PT ≠ PT_TCS) )
    THEN #PF(DS:RBX); FI;

IF ((EPCM(DS:RBX).PENDING = 1) or (EPCM(DS:RBX).MODIFIED = 1))
    THEN #PF(DS:RBX); FI;

IF ( (DS:RBX).OSSA is not 4KByte Aligned)
    THEN #GP(0); FI;

(* Check proposed FS and GS *)
IF ( ( (DS:RBX).OFSBASE is not 4KByte Aligned) or ( (DS:RBX).OGSBASE is not 4KByte Aligned) )
    THEN #GP(0); FI;

(* Get the SECS for the enclave in which the TCS resides *)
TMP_SECS := Address of SECS for TCS;

(* Ensure that the FLAGS field in the TCS does not have any reserved bits set *)
IF ( ( (DS:RBX).FLAGS & FFFFFFFFFFFFFFFCH) ≠ 0)
    THEN #GP(0); FI;

(* SECS must exist and enclave must have previously been EINITted *)
IF (the enclave is not already initialized)
    THEN #GP(0); FI;

(* make sure the logical processor’s operating mode matches the enclave *)
IF ( (TMP_MODE64 ≠ TMP_SECS.ATTRIBUTES.MODE64BIT) )
    THEN #GP(0); FI;
```

EENTER—Enters an Enclave Vol. 3D 41-89

INTEL® SGX INSTRUCTION REFERENCES

IF (CR4.OSFXSR = 0)
    THEN #GP(0); FI;

(\* Check for legal values of SECS.ATTRIBUTES.XFRM \*)
IF (CR4.OSXSAVE = 0)
    THEN
        IF (TMP_SECS.ATTRIBUTES.XFRM ≠ 03H) THEN #GP(0); FI;
    ELSE
        IF ( (TMP_SECS.ATTRIBUTES.XFRM & XCR0) ≠ TMP_SECS.ATTRIBUES.XFRM) THEN #GP(0); FI;
FI;

IF ((DS:RBX).CSSA.FLAGS.DBGOPTIN = 0) and (DS:RBX).CSSA.FLAGS.AEXNOTIFY ≠ TMP_SECS.ATTRIBUTES.AEXNOTIFY))
    THEN #GP(0); FI;

(\* Make sure the SSA contains at least one more frame \*)
IF ( (DS:RBX).CSSA ≥ (DS:RBX).NSSA)
    THEN #GP(0); FI;

(\* Compute linear address of SSA frame \*)
TMP_SSA := (DS:RBX).OSSA + TMP_SECS.BASEADDR + 4096 \* TMP_SECS.SSAFRAMESIZE \* (DS:RBX).CSSA;
TMP_XSIZE := compute_XSAVE_frame_size(TMP_SECS.ATTRIBUTES.XFRM);

FOR EACH TMP_SSA_PAGE = TMP_SSA to TMP_SSA + TMP_XSIZE
    (\* Check page is read/write accessible \*)
    Check that DS:TMP_SSA_PAGE is read/write accessible;
    If a fault occurs, release locks, abort, and deliver that fault;

    IF (DS:TMP_SSA_PAGE does not resolve to EPC page)
        THEN #PF(DS:TMP_SSA_PAGE); FI;
    IF (EPCM(DS:TMP_SSA_PAGE).VALID = 0)
        THEN #PF(DS:TMP_SSA_PAGE); FI;
    IF (EPCM(DS:TMP_SSA_PAGE).BLOCKED = 1)
        THEN #PF(DS:TMP_SSA_PAGE); FI;
    IF ((EPCM(DS:TMP_SSA_PAGE).PENDING = 1) or (EPCM(DS:TMP_SSA_PAGE).MODIFIED = 1))
        THEN #PF(DS:TMP_SSA_PAGE); FI;
    IF ( ( EPCM(DS:TMP_SSA_PAGE).ENCLAVEADDRESS ≠ DS:TMP_SSA_PAGE) or (EPCM(DS:TMP_SSA_PAGE).PT ≠ PT_REG) or
        (EPCM(DS:TMP_SSA_PAGE).ENCLAVESECS ≠ EPCM(DS:RBX).ENCLAVESECS) or
        (EPCM(DS:TMP_SSA_PAGE).R = 0) or (EPCM(DS:TMP_SSA_PAGE).W = 0) )
        THEN #PF(DS:TMP_SSA_PAGE); FI;
    CR_XSAVE_PAGE_n := Physical_Address(DS:TMP_SSA_PAGE);
ENDFOR

(\* Compute address of GPR area\*)
TMP_GPR := TMP_SSA + 4096 \* DS:TMP_SECS.SSAFRAMESIZE - sizeof(GPRSGX_AREA);
If a fault occurs; release locks, abort, and deliver that fault;

IF (DS:TMP_GPR does not resolve to EPC page)
    THEN #PF(DS:TMP_GPR); FI;
IF (EPCM(DS:TMP_GPR).VALID = 0)
    THEN #PF(DS:TMP_GPR); FI;
IF (EPCM(DS:TMP_GPR).BLOCKED = 1)
    THEN #PF(DS:TMP_GPR); FI;
IF ((EPCM(DS:TMP_GPR).PENDING = 1) or (EPCM(DS:TMP_GPR).MODIFIED = 1))
    THEN #PF(DS:TMP_GPR); FI;

41-90 Vol. 3D EENTER—Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

```
IF ( ( EPCM(DS:TMP_GPR).ENCLAVEADDRESS ≠ DS:TMP_GPR) or (EPCM(DS:TMP_GPR).PT ≠ PT_REG) or
   (EPCM(DS:TMP_GPR).ENCLAVESECS ≠ EPCM(DS:RBX).ENCLAVESECS) or
   (EPCM(DS:TMP_GPR).R = 0) or (EPCM(DS:TMP_GPR).W = 0) )
   THEN #PF(DS:TMP_GPR); FI;

IF (TMP_MODE64 = 0)
   THEN
    IF (TMP_GPR + (GPR_SIZE -1) is not in DS segment) THEN #GP(0); FI;
FI;

CR_GPR_PA := Physical_Address (DS: TMP_GPR);

(* Validate TCS.OENTRY *)
TMP_TARGET := (DS:RBX).OENTRY + TMP_SECS.BASEADDR;
IF (TMP_MODE64 = 1)
   THEN
    IF (TMP_TARGET is not canonical) THEN #GP(0); FI;
   ELSE
    IF (TMP_TARGET > CS limit) THEN #GP(0); FI;
FI;

(* Check proposed FS/GS segments fall within DS *)
IF (TMP_MODE64 = 0)
   THEN
    TMP_FSBASE := (DS:RBX).OFSBASE + TMP_SECS.BASEADDR;
    TMP_FSLIMIT := (DS:RBX).OFSBASE + TMP_SECS.BASEADDR + (DS:RBX).FSLIMIT;
    TMP_GSBASE := (DS:RBX).OGSBASE + TMP_SECS.BASEADDR;
    TMP_GSLIMIT := (DS:RBX).OGSBASE + TMP_SECS.BASEADDR + (DS:RBX).GSLIMIT;
    (* if FS wrap-around, make sure DS has no holes*)
    IF (TMP_FSLIMIT < TMP_FSBASE)
        THEN
        IF (DS.limit < 4GB) THEN #GP(0); FI;
        ELSE
        IF (TMP_FSLIMIT > DS.limit) THEN #GP(0); FI;
    FI;
    (* if GS wrap-around, make sure DS has no holes*)
    IF (TMP_GSLIMIT < TMP_GSBASE)
        THEN
        IF (DS.limit < 4GB) THEN #GP(0); FI;
        ELSE
        IF (TMP_GSLIMIT > DS.limit) THEN #GP(0); FI;
    FI;
   ELSE
    TMP_FSBASE := (DS:RBX).OFSBASE + TMP_SECS.BASEADDR;
    TMP_GSBASE := (DS:RBX).OGSBASE + TMP_SECS.BASEADDR;
    IF ( (TMP_FSBASE is not canonical) or (TMP_GSBASE is not canonical))
        THEN #GP(0); FI;
FI;

(* Ensure the enclave is not already active and this thread is the only one using the TCS*)
IF (DS:RBX.STATE = ACTIVE)
   THEN #GP(0); FI;

TMP_IA32_U_CET := 0
```

EENTER—Enters an Enclave

Vol. 3D 41-91

INTEL® SGX INSTRUCTION REFERENCES

TMP_SSP := 0

IF CPUID.12H.01H:EAX[6] = 1
    THEN
        IF ( CR4.CET = 0 )
            THEN
                (\* If part does not support CET or CET has not been enabled and enclave requires CET then fail \*)
                IF ( TMP_SECS.CET_ATTRIBUTES ≠ 0 OR TMP_SECS.CET_LEG_BITMAP_OFFSET ≠ 0 ) #GP(0); FI;
        FI;
        (\* If indirect branch tracking or shadow stacks enabled but CET state save area is not 16B aligned then fail EENTER \*)
        IF ( TMP_SECS.CET_ATTRIBUTES.SH_STK_EN = 1 OR TMP_SECS.CET_ATTRIBUTES.ENDBR_EN = 1 )
            THEN
                IF (DS:RBX.OCETSSA is not 16B aligned) #GP(0); FI;
        FI;

IF (TMP_SECS.CET_ATTRIBUTES.SH_STK_EN OR TMP_SECS.CET_ATTRIBUTES.ENDBR_EN)
    THEN
        (\* Setup CET state from SECS, note tracker goes to IDLE \*)
        TMP_IA32_U_CET = TMP_SECS.CET_ATTRIBUTES;
        IF (TMP_IA32_U_CET.LEG_IW_EN = 1 AND TMP_IA32_U_CET.ENDBR_EN = 1 )
            THEN
                TMP_IA32_U_CET := TMP_IA32_U_CET + TMP_SECS.BASEADDR;
                TMP_IA32_U_CET := TMP_IA32_U_CET + TMP_SECS.CET_LEG_BITMAP_BASE;
        FI;

        (\* Compute linear address of what will become new CET state save area and cache its PA \*)
        TMP_CET_SAVE_AREA = DS:RBX.OCETSSA + TMP_SECS.BASEADDR + (DS:RBX.CSSA) * 16
        TMP_CET_SAVE_PAGE = TMP_CET_SAVE_AREA & ~0xFFF;

        Check the TMP_CET_SAVE_PAGE page is read/write accessible
        If fault occurs release locks, abort, and deliver fault

        (\* Read the EPCM VALID, PENDING, MODIFIED, BLOCKED, and PT fields atomically \*)
        IF ((DS:TMP_CET_SAVE_PAGE Does NOT RESOLVE TO EPC PAGE) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).VALID = 0) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).PENDING = 1) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).MODIFIED = 1) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).BLOCKED = 1) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).R = 0) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).W = 0) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).ENCLAVEADDRESS ≠ DS:TMP_CET_SAVE_PAGE) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).PT ≠ PT_SS_REST) OR
        (EPCM(DS:TMP_CET_SAVE_PAGE).ENCLAVESECS ≠ EPCM(DS:RBX).ENCLAVESECS))
            THEN
                #PF(DS:TMP_CET_SAVE_PAGE);
        FI;

        CR_CET_SAVE_AREA_PA := Physical address(DS:TMP_CET_SAVE_AREA)

        IF TMP_IA32_U_CET.SH_STK_EN = 1
            THEN
                TMP_SSP = TCS.PREVSSP;
        FI;
FI;

<page_number>41-92</page_number> Vol. 3D

EENTER—Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

FI;

CR_ENCLAVE_MODE := 1;
CR_ACTIVE_SECS := TMP_SECS;
CR_ELRANGE := (TMPSECS.BASEADDR, TMP_SECS.SIZE);

(\* Save state for possible AEXs \*)
CR_TCS_PA := Physical_Address (DS:RBX);
CR_TCS_LA := RBX;
CR_TCS_LA.AEP := RCX;

(\* Save the hidden portions of FS and GS \*)
CR_SAVE_FS_selector := FS.selector;
CR_SAVE_FS_base := FS.base;
CR_SAVE_FS_limit := FS.limit;
CR_SAVE_FS_access_rights := FS.access_rights;
CR_SAVE_GS_selector := GS.selector;
CR_SAVE_GS_base := GS.base;
CR_SAVE_GS_limit := GS.limit;
CR_SAVE_GS_access_rights := GS.access_rights;

(\* If XSAVE is enabled, save XCR0 and replace it with SECS.ATTRIBUTES.XFRM\*)
IF (CR4.OSXSAVE = 1)
   CR_SAVE_XCR0 := XCR0;
   XCR0 := TMP_SECS.ATTRIBUTES.XFRM;
FI;

RCX := RIP;
RIP := TMP_TARGET;
RAX := (DS:RBX).CSSA;
(\* Save the outside RSP and RBP so they can be restored on interrupt or EEXIT \*)
DS:TMP_SSA.U_RSP := RSP;
DS:TMP_SSA.U_RBP := RBP;

(\* Do the FS/GS swap \*)
FS.base := TMP_FSBASE;
FS.limit := DS:RBX.FSLIMIT;
FS.type := 0001b;
FS.W := DS[bit 9];
FS.S := 1;
FS.DPL := DS.DPL;
FS.G := 1;
FS.B := 1;
FS.P := 1;
FS.AVL := DS.AVL;
FS.L := DS[bit 21];
FS.unusable := 0;
FS.selector := 0BH;

GS.base := TMP_GSBASE;
GS.limit := DS:RBX.GSLIMIT;
GS.type := 0001b;
GS.W := DS[bit 9];
GS.S := 1;

EENTER—Enters an Enclave <page_number>Vol. 3D 41-93</page_number>

# INTEL® SGX INSTRUCTION REFERENCES

```
GS.DPL := DS.DPL;
GS.G := 1;
GS.B := 1;
GS.P := 1;
GS.AVL := DS.AVL;
GS.L := DS[bit 21];
GS.unusable := 0;
GS.selector := 0BH;

CR_DBGOPTIN := TCS.FLAGS.DBGOPTIN;
Suppress_all_code_breakpoints_that_are_outside_ELRANGE;

IF (CR_DBGOPTIN = 0)
    THEN
        Suppress_all_code_breakpoints_that_overlap_with_ELRANGE;
        CR_SAVE_TF := RFLAGS.TF;
        RFLAGS.TF := 0;
        Suppress_monitor_trap_flag for the source of the execution of the enclave;
        Suppress any pending debug exceptions;
        Suppress any pending MTF VM exit;
    ELSE
        IF RFLAGS.TF = 1
            THEN pend a single-step #DB at the end of EENTER; FI;
        IF the “monitor trap flag” VM-execution control is set
            THEN pend an MTF VM exit at the end of EENTER; FI;
FI;

IF ((CPUID.07H.00H:EDX.CET_IBT = 1) OR (CPUID.07H.00H:ECX.CET_SS = 1)
    THEN
        (* Save enclosing application CET state into save registers *)
        CR_SAVE_IA32_U_CET := IA32_U_CET
        (* Setup enclave CET state *)
IF CPUID.07H.00H:ECX.CET_SS = 1
    THEN
        CR_SAVE_SSP := SSP
        SSP := TMP_SSP
    FI;

    IA32_U_CET := TMP_IA32_U_CET;

FI;

Flush_linear_context;
Allow_front_end_to_begin_fetch_at_new_RIP;
```

## Flags Affected

RFLAGS.TF is cleared on opt-out entry.

<page_number>41-94</page_number> Vol. 3D

EENTER—Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

## Protected Mode Exceptions

#GP(0) If DS:RBX is not page aligned.

If the enclave is not initialized.

If part or all of the FS or GS segment specified by TCS is outside the DS segment or not properly aligned.

If the thread is not in the INACTIVE state.

If CS, DS, ES or SS bases are not all zero.

If executed in enclave mode.

If any reserved field in the TCS FLAG is set.

If the target address is not within the CS segment.

If CR4.OSFXSR = 0.

If CR4.OSXSAVE = 0 and SECS.ATTRIBUTES.XFRM ≠ 3.

If CR4.OSXSAVE = 1 and SECS.ATTRIBUTES.XFRM is not a subset of XCR0.

If SECS.ATTRIBUTES.AEXNOTIFY ≠ TCS.FLAGS.AEXNOTIFY and TCS.FLAGS.DBGOPTIN = 0.

#PF(error code) If a page fault occurs in accessing memory.

If DS:RBX does not point to a valid TCS.

If one or more pages of the current SSA frame are not readable/writable, or do not resolve to a valid PT_REG EPC page.

## 64-Bit Mode Exceptions

#GP(0) If DS:RBX is not page aligned.

If the enclave is not initialized.

If the thread is not in the INACTIVE state.

If CS, DS, ES or SS bases are not all zero.

If executed in enclave mode.

If part or all of the FS or GS segment specified by TCS is outside the DS segment or not properly aligned.

If the target address is not canonical.

If CR4.OSFXSR = 0.

If CR4.OSXSAVE = 0 and SECS.ATTRIBUTES.XFRM ≠ 3.

If CR4.OSXSAVE = 1 and SECS.ATTRIBUTES.XFRM is not a subset of XCR0.

If SECS.ATTRIBUTES.AEXNOTIFY ≠ TCS.FLAGS.AEXNOTIFY and TCS.FLAGS.DBGOPTIN = 0.

#PF(error code) If a page fault occurs in accessing memory operands.

If DS:RBX does not point to a valid TCS.

If one or more pages of the current SSA frame are not readable/writable, or do not resolve to a valid PT_REG EPC page.

EENTER—Enters an Enclave

Vol. 3D 41-95

INTEL® SGX INSTRUCTION REFERENCES

# EEXIT—Exits an Enclave

<table>
  <thead>
    <tr>
        <th>Opcode/<br/>Instruction</th>
        <th>Op/En</th>
        <th>64/32<br/>bit Mode<br/>Support</th>
        <th>CPUID<br/>Feature<br/>Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 04H<br/>ENCLU[EEXIT]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function is used to exit an enclave.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EEXIT (In)</td>
        <td>Target address outside the enclave (In)</td>
        <td>Address of the current AEP (Out)</td>
    </tr>
  </tbody>
</table>

## Description

The ENCLU[EEXIT] instruction exits the currently executing enclave and branches to the location specified in RBX. RCX receives the current AEP. If RBX is not within the CS (32-bit mode) or is not canonical (64-bit mode) a #GP(0) results.

## EEXIT Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>Target Address</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Non-Enclave read and execute access</td>
    </tr>
  </tbody>
</table>

If RBX specifies an address that is inside the enclave, the instruction will complete normally. The fetch of the next instruction will occur in non-enclave mode, but will attempt to fetch from inside the enclave. This fetch returns a fixed data pattern.

If secrets are contained in any registers, it is responsibility of enclave software to clear those registers.

If XCR0 was modified on enclave entry, it is restored to the value it had at the time of the most recent EENTER or ERESUME.

If the enclave is opt-out, RFLAGS.TF is loaded from the value previously saved on EENTER.

Code and data breakpoints are unsuppressed.

Performance monitoring counters are unsuppressed.

## Concurrency Restrictions

Table 41-60. Base Concurrency Restrictions of EEXIT

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EEXIT</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

Table 41-61. Additional Concurrency Restrictions of EEXIT

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY,<br/>EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EEXIT</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

<page_number>41-96</page_number> Vol. 3D

EEXIT—Exits an Enclave

INTEL® SGX INSTRUCTION REFERENCES

# Operation

## Temp Variables in EEXIT Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_RIP</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Saved copy of CRIP for use when creating LBR.</td>
    </tr>
  </tbody>
</table>

TMP_MODE64 := ((IA32_EFER.LMA = 1) && (CS.L = 1));

```
IF (TMP_MODE64 = 1)
    THEN
        IF (RBX is not canonical) THEN #GP(0); FI;
    ELSE
        IF (RBX > CS limit) THEN #GP(0); FI;
FI;
```

TMP_RIP := CRIP;
RIP := RBX;

(\* Return current AEP in RCX \*)
RCX := CR_TCS_PA.AEP;

(\* Do the FS/GS swap \*)

FS.selector := CR_SAVE_FS.selector;

FS.base := CR_SAVE_FS.base;

FS.limit := CR_SAVE_FS.limit;

FS.access_rights := CR_SAVE_FS.access_rights;

GS.selector := CR_SAVE_GS.selector;

GS.base := CR_SAVE_GS.base;

GS.limit := CR_SAVE_GS.limit;

GS.access_rights := CR_SAVE_GS.access_rights;

(\* Restore XCR0 if needed \*)
IF (CR4.OSXSAVE = 1)
    XCR0 := CR_SAVE__XCR0;
FI;

Unsuppress_all_code_breakpoints_that_are_outside_ELRANGE;

IF (CR_DBGOPTIN = 0)
    THEN
        UnSuppress_all_code_breakpoints_that_overlap_with_ELRANGE;
        Restore suppressed breakpoint matches;
        RFLAGS.TF := CR_SAVE_TF;
        UnSuppress_montior_trap_flag;
        UnSuppress_LBR_Generation;
        UnSuppress_performance monitoring_activity;
        Restore performance monitoring counter AnyThread demotion to MyThread in enclave back to AnyThread
FI;

IF RFLAGS.TF = 1
    THEN Pend Single-Step #DB at the end of EEXIT;
FI;

EEXIT—Exits an Enclave

Vol. 3D 41-97

INTEL® SGX INSTRUCTION REFERENCES

```
IF the “monitor trap flag” VM-execution control is set
    THEN pend a MTF VM exit at the end of EEXIT;
FI;
```

```
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN
        (* Record PREVSSP *)
        IF (IA32_U_CET.SH_STK_EN == 1)
            THEN CR_TCS_PA.PREVSSP = SSP; FI;
FI;
```

```
IF ((CPUID.07H.00H:EDX.CET_IBT = 1) OR (CPUID.07H.00H:ECX.CET_SS = 1)
    THEN
        (* Restore enclosing app’s CET state from the save registers *)
        IA32_U_CET := CR_SAVE_IA32_U_CET;
IF CPUID.07H.00H:ECX.CET_SS = 1
    THEN SSP := CR_SAVE_SSP; FI;
```

```
        (* Update enclosing app’s TRACKER if enclosing app has indirect branch tracking enabled *)
        IF (CR4.CET = 1 AND IA32_U_CET.ENDBR_EN = 1)
            THEN
                IA32_U_CET.TRACKER := WAIT_FOR_ENDBRANCH;
                IA32_U_CET.SUPPRESS := 0
        FI;
FI;
```

```
CR_ENCLAVE_MODE := 0;
CR_TCS_PA.STATE := INACTIVE;
```

```
(* Assure consistent translations *)
Flush_linear_context;
```

## Flags Affected

RFLAGS.TF is restored from the value previously saved in EENTER or ERESUME.

## Protected Mode Exceptions

**#GP(0)** | If executed outside an enclave.If RBX is outside the CS segment.
--- | ---
**#PF(error code)** | If a page fault occurs in accessing memory.

## 64-Bit Mode Exceptions

**#GP(0)** | If executed outside an enclave.If RBX is not canonical.
--- | ---
**#PF(error code)** | If a page fault occurs in accessing memory operands.

<page_number>41-98</page_number> Vol. 3D

EEXIT—Exits an Enclave

INTEL® SGX INSTRUCTION REFERENCES

# EGETKEY—Retrieves a Cryptographic Key

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 01H ENCLU[EGETKEY]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function retrieves a cryptographic key.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th colspan="2">EAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
    <tr>
        <th>IR</th>
        <th>EGETKEY (In)</th>
        <th>Return error code (Out)</th>
        <th>Address to a KEYREQUEST (In)</th>
        <th>Address of the OUTPUTDATA (In)</th>
    </tr>
  </thead>
</table>

## Description

The ENCLU[EGETKEY] instruction returns a 128-bit secret key from the processor specific key hierarchy. The register RBX contains the effective address of a KEYREQUEST structure, which the instruction interprets to determine the key being requested. The Requesting Keys section below provides a description of the keys that can be requested. The RCX register contains the effective address where the key will be returned. Both the addresses in RBX & RCX should be locations inside the enclave.

EGETKEY derives keys using a processor unique value to create a specific key based on a number of possible inputs. This instruction leaf can only be executed inside an enclave.

## EEGETKEY Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>KEYREQUEST</th>
        <th>OUTPUTDATA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Enclave read access</td>
        <td>Enclave write access</td>
    </tr>
  </tbody>
</table>

After validating the operands, the instruction determines which key is to be produced and performs the following actions:

* The instruction assembles the derivation data for the key based on the Table 41-62.

* Computes derived key using the derivation data and package specific value.

* Outputs the calculated key to the address in RCX.

The instruction fails with #GP(0) if the operands are not properly aligned. Successful completion of the instruction will clear RFLAGS.{ZF, CF, AF, OF, SF, PF}. The instruction returns an error code if the user tries to request a key based on an invalid CR_CPUSVN or ISVSVN (when the user request is accepted, see the table below), requests a key for which it has not been granted the attribute to request, or requests a key that is not supported by the hardware. These checks may be performed in any order. Thus, an indication by error number of one cause (for example, invalid attribute) does not imply that there are not also other errors. Different processors may thus give different error numbers for the same Enclave. The correctness of software should not rely on the order resulting from the checks documented in this section. In such cases the ZF flag is set and the corresponding error bit (SGX_INVALID_SVN, SGX_INVALID_ATTRIBUTE, SGX_INVALID_KEYNAME) is set in RAX and the data at the address specified by RCX is unmodified.

## Requesting Keys

The KEYREQUEST structure (see Section 38.18.1) identifies the key to be provided. The Keyrequest.KeyName field identifies which type of key is requested.

## Deriving Keys

Key derivation is based on a combination of the enclave specific values (see Table 41-62) and a processor key. Depending on the key being requested a field may either be included by definition or the value may be included from the KeyRequest. A “yes” in Table 41-62 indicates the value for the field is included from its default location, identified in the source row, and a “request” indicates the values for the field is included from its corresponding KeyRequest field.

EGETKEY—Retrieves a Cryptographic Key

Vol. 3D 41-99
<page_number>41-99</page_number>

INTEL® SGX INSTRUCTION REFERENCES

## Table 41-62. Key Derivation

<table>
  <thead>
    <tr>
        <th rowspan="8">Source</th>
        <th> </th>
        <th>Key Name</th>
        <th>Attributes</th>
        <th>Owner Epoch</th>
        <th>CPU SVN</th>
        <th>ISV SVN</th>
        <th>ISV PRODID</th>
        <th>ISVEXT PRODID</th>
        <th>ISVFAMILYID</th>
        <th>MRENCLAVE</th>
        <th>MRSIGNER</th>
        <th>CONFIG ID</th>
        <th>CONFIGSVN</th>
        <th>RAND</th>
    </tr>
    <tr>
        <th>Key Dependent Constant</th>
        <th>Y := SECS.ATTRIBUTES<br/>and SECS.MISCSELECT<br/>and SECS.CET_ATTRIBUTES;</th>
        <th>CR_SGX OWNER EPOCH</th>
        <th>Y := CPUSVN Register;</th>
        <th>R := Req.ISV SVN;</th>
        <th>SECS.ISVID</th>
        <th>SECS.ISVEXTPRODID</th>
        <th>SECS.ISVFAMILYID</th>
        <th>SECS.MRENCLAVE</th>
        <th>SECS.MRSIGNER</th>
        <th>SECS.CONFIGID</th>
        <th>SECS.CONFIGSVN</th>
        <th colspan="2">Req. KEYID</th>
    </tr>
    <tr>
        <th>R := AttribMask &amp; SECS.ATTRIBUTES<br/>and SECS.MISCSELECT<br/>and SECS.CET_ATTRIBUTES;</th>
        <th> </th>
        <th colspan="3">R := Req.CPU SVN;</th>
        <th> </th>
        <th> </th>
        <th> </th>
        <th> </th>
        <th> </th>
        <th> </th>
        <th> </th>
        <th> </th>
        <th> </th>
    </tr>
    <tr>
        <th>EINITTOKEN</th>
        <th>Yes</th>
        <th>Request</th>
        <th>Yes</th>
        <th>Request</th>
        <th>Request</th>
        <th>Yes</th>
        <th>No</th>
        <th>No</th>
        <th>No</th>
        <th>Yes</th>
        <th>No</th>
        <th>No</th>
        <th>Request</th>
    </tr>
    <tr>
        <th>Report</th>
        <th>Yes</th>
        <th>Yes</th>
        <th>Yes</th>
        <th>Yes</th>
        <th>No</th>
        <th>No</th>
        <th>No</th>
        <th>No</th>
        <th>Yes</th>
        <th>No</th>
        <th>Yes</th>
        <th>Yes</th>
        <th>Request</th>
    </tr>
    <tr>
        <th>Seal</th>
        <th>Yes</th>
        <th>Request</th>
        <th>Yes</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
    </tr>
    <tr>
        <th>Provisioning</th>
        <th>Yes</th>
        <th>Request</th>
        <th>No</th>
        <th>Request</th>
        <th>Request</th>
        <th>Yes</th>
        <th>No</th>
        <th>No</th>
        <th>No</th>
        <th>Yes</th>
        <th>No</th>
        <th>No</th>
        <th>Yes</th>
    </tr>
    <tr>
        <th>Provisioning Seal</th>
        <th>Yes</th>
        <th>Request</th>
        <th>No</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>Request</th>
        <th>No</th>
        <th>Yes</th>
        <th>Request</th>
        <th>Request</th>
        <th>Yes</th>
    </tr>
  </thead>
</table>

Keys that permit the specification of a CPU or ISV's code's, or enclave configuration's SVNs have additional requirements. The caller may not request a key for an SVN beyond the current CPU, ISV or enclave configuration's SVN, respectively.

Several keys are access controlled. Access to the Provisioning Key and Provisioning Seal key requires the enclave's ATTRIBUTES.PROVISIONKEY be set. The EINITTOKEN Key requires ATTRIBUTES.EINITTOKEN_KEY be set and SECS.MRSIGNER equal IA32_SGXLEPUBKEYHASH.

Some keys are derived based on a hardcode PKCS padding constant (352 byte string):

HARDCODED_PKCS1_5_PADDING[15:0] := 0100H;

HARDCODED_PKCS1_5_PADDING[2655:16] := SignExtend330Byte(-1); // 330 bytes of 0FFH

HARDCODED_PKCS1_5_PADDING[2815:2656] := 2004000501020403650148866009060D30313000H;

The error codes are:

### Table 41-63. EGETKEY Return Value in RAX

<table>
  <thead>
    <tr>
        <th>Error Code (see Table 41-3)</th>
        <th>Value</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>No Error</td>
        <td>0</td>
        <td>EGETKEY successful.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_ATTRIBUTE</td>
        <td> </td>
        <td>The KEYREQUEST contains a KEYNAME for which the enclave is not authorized.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_CPUSVN</td>
        <td> </td>
        <td>If KEYREQUEST.CPUSVN is an unsupported platforms CPUSVN value.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_ISVSVN</td>
        <td> </td>
        <td>If KEYREQUEST software SVN (ISVSVN or CONFIGSVN) is greater than the enclave's corresponding SVN.</td>
    </tr>
    <tr>
        <td>SGX_INVALID_KEYNAME</td>
        <td> </td>
        <td>If KEYREQUEST.KEYNAME is an unsupported value.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

### Table 41-64. Base Concurrency Restrictions of EGETKEY

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EGETKEY</td>
        <td>KEYREQUEST [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>OUTPUTDATA [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

41-100 Vol. 3D
<page_number>41-100</page_number>

EGETKEY—Retrieves a Cryptographic Key

INTEL® SGX INSTRUCTION REFERENCES

## Table 41-65. Additional Concurrency Restrictions of EGETKEY

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EGETKEY</td>
        <td>KEYREQUEST<br/>[DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>OUTPUTDATA<br/>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

### Temp Variables in EGETKEY Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (Bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_CURRENTSECS</td>
        <td> </td>
        <td> </td>
        <td>Address of the SECS for the currently executing enclave.</td>
    </tr>
    <tr>
        <td>TMP_KEYDEPENDENCIES</td>
        <td> </td>
        <td> </td>
        <td>Temp space for key derivation.</td>
    </tr>
    <tr>
        <td>TMP_ATTRIBUTES</td>
        <td> </td>
        <td>128</td>
        <td>Temp Space for the calculation of the sealable Attributes.</td>
    </tr>
    <tr>
        <td>TMP_ISVEXTPRODID</td>
        <td> </td>
        <td>16 bytes</td>
        <td>Temp Space for ISVEXTPRODID.</td>
    </tr>
    <tr>
        <td>TMP_ISVPRODID</td>
        <td> </td>
        <td>2 bytes</td>
        <td>Temp Space for ISVPRODID.</td>
    </tr>
    <tr>
        <td>TMP_ISVFAMILYID</td>
        <td> </td>
        <td>16 bytes</td>
        <td>Temp Space for ISVFAMILYID.</td>
    </tr>
    <tr>
        <td>TMP_CONFIGID</td>
        <td> </td>
        <td>64 bytes</td>
        <td>Temp Space for CONFIGID.</td>
    </tr>
    <tr>
        <td>TMP_CONFIGSVN</td>
        <td> </td>
        <td>2 bytes</td>
        <td>Temp Space for CONFIGSVN.</td>
    </tr>
    <tr>
        <td>TMP_OUTPUTKEY</td>
        <td> </td>
        <td>128</td>
        <td>Temp Space for the calculation of the key.</td>
    </tr>
  </tbody>
</table>

(\* Make sure KEYREQUEST is properly aligned and inside the current enclave \*)

IF ( (DS:RBX is not 512Byte aligned) or (DS:RBX is not within CR_ELRANGE) )
  THEN #GP(0); FI;

(\* Make sure DS:RBX is an EPC address and the EPC page is valid \*)

IF ( (DS:RBX does not resolve to an EPC address) or (EPCM(DS:RBX).VALID = 0) )
  THEN #PF(DS:RBX); FI;

IF (EPCM(DS:RBX).BLOCKED = 1)
  THEN #PF(DS:RBX); FI;

(\* Check page parameters for correctness \*)

IF ( (EPCM(DS:RBX).PT ≠ PT_REG) or (EPCM(DS:RBX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or (EPCM(DS:RBX).PENDING = 1) or
  (EPCM(DS:RBX).MODIFIED = 1) or (EPCM(DS:RBX).ENCLAVEADDRESS ≠ (DS:RBX & ~0FFFH) ) or (EPCM(DS:RBX).R = 0) )
  THEN #PF(DS:RBX);
FI;

(\* Make sure OUTPUTDATA is properly aligned and inside the current enclave \*)

IF ( (DS:RCX is not 16Byte aligned) or (DS:RCX is not within CR_ELRANGE) )
  THEN #GP(0); FI;

(\* Make sure DS:RCX is an EPC address and the EPC page is valid \*)

IF ( (DS:RCX does not resolve to an EPC address) or (EPCM(DS:RCX).VALID = 0) )

EGETKEY—Retrieves a Cryptographic Key <page_number>Vol. 3D 41-101</page_number>

INTEL® SGX INSTRUCTION REFERENCES

THEN #PF(DS:RCX); FI;

IF (EPCM(DS:RCX).BLOCKED = 1)
    THEN #PF(DS:RCX); FI;

(\* Check page parameters for correctness \*)
IF ( (EPCM(DS:RCX).PT ≠ PT_REG) or (EPCM(DS:RCX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or (EPCM(DS:RCX).PENDING = 1) or
    (EPCM(DS:RCX).MODIFIED = 1) or (EPCM(DS:RCX).ENCLAVEADDRESS ≠ (DS:RCX & ~0FFFH) ) or (EPCM(DS:RCX).W = 0) )
    THEN #PF(DS:RCX);
FI;

(\* Verify RESERVED spaces in KEYREQUEST are valid \*)
IF ( (DS:RBX).RESERVED ≠ 0) or (DS:RBX.KEYPOLICY.RESERVED ≠ 0) )
    THEN #GP(0); FI;

TMP_CURRENTSECS := CR_ACTIVE_SECS;

(\* Verify that CONFIGSVN & New Policy bits are not used if KSS is not enabled \*)
IF ((TMP_CURRENTSECS.ATTRIBUTES.KSS == 0) AND ((DS:RBX.KEYPOLICY & 0x003C ≠ 0) OR (DS:RBX.CONFIGSVN > 0)))
    THEN #GP(0); FI;
(\* Determine which enclave attributes that must be included in the key. Attributes that must always be include INIT & DEBUG \*)
REQUIRED_SEALING_MASK[127:0] := 00000000 00000000 00000000 00000003H;
TMP_ATTRIBUTES := (DS:RBX.ATTRIBUTEMASK | REQUIRED_SEALING_MASK) & TMP_CURRENTSECS.ATTRIBUTES;

(\* Compute MISCSELECT fields to be included \*)
TMP_MISCSELECT := DS:RBX.MISCMASK & TMP_CURRENTSECS.MISCSELECT

(\* Compute CET_ATTRIBUTES fields to be included \*)
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN TMP_CET_ATTRIBUTES := DS:RBX.CET_ATTRIBUTES_ MASK & TMP_CURRENTSECS.CET_ATTRIBUTES; FI;
TMP_KEYDEPENDENCIES := 0;

CASE (DS:RBX.KEYNAME)
    SEAL_KEY:
        IF (DS:RBX.CPUSVN is beyond current CPU configuration)
            THEN
                RFLAGS.ZF := 1;
                RAX := SGX_INVALID_CPUSVN;
                GOTO EXIT;
        FI;
        IF (DS:RBX.ISVSVN > TMP_CURRENTSECS.ISVSVN)
            THEN
                RFLAGS.ZF := 1;
                RAX := SGX_INVALID_ISVSVN;
                GOTO EXIT;
        FI;
        IF (DS:RBX.CONFIGSVN > TMP_CURRENTSECS.CONFIGSVN)
            THEN
                RFLAGS.ZF := 1;
                RAX := SGX_INVALID_ISVSVN;
                GOTO EXIT;
        FI;

(\*Include enclave identity?\*)

<page_number>41-102</page_number> Vol. EGETKEY—Retrieves a Cryptographic Key

INTEL® SGX INSTRUCTION REFERENCES

```
    TMP_MRENCLAVE := 0;
    IF (DS:RBX.KEYPOLICY.MRENCLAVE = 1)
        THEN TMP_MRENCLAVE := TMP_CURRENTSECS.MRENCLAVE;
    FI;
    (*Include enclave author?*)
    TMP_MRSIGNER := 0;
    IF (DS:RBX.KEYPOLICY.MRSIGNER = 1)
        THEN TMP_MRSIGNER := TMP_CURRENTSECS.MRSIGNER;
    FI;
(* Include enclave product family ID? *)
TMP_ISVFAMILYID := 0;
IF (DS:RBX.KEYPOLICY.ISVFAMILYID = 1)
    THEN TMP_ISVFAMILYID := TMP_CURRENTSECS.ISVFAMILYID;
    FI;

(* Include enclave product ID? *)
TMP_ISVPRODID := 0;
IF (DS:RBX.KEYPOLICY.NOISVPRODID = 0)
    TMP_ISVPRODID := TMP_CURRENTSECS.ISVPRODID;
    FI;

(* Include enclave Config ID? *)
TMP_CONFIGID := 0;
TMP_CONFIGSVN := 0;
IF (DS:RBX.KEYPOLICY.CONFIGID = 1)
    TMP_CONFIGID := TMP_CURRENTSECS.CONFIGID;
    TMP_CONFIGSVN := DS:RBX.CONFIGSVN;
    FI;

(* Include enclave extended product ID? *)
TMP_ISVEXTPRODID := 0;
IF (DS:RBX.KEYPOLICY.ISVEXTPRODID = 1 )
    TMP_ISVEXTPRODID := TMP_CURRENTSECS.ISVEXTPRODID;
FI;

    //Determine values key is based on
    TMP_KEYDEPENDENCIES.KEYNAME := SEAL_KEY;
    TMP_KEYDEPENDENCIES.ISVFAMILYID := TMP_ISVFAMILYID;
    TMP_KEYDEPENDENCIES.ISVEXTPRODID := TMP_ISVEXTPRODID;
    TMP_KEYDEPENDENCIES.ISVPRODID := TMP_ISVPRODID;
    TMP_KEYDEPENDENCIES.ISVSVN := DS:RBX.ISVSVN;
    TMP_KEYDEPENDENCIES.SGXOWNEREPOCH := CR_SGXOWNEREPOCH;
    TMP_KEYDEPENDENCIES.ATTRIBUTES := TMP_ATTRIBUTES;
    TMP_KEYDEPENDENCIES.ATTRIBUTESMASK := DS:RBX.ATTRIBUTEMASK;
    TMP_KEYDEPENDENCIES.MRENCLAVE := TMP_MRENCLAVE;
    TMP_KEYDEPENDENCIES.MRSIGNER := TMP_MRSIGNER;
    TMP_KEYDEPENDENCIES.KEYID := DS:RBX.KEYID;
    TMP_KEYDEPENDENCIES.SEAL_KEY_FUSES := CR_SEAL_FUSES;
    TMP_KEYDEPENDENCIES.CPUSVN := DS:RBX.CPUSVN;
    TMP_KEYDEPENDENCIES.PADDING := TMP_CURRENTSECS.PADDING;
    TMP_KEYDEPENDENCIES.MISCSELECT := TMP_MISCSELECT;
    TMP_KEYDEPENDENCIES.MISCMASK := ~DS:RBX.MISCMASK;
    TMP_KEYDEPENDENCIES.KEYPOLICY := DS:RBX.KEYPOLICY;
    TMP_KEYDEPENDENCIES.CONFIGID := TMP_CONFIGID;
```

EGETKEY—Retrieves a Cryptographic Key Vol. 3D 41-103

INTEL® SGX INSTRUCTION REFERENCES

```
        TMP_KEYDEPENDENCIES.CONFIGSVN := TMP_CONFIGSVN;
IF CPUID.12H.01H:EAX[6] = 1
    THEN
              TMP_KEYDEPENDENCIES.CET_ATTRIBUTES := TMP_CET_ATTRIBUTES;
              TMP_KEYDEPENDENCIES.CET_ATTRIBUTES_MASK := DS:RBX.CET_ATTRIBUTES_MASK;
 FI;
 BREAK;
REPORT_KEY:
 //Determine values key is based on
 TMP_KEYDEPENDENCIES.KEYNAME := REPORT_KEY;
 TMP_KEYDEPENDENCIES.ISVFAMILYID := 0;
 TMP_KEYDEPENDENCIES.ISVEXTPRODID := 0;
 TMP_KEYDEPENDENCIES.ISVPRODID := 0;
 TMP_KEYDEPENDENCIES.ISVSVN := 0;
 TMP_KEYDEPENDENCIES.SGXOWNEREPOCH := CR_SGXOWNEREPOCH;
 TMP_KEYDEPENDENCIES.ATTRIBUTES := TMP_CURRENTSECS.ATTRIBUTES;
 TMP_KEYDEPENDENCIES.ATTRIBUTESMASK := 0;
 TMP_KEYDEPENDENCIES.MRENCLAVE := TMP_CURRENTSECS.MRENCLAVE;
 TMP_KEYDEPENDENCIES.MRSIGNER := 0;
 TMP_KEYDEPENDENCIES.KEYID := DS:RBX.KEYID;
 TMP_KEYDEPENDENCIES.SEAL_KEY_FUSES := CR_SEAL_FUSES;
 TMP_KEYDEPENDENCIES.CPUSVN := CR_CPUSVN;
 TMP_KEYDEPENDENCIES.PADDING := HARDCODED_PKCS1_5_PADDING;
 TMP_KEYDEPENDENCIES.MISCSELECT := TMP_CURRENTSECS.MISCSELECT;
 TMP_KEYDEPENDENCIES.MISCMASK := 0;
 TMP_KEYDEPENDENCIES.KEYPOLICY := 0;
 TMP_KEYDEPENDENCIES.CONFIGID := TMP_CURRENTSECS.CONFIGID;
 TMP_KEYDEPENDENCIES.CONFIGSVN := TMP_CURRENTSECS.CONFIGSVN;
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN
              TMP_KEYDEPENDENCIES.CET_ATTRIBUTES := TMP_CURRENTSECS.CET_ATTRIBUTES;
              TMP_KEYDEPENDENCIES.CET_ATTRIBUTES_MASK := 0;
 FI;
 BREAK;
EINITTOKEN_KEY:
 (* Check ENCLAVE has EINITTOKEN Key capability *)
 IF (TMP_CURRENTSECS.ATTRIBUTES.EINITTOKEN_KEY = 0)
    THEN
              RFLAGS.ZF := 1;
              RAX := SGX_INVALID_ATTRIBUTE;
              GOTO EXIT;
 FI;
 IF (DS:RBX.CPUSVN is beyond current CPU configuration)
    THEN
              RFLAGS.ZF := 1;
              RAX := SGX_INVALID_CPUSVN;
              GOTO EXIT;
 FI;
 IF (DS:RBX.ISVSVN > TMP_CURRENTSECS.ISVSVN)
    THEN
              RFLAGS.ZF := 1;
              RAX := SGX_INVALID_ISVSVN;
              GOTO EXIT;
 FI;
```

<page_number>41-104</page_number> Vol. EGETKEY—Retrieves a Cryptographic Key

INTEL® SGX INSTRUCTION REFERENCES

```
(* Determine values key is based on *)
TMP_KEYDEPENDENCIES.KEYNAME := EINITTOKEN_KEY;
TMP_KEYDEPENDENCIES.ISVFAMILYID := 0;
TMP_KEYDEPENDENCIES.ISVEXTPRODID := 0;
TMP_KEYDEPENDENCIES.ISVPRODID := TMP_CURRENTSECS.ISVPRODID;
TMP_KEYDEPENDENCIES.ISVSVN := DS:RBX.ISVSVN;
TMP_KEYDEPENDENCIES.SGXOWNEREPOCH := CR_SGXOWNEREPOCH;
TMP_KEYDEPENDENCIES.ATTRIBUTES := TMP_ATTRIBUTES;
TMP_KEYDEPENDENCIES.ATTRIBUTESMASK := 0;
TMP_KEYDEPENDENCIES.MRENCLAVE := 0;
TMP_KEYDEPENDENCIES.MRSIGNER := TMP_CURRENTSECS.MRSIGNER;
TMP_KEYDEPENDENCIES.KEYID := DS:RBX.KEYID;
TMP_KEYDEPENDENCIES.SEAL_KEY_FUSES := CR_SEAL_FUSES;
TMP_KEYDEPENDENCIES.CPUSVN := DS:RBX.CPUSVN;
TMP_KEYDEPENDENCIES.PADDING := TMP_CURRENTSECS.PADDING;
TMP_KEYDEPENDENCIES.MISCSELECT := TMP_MISCSELECT;
TMP_KEYDEPENDENCIES.MISCMASK := 0;
TMP_KEYDEPENDENCIES.KEYPOLICY := 0;
TMP_KEYDEPENDENCIES.CONFIGID := 0;
TMP_KEYDEPENDENCIES.CONFIGSVN := 0;
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN
        TMP_KEYDEPENDENCIES.CET_ATTRIBUTES := TMP_CET_ATTRIBUTES;
        TMP_KEYDEPENDENCIES.CET_ATTRIBUTES_MASK := 0;
FI;
BREAK;
PROVISION_KEY:
(* Check ENCLAVE has PROVISIONING capability *)
IF (TMP_CURRENTSECS.ATTRIBUTES.PROVISIONKEY = 0)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_INVALID_ATTRIBUTE;
        GOTO EXIT;
FI;
IF (DS:RBX.CPUSVN is beyond current CPU configuration)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_INVALID_CPUSVN;
        GOTO EXIT;
FI;
IF (DS:RBX.ISVSVN > TMP_CURRENTSECS.ISVSVN)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_INVALID_ISVSVN;
        GOTO EXIT;
FI;
(* Determine values key is based on *)
TMP_KEYDEPENDENCIES.KEYNAME := PROVISION_KEY;
TMP_KEYDEPENDENCIES.ISVFAMILYID := 0;
TMP_KEYDEPENDENCIES.ISVEXTPRODID := 0;
TMP_KEYDEPENDENCIES.ISVPRODID := TMP_CURRENTSECS.ISVPRODID;
TMP_KEYDEPENDENCIES.ISVSVN := DS:RBX.ISVSVN;
TMP_KEYDEPENDENCIES.SGXOWNEREPOCH := 0;
TMP_KEYDEPENDENCIES.ATTRIBUTES := TMP_ATTRIBUTES;
```

EGETKEY—Retrieves a Cryptographic Key Vol. 3D 41-105

INTEL® SGX INSTRUCTION REFERENCES

```
        TMP_KEYDEPENDENCIES.ATTRIBUTESMASK := DS:RBX.ATTRIBUTEMASK;
        TMP_KEYDEPENDENCIES.MRENCLAVE := 0;
        TMP_KEYDEPENDENCIES.MRSIGNER := TMP_CURRENTSECS.MRSIGNER;
        TMP_KEYDEPENDENCIES.KEYID := 0;
        TMP_KEYDEPENDENCIES.SEAL_KEY_FUSES := 0;
        TMP_KEYDEPENDENCIES.CPUSVN := DS:RBX.CPUSVN;
        TMP_KEYDEPENDENCIES.PADDING := TMP_CURRENTSECS.PADDING;
        TMP_KEYDEPENDENCIES.MISCSELECT := TMP_MISCSELECT;
        TMP_KEYDEPENDENCIES.MISCMASK := ~DS:RBX.MISCMASK;
        TMP_KEYDEPENDENCIES.KEYPOLICY := 0;
        TMP_KEYDEPENDENCIES.CONFIGID := 0;
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN
        TMP_KEYDEPENDENCIES.CET_ATTRIBUTES := TMP_CET_ATTRIBUTES;
        TMP_KEYDEPENDENCIES.CET_ATTRIBUTES_MASK := 0;
    FI;
    BREAK;
PROVISION_SEAL_KEY:
    (* Check ENCLAVE has PROVISIONING capability *)
    IF (TMP_CURRENTSECS.ATTRIBUTES.PROVISIONKEY = 0)
        THEN
            RFLAGS.ZF := 1;
            RAX := SGX_INVALID_ATTRIBUTE;
            GOTO EXIT;
    FI;
    IF (DS:RBX.CPUSVN is beyond current CPU configuration)
        THEN
            RFLAGS.ZF := 1;
            RAX := SGX_INVALID_CPUSVN;
            GOTO EXIT;
    FI;
    IF (DS:RBX.ISVSVN > TMP_CURRENTSECS.ISVSVN)
        THEN
            RFLAGS.ZF := 1;
            RAX := SGX_INVALID_ISVSVN;
            GOTO EXIT;
    FI;
(* Include enclave product family ID? *)
TMP_ISVFAMILYID := 0;
IF (DS:RBX.KEYPOLICY.ISVFAMILYID = 1)
    THEN TMP_ISVFAMILYID := TMP_CURRENTSECS.ISVFAMILYID;
FI;
```

```
(* Include enclave product ID? *)
TMP_ISVPRODID := 0;
IF (DS:RBX.KEYPOLICY.NOISVPRODID = 0)
    TMP_ISVPRODID := TMP_CURRENTSECS.ISVPRODID;
FI;
```

```
(* Include enclave Config ID? *)
TMP_CONFIGID := 0;
TMP_CONFIGSVN := 0;
IF (DS:RBX.KEYPOLICY.CONFIGID = 1)
    TMP_CONFIGID := TMP_CURRENTSECS.CONFIGID;
```

<page_number>41-106</page_number> Vol. EGETKEY—Retrieves a Cryptographic Key

INTEL® SGX INSTRUCTION REFERENCES

TMP_CONFIGSVN := DS:RBX.CONFIGSVN;
FI;

(\* Include enclave extended product ID? \*)
TMP_ISVEXTPRODID := 0;
IF (DS:RBX.KEYPOLICY.ISVEXTPRODID = 1)
    TMP_ISVEXTPRODID := TMP_CURRENTSECS.ISVEXTPRODID;
FI;

    (\* Determine values key is based on \*)
    TMP_KEYDEPENDENCIES.KEYNAME := PROVISION_SEAL_KEY;
    TMP_KEYDEPENDENCIES.ISVFAMILYID := TMP_ISVFAMILYID;
    TMP_KEYDEPENDENCIES.ISVEXTPRODID := TMP_ISVEXTPRODID;
    TMP_KEYDEPENDENCIES.ISVPRODID := TMP_ISVPRODID;
    TMP_KEYDEPENDENCIES.ISVSVN := DS:RBX.ISVSVN;
    TMP_KEYDEPENDENCIES.SGXOWNEREPOCH := 0;
    TMP_KEYDEPENDENCIES.ATTRIBUTES := TMP_ATTRIBUTES;
    TMP_KEYDEPENDENCIES.ATTRIBUTEMASK := DS:RBX.ATTRIBUTEMASK;
    TMP_KEYDEPENDENCIES.MRENCLAVE := 0;
    TMP_KEYDEPENDENCIES.MRSIGNER := TMP_CURRENTSECS.MRSIGNER;
    TMP_KEYDEPENDENCIES.KEYID := 0;
    TMP_KEYDEPENDENCIES.SEAL_KEY_FUSES := CR_SEAL_FUSES;
    TMP_KEYDEPENDENCIES.CPUSVN := DS:RBX.CPUSVN;
    TMP_KEYDEPENDENCIES.PADDING := TMP_CURRENTSECS.PADDING;
    TMP_KEYDEPENDENCIES.MISCSELECT := TMP_MISCSELECT;
    TMP_KEYDEPENDENCIES.MISCMASK := ~DS:RBX.MISCMASK;
    TMP_KEYDEPENDENCIES.KEYPOLICY := DS:RBX.KEYPOLICY;
    TMP_KEYDEPENDENCIES.CONFIGID := TMP_CONFIGID;
    TMP_KEYDEPENDENCIES.CONFIGSVN := TMP_CONFIGSVN;
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN
        TMP_KEYDEPENDENCIES.CET_ATTRIBUTES := TMP_CET_ATTRIBUTES;
        TMP_KEYDEPENDENCIES.CET_ATTRIBUTES_MASK := 0;
FI;
BREAK;
DEFAULT:
    (\* The value of KEYNAME is invalid \*)
    RFLAGS.ZF := 1;
    RAX := SGX_INVALID_KEYNAME;
    GOTO EXIT:
ESAC;

(\* Calculate the final derived key and output to the address in RCX \*)
TMP_OUTPUTKEY := derivekey(TMP_KEYDEPENDENCIES);
DS:RCX[15:0] := TMP_OUTPUTKEY;
RAX := 0;
RFLAGS.ZF := 0;

EXIT:
RFLAGS.CF := 0;
RFLAGS.PF := 0;
RFLAGS.AF := 0;
RFLAGS.OF := 0;
RFLAGS.SF := 0;

EGETKEY—Retrieves a Cryptographic Key Vol. 3D 41-107

INTEL® SGX INSTRUCTION REFERENCES

## Flags Affected

ZF is cleared if successful, otherwise ZF is set. CF, PF, AF, OF, SF are cleared.

## Protected Mode Exceptions

**#GP(0)**
* If executed outside an enclave.
* If a memory operand effective address is outside the current enclave.
* If an effective address is not properly aligned.
* If an effective address is outside the DS segment limit.
* If KEYREQUEST format is invalid.

**#PF(error code)**
* If a page fault occurs in accessing memory.

## 64-Bit Mode Exceptions

**#GP(0)**
* If executed outside an enclave.
* If a memory operand effective address is outside the current enclave.
* If an effective address is not properly aligned.
* If an effective address is not canonical.
* If KEYREQUEST format is invalid.

**#PF(error code)**
* If a page fault occurs in accessing memory operands.

<page_number>41-108</page_number> Vol.

EGETKEY—Retrieves a Cryptographic Key

INTEL® SGX INSTRUCTION REFERENCES

# EMODPE—Extend an EPC Page Permissions

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 06H ENCLU[EMODPE]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX2</td>
        <td>This leaf function extends the access rights of an existing EPC page.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EMODPE (In)</td>
        <td>Address of a SECINFO (In)</td>
        <td>Address of the destination EPC page (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function extends the access rights associated with an existing EPC page in the running enclave. THE RWX bits of the SECINFO parameter are treated as a permissions mask; supplying a value that does not extend the page permissions will have no effect. This instruction leaf can only be executed when inside the enclave.

RBX contains the effective address of a SECINFO structure while RCX contains the effective address of an EPC page. The table below provides additional information on the memory parameter of the EMODPE leaf function.

## EMODPE Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>SECINFO</th>
        <th>EPCPAGE</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access permitted by Non Enclave</td>
        <td>Read access permitted by Enclave</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following:

## EMODPE Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>The operands are not properly aligned.</td>
        <td>If security attributes of the SECINFO page make the page inaccessible.</td>
    </tr>
    <tr>
        <td>The EPC page is locked by another thread.</td>
        <td>RBX does not contain an effective address in an EPC page in the running enclave.</td>
    </tr>
    <tr>
        <td>The EPC page is not valid.</td>
        <td>RCX does not contain an effective address of an EPC page in the running enclave.</td>
    </tr>
    <tr>
        <td colspan="2">SECINFO contains an invalid request.</td>
    </tr>
  </tbody>
</table>

## Concurrency Restrictions

### Table 41-66. Base Concurrency Restrictions of EMODPE

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EMODPE</td>
        <td>Target [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECINFO [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

### Table 41-67. Additional Concurrency Restrictions of EMODPE

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="2">EMODPE</td>
        <td>Target [DS:RCX]</td>
        <td>Exclusive</td>
        <td>#GP</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>SECINFO [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

EMODPE—Extend an EPC Page Permissions

Vol. 3D 41-109

INTEL® SGX INSTRUCTION REFERENCES

# Operation

## Temp Variables in EMODPE Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>SCRATCH_SECINFO</td>
        <td>SECINFO</td>
        <td>512</td>
        <td>Scratch storage for holding the contents of DS:RBX.</td>
    </tr>
  </tbody>
</table>

IF (DS:RBX is not 64Byte Aligned)

  THEN #GP(0); FI;

IF (DS:RCX is not 4KByte Aligned)

  THEN #GP(0); FI;

IF ((DS:RBX is not within CR_ELRANGE) or (DS:RCX is not within CR_ELRANGE) )

  THEN #GP(0); FI;

IF (DS:RBX does not resolve within an EPC)

  THEN #PF(DS:RBX); FI;

IF (DS:RCX does not resolve within an EPC)

  THEN #PF(DS:RCX); FI;

IF ( (EPCM(DS:RBX).VALID = 0) or (EPCM(DS:RBX).R = 0) or (EPCM(DS:RBX).PENDING ≠ 0) or (EPCM(DS:RBX).MODIFIED ≠ 0) or

  (EPCM(DS:RBX).BLOCKED ≠ 0) or (EPCM(DS:RBX).PT ≠ PT_REG) or (EPCM(DS:RBX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or

  (EPCM(DS:RBX).ENCLAVEADDRESS ≠ (DS:RBX & ~0xFFF)) )

  THEN #PF(DS:RBX); FI;

SCRATCH_SECINFO := DS:RBX;

(\* Check for misconfigured SECINFO flags\*)

IF (SCRATCH_SECINFO reserved fields are not zero )

  THEN #GP(0); FI;

(\* Check security attributes of the EPC page \*)

IF ( (EPCM(DS:RCX).VALID = 0) or (EPCM(DS:RCX).PENDING ≠ 0) or (EPCM(DS:RCX).MODIFIED ≠ 0) or

  (EPCM(DS:RCX).BLOCKED ≠ 0) or (EPCM(DS:RCX).PT ≠ PT_REG) or (EPCM(DS:RCX).ENCLAVESECS ≠ CR_ACTIVE_SECS) )

  THEN #PF(DS:RCX); FI;

(\* Check the EPC page for concurrency \*)

IF (EPC page in use by another SGX2 instruction)

  THEN #GP(0); FI;

(\* Re-Check security attributes of the EPC page \*)

IF ( (EPCM(DS:RCX).VALID = 0) or (EPCM(DS:RCX).PENDING ≠ 0) or (EPCM(DS:RCX).MODIFIED ≠ 0) or

  (EPCM(DS:RCX).PT ≠ PT_REG) or (EPCM(DS:RCX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or

  (EPCM(DS:RCX).ENCLAVEADDRESS ≠ DS:RCX))

  THEN #PF(DS:RCX); FI;

(\* Check for misconfigured SECINFO flags\*)

IF ( (EPCM(DS:RCX).R = 0) and (SCRATCH_SECINFO.FLAGS.R = 0) and (SCRATCH_SECINFO.FLAGS.W ≠ 0) )

  THEN #GP(0); FI;

41-110 Vol.

EMODPE—Extend an EPC Page Permissions

INTEL® SGX INSTRUCTION REFERENCES

(\* Update EPCM permissions \*)

EPCM(DS:RCX).R := EPCM(DS:RCX).R | SCRATCH_SECINFO.FLAGS.R;

EPCM(DS:RCX).W := EPCM(DS:RCX).W | SCRATCH_SECINFO.FLAGS.W;

EPCM(DS:RCX).X := EPCM(DS:RCX).X | SCRATCH_SECINFO.FLAGS.X;

## Flags Affected

None

## Protected Mode Exceptions

**#GP(0)**:
* If executed outside an enclave.
* If a memory operand effective address is outside the DS segment limit.
* If a memory operand is not properly aligned.
* If a memory operand is locked.

**#PF(error code)**:
* If a page fault occurs in accessing memory operands.

## 64-Bit Mode Exceptions

**#GP(0)**:
* If executed outside an enclave.
* If a memory operand is non-canonical form.
* If a memory operand is not properly aligned.
* If a memory operand is locked.

**#PF(error code)**:
* If a page fault occurs in accessing memory operands.

EMODPE—Extend an EPC Page Permissions

Vol. 3D 41-111

INTEL® SGX INSTRUCTION REFERENCES

# EREPORT—Create a Cryptographic Report of the Enclave

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 00H<br/>ENCLU[EREPORT]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function creates a cryptographic report of the enclave.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
        <th>RDX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>EREPORT (In)</td>
        <td>Address of TARGETINFO (In)</td>
        <td>Address of REPORTDATA (In)</td>
        <td>Address where the REPORT is written to in an OUTPUTDATA (In)</td>
    </tr>
  </tbody>
</table>

## Description

This leaf function creates a cryptographic REPORT that describes the contents of the enclave. This instruction leaf can only be executed when inside the enclave. The cryptographic report can be used by other enclaves to determine that the enclave is running on the same platform.

RBX contains the effective address of the MRENCLAVE value of the enclave that will authenticate the REPORT output, using the REPORT key delivered by EGETKEY command for that enclave. RCX contains the effective address of a 64-byte REPORTDATA structure, which allows the caller of the instruction to associate data with the enclave from which the instruction is called. RDX contains the address where the REPORT will be output by the instruction.

## EREPORT Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>TARGETINFO</th>
        <th>REPORTDATA</th>
        <th>OUTPUTDATA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Read access by Enclave</td>
        <td>Read access by Enclave</td>
        <td>Read/Write access by Enclave</td>
    </tr>
  </tbody>
</table>

This instruction leaf perform the following:

1. Validate the 3 operands (RBX, RCX, RDX) are inside the enclave.

2. Compute a report key for the target enclave, as indicated by the value located in RBX(TARGETINFO).

3. Assemble the enclave SECS data to complete the REPORT structure (including the data provided using the RCX (REPORTDATA) operand).

4. Computes a cryptographic hash over REPORT structure.

5. Add the computed hash to the REPORT structure.

6. Output the completed REPORT structure to the address in RDX (OUTPUTDATA).

The instruction fails if the operands are not properly aligned.

CR_REPORT_KEYID, used to provide key wearout protection, is populated with a statistically unique value on boot of the platform by a trusted entity within the SGX TCB.

The instruction faults if any of the following:

## EREPORT Faulting Conditions

<table>
  <tbody>
    <tr>
        <td>An effective address not properly aligned.</td>
        <td>An memory address does not resolve in an EPC page.</td>
    </tr>
    <tr>
        <td>If accessing an invalid EPC page.</td>
        <td>If the EPC page is blocked.</td>
    </tr>
    <tr>
        <td colspan="2">May page fault.</td>
    </tr>
  </tbody>
</table>

<page_number>41-112</page_number> Vol. EREPORT—Create a Cryptographic Report of the Enclave

INTEL® SGX INSTRUCTION REFERENCES

## Concurrency Restrictions

Table 41-68. Base Concurrency Restrictions of EREPORT

<table>
  <thead><tr><th rowspan="2">Leaf</th><th rowspan="2">Parameter</th><th>Base Concurrency Restrictions</th></tr><tr><th>Access</th><th>On Conflict</th></tr></thead>
  <tbody>
    <tr>
        <td rowspan="3">EREPORT</td>
        <td>TARGETINFO [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>REPORTDATA [DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>OUTPUTDATA [DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

Table 41-69. Additional Concurrency Restrictions of EREPORT

<table>
  <thead>
    <tr>
        <th rowspan="3">Leaf</th>
        <th rowspan="3">Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY,<br/>EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td rowspan="3">EREPORT</td>
        <td>TARGETINFO [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>REPORTDATA<br/>[DS:RCX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
    <tr>
        <td>OUTPUTDATA<br/>[DS:RDX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

Temp Variables in EREPORT Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size (bits)</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_ATTRIBUTES</td>
        <td> </td>
        <td>32</td>
        <td>Physical address of SECS of the enclave to which source operand belongs.</td>
    </tr>
    <tr>
        <td>TMP_CURRENTSECS</td>
        <td> </td>
        <td> </td>
        <td>Address of the SECS for the currently executing enclave.</td>
    </tr>
    <tr>
        <td>TMP_KEYDEPENDENCIES</td>
        <td> </td>
        <td> </td>
        <td>Temp space for key derivation.</td>
    </tr>
    <tr>
        <td>TMP_REPORTKEY</td>
        <td> </td>
        <td>128</td>
        <td>REPORTKEY generated by the instruction.</td>
    </tr>
    <tr>
        <td>TMP_REPORT</td>
        <td> </td>
        <td>3712</td>
        <td> </td>
    </tr>
  </tbody>
</table>

TMP_MODE64 := ((IA32_EFER.LMA = 1) && (CS.L = 1));

(\* Address verification for TARGETINFO (RBX) \*)

IF ( (DS:RBX is not 512Byte Aligned) or (DS:RBX is not within CR_ELRANGE) )
    THEN #GP(0); FI;

IF (DS:RBX does not resolve within an EPC)
    THEN #PF(DS:RBX); FI;

IF (EPCM(DS:RBX).VALID = 0)
    THEN #PF(DS:RBX); FI;

IF (EPCM(DS:RBX).BLOCKED = 1)
    THEN #PF(DS:RBX); FI;

(\* Check page parameters for correctness \*)

IF ( (EPCM(DS:RBX).PT ≠ PT_REG) or (EPCM(DS:RBX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or (EPCM(DS:RBX).PENDING = 1) or
    (EPCM(DS:RBX).MODIFIED = 1) or (EPCM(DS:RBX).ENCLAVEADDRESS ≠ (DS:RBX & ~0FFFH) ) or (EPCM(DS:RBX).R = 0) )

EREPORT—Create a Cryptographic Report of the Enclave

Vol. 3D 41-113

INTEL® SGX INSTRUCTION REFERENCES

```
    THEN #PF(DS:RBX);
FI;

(* Verify RESERVED spaces in TARGETINFO are valid *)
IF (DS:RBX.RESERVED != 0)
    THEN #GP(0); FI;

(* Address verification for REPORTDATA (RCX) *)
IF ( (DS:RCX is not 128Byte Aligned) or (DS:RCX is not within CR_ELRANGE) )
    THEN #GP(0); FI;

IF (DS:RCX does not resolve within an EPC)
    THEN #PF(DS:RCX); FI;

IF (EPCM(DS:RCX).VALID = 0)
    THEN #PF(DS:RCX); FI;

IF (EPCM(DS:RCX).BLOCKED = 1)
    THEN #PF(DS:RCX); FI;

(* Check page parameters for correctness *)
IF ( (EPCM(DS:RCX).PT ≠ PT_REG) or (EPCM(DS:RCX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or (EPCM(DS:RCX).PENDING = 1) or
    (EPCM(DS:RCX).MODIFIED = 1) or (EPCM(DS:RCX).ENCLAVEADDRESS ≠ (DS:RCX & ~0FFFH) ) or (EPCM(DS:RCX).R = 0) )
    THEN #PF(DS:RCX);
FI;

(* Address verification for OUTPUTDATA (RDX) *)
IF ( (DS:RDX is not 512Byte Aligned) or (DS:RDX is not within CR_ELRANGE) )
    THEN #GP(0); FI;

IF (DS:RDX does not resolve within an EPC)
    THEN #PF(DS:RDX); FI;

IF (EPCM(DS:RDX).VALID = 0)
    THEN #PF(DS:RDX); FI;

IF (EPCM(DS:RDX).BLOCKED = 1)
    THEN #PF(DS:RDX); FI;

(* Check page parameters for correctness *)
IF ( (EPCM(DS:RDX).PT ≠ PT_REG) or (EPCM(DS:RDX).ENCLAVESECS ≠ CR_ACTIVE_SECS) or (EPCM(DS:RCX).PENDING = 1) or
    (EPCM(DS:RCX).MODIFIED = 1) or (EPCM(DS:RDX).ENCLAVEADDRESS ≠ (DS:RDX & ~0FFFH) ) or (EPCM(DS:RDX).W = 0) )
    THEN #PF(DS:RDX);
FI;

(* REPORT MAC needs to be computed over data which cannot be modified *)
TMP_REPORT.CPUSVN := CR_CPUSVN;
TMP_REPORT.ISVFAMILYID := TMP_CURRENTSECS.ISVFAMILYID;
TMP_REPORT.ISVEXTPRODID := TMP_CURRENTSECS.ISVEXTPRODID;
TMP_REPORT.ISVPRODID := TMP_CURRENTSECS.ISVPRODID;
TMP_REPORT.ISVSVN := TMP_CURRENTSECS.ISVSVN;
TMP_REPORT.ATTRIBUTES := TMP_CURRENTSECS.ATTRIBUTES;
TMP_REPORT.REPORTDATA := DS:RCX[511:0];
TMP_REPORT.MRENCLAVE := TMP_CURRENTSECS.MRENCLAVE;
```

41-114 Vol. <page_number>41-114</page_number> EREPORT—Create a Cryptographic Report of the Enclave

INTEL® SGX INSTRUCTION REFERENCES

TMP_REPORT.MRSIGNER := TMP_CURRENTSECS.MRSIGNER;
TMP_REPORT.MRRESERVED := 0;
TMP_REPORT.KEYID[255:0] := CR_REPORT_KEYID;
TMP_REPORT.MISCSELECT := TMP_CURRENTSECS.MISCSELECT;
TMP_REPORT.CONFIGID := TMP_CURRENTSECS.CONFIGID;
TMP_REPORT.CONFIGSVN := TMP_CURRENTSECS.CONFIGSVN;
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN TMP_REPORT.CET_ATTRIBUTES := TMP_CURRENTSECS.CET_ATTRIBUTES; FI;

(\* Derive the report key \*)
TMP_KEYDEPENDENCIES.KEYNAME := REPORT_KEY;
TMP_KEYDEPENDENCIES.ISVFAMILYID := 0;
TMP_KEYDEPENDENCIES.ISVEXTPRODID := 0;
TMP_KEYDEPENDENCIES.ISVPRODID := 0;
TMP_KEYDEPENDENCIES.ISVSVN := 0;
TMP_KEYDEPENDENCIES.SGXOWNEREPOCH := CR_SGXOWNEREPOCH;
TMP_KEYDEPENDENCIES.ATTRIBUTES := DS:RBX.ATTRIBUTES;
TMP_KEYDEPENDENCIES.ATTRIBUTESMASK := 0;
TMP_KEYDEPENDENCIES.MRENCLAVE := DS:RBX.MEASUREMENT;
TMP_KEYDEPENDENCIES.MRSIGNER := 0;
TMP_KEYDEPENDENCIES.KEYID := TMP_REPORT.KEYID;
TMP_KEYDEPENDENCIES.SEAL_KEY_FUSES := CR_SEAL_FUSES;
TMP_KEYDEPENDENCIES.CPUSVN := CR_CPUSVN;
TMP_KEYDEPENDENCIES.PADDING := TMP_CURRENTSECS.PADDING;
TMP_KEYDEPENDENCIES.MISCSELECT := DS:RBX.MISCSELECT;
TMP_KEYDEPENDENCIES.MISCMASK := 0;
TMP_KEYDEPENDENCIES.KEYPOLICY := 0;
TMP_KEYDEPENDENCIES.CONFIGID := DS:RBX.CONFIGID;
TMP_KEYDEPENDENCIES.CONFIGSVN := DS:RBX.CONFIGSVN;
IF (CPUID.12H.01H:EAX[6] = 1)
    THEN
        TMP_KEYDEPENDENCIES.CET_ATTRIBUTES := DS:RBX.CET_ATTRIBUTES;
        TMP_KEYDEPENDENCIES.CET_ATTRIBUTES_MASK := 0;
FI;

(\* Calculate the derived key\*)
TMP_REPORTKEY := derivekey(TMP_KEYDEPENDENCIES);

(\* call cryptographic CMAC function, CMAC data are not including MAC&KEYID \*)
TMP_REPORT.MAC := cmac(TMP_REPORTKEY, TMP_REPORT[3071:0] );
DS:RDX[3455: 0] := TMP_REPORT;

## Flags Affected

None

## Protected Mode Exceptions

#GP(0) If executed outside an enclave.
If the address in RCS is outside the DS segment limit.
If a memory operand is not properly aligned.
If a memory operand is not in the current enclave.
#PF(error code) If a page fault occurs in accessing memory operands.

EREPORT—Create a Cryptographic Report of the Enclave

Vol. 3D 41-115

INTEL® SGX INSTRUCTION REFERENCES

## 64-Bit Mode Exceptions

<table>
  <tbody>
    <tr>
        <td rowspan="4">#GP(0)</td>
        <td>If executed outside an enclave.</td>
    </tr>
    <tr>
        <td>If RCX is non-canonical form.</td>
    </tr>
    <tr>
        <td>If a memory operand is not properly aligned.</td>
    </tr>
    <tr>
        <td>If a memory operand is not in the current enclave.</td>
    </tr>
    <tr>
        <td>#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
  </tbody>
</table>

<page_number>41-116</page_number> Vol. EREPORT—Create a Cryptographic Report of the Enclave

INTEL® SGX INSTRUCTION REFERENCES

# ERESUME—Re-Enters an Enclave

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 03H ENCLU[ERESUME]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>SGX1</td>
        <td>This leaf function is used to re-enter an enclave after an interrupt.</td>
    </tr>
  </tbody>
</table>

## Instruction Operand Encoding

<table>
  <thead>
    <tr>
        <th>Op/En</th>
        <th>RAX</th>
        <th>RBX</th>
        <th>RCX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>IR</td>
        <td>ERESUME (In)</td>
        <td>Address of a TCS (In)</td>
        <td>Address of AEP (In)</td>
    </tr>
  </tbody>
</table>

## Description

The ENCLU[ERESUME] instruction resumes execution of an enclave that was interrupted due to an exception or interrupt, using the machine state previously stored in the SSA.

## ERESUME Memory Parameter Semantics

<table>
  <thead>
    <tr>
        <th>TCS</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Enclave read/write access</td>
    </tr>
  </tbody>
</table>

The instruction faults if any of the following occurs:

<table>
  <tbody>
    <tr>
        <td>Address in RBX is not properly aligned.</td>
        <td>Any TCS.FLAGS’s must-be-zero bit is not zero.</td>
    </tr>
    <tr>
        <td>TCS pointed to by RBX is not valid or available or locked.</td>
        <td>Current 32/64 mode does not match the enclave mode in SECS.ATTRIBUTES.MODE64.</td>
    </tr>
    <tr>
        <td>The SECS is in use by another enclave.</td>
        <td>Either of TCS-specified FS and GS segment is not a subset of the current DS segment.</td>
    </tr>
    <tr>
        <td>Any one of DS, ES, CS, SS is not zero.</td>
        <td>If XSAVE available, CR4.OSXSAVE = 0, but SECS.ATTRIBUTES.XFRM ≠ 3.</td>
    </tr>
    <tr>
        <td>CR4.OSFXSR ≠ 1.</td>
        <td>If CR4.OSXSAVE = 1, SECS.ATTRIBUTES.XFRM is not a subset of XCR0.</td>
    </tr>
    <tr>
        <td>Offsets 520-535 of the XSAVE area not 0.</td>
        <td>The bit vector stored at offset 512 of the XSAVE area must be a subset of SECS.ATTRIBUTES.XFRM.</td>
    </tr>
    <tr>
        <td>The SSA frame is not valid or in use.</td>
        <td>If SECS.ATTRIBUTES.AEXNOTIFY ≠ TCS.FLAGS.AEXNOTIFY and TCS.FLAGS.DBGOPTIN = 0.</td>
    </tr>
  </tbody>
</table>

The following operations are performed by ERESUME:

* RSP and RBP are saved in the current SSA frame on EENTER and are automatically restored on EEXIT or an asynchronous exit due to any Interrupt event.

* The AEP contained in RCX is stored into the TCS for use by AEXs. FS and GS (including hidden portions) are saved and new values are constructed using TCS.OFSBASE/GSBASE (32 and 64-bit mode) and TCS.OFSLIMIT/GSLIMIT (32-bit mode only). The resulting segments must be a subset of the DS segment.

* If CR4.OSXSAVE == 1, XCR0 is saved and replaced by SECS.ATTRIBUTES.XFRM. The effect of RFLAGS.TF depends on whether the enclave entry is opt-in or opt-out (see Section 43.1.2):

  - On opt-out entry, TF is saved and cleared (it is restored on EEXIT or AEX). Any attempt to set TF via a POPF instruction while inside the enclave clears TF (see Section 43.2.5).

  - On opt-in entry, a single-step debug exception is pended on the instruction boundary immediately after EENTER (see Section 43.2.3).

* All code breakpoints that do not overlap with ELRANGE are also suppressed. If the entry is an opt-out entry, all code and data breakpoints that overlap with the ELRANGE are suppressed.

ERESUME—Re-Enters an Enclave

Vol. 3D 41-117

INTEL® SGX INSTRUCTION REFERENCES

* On opt-out entry, a number of performance monitoring counters and behaviors are modified or suppressed (see Section 43.2.3):

  — All performance monitoring activity on the current thread is suppressed except for incrementing and firing of FIXED_CTR1 and FIXED_CTR2.

  — PEBS is suppressed.

  — AnyThread counting on other threads is demoted to MyThread mode and IA32_PERF_GLOBAL_STATUS[60] on that thread is set.

  — If the opt-out entry on a hardware thread results in suppression of any performance monitoring, then the processor sets IA32_PERF_GLOBAL_STATUS[60] and IA32_PERF_GLOBAL_STATUS[63].

## Concurrency Restrictions

Table 41-70. Base Concurrency Restrictions of ERESUME

<table>
  <thead>
    <tr>
        <th rowspan="2">Leaf</th>
        <th rowspan="2">Parameter</th>
        <th colspan="2">Base Concurrency Restrictions</th>
    </tr>
    <tr>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ERESUME</td>
        <td>TCS [DS:RBX]</td>
        <td>Shared</td>
        <td>#GP</td>
    </tr>
  </tbody>
</table>

Table 41-71. Additional Concurrency Restrictions of ERESUME

<table>
  <thead>
    <tr>
        <th>Leaf</th>
        <th>Parameter</th>
        <th colspan="6">Additional Concurrency Restrictions</th>
    </tr>
    <tr>
        <th> </th>
        <th> </th>
        <th colspan="2">vs. EACCEPT, EACCEPTCOPY, EMODPE, EMODPR, EMODT</th>
        <th colspan="2">vs. EADD, EEXTEND, EINIT</th>
        <th colspan="2">vs. ETRACK</th>
    </tr>
    <tr>
        <th> </th>
        <th> </th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
        <th>Access</th>
        <th>On Conflict</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>ERESUME</td>
        <td>TCS [DS:RBX]</td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
        <td>Concurrent</td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Operation

Temp Variables in ERESUME Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_FSBASE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Proposed base address for FS segment.</td>
    </tr>
    <tr>
        <td>TMP_GSBASE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Proposed base address for FS segment.</td>
    </tr>
    <tr>
        <td>TMP_FSLIMIT</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Highest legal address in proposed FS segment.</td>
    </tr>
    <tr>
        <td>TMP_GSLIMIT</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Highest legal address in proposed GS segment.</td>
    </tr>
    <tr>
        <td><u>TMP_TARGET</u></td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of first instruction inside enclave at which execution is to resume.</td>
    </tr>
    <tr>
        <td>TMP_SECS</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Physical address of SECS for this enclave.</td>
    </tr>
    <tr>
        <td>TMP_SSA</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of current SSA frame.</td>
    </tr>
    <tr>
        <td>TMP_XSIZE</td>
        <td>integer</td>
        <td>64</td>
        <td>Size of XSAVE area based on SECS.ATTRIBUTES.XFRM.</td>
    </tr>
    <tr>
        <td>TMP_SSA_PAGE</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Pointer used to iterate over the SSA pages in the current frame.</td>
    </tr>
    <tr>
        <td>TMP_GPR</td>
        <td>Effective Address</td>
        <td>32/64</td>
        <td>Address of the GPR area within the current SSA frame.</td>
    </tr>
    <tr>
        <td>TMP_BRANCH_RECORD</td>
        <td>LBR Record</td>
        <td> </td>
        <td>From/to addresses to be pushed onto the LBR stack.</td>
    </tr>
    <tr>
        <td>TMP_NOTIFY</td>
        <td>Boolean</td>
        <td>1</td>
        <td>When set to 1, deliver an AEX notification.</td>
    </tr>
  </tbody>
</table>

TMP_MODE64 := ((IA32_EFER.LMA = 1) && (CS.L = 1));

(\* Make sure DS is usable, expand up \*)
IF (TMP_MODE64 = 0 and (DS not usable or DS[bits 11:9] != 001B))

41-118 Vol.

ERESUME—Re-Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

```
    THEN #GP(0); FI;

(* Check that CS, SS, DS, ES.base is 0 *)
IF (TMP_MODE64 = 0)
    THEN
        IF(CS.base ≠ 0 or DS.base ≠ 0) #GP(0); FI;
        IF(ES usable and ES.base ≠ 0) #GP(0); FI;
        IF(SS usable and SS.base ≠ 0) #GP(0); FI;
        IF(SS usable and SS.B = 0) #GP(0); FI;
FI;

IF (DS:RBX is not 4KByte Aligned)
    THEN #GP(0); FI;

IF (DS:RBX does not resolve within an EPC)
    THEN #PF(DS:RBX); FI;

(* Check AEP is canonical*)
IF (TMP_MODE64 = 1 and (CS:RCX is not canonical))
    THEN #GP(0); FI;

(* Check concurrency of TCS operation*)
IF (Other Intel SGX instructions are operating on TCS)
    THEN #GP(0); FI;

(* TCS verification *)
IF (EPCM(DS:RBX).VALID = 0)
    THEN #PF(DS:RBX); FI;

IF (EPCM(DS:RBX).BLOCKED = 1)
    THEN #PF(DS:RBX); FI;

IF ((EPCM(DS:RBX).PENDING = 1) or (EPCM(DS:RBX).MODIFIED = 1))
    THEN #PF(DS:RBX); FI;

IF ( (EPCM(DS:RBX).ENCLAVEADDRESS ≠ DS:RBX) or (EPCM(DS:RBX).PT ≠ PT_TCS))
    THEN #PF(DS:RBX); FI;

IF ( (DS:RBX).OSSA is not 4KByte Aligned)
    THEN #GP(0); FI;

(* Check proposed FS and GS *)
IF ( ( (DS:RBX).OFSBASE is not 4KByte Aligned) or ( (DS:RBX).OGSBASE is not 4KByte Aligned))
    THEN #GP(0); FI;

(* Get the SECS for the enclave in which the TCS resides *)
TMP_SECS := Address of SECS for TCS;

(* Make sure that the FLAGS field in the TCS does not have any reserved bits set *)
IF ( ( (DS:RBX).FLAGS & FFFFFFFFFFFFFFFCH) ≠ 0)
    THEN #GP(0); FI;

(* SECS must exist and enclave must have previously been EINITted *)
IF (the enclave is not already initialized)
```

ERESUME—Re-Enters an Enclave

Vol. 3D 41-119
<page_number>41-119</page_number>

INTEL® SGX INSTRUCTION REFERENCES

THEN #GP(0); FI;

(\* make sure the logical processor's operating mode matches the enclave \*)
IF ( (TMP_MODE64 ≠ TMP_SECS.ATTRIBUTES.MODE64BIT))
THEN #GP(0); FI;

IF (CR4.OSFXSR = 0)
THEN #GP(0); FI;

(\* Check for legal values of SECS.ATTRIBUTES.XFRM \*)
IF (CR4.OSXSAVE = 0)
THEN
IF (TMP_SECS.ATTRIBUTES.XFRM ≠ 03H) THEN #GP(0); FI;
ELSE
IF ( (TMP_SECS.ATTRIBUTES.XFRM & XCR0) ≠ TMP_SECS.ATTRIBUTES.XFRM) THEN #GP(0); FI;
FI;

IF ( (DS:RBX).CSSA.FLAGS.DBGOPTIN = 0) and (DS:RBX).CSSA.FLAGS.AEXNOTIFY ≠ TMP_SECS.ATTRIBUTES.AEXNOTIFY))
THEN #GP(0); FI;

(\* Make sure the SSA contains at least one active frame \*)
IF ( (DS:RBX).CSSA = 0)
THEN #GP(0); FI;

(\* Compute linear address of SSA frame \*)
TMP_SSA := (DS:RBX).OSSA + TMP_SECS.BASEADDR + 4096 \* TMP_SECS.SSAFRAMESIZE \* ( (DS:RBX).CSSA - 1);
TMP_XSIZE := compute_XSAVE_frame_size(TMP_SECS.ATTRIBUTES.XFRM);

FOR EACH TMP_SSA_PAGE = TMP_SSA to TMP_SSA + TMP_XSIZE
(\* Check page is read/write accessible \*)
Check that DS:TMP_SSA_PAGE is read/write accessible;
If a fault occurs, release locks, abort and deliver that fault;
IF (DS:TMP_SSA_PAGE does not resolve to EPC page)
THEN #PF(DS:TMP_SSA_PAGE); FI;
IF (EPCM(DS:TMP_SSA_PAGE).VALID = 0)
THEN #PF(DS:TMP_SSA_PAGE); FI;
IF (EPCM(DS:TMP_SSA_PAGE).BLOCKED = 1)
THEN #PF(DS:TMP_SSA_PAGE); FI;
IF ((EPCM(DS:TMP_SSA_PAGE).PENDING = 1) or (EPCM(DS:TMP_SSA_PAGE_.MODIFIED = 1))
THEN #PF(DS:TMP_SSA_PAGE); FI;
IF ( ( EPCM(DS:TMP_SSA_PAGE).ENCLAVEADDRESS ≠ DS:TMPSSA_PAGE) or (EPCM(DS:TMP_SSA_PAGE).PT ≠ PT_REG) or
(EPCM(DS:TMP_SSA_PAGE).ENCLAVESECS ≠ EPCM(DS:RBX).ENCLAVESECS) or
(EPCM(DS:TMP_SSA_PAGE).R = 0) or (EPCM(DS:TMP_SSA_PAGE).W = 0) )
THEN #PF(DS:TMP_SSA_PAGE); FI;
CR_XSAVE_PAGE_n := Physical_Address(DS:TMP_SSA_PAGE);
ENDFOR

(\* Compute address of GPR area\*)
TMP_GPR := TMP_SSA + 4096 \* DS:TMP_SECS.SSAFRAMESIZE - sizeof(GPRSGX_AREA);
Check that DS:TMP_SSA_PAGE is read/write accessible;
If a fault occurs, release locks, abort and deliver that fault;
IF (DS:TMP_GPR does not resolve to EPC page)
THEN #PF(DS:TMP_GPR); FI;
IF (EPCM(DS:TMP_GPR).VALID = 0)

<page_number>41-120</page_number> Vol. ERESUME—Re-Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

```
    THEN #PF(DS:TMP_GPR); FI;
IF (EPCM(DS:TMP_GPR).BLOCKED = 1)
    THEN #PF(DS:TMP_GPR); FI;
IF ((EPCM(DS:TMP_GPR).PENDING = 1) or (EPCM(DS:TMP_GPR).MODIFIED = 1))
    THEN #PF(DS:TMP_GPR); FI;
IF ( ( EPCM(DS:TMP_GPR).ENCLAVEADDRESS ≠ DS:TMP_GPR) or (EPCM(DS:TMP_GPR).PT ≠ PT_REG) or
    (EPCM(DS:TMP_GPR).ENCLAVESECS ≠ EPCM(DS:RBX).ENCLAVESECS) or
    (EPCM(DS:TMP_GPR).R = 0) or (EPCM(DS:TMP_GPR).W = 0))
    THEN #PF(DS:TMP_GPR); FI;
```

```
IF (TMP_MODE64 = 0)
    THEN
        IF (TMP_GPR + (GPR_SIZE -1) is not in DS segment) THEN #GP(0); FI;
FI;
```

```
CR_GPR_PA := Physical_Address (DS: TMP_GPR);
```

```
IF ((DS:RBX).FLAGS.AEXNOTIFY = 1) and (DS:TMP_GPR.AEXNOTIFY[0] = 1))
    THEN
        TMP_NOTIFY := 1;
    ELSE
        TMP_NOTIFY := 0;
FI;
```

```
IF (TMP_NOTIFY = 1)
    THEN
        (* Make sure the SSA contains at least one more frame *)
        IF ((DS:RBX).CSSA ≥ (DS:RBX).NSSA)
            THEN #GP(0); FI;
```

```
        TMP_SSA := TMP_SSA + 4096 * TMP_SECS.SSAFRAMESIZE;
        TMP_XSIZE := compute_XSAVE_frame_size(TMP_SECS.ATTRIBUTES.XFRM);
```

```
        FOR EACH TMP_SSA_PAGE = TMP_SSA to TMP_SSA + TMP_XSIZE
            (* Check page is read/write accessible *)
            Check that DS:TMP_SSA_PAGE is read/write accessible;
            If a fault occurs, release locks, abort and deliver that fault;
```

```
            IF (DS:TMP_SSA_PAGE does not resolve to EPC page)
                THEN #PF(DS:TMP_SSA_PAGE); FI;
            IF (EPCM(DS:TMP_SSA_PAGE).VALID = 0)
                THEN #PF(DS:TMP_SSA_PAGE); FI;
            IF (EPCM(DS:TMP_SSA_PAGE).BLOCKED = 1)
                THEN #PF(DS:TMP_SSA_PAGE); FI;
            IF ((EPCM(DS:TMP_SSA_PAGE).PENDING = 1) or
            (EPCM(DS:TMP_SSA_PAGE).MODIFIED = 1))
                THEN #PF(DS:TMP_SSA_PAGE); FI;
            IF ((EPCM(DS:TMP_SSA_PAGE).ENCLAVEADDRESS ≠ DS:TMP_SSA_PAGE) or
            (EPCM(DS:TMP_SSA_PAGE).PT ≠ PT_REG) or
            (EPCM(DS:TMP_SSA_PAGE).ENCLAVESECS ≠ EPCM(DS:RBX).ENCLAVESECS) or
            (EPCM(DS:TMP_SSA_PAGE).R = 0) or (EPCM(DS:TMP_SSA_PAGE).W = 0))
                THEN #PF(DS:TMP_SSA_PAGE); FI;
            CR_XSAVE_PAGE_n := Physical_Address(DS:TMP_SSA_PAGE);
        ENDFOR
```

ERESUME—Re-Enters an Enclave
<page_number>
Vol. 3D 41-121
</page_number>

INTEL® SGX INSTRUCTION REFERENCES

```
(* Compute address of GPR area*)
TMP_GPR := TMP_SSA + 4096 * DS:TMP_SECS.SSAFRAMESIZE - sizeof(GPRSGX_AREA);
If a fault occurs; release locks, abort and deliver that fault;

IF (DS:TMP_GPR does not resolve to EPC page)
    THEN #PF(DS:TMP_GPR); FI;
IF (EPCM(DS:TMP_GPR).VALID = 0)
    THEN #PF(DS:TMP_GPR); FI;
IF (EPCM(DS:TMP_GPR).BLOCKED = 1)
    THEN #PF(DS:TMP_GPR); FI;
IF ((EPCM(DS:TMP_GPR).PENDING = 1) or (EPCM(DS:TMP_GPR).MODIFIED = 1))
    THEN #PF(DS:TMP_GPR); FI;
IF ((EPCM(DS:TMP_GPR).ENCLAVEADDRESS ≠ DS:TMP_GPR) or
(EPCM(DS:TMP_GPR).PT ≠ PT_REG) or
(EPCM(DS:TMP_GPR).ENCLAVESECS ≠ EPCM(DS:RBX).ENCLAVESECS) or
(EPCM(DS:TMP_GPR).R = 0) or (EPCM(DS:TMP_GPR).W = 0))
    THEN #PF(DS:TMP_GPR); FI;

IF (TMP_MODE64 = 0)
    THEN
        IF (TMP_GPR + (GPR_SIZE -1) is not in DS segment) THEN #GP(0); FI;
FI;

CR_GPR_PA := Physical_Address (DS: TMP_GPR);

    TMP_TARGET := (DS:RBX).OENTRY + TMP_SECS.BASEADDR;
ELSE
    TMP_TARGET := (DS:TMP_GPR).RIP;
FI;

IF (TMP_MODE64 = 1)
    THEN
        IF (TMP_TARGET is not canonical) THEN #GP(0); FI;
    ELSE
        IF (TMP_TARGET > CS limit) THEN #GP(0); FI;
FI;

(* Check proposed FS/GS segments fall within DS *)
IF (TMP_MODE64 = 0)
    THEN
        TMP_FSBASE := (DS:RBX).OFSBASE + TMP_SECS.BASEADDR;
        TMP_FSLIMIT := (DS:RBX).OFSBASE + TMP_SECS.BASEADDR + (DS:RBX).FSLIMIT;
        TMP_GSBASE := (DS:RBX).OGSBASE + TMP_SECS.BASEADDR;
        TMP_GSLIMIT := (DS:RBX).OGSBASE + TMP_SECS.BASEADDR + (DS:RBX).GSLIMIT;
        (* if FS wrap-around, make sure DS has no holes*)
        IF (TMP_FSLIMIT < TMP_FSBASE)
            THEN
                IF (DS.limit < 4GB) THEN #GP(0); FI;
            ELSE
                IF (TMP_FSLIMIT > DS.limit) THEN #GP(0); FI;
        FI;
        (* if GS wrap-around, make sure DS has no holes*)
        IF (TMP_GSLIMIT < TMP_GSBASE)
            THEN
```

<page_number>41-122</page_number> Vol. ERESUME—Re-Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

```
            IF (DS.limit < 4GB) THEN #GP(0); FI;
       ELSE
            IF (TMP_GSLIMIT > DS.limit) THEN #GP(0); FI;
   FI;
ELSE
   IF (TMP_NOTIFY = 1)
       THEN
            TMP_FSBASE := (DS:RBX).OFSBASE + TMP_SECS.BASEADDR;
            TMP_GSBASE := (DS:RBX).OGSBASE + TMP_SECS.BASEADDR;
       ELSE
            TMP_FSBASE := DS:TMP_GPR.FSBASE;
            TMP_GSBASE := DS:TMP_GPR.GSBASE;
   FI;
   IF ((TMP_FSBASE is not canonical) or (TMP_GSBASE is not canonical))
       THEN #GP(0); FI;
FI;
```

(\* Ensure the enclave is not already active and this thread is the only one using the TCS\*)
IF (DS:RBX.STATE = ACTIVE))
   THEN #GP(0); FI;

TMP_IA32_U_CET := 0
TMP_SSP := 0

```
IF (CPUID.12H.01H:EAX[6] = 1)
   THEN
   IF ( CR4.CET = 0 )
       THEN
            (* If part does not support CET or CET has not been enabled and enclave requires CET then fail *)
            IF (TMP_SECS.CET_ATTRIBUTES ≠ 0 OR TMP_SECS.CET_LEG_BITMAP_OFFSET ≠ 0) #GP(0); FI;
   FI;
   (* If indirect branch tracking or shadow stacks enabled but CET state save area is not 16B aligned then fail ERESUME *)
   IF (TMP_SECS.CET_ATTRIBUTES.SH_STK_EN = 1 OR TMP_SECS.CET_ATTRIBUTES.ENDBR_EN = 1)
       THEN
            IF (DS:RBX.OCETSSA is not 16B aligned) #GP(0); FI;
   FI;

IF (TMP_SECS.CET_ATTRIBUTES.SH_STK_EN OR TMP_SECS.CET_ATTRIBUTES.ENDBR_EN)
   THEN
   (* Setup CET state from SECS, note tracker goes to IDLE *)
   TMP_IA32_U_CET = TMP_SECS.CET_ATTRIBUTES;
   IF (TMP_IA32_U_CET.LEG_IW_EN = 1 AND TMP_IA32_U_CET.ENDBR_EN = 1)
       THEN
            TMP_IA32_U_CET := TMP_IA32_U_CET + TMP_SECS.BASEADDR;
            TMP_IA32_U_CET := TMP_IA32_U_CET + TMP_SECS.CET_LEG_BITMAP_BASE;
   FI;

   (* Compute linear address of what will become new CET state save area and cache its PA *)
   IF (TMP_NOTIFY = 1)
       THEN
            TMP_CET_SAVE_AREA = DS:RBX.OCETSSA + TMP_SECS.BASEADDR + (DS:RBX.CSSA) * 16;
       ELSE
            TMP_CET_SAVE_AREA = DS:RBX.OCETSSA + TMP_SECS.BASEADDR + (DS:RBX.CSSA - 1) * 16;
   FI;
```

ERESUME—Re-Enters an Enclave Vol. 3D 41-123

INTEL® SGX INSTRUCTION REFERENCES

TMP_CET_SAVE_PAGE = TMP_CET_SAVE_AREA & ~0xFFF;

Check the TMP_CET_SAVE_PAGE page is read/write accessible
If fault occurs release locks, abort and deliver fault

(\* read the EPCM VALID, PENDING, MODIFIED, BLOCKED and PT fields atomically \*)
IF ((DS:TMP_CET_SAVE_PAGE Does NOT RESOLVE TO EPC PAGE) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).VALID = 0) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).PENDING = 1) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).MODIFIED = 1) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).BLOCKED = 1) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).R = 0) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).W = 0) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).ENCLAVEADDRESS ≠ DS:TMP_CET_SAVE_PAGE) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).PT ≠ PT_SS_REST) OR
(EPCM(DS:TMP_CET_SAVE_PAGE).ENCLAVESECS ≠ EPCM(DS:RBX).ENCLAVESECS))
THEN
#PF(DS:TMP_CET_SAVE_PAGE);
FI;

CR_CET_SAVE_AREA_PA := Physical address(DS:TMP_CET_SAVE_AREA)
IF (TMP_NOTIFY = 1)
THEN
IF TMP_IA32_U_CET.SH_STK_EN = 1
THEN TMP_SSP = TCS.PREVSSP; FI;
ELSE
TMP_SSP = CR_CET_SAVE_AREA_PA.SSP
TMP_IA32_U_CET.TRACKER = CR_CET_SAVE_AREA_PA.TRACKER;
TMP_IA32_U_CET.SUPPRESS = CR_CET_SAVE_AREA_PA.SUPPRESS;
IF ( (TMP_MODE64 = 1 AND TMP_SSP is not canonical) OR
(TMP_MODE64 = 0 AND (TMP_SSP & 0xFFFFFFFF00000000) ≠ 0) OR
(TMP_SSP is not 4 byte aligned) OR
(TMP_IA32_U_CET.TRACKER = WAIT_FOR_ENDBRANCH AND TMP_IA32_U_CET.SUPPRESS = 1) OR
(CR_CET_SAVE_AREA_PA.Reserved ≠ 0) ) #GP(0); FI;
FI;
FI;

IF (TMP_NOTIFY = 0)
THEN
(\* SECS.ATTRIBUTES.XFRM selects the features to be saved. \*)
(\* CR_XSAVE_PAGE_n: A list of 1 or more physical address of pages that contain the XSAVE area. \*)
XRSTOR(TMP_MODE64, SECS.ATTRIBUTES.XFRM, CR_XSAVE_PAGE_n);

IF (XRSTOR failed with #GP)
THEN
DS:RBX.STATE := INACTIVE;
#GP(0);
FI;
FI;

CR_ENCLAVE_MODE := 1;
CR_ACTIVE_SECS := TMP_SECS;
CR_ELRANGE := (TMP_SECS.BASEADDR, TMP_SECS.SIZE);

41-124 Vol. ERESUME—Re-Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

```
(* Save sate for possible AEXs *)
CR_TCS_PA := Physical_Address (DS:RBX);
CR_TCS_LA := RBX;
CR_TCS_LA.AEP := RCX;

(* Save the hidden portions of FS and GS *)
CR_SAVE_FS_selector := FS.selector;
CR_SAVE_FS_base := FS.base;
CR_SAVE_FS_limit := FS.limit;
CR_SAVE_FS_access_rights := FS.access_rights;
CR_SAVE_GS_selector := GS.selector;
CR_SAVE_GS_base := GS.base;
CR_SAVE_GS_limit := GS.limit;
CR_SAVE_GS_access_rights := GS.access_rights;

IF (TMP_NOTIFY = 1)
    THEN
        (* If XSAVE is enabled, save XCR0 and replace it with SECS.ATTRIBUTES.XFRM*)
        IF (CR4.OSXSAVE = 1)
            THEN
                CR_SAVE_XCR0 := XCR0;
                XCR0 := TMP_SECS.ATTRIBUTES.XFRM;
        FI;
FI;

RIP := TMP_TARGET;

IF (TMP_NOTIFY = 1)
    THEN
        RCX := RIP;
        RAX := (DS:RBX).CSSA;
        (* Save the outside RSP and RBP so they can be restored on interrupt or EEXIT *)
        DS:TMP_SSA.U_RSP := RSP;
        DS:TMP_SSA.U_RBP := RBP;
    ELSE
        Restore_GPRs from DS:TMP_GPR;

        (*Restore the RFLAGS values from SSA*)
        RFLAGS.CF := DS:TMP_GPR.RFLAGS.CF;
        RFLAGS.PF := DS:TMP_GPR.RFLAGS.PF;
        RFLAGS.AF := DS:TMP_GPR.RFLAGS.AF;
        RFLAGS.ZF := DS:TMP_GPR.RFLAGS.ZF;
        RFLAGS.SF := DS:TMP_GPR.RFLAGS.SF;
        RFLAGS.DF := DS:TMP_GPR.RFLAGS.DF;
        RFLAGS.OF := DS:TMP_GPR.RFLAGS.OF;
        RFLAGS.NT := DS:TMP_GPR.RFLAGS.NT;
        RFLAGS.AC := DS:TMP_GPR.RFLAGS.AC;
        RFLAGS.ID := DS:TMP_GPR.RFLAGS.ID;
        RFLAGS.RF := DS:TMP_GPR.RFLAGS.RF;
        RFLAGS.VM := 0;
        IF (RFLAGS.IOPL = 3)
            THEN RFLAGS.IF := DS:TMP_GPR.RFLAGS.IF; FI;

IF (TCS.FLAGS.OPTIN = 0)
```

ERESUME—Re-Enters an Enclave

Vol. 3D 41-125

INTEL® SGX INSTRUCTION REFERENCES

```
        THEN RFLAGS.TF := 0; FI;

    (* If XSAVE is enabled, save XCR0 and replace it with SECS.ATTRIBUTES.XFRM*)
    IF (CR4.OSXSAVE = 1)
        THEN
            CR_SAVE_XCR0 := XCR0;
            XCR0 := TMP_SECS.ATTRIBUTES.XFRM;
    FI;

    (* Pop the SSA stack*)
    (DS:RBX).CSSA := (DS:RBX).CSSA -1;
FI;

(* Do the FS/GS swap *)
FS.base := TMP_FSBASE;
FS.limit := DS:RBX.FSLIMIT;
FS.type := 0001b;
FS.W := DS[bit 9];
FS.S := 1;
FS.DPL := DS.DPL;
FS.G := 1;
FS.B := 1;
FS.P := 1;
FS.AVL := DS.AVL;
FS.L := DS[bit 21];
FS.unusable := 0;
FS.selector := 0BH;
```

```
GS.base := TMP_GSBASE;
GS.limit := DS:RBX.GSLIMIT;
GS.type := 0001b;
GS.W := DS[bit 9];
GS.S := 1;
GS.DPL := DS.DPL;
GS.G := 1;
GS.B := 1;
GS.P := 1;
GS.AVL := DS.AVL;
GS.L := DS[bit 21];
GS.unusable := 0;
GS.selector := 0BH;
```

```
CR_DBGOPTIN := TCS.FLAGS.DBGOPTIN;
Suppress all code breakpoints that are outside ELRANGE;
```

```
IF (CR_DBGOPTIN = 0)
    THEN
        Suppress all code breakpoints that overlap with ELRANGE;
        CR_SAVE_TF := RFLAGS.TF;
        RFLAGS.TF := 0;
        Suppress any MTF VM exits during execution of the enclave;
        Clear all pending debug exceptions;
        Clear any pending MTF VM exit;
    ELSE
```

41-126 Vol. ERESUME—Re-Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

```
IF (TMP_NOTIFY = 1)
    THEN
        IF RFLAGS.TF = 1
            THEN pend a single-step #DB at the end of ERESUME; FI;
        IF the “monitor trap flag” VM-execution control is set
            THEN pend an MTF VM exit at the end of ERESUME; FI;
    ELSE
        Clear all pending debug exceptions;
        Clear pending MTF VM exits;
FI;
FI;

IF ((CPUID.07H.00H:EDX.CET_IBT = 1) OR (CPUID.07H.00H:ECX.CET_SS = 1)
    THEN
    (* Save enclosing application CET state into save registers *)
    CR_SAVE_IA32_U_CET := IA32_U_CET
    (* Setup enclave CET state *)
IF CPUID.07H.00H:ECX.CET_SS = 1
    THEN
        CR_SAVE_SSP := SSP
        SSP := TMP_SSP;
    FI;
    IA32_U_CET := TMP_IA32_U_CET;
FI;

(* Assure consistent translations *)
Flush_linear_context;
Clear_Monitor_FSM;
Allow_front_end_to_begin_fetch_at_new_RIP;
```

## Flags Affected

RFLAGS.TF is cleared on opt-out entry

## Protected Mode Exceptions

<table>
  <tbody>
    <tr>
        <td rowspan="12">#GP(0)</td>
        <td>If DS:RBX is not page aligned.</td>
    </tr>
    <tr>
        <td>If the enclave is not initialized.</td>
    </tr>
    <tr>
        <td>If the thread is not in the INACTIVE state.</td>
    </tr>
    <tr>
        <td>If CS, DS, ES or SS bases are not all zero.</td>
    </tr>
    <tr>
        <td>If executed in enclave mode.</td>
    </tr>
    <tr>
        <td>If part or all of the FS or GS segment specified by TCS is outside the DS segment.</td>
    </tr>
    <tr>
        <td>If any reserved field in the TCS FLAG is set.</td>
    </tr>
    <tr>
        <td>If the target address is not within the CS segment.</td>
    </tr>
    <tr>
        <td>If CR4.OSFXSR = 0.</td>
    </tr>
    <tr>
        <td>If CR4.OSXSAVE = 0 and SECS.ATTRIBUTES.XFRM ≠ 3.</td>
    </tr>
    <tr>
        <td>If CR4.OSXSAVE = 1and SECS.ATTRIBUTES.XFRM is not a subset of XCR0.</td>
    </tr>
    <tr>
        <td>If SECS.ATTRIBUTES.AEXNOTIFY ≠ TCS.FLAGS.AEXNOTIFY and TCS.FLAGS.DBGOPTIN = 0.</td>
    </tr>
    <tr>
        <td rowspan="3">#PF(error code)</td>
        <td>If a page fault occurs in accessing memory.</td>
    </tr>
    <tr>
        <td>If DS:RBX does not point to a valid TCS.</td>
    </tr>
    <tr>
        <td>If one or more pages of the current SSA frame are not readable/writable, or do not resolve to a valid PT_REG EPC page.</td>
    </tr>
  </tbody>
</table>

ERESUME—Re-Enters an Enclave Vol. 3D 41-127

INTEL® SGX INSTRUCTION REFERENCES

## 64-Bit Mode Exceptions

<table>
    <tr>
        <td>#GP(0)</td>
        <td>If DS:RBX is not page aligned.</td>
    </tr>
    <tr>
        <td></td>
        <td>If the enclave is not initialized.</td>
    </tr>
    <tr>
        <td></td>
        <td>If the thread is not in the INACTIVE state.</td>
    </tr>
    <tr>
        <td></td>
        <td>If CS, DS, ES or SS bases are not all zero.</td>
    </tr>
    <tr>
        <td></td>
        <td>If executed in enclave mode.</td>
    </tr>
    <tr>
        <td></td>
        <td>If part or all of the FS or GS segment specified by TCS is outside the DS segment.</td>
    </tr>
    <tr>
        <td></td>
        <td>If any reserved field in the TCS FLAG is set.</td>
    </tr>
    <tr>
        <td></td>
        <td>If the target address is not canonical.</td>
    </tr>
    <tr>
        <td></td>
        <td>If CR4.OSFXSR = 0.</td>
    </tr>
    <tr>
        <td></td>
        <td>If CR4.OSXSAVE = 0 and SECS.ATTRIBUTES.XFRM ≠ 3.</td>
    </tr>
    <tr>
        <td></td>
        <td>If CR4.OSXSAVE = 1 and SECS.ATTRIBUTES.XFRM is not a subset of XCR0.</td>
    </tr>
    <tr>
        <td></td>
        <td>If SECS.ATTRIBUTES.AEXNOTIFY ≠ TCS.FLAGS.AEXNOTIFY and TCS.FLAGS.DBGOPTIN = 0.</td>
    </tr>
    <tr>
        <td>#PF(error code)</td>
        <td>If a page fault occurs in accessing memory operands.</td>
    </tr>
    <tr>
        <td></td>
        <td>If DS:RBX does not point to a valid TCS.</td>
    </tr>
    <tr>
        <td></td>
        <td>If one or more pages of the current SSA frame are not readable/writable, or do not resolve to a valid PT_REG EPC page.</td>
    </tr>
</table>

41-128 Vol.

ERESUME—Re-Enters an Enclave

INTEL® SGX INSTRUCTION REFERENCES

# EVERIFYREPORT2—Verify a Cryptographic Report Created by SEAMREPORT

<table>
  <thead>
    <tr>
        <th>Opcode/ Instruction</th>
        <th>Op/En</th>
        <th>64/32 bit Mode Support</th>
        <th>CPUID Feature Flag</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EAX = 08H ENCLU[EVERIFYREPORT2]</td>
        <td>IR</td>
        <td>V/V</td>
        <td>EVERIFYREPORT2</td>
        <td>This leaf function verifies a cryptographic report of the TD. RBX holds the address of a REPORTMACSTRUCT.</td>
    </tr>
  </tbody>
</table>

## EVERIFYREPORT2 Instruction Layout

<table>
  <thead>
    <tr>
        <th>Instruction</th>
        <th>EAX</th>
        <th>RBX</th>
        <th>RCX</th>
        <th>RDX</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>EVERIFYREPORT2</td>
        <td>08H</td>
        <td>REPORTMACSTRUCT effective address.</td>
        <td> </td>
        <td> </td>
    </tr>
  </tbody>
</table>

## Description

This instruction verifies REPORTMACSTRUCT, which is part of a cryptographic report of a TDX trust domain (TD), created by execution of the SEAMREPORT operation of the SEAMOPS instruction (see Section 35.5 of Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 3C).

REPORTMACSTRUCT is a 256-byte data structure at the effective address provided in RBX. The first 224 bytes contain information about the TD being reported, including the value of CR_CPUSVN when the report was created (bytes 31:16). The last 32 bytes (bytes 255:224) contain the 256-bit MAC value. The MAC is computed over the first 224 bytes using HMAC-SHA-256 algorithm with CR_REPORT_MAC_KEY (see Section 41.1.4).

For more details about REPORTMACSTRUCT, see Section “Report MAC Structure (REPORTMACSTRUCT)” in the Intel® Architecture Instruction Set Extensions and Future Features Programming Reference.

## Operation

### Temp Variables in EVERIFYREPORT2 Operational Flow

<table>
  <thead>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Size</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>TMP_CURRENTSECS</td>
        <td>Effective Address</td>
        <td>32/64 Bytes</td>
        <td>The address of the SECS for the currently executing enclave.</td>
    </tr>
    <tr>
        <td>TMP_REPORTMACSTRUCT</td>
        <td>REPORTMACSTRUCT</td>
        <td>256 Bytes</td>
        <td>Cryptographic Report of the TEE.</td>
    </tr>
    <tr>
        <td>TMP_MAC</td>
        <td>MAC</td>
        <td>32 Bytes</td>
        <td>MAC over REPORT calculated by instruction.</td>
    </tr>
  </tbody>
</table>

RFLAGS.ZF,CF,PF,AF,OF,SF := 0;

RAX := 0;

(\* verify REPORTMACSTRUCT address (RBX) \*)

IF ((DS:RBX is not 4KB-aligned) or (DS:RBX is not within CR_ELRANGE))

THEN #GP(0); FI;

(\* check page parameters for correctness \*)

IF (DS:RBX does not resolve within an EPC)

or (EPCM(DS:RBX).VALID = 0)

or (EPCM(DS:RBX).BLOCKED = 1))

or (EPCM(DS:RBX).PENDING = 1)

or (EPCM(DS:RBX).MODIFIED = 1)

or (EPCM(DS:RBX).PT ≠ PT_REG)

or (EPCM(DS:RBX).ENCLAVESECS ≠ CR_ACTIVE_SECS)

or (EPCM(DS:RBX).ENCLAVEADDRESS ≠ (DS:RBX & ~0FFFH))

or (EPCM(DS:RBX).R = 0))

EVERIFYREPORT2—Verify a Cryptographic Report Created by SEAMREPORT Vol. 3D 41-129

INTEL® SGX INSTRUCTION REFERENCES

```
    THEN #PF(DS:RBX);
FI;

(* get a temp copy of input REPORTMACSTRUCT *)
TMP_REPORTMACSTRUCT[255:0B] = DS:RBX[255:0B];

(* verify CPUSVN *)
IF (TMP_REPORTMACSTRUCT[31:16B] ≠ CR_CPUSVN)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_INVALID_CPUSVN;
        GOTO ERROR_EXIT;
FI;

(* verify MAC *)
TMP_MAC = HMAC-SHA256(CR_REPORT_MAC_KEY, TMP_REPORTMACSTRUCT[223:0B], 224);
IF (TMP_REPORTMACSTRUCT[255:224B] ≠ TMP_MAC)
    THEN
        RFLAGS.ZF := 1;
        RAX := SGX_INVALID_REPORTMACSTRUCT;
FI;
```

ERROR_EXIT:

## Flags Affected

None.

## Protected Mode Exceptions

**#GP(0)**: If a memory operand effective address is outside the DS segment limit.
If DS segment is unusable.
If a memory operand is not properly aligned.
**#PF(fault-code)**: If a page fault occurs in accessing memory operands, including EPCM-induced faults.

## 64-Bit Mode Exceptions

**#GP(0)**: If a memory address is in a non-canonical form.
If a memory operand is not properly aligned.
**#PF(fault-code)**: If a page fault occurs in accessing memory operands, including EPCM-induced faults.

## Error Codes

* SGX_INVALID_CPUSVN (32): If REPOSRTMACSTRUC.CPUSVN is an unsupported value.

* SGX_INVALID_REPORTMACSTRUCT (28): MAC verification failed.

<page_number>

41-130
</page_number>

Vol. EVERIFYREPORT2—Verify a Cryptographic Report Created by SEAMREPORT

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

# CHAPTER 42
# <u>INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE</u>

Intel® SGX provides Intel® Architecture with a collection of enclave instructions for creating protected execution environments on processors supporting IA32 and Intel® 64 architectures. These Intel SGX instructions are designed to work with legacy software and the various IA32 and Intel 64 modes of operation.

## 42.1 INTEL® SGX AVAILABILITY IN VARIOUS PROCESSOR MODES

The Intel SGX extensions (see Table 37-1) are available only when the processor is executing in protected mode of operation. Additionally, the extensions are not available in System Management Mode (SMM) of operation or in Virtual 8086 (VM86) mode of operation. Finally, all leaf functions of ENCLU and ENCLS require CR0.PG enabled.

The exact details of exceptions resulting from illegal modes and their priority are listed in the reference pages of ENCLS and ENCLU.

## 42.2 IA32_FEATURE_CONTROL

IA32_FEATURE_CONTROL MSR provides two new bits related to two aspects of Intel SGX: using the instruction extensions and launch control configuration.

### 42.2.1 Availability of Intel SGX

IA32_FEATURE_CONTROL[bit 18] allows BIOS to control the availability of Intel SGX extensions. For Intel SGX extensions to be available on a logical processor, bit 18 in the IA32_FEATURE_CONTROL MSR on that logical processor must be set, and IA32_FEATURE_CONTROL MSR on that logical processor must be locked (bit 0 must be set). See Section 37.7.1 for additional details. OS is expected to examine the value of bit 18 prior to enabling Intel SGX on the thread, as the settings of bit 18 is not reflected by CPUID.

### 42.2.2 Intel SGX Launch Control Configuration

The IA32_SGXLEPUBKEYHASHn MSRs used to configure authorized launch enclaves' MRSIGNER digest value. They are present on logical processors that support the collection of SGX1 leaf functions (i.e., CPUID.12H.00H:EAX[0] = 1) and that CPUID.07H.00H:ECX[30] = 1. IA32_FEATURE_CONTROL[bit 17] allows to BIOS to enable write access to these MSRs. If IA32_FEATURE_CONTROL.LE_WR (bit 17) is set to 1 and IA32_FEATURE_CONTROL is locked on that logical processor, IA32_SGXLEPUBKEYHASH MSRs on that logical processor are writeable. If this bit 17 is not set or IA32_FEATURE_CONTROL is not locked, IA32_SGXLEPUBKEYHASH MSRs are read only. See Section 39.1.4 for additional details.

## 42.3 INTERACTIONS WITH SEGMENTATION

### 42.3.1 Scope of Interaction

Intel SGX extensions are available only when the processor is executing in a protected mode operation (see Section 42.1 for Intel SGX availability in various processor modes). Enclaves abide by all the segmentation policies set up by the OS, but they can be more restrictive than the OS.

Intel SGX interacts with segmentation at two levels:

* The Intel SGX instruction (see the enclave instruction in Table 37-1).

Vol. 3D 42-1
<page_number>42-1</page_number>

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

* While executing inside an enclave (legacy instructions and enclave instructions permitted inside an enclave).

## 42.3.2 Interactions of Intel® SGX Instructions with Segment, Operand, and Addressing Prefixes

All the memory operands used by the Intel SGX instructions are interpreted as offsets within the data segment (DS). The segment-override prefix on Intel SGX instructions is ignored.

Operand size is fixed for each enclave instruction. The operand-size prefix is reserved, and results in a #UD exception if used.

All address sizes are determined by the operating mode of the processor. The address-size prefix is ignored. This implies that while operating in 64-bit mode of operation, the address size is always 64 bits, and while operating in 32-bit mode of operation, the address size is always 32 bits. Additionally, when operating in 16-bit addressing, memory operands used by enclave instructions use 32 bit addressing; the value of CS.D is ignored.

## 42.3.3 Interaction of Intel® SGX Instructions with Segmentation

All leaf functions of ENCLU and ENCLS instructions require that the DS segment be usable, and be an expand-up segment. Failing this check results in generation of a #GP(0) exception.

The Intel SGX leaf functions used for entering the enclave (ENCLU[EENTER] and ENCLU[ERESUME]) operate as follows:

* All usable segment registers except for FS and GS have a zero base.

* The contents of the FS/GS segment registers (including the hidden portion) is saved in the processor.

* New FS and GS values compatible with enclave security are loaded from the TCS

* The linear ranges and access rights available under the newly-loaded FS and GS must abide to OS policies by ensuring they are subsets of the linear-address range and access rights available for the DS segment.

* The CS segment mode (64-bit, compatible, or 32 bit modes) must be consistent with the segment mode for which the enclave was created, as indicated by the SECS.ATTRIBUTES.MODE64 bit, and that the CPL of the logical processor is 3

An exit from the enclave either via ENCLU[EEXIT] or via an AEX restores the saved values of FS/GS segment registers.

## 42.3.4 Interactions of Enclave Execution with Segmentation

During the course of execution, enclave code abides by all segmentation policies as dictated by IA32 and Intel 64 Architectures, and generates appropriate exceptions on violations.

Additionally, any attempt by software executing inside an enclave to modify the processor's segmentation state (e.g., via MOV seg register, POP seg register, LDS, far jump, etc; excluding WRFSBASE/WRGSBASE) results in the generation of a #UD. See Section 39.6.1 for more information.

Upon enclave entry via the EENTER leaf function, FS is loaded from the (TCS.OFSBASE + SECS.BASEADDR) and TCS.FSLIMIT fields and GS is loaded from the (TCS.OGSBASE + SECS.BASEADDR) and TCS.GSLIMIT fields.

Execution of WRFSBASE and WRGSBASE from inside a 64-bit enclave is allowed. The processor will save the new values into the current SSA frame on an asynchronous exit (AEX) and restore them back on enclave entry via ENCLU[ERESUME] instruction.

# 42.4 INTERACTIONS WITH PAGING

Intel SGX instructions are available only when the processor is executing in a protected mode of operation. Additionally, all Intel SGX leaf functions except for EDBGRD and EDBGWR are available only if paging is enabled. Any attempt to execute these leaf functions with paging disabled results in an invalid-opcode exception (#UD). As with

42-2 Vol. 3D

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

segmentation, enclaves abide by all the paging policies set up by the OS, but they can be more restrictive than the OS.

All the memory operands passed into Intel SGX instructions are interpreted as offsets within the DS segment, and the linear addresses generated by combining these offsets with DS segment register are subject to paging-based access control if paging is enabled at the time of the execution of the leaf function.

Since the ENCLU[EENTER] and ENCLU[ERESUME] can only be executed when paging is enabled, and since paging cannot be disabled by software running inside an enclave (recall that enclaves always run with CPL = 3), enclave execution is always subject to paging-based access control. The Intel SGX access control itself is implemented as an extension to the existing paging modes. See Section 38.5 for details.

Execution of Intel SGX instructions may set accessed and dirty flags on accesses to EPC pages that do not fault even if the instruction later causes a fault for some other reason.

## 42.5 INTERACTIONS WITH VMX

Intel SGX functionality (including SGX1 and SGX2) can be made available to software running in either VMX root operation or VMX non-root operation, as long as the processor is using a legal mode of operation (see Section 42.1).

A VMM has the flexibility to configure a VMCS to permit a guest to use any subset of the ENCLS leaf functions. Availability of the ENCLU leaf functions in VMX non-root operation has the same requirement as ENCLU leaf functions outside of a virtualized environment.

Details of the VMCS control to allow VMM to configure support of Intel SGX in VMX non-root operation is described in Section 42.5.1

### 42.5.1 VMM Controls to Configure Guest Support of Intel® SGX

Intel SGX capabilities are primarily exposed to the software via the CPUID instruction. VMMs can virtualize CPUID instruction to expose/hide this capability to/from guests.

Some of Intel SGX resources are exposed/controlled via model-specific registers (see Section 37.7). VMMs can virtualize these MSRs for the guests using the MSR bitmaps referenced by pointers in the VMCS.

The VMM can partition the Enclave Page Cache, and assign various partitions to (a subset of) its guests via the usual memory-virtualization techniques such as paging or the extended page table mechanism (EPT).

The VMM can set the "enable ENCLS exiting" VM-execution controls to cause a VM exit when the ENCLS instruction is executed in VMX non-root operation. If the "enable ENCLS exiting" control is 0, all of the ENCLS leaf functions are permitted in VMX non-root operation. If the "enable ENCLS exiting" control is 1, execution of ENCLS leaf functions in VMX non-root operation is governed by consulting the bits in a new 64-bit VM-execution control field called the ENCLS-exiting bitmap (Each bit in the bitmap corresponds to an ENCLS leaf function with an EAX value that is identical to the bit's position). When bits in the "ENCLS-exiting bitmap" are set, attempts to execute the corresponding ENCLS leaf functions in VMX non-root operation causes VM exits. The checking for these VM exits occurs immediately after checking that CPL = 0.

### 42.5.2 Interactions with the Extended Page Table Mechanism (EPT)

Intel SGX instructions are fully compatible with the extended page-table mechanism (EPT; see Section 31.3).

All the memory operands passed into Intel SGX instructions are interpreted as offsets within the DS segment, and the linear addresses generated by combining these offsets with DS segment register are subject to paging and EPT. As with paging, enclaves abide by all the policies set up by the VMM.

The Intel SGX access control itself is implemented as an extension to paging and EPT, and may be more restrictive. See Section 42.4 for details of this extension.

An execution of an Intel SGX instruction may set accessed and dirty flags for EPT (when enabled; see Section 31.3.5) on accesses to EPC pages that do not fault or cause VM exits even if the instruction later causes a fault or VM exit for some other reason.

Vol. 3D 42-3

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

## 42.5.3 Interactions with APIC Virtualization

This section applies to Intel SGX in VMX non-root operation when the “virtualize APIC accesses” VM-execution control is 1.

A memory access by an enclave instruction that implicitly uses a cached physical address is never checked for overlap with the APIC-access page. Such accesses never cause APIC-access VM exits and are never redirected to the virtual-APIC page. Implicit memory accesses can only be made to the SECS, the TCS, or the SSA of an enclave (see Section 38.5.3.2).

An explicit Enclave Access (a linear memory access which is either from within an enclave into its ELRANGE, or an access by an Intel SGX instruction that is expected to be in the EPC) that overlaps with the APIC-access page causes a #PF exception (APIC page is expected to be outside of EPC).

Non-Enclave accesses made either by an Intel SGX instruction or by a logical processor inside an enclave to an address that without SGX would have caused redirection to the virtual-APIC page instead cause an APIC-access VM exit.

Other than implicit accesses made by Intel SGX instructions, guest-physical and physical accesses are not considered “enclave accesses”; consequently, such accesses result in undefined behavior if these accesses eventually reach EPC. This applies to any non-enclave physical accesses.

While a logical processor is executing inside an enclave, an attempt to execute an instruction outside of ELRANGE results in a #GP(0), even if the linear address would translate to a physical address that overlaps the APIC-access page.

## 42.6 INTEL® SGX INTERACTIONS WITH ARCHITECTURALLY-VISIBLE EVENTS

All architecturally visible events (exceptions, interrupts, SMI, NMI, INIT, VM exit) can be detected while inside an enclave and will cause an asynchronous enclave exit if they are not blocked. Additionally, INT3, and the SignalTXTMsg[SENTER] (i.e., GETSEC[SENTER]’s rendezvous event message) events also cause asynchronous enclave exits. Note that SignalTXTMsg[SEXIT] (i.e., GETSEC[SEXIT]’s teardown message) does not cause an AEX.

On an AEX, information about the event causing the AEX is stored in the SSA (see Section 40.4 for details of AEX). The information stored in the SSA only describes the first event that triggered the AEX. If parsing/delivery of the first event results in detection of further events (e.g., VM exit, double fault, etc.), then the event information in the SSA is not updated to reflect these subsequently detected events.

## 42.7 INTERACTIONS WITH THE PROCESSOR EXTENDED STATE AND MISCELLANEOUS STATE

### 42.7.1 Requirements and Architecture Overview

Processor extended states are the ISA features that are enabled by the settings of CR4.OSXSAVE and the XCR0 register. Processor extended states are normally saved/restored by software via XSAVE/XRSTOR instructions. Details of discovery of processor extended states and management of these states are described in Chapter 13 of Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1.

Additionally, the following requirements apply to Intel SGX:

* On an AEX, the Intel SGX architecture must protect the processor extended state and miscellaneous state by saving them in the enclave’s state-save area (SSA), and clear the secrets from the processor extended state that is used by an enclave.

* Intel SGX architecture must verify that the SSA frame size is large enough to contain all the processor extended states and miscellaneous state used by the enclave.

* Intel SGX architecture must ensure that enclaves can only use processor extended state that is enabled by system software in XCR0.

42-4 Vol. 3D

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

* Enclave software should be able to discover only those processor extended state and miscellaneous state for which such protection is enabled.

* The processor extended states that are enabled inside the enclave must be approved by the enclave developer:

  — Certain processor extended state (e.g., Memory Protection Extensions, see Appendix E, “Intel® Memory Protection Extensions,” of the Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 1) modify the behavior of the legacy ISA software. If such features are enabled for enclaves that do not understand those features, then such a configuration could lead to a compromise of the enclave's security.

* The processor extended states that are enabled inside the enclave must form an integral part of the enclave's identity. This requirement has two implications:

  — Service providers may decide to assign different trust level to the same enclave depending on the ISA features the enclave is using.

To meet these requirements, the Intel SGX architecture defines a sub-field called X-Feature Request Mask (XFRM) in the ATTRIBUTES field of the SECS. On enclave creation (ENCLS[ECREATE] leaf function), the required SSA frame size is calculated by the processor from the list of enabled extended and miscellaneous states and verified against the actual SSA frame size defined by SECS.SSAFRAMESIZE.

On enclave entry, after verifying that XFRM is only enabling features that are already enabled in XCR0, the value in the XCR0 is saved internally by the processor, and is replaced by the XFRM. On enclave exit, the original value of XCR0 is restored. Consequently, while inside the enclave, the processor extended states enabled in XFRM are in enabled state, and those that are disabled in XFRM are in disabled state.

The entire ATTRIBUTES field, including the XFRM subfield is integral part of enclave's identity (i.e., its value is included in reports generated by ENCLU[EREPORT], and select bits from this field can be included in key-derivation for keys obtained via the ENCLU[EGETKEY] leaf function).

Enclave developers can create their enclave to work with certain features and fallback to another code path in case those features aren't available (e.g., optimize for AVX and fallback to SSE). For this purpose Intel SGX provides the following fields in SIGSTRUCT: ATTRIBUTES, ATTRIBUTESMASK, MISCSELECT, and MISCMASK. EINIT ensures that the final SECS.ATTRIBUTES and SECS.MISCSELECT comply with the enclave developer's requirements as follows:

SIGSTRUCT.ATTRIBUTES & SIGSTRUCT.ATTRIBUTEMASK = SECS.ATTRIBUTES & SIGSTRUCT.ATTRIBUTEMASK
SIGSTRUCT.MISCSELECT & SIGSTRUCT.MISCMASK = SECS.MISCSELECT & SIGSTRUCT.MISCMASK.

On an asynchronous enclave exit, the processor extended states enabled by XFRM are saved in the current SSA frame, and overwritten by synthetic state (see Section 40.3 for the definition of the synthetic state). When the interrupted enclave is resumed via the ENCLU[ERESUME] leaf function, the saved state for processor extended states enabled by XFRM is restored.

## 42.7.2 Relevant Fields in Various Data Structures

### 42.7.2.1 SECS.ATTRIBUTES.XFRM

The ATTRIBUTES field of the SECS data structure (see Section 38.7) contains a sub-field called XSAVE-Feature Request Mask (XFRM). Software populates this field at the time of enclave creation according to the features that are enabled by the operating system and approved by the enclave developer.

Intel SGX architecture guarantees that during enclave execution, the processor extended state configuration of the processor is identical to what is required by the XFRM sub-field. All the processor extended states enabled in XFRM are saved on AEX from the enclave and restored on ERESUME.

The XFRM sub-field has the same layout as XCR0, and has consistency requirements that are similar to those for XCR0. Specifically, the consistency requirements on XFRM values depend on the processor implementation and the set of features enabled in CR4.

Legal values for SECS.ATTRIBUTES.XFRM conform to these requirements:

* XFRM[1:0] must be set to 0x3.

* If the processor does not support XSAVE, or if the system software has not enabled XSAVE, then XFRM[63:2] must be zero.

* If the processor does support XSAVE, XFRM must contain a value that would be legal if loaded into XCR0.

Vol. 3D 42-5

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

The various consistency requirements are enforced at different times in the enclave's life cycle, and the exact enforcement mechanisms are elaborated in Section 42.7.3 through Section 42.7.6.

On processors not supporting XSAVE, software should initialize XFRM to 0x3. On processors supporting XSAVE, software should initialize XFRM to be a subset of XCR0 that would be present at the time of enclave execution. Because bits 0 and 1 of XFRM must always be set, the use of Intel SGX requires that SSE be enabled (CR4.OSFXSR = 1).

## 42.7.2.2 SECS.SSAFRAMESIZE

The SSAFRAMESIZE field in the SECS data structure specifies the number of pages which software allocated<sup>1</sup> for each SSA frame, including both the GPRSGX area, MISC area, the XSAVE area (x87 and XMM states are stored in the latter area), and optionally padding between the MISC and XSAVE area. The GPRSGX area must hold all the general-purpose registers and additional Intel SGX specific information. The MISC area must hold the Miscellaneous state as specified by SECS.MISCSELECT, the XSAVE area holds the set of processor extended states specified by SECS.ATTRIBUTES.XFRM (see Section 38.9 for the layout of SSA and Section 42.7.3 for ECREATE's consistency checks). The SSA is always in non-compacted format.

If the processor does not support XSAVE, the XSAVE area will always be 576 bytes; a copy of XFRM (which will be set to 0x3) is saved at offset 512 on an AEX.

If the processor does support XSAVE, the length of the XSAVE area depends on SECS.ATTRIBUTES.XFRM. The length would be equal to what CPUID.0DH.00H:EBX would return if XCR0 were set to XFRM. The following pseudo code illustrates how software can calculate this length using XFRM as the input parameter without modifying XCR0:

```
offset = 576;
size_last_x = 0;
For x=2 to 63
    IF (XFRM[x] != 0) Then
        tmp_offset = CPUID.0DH.x:EBX[31:0];
        IF (tmp_offset >= offset + size_last_x) Then
            offset = tmp_offset;
            size_last_x = CPUID.0DH.x:EAX[31:0];
        FI;
    FI;
EndFor
return (offset + size_last_x); (* compute_xsave_size(XFRM), see “ECREATE—Create an SECS page in the Enclave Page Cache”*)
```

Where the non-zero bits in XFRM are a subset of non-zero bit fields in XCR0.

The size of the MISC region depends on the setting of SECS.MISCSELECT and can be calculated using the layout information described in Section 38.9.2

## 42.7.2.3 XSAVE Area in SSA

The XSAVE area of an SSA frame begins at offset 0 of the frame.

## 42.7.2.4 MISC Area in SSA

The MISC area of an SSA frame is positioned immediately before the GPRSGX region.

## 42.7.2.5 SIGSTRUCT Fields

Intel SGX provides the flexibility for an enclave developer to choose the enclave's code path according to the features that are enabled on the platform (e.g., optimize for AVX and fallback to SSE). See Section 42.7.1 for details.

<sup>1.</sup> It is the responsibility of the enclave to actually allocate this memory.

42-6 Vol. 3D

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

SIGSTRUCT includes the following fields:

SIGSTRUCT.ATTRIBUTES, SIGSTRUCT.ATTRIBUTEMASK, SIGSTRUCT.MISCSELECT, SIGSTRUCT.MISCMASK.

## 42.7.2.6 REPORT.ATTRIBUTES.XFRM and REPORT.MISCSELECT

The processor extended states and miscellaneous states that are enabled inside the enclave form an integral part of the enclave's identity and are therefore included in the enclave's report, as provided by the ENCLU[EREPORT] leaf function. The REPORT structure includes the enclave's XFRM and MISCSELECT configurations.

## 42.7.2.7 KEYREQUEST

An enclave developer can specify which bits out of XFRM and MISCSELECT ENCLU[EGETKEY] should include in the derivation of the sealing key by specifying ATTRIBUTESMASK and MISCMASK in the KEYREQUEST structure.

## 42.7.3 Processor Extended States and ENCLS[ECREATE]

The ECREATE leaf function of the ENCLS instruction enforces a number of consistency checks described earlier. The execution of ENCLS[ECREATE] leaf function results in a #GP(0) in any of the following cases:

* SECS.ATTRIBUTES.XFRM[1:0] is not 3.

* The processor does not support XSAVE and any of the following is true:

    - SECS.ATTRIBUTES.XFRM[63:2] is not 0.

    - SECS.SSAFRAMESIZE is 0.

* The processor supports XSAVE and any of the following is true:

    - XSETBV would fault on an attempt to load XFRM into XCR0.

    - XFRM[63]=1.

    - The SSAFRAME is too small to hold required, enabled states (see Section 42.7.2.2).

## 42.7.4 Processor Extended States and ENCLU[EENTER]

### 42.7.4.1 Fault Checking

The EENTER leaf function of the ENCLU instruction enforces a number of consistency requirements described earlier. The execution of the ENCLU[EENTER] leaf function results in a #GP(0) in any of the following cases:

* If CR4.OSFXSR=0.

* If The processor supports XSAVE and either of the following is true:

    - CR4.OSXSAVE=0 and SECS.ATTRIBUTES.XFRM is not 3.

    - (SECS.ATTRIBUTES.XFRM & XCR0) != SECS.ATTRIBUTES.XFRM

### 42.7.4.2 State Loading

If ENCLU[EENTER] is successful, the current value of XCR0 is saved internally by the processor and replaced by SECS.ATTRIBUTES.XFRM.

Vol. 3D <page_number>42-7</page_number>

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

## 42.7.5 Processor Extended States and AEX

### 42.7.5.1 State Saving

On an AEX, processor extended states are saved into the XSAVE area of the SSA frame in a compatible format with XSAVE that was executed with EDX:EAX = SECS.ATTRIBUTES.XFRM, with the memory operand being the XSAVE area, and (for 64-bit enclaves) as if REX.W=1. The XSTATE_BV part of the XSAVE header is saved with 0 for every bit that is 0 in XFRM. Other bits may be saved as 0 if the state saved is initialized.

Note that enclave entry ensures that if CR4.OSXSAVE is set to 0, then SECS.ATTRIBUTES.XFRM is set to 3. It should also be noted that it is not possible to enter an enclave with FXSAVE disabled.

### 42.7.5.2 State Synthesis

After saving the extended state, the processor restores XCR0 to the value it held at the time of the most recent enclave entry.

The state of features corresponding to bits set in XFRM is synthesized. In general, these states are initialized. Details of state synthesis on AEX are documented in Section 40.3.1.

## 42.7.6 Processor Extended States and ENCLU[ERESUME]

### 42.7.6.1 Fault Checking

The ERESUME leaf function of the ENCLU instruction enforces a number of consistency requirements described earlier. Specifically, the ENCLU[ERESUME] leaf function results in a #GP(0) in any of the following cases:

* CR4.OSFXSR=0.

* The processor supports XSAVE and either of the following is true:

  - CR4.OSXSAVE=0 and SECS.ATTRIBUTES.XFRM is not 3.

  - (SECS.ATTRIBUTES.XFRM & XCR0) != SECS.ATTRIBUTES.XFRM.

A successful execution of ENCLU[ERESUME] loads state from the XSAVE area of the SSA frame in a fashion similar to that used by the XRSTOR instruction. Data in the XSAVE area that would cause the XRSTOR instruction to fault will cause the ENCLU[ERESUME] leaf function to fault. Examples include, but are not restricted to the following:

* A bit is set in the XSTATE_BV field and clear in XFRM.

* The required bytes in the header are not clear.

* Loading data would set a reserved bit in MXCSR.

Any of these conditions will cause ERESUME to fault, even if CR4.OSXSAVE=0.

### 42.7.6.2 State Loading

If ENCLU[ERESUME] is successful, the current value of XCR0 is saved internally by the processor and replaced by SECS.ATTRIBUTES.XFRM.

State is loaded from the XSAVE area of the SSA frame as if the XRSTOR instruction were executed with XCR0=XFRM, EDX:EAX = XFRM, with the memory operand being the XSAVE area, and (for 64-bit enclaves) as if REX.W=1.

ENCLU[ERESUME] ensures that a subsequent execution of XSAVEOPT inside the enclave will operate properly (e.g., by marking all state as modified).

## 42.7.7 Processor Extended States and ENCLU[EEXIT]

The ENCLU[EEXIT] leaf function does not perform any X-feature specific consistency checks, nor performs any state synthesis. It is the responsibility of enclave software to clear any sensitive data from the registers before

42-8 Vol. 3D

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

executing EEXIT. However, successful execution of the ENCLU[EEXIT] leaf function restores XCR0 to the value it held at the time of the most recent enclave entry.

## 42.7.8 Processor Extended States and ENCLU[EREPORT]

The ENCLU[EREPORT] leaf function creates the MAC-protected REPORT structure that reports on the enclave’s identity. ENCLU[EREPORT] includes in the report the values of SECS.ATTRIBUTES.XFRM and SECS.MISCSELECT.

## 42.7.9 Processor Extended States and ENCLU[EGETKEY]

The ENCLU[EGETKEY] leaf function returns a cryptographic key based on the information provided by the KEYREQUEST structure. Intel SGX provides the means for isolation between different operating conditions by allowing an enclave developer to select which bits out of XFRM and MISCSELECT need to be included in the derivation of the keys.

## 42.8 INTERACTIONS WITH SMM

### 42.8.1 Availability of Intel® SGX instructions in SMM

Enclave instructions are not available in SMM, and any attempt to execute ENCLS or ENCLU instructions inside SMM results in an invalid-opcode exception (#UD).

### 42.8.2 SMI while Inside an Enclave

If the logical processor executing inside an enclave receives an SMI, the logical processor exits the enclave asynchronously. The response to an SMI received while executing inside an enclave depends on whether the dual-monitor treatment is enabled. For detailed discussion of transfer to SMM, see Chapter 34, “System Management Mode,” of the Intel<sup>®</sup> 64 and IA-32 Architectures Software Developer’s Manual, Volume 3C.

If the logical processor executing inside an enclave receives an SMI when dual-monitor treatment is not enabled, the logical processor exits the enclave asynchronously, and transfers the control to the SMM handler. In addition to saving the synthetic architectural state to the SMRAM State Save Map (SSM), the logical processor also sets the “incident to enclave mode” bit in the SMRAM SSM (bit position 1 in SMRAM field at offset 7EE0H). RSM reads this bit to ensure proper treatment of any VM exit due to an event pending following RSM (see Section 30.2.1 for details).

If the logical processor executing inside an enclave receives an SMI when dual-monitor treatment is enabled, the logical processor exits the enclave asynchronously, and transfers the control to the SMM monitor via SMM VM exit. The SMM VM exit sets the “Enclave Interruption” bit in the Exit Reason (see Table 42-1) and in the Guest Interruptibility State field (see Table 42-2) of the SMM VMCS.

### 42.8.3 SMRAM Synthetic State of AEX Triggered by SMI

All processor registers saved in the SMRAM have the same synthetic values listed in Section 40.3. Additional SMRAM fields that are treated specially on SMI are:

Table 42-1. SMRAM Synthetic States on Asynchronous Enclave Exit

<table>
  <thead>
    <tr>
        <th>Position</th>
        <th>Field</th>
        <th>Value</th>
        <th>Writable</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>SMRAM Offset 07EE0H.Bit 1</td>
        <td>ENCLAVE_INTERRUPTION</td>
        <td>Set to 1 if exit occurred in enclave mode</td>
        <td>No</td>
    </tr>
  </tbody>
</table>

Vol. 3D 42-9
<page_number>42-9</page_number>

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

# 42.9 INTERACTIONS OF INIT, SIPI, AND WAIT-FOR-SIPI WITH INTEL® SGX

INIT received inside an enclave, while the logical processor is not in VMX operation, causes the logical processor to exit the enclave asynchronously. After the AEX, the processor's architectural state is initialized to “Power-on” state (Table 9.1 in Intel® 64 and IA-32 Architectures Software Developer’s Manual, Volume 3A). If the logical processor is BSP, then it proceeds to execute the BIOS initialization code. If the logical processor is an AP, it enters wait-for-SIPI state.

INIT received inside an enclave, while the logical processor (LP) is in VMX root operation, follows regular Intel Architecture behavior and is blocked.

INIT received inside an enclave, while the logical processor is in VMX non-root operation, causes an AEX. Subsequent to the AEX, the INIT causes a VM exit with the Enclave Interruption bit in the exit-reason field in the VMCS.

A processor cannot be inside an enclave in the wait-for-SIPI state. Consequently, a SIPI received while inside an enclave is lost.

Intel SGX does not change the behavior of the processor in the wait-for-SIPI state.

The SGX-related processor states after INIT-SIPI-SIPI is as follows:

* EPC Settings: Unchanged

* EPCM: Unchanged

* CPUID.12H.*: Unchanged

* ENCLAVE_MODE: 0 (LP exits enclave asynchronously)

* MEE state: Unchanged

Software should be aware that following INIT-SIPI-SIPI, the EPC might contain valid pages and should take appropriate measures such as initialize the EPC with the EREMOVE leaf function.

# 42.10 INTERACTIONS WITH DMA

DMA is not allowed to access any Processor Reserved Memory.

# 42.11 INTERACTIONS WITH TXT

## 42.11.1 Enclaves Created Prior to Execution of GETSEC

Enclaves which have been created before the GETSEC[SENTER] leaf function are available for execution after the successful completion of GETSEC[SENTER] and the corresponding SINIT ACM. Actions that a TXT Launched Environment performs in preparation to execute code in the Launched Environment, also applies to enclave code that would run after GETSEC[SENTER].

## 42.11.2 Interaction of GETSEC with Intel® SGX

All leaf functions of the GETSEC instruction are illegal inside an enclave, and results in an invalid-opcode exception (#UD).

Responding Logical Processors (RLP) which are executing inside an enclave at the time a GETSEC[SENTER] event occurs perform an AEX from the enclave and then enter the Wait-for-SIPI state.

RLP executing inside an enclave at the time of GETSEC[SEXIT], behave as defined for GETSEC[SEXIT]—that is, the RLPs pause during execution of SEXIT and resume after the completion of SEXIT.

The execution of a TXT launch does not affect Intel SGX configuration or security parameters.

42-10 Vol. 3D

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

### 42.11.3 Interactions with Authenticated Code Modules (ACMs)

Intel SGX only allows launching ACMs with an Intel SGX SVN that is at the same level or higher than the expected Intel SGX SVN. The expected Intel SGX SVN is specified by BIOS and locked down by the processor on the first successful execution of an Intel SGX instruction that doesn't return an error code. Intel SGX provides interfaces for system software to discover whether a non faulting Intel SGX instruction has been executed, and evaluate the suitability of the Intel SGX SVN value of any ACM that is expected to be launched by the OS or the VMM.

These interfaces are provided through a read-only MSR called the IA32_SGX_SVN_STATUS MSR (MSR address 500h). The IA32_SGX_SVN_STATUS MSR has the format shown in Table 42-2.

Table 42-2. Layout of the IA32_SGX_SVN_STATUS MSR

<table>
  <thead>
    <tr>
        <th>Bit Position</th>
        <th>Name</th>
        <th>ACM Module ID</th>
        <th>Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>Lock</td>
        <td>N.A.</td>
        <td>\* If 1, indicates that a non-faulting Intel SGX instruction has been executed, consequently, launching a properly signed ACM but with Intel SGX SVN value less than the BIOS specified Intel SGX SVN threshold would lead to an TXT shutdown.<br/>\* If 0, indicates that the processor will allow a properly signed ACM to launch irrespective of the Intel SGX SVN value of the ACM.</td>
    </tr>
    <tr>
        <td>15:1</td>
        <td>RSVD</td>
        <td>N.A.</td>
        <td>0</td>
    </tr>
    <tr>
        <td>23:16</td>
        <td>SGX_SVN_SINIT</td>
        <td>SINIT ACM</td>
        <td>\* If CPUID.01H:ECX.SMX =1, this field reflects the expected threshold of Intel SGX SVN for the SINIT ACM.<br/>\* If CPUID.01H:ECX.SMX =0, this field is reserved (0).</td>
    </tr>
    <tr>
        <td>63:24</td>
        <td>RSVD</td>
        <td>N.A.</td>
        <td>0</td>
    </tr>
  </tbody>
</table>

OS/VMM that wishes to launch an architectural ACM such as SINIT is expected to read the IA32_SGX_SVN_STATUS MSR to determine whether the ACM can be launched or a new ACM is needed:

* If either the Intel SGX SVN of the ACM is greater than the value reported by IA32_SGX_SVN_STATUS, or the lock bit in the IA32_SGX_SVN_STATUS is not set, then the OS/VMM can safely launch the ACM.

* If the Intel SGX SVN value reported in the corresponding component of the IA32_SGX_SVN_STATUS is greater than the Intel SGX SVN value in the ACM's header, and if bit 0 of IA32_SGX_SVN_STATUS is 1, then the OS/VMM should not launch that version of the ACM. It should obtain an updated version of the ACM either from the BIOS or from an external resource.

However, OSVs/VMMs are strongly advised to update their version of the ACM any time they detect that the Intel SGX SVN of the ACM carried by the OS/VMM is lower than that reported by IA32_SGX_SVN_STATUS MSR, irrespective of the setting of the lock bit.

## 42.12 INTERACTIONS WITH CACHING OF LINEAR-ADDRESS TRANSLATIONS

Entering and exiting an enclave causes the logical processor to flush all the global linear-address context as well as the linear-address context associated with the current VPID and PCID. The MONITOR FSM is also cleared.

## 42.13 INTERACTIONS WITH INTEL® TRANSACTIONAL SYNCHRONIZATION EXTENSIONS (INTEL® TSX)

1. ENCLU or ENCLS instructions inside an HLE region will cause the flow to be aborted and restarted non-speculatively. ENCLU or ENCLS instructions inside an RTM region will cause the flow to be aborted and transfer control to the fallback handler.

2. If XBEGIN is executed inside an enclave, the processor does NOT check whether the address of the fallback handler is within the enclave.

3. If an RTM transaction is executing inside an enclave and there is an attempt to fetch an instruction outside the enclave, the transaction is aborted and control is transferred to the fallback handler. No #GP is delivered.

Vol. 3D <page_number>42-11</page_number>

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

4. If an RTM transaction is executing inside an enclave and there is a data access to an address within the enclave that denied due to EPCM content (e.g., to a page belonging to a different enclave), the transaction is aborted and control is transferred to the fallback handler. No #GP is delivered.

5. If an RTM transaction executing inside an enclave aborts and the address of the fallback handler is outside the enclave, a #GP is delivered after the abort (EIP reported is that of the fallback handler).

## 42.13.1 HLE and RTM Debug

RTM debug will be suppressed on opt-out enclave entry. After opt-out entry, the logical processor will behave as if IA32_DEBUG_CTL[15]=0. Any #DB detected inside an RTM transaction region will just cause an abort with no exception delivered.

After opt-in entry, if either DR7[11] = 0 OR IA32_DEBUGCTL[15] = 0, any #DB or #BP detected inside an RTM transaction region will just cause an abort with no exception delivered.

After opt-in entry, if DR7[11] = 1 AND IA32_DEBUGCTL[15] = 1, any #DB or #BP detected inside an RTM translation will

* terminate speculative execution,

* set RIP to the address of the XBEGIN instruction, and

* be delivered as #DB (implying an Intel SGX AEX; any #BP is converted to #DB).

* DR6[16] will be cleared, indicating RTM debug (if the #DB causes a VM exit, DR6 is not modified but bit 16 of the pending debug exceptions field in the VMCS will be set).

## 42.14 INTEL® SGX INTERACTIONS WITH S STATES

Whenever an Intel SGX enabled processor enters S3-S5 state, enclaves are destroyed. This is due to the EPC being destroyed when power down occurs. It is the application runtime’s responsibility to re-instantiate an enclave after a power transition for which the enclaves were destroyed.

## 42.15 INTEL® SGX INTERACTIONS WITH MACHINE CHECK ARCHITECTURE (MCA)

### 42.15.1 Interactions with MCA Events

All architecturally visible machine check events (#MC and CMCI) that are detected while inside an enclave cause an asynchronous enclave exit.

Any machine check exception (#MC) that occurs after Intel SGX is first enables causes Intel SGX to be disabled, (CPUID.12H.00H:EAX.SGX1 == 0). It cannot be enabled until after the next reset.

### 42.15.2 Machine Check Enables (IA32_MCi_CTL)

All supported IA32_MCi_CTL bits for all the machine check banks must be set for Intel SGX to be available (CPUID.12H.00H:EAX.SGX1 == 1). Any act of clearing bits from '1 to '0 in any of the IA32_MCi_CTL register may disable Intel SGX (set CPUID.12H.00H:EAX.SGX1 to 0) until the next reset.

### 42.15.3 CR4.MCE

CR4.MCE can be set or cleared with no interactions with Intel SGX.

42-12 Vol. 3D

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

## 42.16 INTEL® SGX INTERACTIONS WITH PROTECTED MODE VIRTUAL INTERRUPTS

ENCLS[EENTER] modifies neither EFLAGS.VIP nor EFLAGS.VIF.

ENCLS[ERESUME] loads EFLAGS in a manner similar to that of an execution of IRET with CPL = 3. This means that ERESUME modifies neither EFLAGS.VIP nor EFLAGS.VIF regardless of the value of the EFLAGS image in the SSA frame.

AEX saves EFLAGS.VIP and EFLAGS.VIF unmodified into the EFLAGS image in the SSA frame. AEX modifies neither EFLAGS.VIP nor EFLAGS.VIF after saving EFLAGS.

If CR4.PVI = 1, CPL = 3, EFLAGS.VM = 0, IOPL < 3, EFLAGS.VIP = 1, and EFLAGS.VIF = 0, execution of STI causes a #GP fault. In this case, STI modifies neither EFLAGS.IF nor EFLAGS.VIF. This behavior applies without change within an enclave (where CPL is always 3). Note that, if IOPL = 3, STI always sets EFLAGS.IF without fault; CR4.PVI, EFLAGS.VIP, and EFLAGS.VIF are neither consulted nor modified in this case.

## 42.17 INTEL SGX INTERACTION WITH PROTECTION KEYS

SGX interactions with PKRU are as follows:

* CPUID.12H.01H:ECX.PKRU indicates whether SECS.ATTRIBUTES.XFRM.PKRU can be set. If SECS.ATTRIBUTES.XFRM.PKRU is set, then PKRU is saved and cleared as part of AEX and is restored as part of ERESUME. If CR4.PKE is set, an enclave can execute RDPKRU and WRKRU independent of whether SECS.ATTRIBUTES.XFRM.PKRU is set.

SGX interactions with domain permission checks are as follows:

1) If CR4.PKE is not set, then legacy and SGX permission checks are not effected.

2) If CR4.PKE is set, then domain permission checks are applied to all non-enclave access and enclave accesses to user pages in addition to legacy and SGX permission checks at a higher priority than SGX permission checks.

3) Implicit accesses aren't subject to domain permission checks.

Vol. 3D 42-13
<page_number>42-13</page_number>

INTEL® SGX INTERACTIONS WITH IA32 AND INTEL® 64 ARCHITECTURE

42-14 Vol. 3D

ENCLAVE CODE DEBUG AND PROFILING

# CHAPTER 43
# ENCLAVE CODE DEBUG AND PROFILING

Intel<sup>®</sup> SGX is architected to provide protection for production enclaves and permit enclave code developers to use an SGX-aware debugger to effectively debug a non-production enclave (debug enclave). Intel SGX also allows a non-SGX-aware debugger to debug non-enclave portions of the application without getting confused by enclave instructions.

## 43.1 CONFIGURATION AND CONTROLS

### 43.1.1 Debug Enclave vs. Production Enclave

The SECS of each enclave provides a bit, SECS.ATTRIBUTES.DEBUG, indicating whether the enclave is a debug enclave (if set) or a production enclave (if 0). If this bit is set, software outside the enclave can use EDBGRD/EDBGWR to access the EPC memory of the enclave. The value of DEBUG is not included in the measurement of the enclave and therefore doesn't require an alternate SIGSTRUCT to be generated to debug the enclave.

The ATTRIBUTES field in the SECS is reported in the enclave's attestation, and is included in the key derivation. Enclave secrets that were protected by the enclave using Intel SGX keys when it ran as a production enclave will not be accessible by the debug enclave. A debugger needs to be aware that special debug content might be required for a debug enclave to run in a meaningful way.

EPC memory belonging to a debug enclave can be accessed via the EDBGRD/EDBGWR leaf functions (see Section 41.4), while that belonging to a non-debug enclave cannot be accessed by these leaf functions.

### 43.1.2 Tool-Chain Opt-in

The TCS.FLAGS.DBGOPTIN bit controls interactions of certain debug and profiling features with enclaves, including code/data breakpoints, TF, RF, monitor trap flag, BTF, LBRs, BTM, BTS, Intel Processor Trace, and performance monitoring. This bit is forced to zero when EPC pages are added via EADD. A debugger can set this bit via EDBGWR to the TCS of a debug enclave.

An enclave entry through a TCS with the TCS.FLAGS.DBGOPTIN set to 0 is called an opt-out entry. Conversely, an enclave entry through a TCS with TCS.FLAGS.DBGOPTIN set to 1 is called an opt-in entry.

### 43.1.3 Debugging an Enclave That Uses Asynchronous Enclave Exit Notify

Whenever an opt-in enclave entry is used to perform enclave code debugging or profiling, the debugger or profiling tool may clear TCS.FLAGS.AEXNOTIFY to prevent AEX notifications from being delivered at each interrupt, breakpoint, trap, or other exception.

## 43.2 SINGLE STEP DEBUG

### 43.2.1 Single Stepping ENCLS Instruction Leafs

If the RFLAGS.TF bit is set at the beginning of ENCLS, then a single-step debug exception is pending as a trap-class exception on the instruction boundary immediately after the ENCLS instruction. Additionally, if the instruction is executed in VMX non-root operation and the “monitor trap flag” VM-execution control is 1, an MTF VM exit is pending on the instruction boundary immediately after the instruction if the instruction does not fault.

Vol. 3D 43-1

ENCLAVE CODE DEBUG AND PROFILING

## 43.2.2 Single Stepping ENCLU Instruction Leafs

The interactions of the unprivileged Intel SGX instruction ENCLU are leaf dependent.

An enclave entry via EENTER/ERESUME leaf functions of the ENCLU, in certain cases, may mask the RFLAGS.TF bit, and mask the setting of the “monitor trap flag” VM-execution control. In such situations, an exit from the enclave, either via the EEXIT leaf function or via an AEX unmasks the RFLAGS.TF bit and the “monitor trap flag” VM-execution control. The details of this masking/unmasking and the pending of single stepping events across EENTER/ERESUME/EEXIT/AEX are covered in detail in Section 43.2.3.

If the EFLAGS.TF bit is set at the beginning of EREPORT or EGETKEY leafs, and if the EFLAGS.TF is not masked by the preceding enclave entry, then a single-step debug exception is pending on the instruction boundary immediately after the ENCLU instruction. Additionally, if the instruction is executed in VMX non-root operation and the “monitor trap flag” VM-execution control is 1, and if the monitor trap flag is not masked by the preceding enclave entry, then an MTF VM exit is pending on the instruction boundary immediately after the instruction.

If the instruction under consideration results in a fault, then the control flow goes to the fault handler, and no single-step debug exception is asserted. In such a situation, if the instruction is executed in VMX non-root operation and the “monitor trap flag” VM-execution control is 1, an MTF VM exit is pending after the delivery of the fault (or any nested exception). No MTF VM exit occurs if another VM exit occurs before reaching that boundary on which an MTF VM exit would be pending.

## 43.2.3 Single-Stepping Enclave Entry with Opt-out Entry

### 43.2.3.1 Single Stepping without AEX

Figure 43-1 shows the most common case for single-stepping after an opt-out entry.

```mermaid
graph LR
    subgraph Enclave
        A[EENTERERESUME] --> B[Inst1]
        B --> C[Inst2]
        C --> D[Inst3]
        D --> E[EEXIT]
    end
    E --> F[Inst4]
    E -.-> G[TF/MTFHandler]
    
    H[RFLAGS.TF] -- "Single-Step #DB Pending" --> G
    I[VMCS.MTF] -- "MTF VM Exit Pending" --> G
    
    J[SMIINIT#MC] -- "Higher PriorityHandler" --> K[Handler]
```

Figure 43-1. Single Stepping with Opt-out Entry - No AEX

In this scenario, if the RFLAGS.TF bit is set at the time of the enclave entry, then a single step debug exception is pending on the instruction boundary after EEXIT. Additionally, if the enclave is executing in VMX non-root operation and the “monitor trap flag” VM-execution control is 1, an MTF VM exit is pending on the instruction boundary after EEXIT.

The value of the RFLAGS.TF bit at the end of EEXIT is the same as the value of RFLAGS.TF at the time of the enclave entry.

### 43.2.3.2 Single Step Preempted by AEX Due to Non-SMI Event

Figure 43-2 shows the interaction of single stepping with AEX due to a non-SMI event after an opt-out entry.

43-2 Vol. 3D

ENCLAVE CODE DEBUG AND PROFILING

Single Stepping with Opt-out Entry -AEX Due to Non-SMI Event Before Single-Step Boundary diagram showing EENTER/ERESUME, instructions Inst1-Inst3, EEXIT, AEX, and handlers.

Figure 43-2. Single Stepping with Opt-out Entry -AEX Due to Non-SMI Event Before Single-Step Boundary

In this scenario, if the enclave is executing in VMX non-root operation and the “monitor trap flag” VM-execution control is 1, an MTF VM exit is pending on the instruction boundary after the AEX. No MTF VM exit occurs if another VM exit happens before reaching that instruction boundary.

The value of the RFLAGS.TF bit at the end of AEX is the same as the value of RFLAGS.TF at the time of the enclave entry.

## 43.2.4 RFLAGS.TF Treatment on AEX

The value of EFLAGS.TF at the end of AEX from an opt-out enclave is same as the value of EFLAGS.TF at the time of the enclave entry. The value of EFLAGS.TF at the end of AEX from an opt-in enclave is unmodified. The EFLAGS.TF saved in GPR portion of the SSA on an AEX is 0. For more detail see EENTER and ERESUME in Chapter 5.

## 43.2.5 Restriction on Setting of TF after an Opt-Out Entry

Enclave entered through an opt-out entry is not allowed to set EFLAGS.TF. The POPF instruction forces RFLAGS.TF to 0 if the enclave was entered through opt-out entry.

## 43.2.6 Trampoline Code Considerations

Any AEX from the enclave which results in the RFLAGS.TF =1 on the reporting stack will result in a single-step #DB after the first instruction of the trampoline code if the trampoline is entered using the IRET instruction.

# 43.3 CODE AND DATA BREAKPOINTS

## 43.3.1 Breakpoint Suppression

Following an opt-out entry:

* Instruction breakpoints are suppressed during execution in an enclave.

* Data breakpoints are not triggered on accesses to the address range defined by ELRANGE.

* Data breakpoints are triggered on accesses to addresses outside the ELRANGE

Vol. 3D 43-3

ENCLAVE CODE DEBUG AND PROFILING

Following an opt-in entry instruction and data breakpoints are not suppressed.

The processor does not report any matches on debug breakpoints that are suppressed on enclave entry. However, the processor does not clear any bits in DR6 that were already set at the time of the enclave entry.

## 43.3.2 Reporting of Instruction Breakpoint on Next Instruction on a Debug Trap

A debug exception caused by the single-step execution mode or when a data breakpoint condition was met causes the processor to perform an AEX. Following such an AEX, the processor reports in the debug status register (DR6) matches of the new instruction pointer (the AEP address) in a breakpoint address register setup to detect instruction execution.

## 43.3.3 RF Treatment on AEX

RF flag value saved in SSA is the same as what would have been pushed on stack if the exception or event causing the AEX occurred when executing outside an enclave (see Section 20.3.1.1). Following an AEX, the RF flag is 0 in the synthetic state.

## 43.3.4 Breakpoint Matching in Intel® SGX Instruction Flows

Implicit accesses made by Intel SGX instructions to EPC regions do not trigger data breakpoints. Explicit accesses made by ENCLS[ECREATE], ENCLS[EADD], ENCLS[EEXTEND], ENCLS[EINIT], ENCLS[EREMOVE], ENCLS[ETRACK], ENCLS[EBLOCK], ENCLS[EPA], ENCLS[EWB], ENCLS[ELD], ENCLS[EDBGRD], ENCLS[EDBGWR], ENCLU[EENTER], and ENCLU[ERESUME] to the EPC operands do not trigger data breakpoints.

Explicit accesses made by the Intel SGX instructions (ENCLU[EGETKEY] and ENCLU[EREPORT]) executed by an enclave following an opt-in entry, trigger data breakpoints on accesses to their EPC operands. All Intel SGX instructions trigger data breakpoints on accesses to their non-EPC operands.

## 43.4 CONSIDERATION OF THE INT1 AND INT3 INSTRUCTIONS

This section considers the operation of the INT1 and INT3 instructions when executed inside an enclave. These are the instructions with opcodes F1 and CC, respectively, and not INT n (with opcode CD) with value 1 or 3 for n.

## 43.4.1 Behavior of INT1 and INT3 Inside an Enclave

An execution of either INT1 or INT3 inside an enclave results in a fault-class exception. Following an opt-out entry, execution of either instruction results in an invalid-opcode exception (#UD). Following opt-in entry, INT1 results in a debug exception (#DB) and INT3 delivers a breakpoint exception (#BP). The normal requirement for INT3 (that the CPL not be greater than the DPL of descriptor 3 in the IDT) is not enforced.

Because execution of INT1 or INT3 inside an enclave results in a fault, the RIP saved in the SSA on AEX references the INT1 or INT3 instruction (and not the following instruction). The RIP value saved on the stack (or in the TSS or VMCS) is that of the AEP.

If execution of INT1 or INT3 inside an enclave causes a VM exit, the event type in the VM-exit interruption information field indicates a hardware exception (type 3),<sup>1</sup> and the VM-exit instruction length field is saved as zero.

## 43.4.2 Debugger Considerations

A debugger using INT3 inside an enclave should account for the modified behavior described in Section 43.4.1. Because INT3 is fault-like inside an enclave, the RIP saved in the SSA on AEX is that of the INT3 instruction. Conse-

<sup>1.</sup> INT1 would normally indicate a privileged software exception (type 5), and INT3 would normally indicate a software exception (type 6).

43-4 Vol. 3D

ENCLAVE CODE DEBUG AND PROFILING

quently, the debugger must not decrement SSA.RIP for #BP coming from an enclave to re-execute the instruction at the RIP of the INT3 instruction on a subsequent enclave entry.

## 43.4.3 VMM Considerations

As described in Section 43.4.1, execution of INT3 inside an enclave delivers #BP with “interruption type” of 3. A VMM that re-injects #BP into the guest should establish the VM-entry interruption information field using data saved into the appropriate VMCS fields by the VM exit incident to the #BP (as recommended in the Intel<sup>®</sup> 64 and IA-32 Architectures Software Developer’s Manual, Volume 3C).

VMMs that create the VM-entry interruption information based solely on the exception vector should take care to use event type 3 (instead of 6) when they detect a VM exit incident to enclave mode that is due to an exception with vector 3.

## 43.5 BRANCH TRACING

### 43.5.1 BTF Treatment

When software enables single-stepping on branches then:

* Following an opt-in entry using EENTER the processor generates a single step debug exception.

* Following an EEXIT the processor generates a single-step debug exception

Enclave entry using ERESUME (opt-in or opt-out) and an AEX from the enclave do not cause generation of the single-step debug exception.

### 43.5.2 LBR Treatment

#### 43.5.2.1 LBR Stack on Opt-in Entry

Following an opt-in entry into an enclave, last branch recording facilities if enabled continued to store branch records in the LBR stack MSRs as follows:

* On enclave entry using EENTER/ERESUME, the processor push the address of EENTER/ERESUME instruction into MSR_LASTBRANCH_n_FROM_IP, and the destination address of the EENTER/ERESUME into MSR_LASTBRANCH_n_TO_IP.

* On EEXIT, the processor pushes the address of EEXIT instruction into MSR_LASTBRANCH_n_FROM_IP, and the address of EEXIT destination into MSR_LASTBRANCH_n_TO_IP.

* On AEX, the processor pushes RIP saved in the SSA into MSR_LASTBRANCH_n_FROM_IP, and the address of AEP into MSR_LASTBRANCH_n_TO_IP.

* For every branch inside the enclave, a branch record is pushed on the LBR stack.

Figure 43-3 shows an example of LBR stack manipulation after an opt-in entry. Every arrow in this picture indicates a branch record pushed on the LBR stack. The “From IP” of the branch record contains the linear address of the instruction located at the start of the arrow, while the “To IP” of the branch record contains the linear address of the instruction at the end of the arrow.

Vol. 3D <page_number>43-5</page_number>

ENCLAVE CODE DEBUG AND PROFILING

```mermaid
graph LR
    subgraph Enclave_Entry_Exit_Flow
        direction TB
        EENTER[EENTER] --> Inst1[Inst1]
        BR2[BR2] --> Inst3[Inst3]
        Inst4_1[Inst4] -. X .-> Fault[Fault]
        Inst4_2[Inst4] --> AEP1[AEP]
        AEP2[AEP] --> OS[OS]
        IRET[IRET] --> AEP3[AEP]
        ERESUME[ERESUME] --> Inst4_3[Inst4]
        BR5[BR5] --> Inst6[Inst6]
        EEXIT[EEXIT] --> Inst7[Inst7]
    end
```

Figure 43-3. LBR Stack Interaction with Opt-in Entry

## 43.5.2.2 LBR Stack on Opt-out Entry

An opt-out entry into an enclave suppresses last branch recording facilities, and enclave exit after an opt-out entry un-suppresses last branch recording facilities.

Opt-out entry into an enclave does not push any record on LBR stack.

If last branch recording facilities were enabled at the time of enclave entry, then EEXIT following such an enclave entry pushes one record on LBR stack. The MSR_LASTBRANCH_n_FROM_IP of such record holds the linear address of the instruction (EENTER or ERESUME) that was used to enter the enclave, while the MSR_LAST-BRANCH_n_TO_IP of such record holds linear address of the destination of EEXIT.

Additionally, if last branch recording facilities were enabled at the time of enclave entry, then an AEX after such an entry pushes one record on LBR stack, before pushing record for the event causing the AEX if the event pushes a record on LBR stack. The MSR_LASTBRANCH_n_FROM_IP of the new record holds linear address of the instruction (EENTER or ERESUME) that was used to enter the enclave, while MSR_LASTBRANCH_n_TO_IP of the new record holds linear address of the AEP. If the event causing AEX pushes a record on LBR stack, then the MSR_LAST-BRANCH_n_FROM_IP for that record holds linear address of the AEP.

Figure 43-4 shows an example of LBR stack manipulation after an opt-out entry. Every arrow in this picture indicates a branch record pushed on the LBR stack. The "From IP" of the branch record contains the linear address of the instruction located at the start of the arrow, while the "To IP" of the branch record contains the linear address of the instruction at the end of the arrow.

43-6 Vol. 3D

ENCLAVE CODE DEBUG AND PROFILING

```mermaid
graph TD
    subgraph Enclave
        EENTER[EENTER]
        BR2[BR2]
        Inst4_1[Inst4]
        AEP_1[AEP]
        IRET[IRET]
        ERESUME[ERESUME]
        BR5[BR5]
        EEXIT[EEXIT]
    end

    subgraph Outside
        Inst1[Inst1]
        Inst3[Inst3]
        Fault[Fault]
        AEP_2[AEP]
        OS[OS]
        AEP_3[AEP]
        Inst4_2[Inst4]
        Inst6[Inst6]
        Inst7[Inst7]
    end

    EENTER --> AEP_2
    Inst4_1 -- X --- Fault
    AEP_1 --> OS
    IRET --> AEP_3
    ERESUME --> Inst7
```

Figure 43-4. LBR Stack Interaction with Opt-out Entry

### 43.5.2.3 Mispredict Bit, Record Type, and Filtering

All branch records resulting from Intel SGX instructions/AEXs are reported as predicted branches, and consequently, bit 63 of MSR_LASTBRANCH_n_FROM_IP for such records is set. Branch records due to these Intel SGX operations are always non-HLE/non-RTM records.

EENTER, ERESUME, EEXIT, and AEX are considered to be far branches. Consequently, bit 8 in MSR_LBR_SELECT controls filtering of the new records introduced by Intel SGX.

## 43.6 INTERACTION WITH PERFORMANCE MONITORING

### 43.6.1 IA32_PERF_GLOBAL_STATUS Enhancement

On processors supporting Intel SGX, the IA32_PERF_GLOBAL_STATUS MSR provides a bit indicator, known as "Anti Side-channel Interference" (ASCI) at bit position 60. If this bit is 0, the performance monitoring data in various performance monitoring counters are accumulated normally as defined by relevant architectural/microarchitectural conditions. If the ASCI bit is set, the contents in various performance monitoring counters can be affected by the direct or indirect consequence of Intel SGX protection of enclave code executing in the processor.

### 43.6.2 Performance Monitoring with Opt-in Entry

An opt-in enclave entry allow performance monitoring logic to observe the contribution of enclave code executing in the processor. Thus the contents of performance monitoring counters does not distinguish between contribution originating from enclave code or otherwise. All counters, events, precise events, etc. continue to work as defined in the IA32/Intel 64 Software Developer Manual. Consequently, bit 60 of IA32_PERF_GLOBAL_STATUS MSR is not set.

Vol. 3D 43-7
<page_number>43-7</page_number>

ENCLAVE CODE DEBUG AND PROFILING

## 43.6.3 Performance Monitoring with Opt-out Entry

In general, performance monitoring activities are suppressed when entering an opt-out enclave. This applies to all thread-specific, configured performance monitoring, except for the cycle-counting fixed counter, IA32_FIXED_CTR1 and IA32_FIXED_CTR2. Upon entering an opt-out enclave, IA32_FIXED_CTR0, IA32_PMCx will stop accumulating counts. Additionally, if PEBS is configured to capture PEBS record for this thread, PEBS record generation will also be suppressed. Consequently, bit 60 of IA32_PERF_GLOBAL_STATUS MSR is set.

Performance monitoring on the sibling thread may also be affected. Any one of IA32_FIXED_CTRx or IA32_PMCx on the sibling thread configured to monitor thread-specific eventing logic with AnyThread =1 is demoted to count only MyThread while an opt-out enclave is executing on the other thread.

## 43.6.4 Enclave Exit and Performance Monitoring

When a logical processor exits an enclave, either via ENCLU[EEXIT] or via AEX, all performance monitoring activity (including PEBS) on that logical processor that was suppressed is unsuppressed.

Any counters that were demoted from AnyThread to MyThread on the sibling thread are promoted back to AnyThread.

## 43.6.5 PEBS Record Generation on Intel® SGX Instructions

All leaf functions of the ENCLS instruction report “Eventing RIP” of the ENCLS instruction if a PEBS record is generated at the end of the instruction execution. Additionally, the EGETKEY and EREPORT leaf functions of the ENCLU instruction report “Eventing RIP” of the ENCLU instruction if a PEBS record is generated at the end of the instruction execution.

If the EENTER and ERESUME leaf functions are performing an opt-in entry report “Eventing RIP” of the ENCLU instruction if a PEBS record is generated at the end of the instruction execution. On the other hand, if these leaf functions are performing an opt-out entry, then these leaf functions result in PEBS being suppressed, and no PEBS record is generated at the end of these instructions.

A PEBS record is generated if there is a PEBS event pending at the end of EEXIT (due to a counter overflowing during enclave execution or during EEXIT execution). This PEBS record contains the architectural state of the logical processor at the end of EEXIT. If the enclave was entered via an opt-in entry, then this record reports the “Eventing RIP” as the linear address of the ENCLU[EEXIT] instruction. If the enclave was entered via an opt-out entry, then the record reports the “Eventing RIP” as the linear address of the ENCLU[EENTER/ERESUME] instruction that performed the last enclave entry.

A PEBS record is generated after the AEX if there is a PEBS event pending at the end of AEX (due to a counter overflowing during enclave execution or during AEX execution). This PEBS record contains the synthetic state of the logical processor that is established at the end of AEX. For opt-in entry, this record has the EVENTING_RIP set to the RIP saved in the SSA. For opt-out entry, the record has the EVENTING_RIP set to the linear address of EENTER/ERESUME used for the last enclave entry.

If the enclave was entered via an opt-in entry, then this record reports the “Eventing RIP” as the linear address in the SSA of the enclave (a.k.a., the “Eventing LIP” inside the enclave). If the enclave was entered via an opt-out entry, then the record reports the “Eventing RIP” as the linear address of the ENCLU[EENTER/ERESUME] instruction that performed the last enclave entry.

A second PEBS event may be pended during the Enclave Exiting Event (EEE). If the PEBS event is taken at the end of delivery of the EEE then the “Eventing RIP” in this second PEBS record is the linear address of the AEP.

## 43.6.6 Exception-Handling on PEBS/BTS Loads/Stores after AEX

As noted in Section 20.4.9.2, recording in the BTS buffer or in the PEBS buffer may not operate properly if accesses to any of the DS save area sections cause page faults or VM exits. Such page faults or VM exits, if they occur, are delivered immediately to the OS or VMM, and generation of a BTS or PEBS record is skipped and may leave the buffers in a state where they have a partial BTS or PEBS records.

However, any events that are detected during PEBS/BTS record generation at the end of AEX and before delivering the Enclave Exiting Event (EEE) cannot be reported immediately to the OS/VMM, as an event window is not open at

43-8 Vol. 3D

ENCLAVE CODE DEBUG AND PROFILING

the end of AEX. Consequently, fault-like events such as page faults, EPT faults, EPT mis-configuration, and accesses to APIC-access page detected on stores to the PEBS/BTS buffer are not reported, and generation of the PEBS and/or BTS record at the end of AEX is aborted (this may leave the buffers in a state where they have partial PEBS or BTS records). Trap-like events detected on stores to the PEBS/BTS buffer (such as debug traps) are pended until the next instruction boundary, where they are handled according to the architecturally defined priority. The processor continues the handling of the Enclave Exiting Event (SMI, NMI, interrupt, exception delivery, VM exit, etc.) after aborting the PEBS/BTS record generation.

## 43.6.6.1 Other Interactions with Performance Monitoring

For opt-in entry, EENTER, ERESUME, EEXIT, and AEX are all treated as predicted far branches, and any counters that are counting such branches are incremented by 1 as a part of retirement of these instructions. Retirement of these instructions is also counted in any counters configured to count instructions retired.

For opt-out entry, execution inside an enclave is treated as a single predicted branch, and all branch-counting performance monitoring counters are incremented accordingly. Additionally, such execution is also counted as a single instruction, and all performance monitoring counters counting instructions are incremented accordingly.

Enclave entry does not affect any performance monitoring counters shared between cores.

Vol. 3D 43-9

ENCLAVE CODE DEBUG AND PROFILING

43-10 Vol. 3D

# APPENDIX A
# VMX CAPABILITY REPORTING FACILITY

The ability of a processor to support VMX operation and related instructions is indicated by CPUID.01H:ECX.VMX[5] = 1. A value 1 in this bit indicates support for VMX features.

Support for specific features detailed in Chapter 29 and other VMX chapters is determined by reading values from a set of capability MSRs. These MSRs are indexed starting at MSR address 480H. VMX capability MSRs are read-only; an attempt to write them (with WRMSR) produces a general-protection exception (#GP(0)). They do not exist on processors that do not support VMX operation; an attempt to read them (with RDMSR) on such processors produces a general-protection exception (#GP(0)).

## A.1 BASIC VMX INFORMATION

The IA32_VMX_BASIC MSR (index 480H) consists of the following fields:

* Bits 30:0 contain the 31-bit VMCS revision identifier used by the processor. Processors that use the same VMCS revision identifier use the same size for VMCS regions (see subsequent item on bits 44:32).<sup>1</sup>

* Bit 31 is always 0.

* Bits 44:32 report the number of bytes that software should allocate for the VMXON region and any VMCS region. It is a value greater than 0 and at most 4096 (bit 44 is set if and only if bits 43:32 are clear).

* Bit 48 indicates the width of the physical addresses that may be used for the VMXON region, each VMCS, and data structures referenced by pointers in a VMCS (I/O bitmaps, virtual-APIC page, MSR areas for VMX transitions). If the bit is 0, these addresses are limited to the processor’s physical-address width.<sup>2</sup> If the bit is 1, these addresses are limited to 32 bits. This bit is always 0 for processors that support Intel 64 architecture.

* If bit 49 is read as 1, the logical processor supports the dual-monitor treatment of system-management interrupts and system-management mode. See Section 34.15 for details of this treatment.

* Bits 53:50 report the memory type that should be used for the VMCS, for data structures referenced by pointers in the VMCS (I/O bitmaps, virtual-APIC page, MSR areas for VMX transitions), and for the MSEG header. If software needs to access these data structures (e.g., to modify the contents of the MSR bitmaps), it can configure the paging structures to map them into the linear-address space. If it does so, it should establish mappings that use the memory type reported bits 53:50 in this MSR.<sup>3</sup>

As of this writing, all processors that support VMX operation indicate the write-back type. The values used are given in Table A-1.

Table A-1. Memory Types Recommended for VMCS and Related Data Structures

<table>
  <thead>
    <tr>
        <th>Value(s)</th>
        <th>Field</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td>Uncacheable (UC)</td>
    </tr>
    <tr>
        <td>1–5</td>
        <td>Not used</td>
    </tr>
    <tr>
        <td>6</td>
        <td>Write Back (WB)</td>
    </tr>
    <tr>
        <td>7–15</td>
        <td>Not used</td>
    </tr>
  </tbody>
</table>

<sup>1.</sup> Earlier versions of this manual specified that the VMCS revision identifier was a 32-bit field in bits 31:0 of this MSR. For all processors produced prior to this change, bit 31 of this MSR was read as 0.

<sup>2.</sup> On processors that support Intel 64 architecture, the pointer must not set bits beyond the processor's physical address width. This width is denoted MAXPHYADDR and is derived from the value enumerated in CPUID.80000008H:EAX[7:0]. If IA32_TME_ACTIVATE[0] = 1 (indicating that TME has been configured), MAXPHYADDR is reduced by the value of IA32_TME_ACTIVATE[39:36] when a logical processor is outside secure arbitration mode (SEAM; see Chapter 35); the value is not reduced in SEAM.

<sup>3.</sup> Alternatively, software may map any of these regions or structures with the UC memory type. (This may be necessary for the MSEG header.) Doing so is discouraged unless necessary as it will cause the performance of software accesses to those structures to suffer.

Vol. 3D A-1

VMX CAPABILITY REPORTING FACILITY

* If bit 54 is read as 1, the processor reports information in the VM-exit instruction-information field on VM exits due to execution of the INS and OUTS instructions (see Section 30.2.5). This reporting is done only if this bit is read as 1.

* Bit 55 is read as 1 if any VMX controls that default to 1 may be cleared to 0. See Appendix A.2 for details. It also reports support for the VMX capability MSRs IA32_VMX_TRUE_PINBASED_CTLS, IA32_VMX_TRUE_PROCBASED_CTLS, IA32_VMX_TRUE_EXIT_CTLS, and IA32_VMX_TRUE_ENTRY_CTLS. See Appendix A.3.1, Appendix A.3.2, Appendix A.4, and Appendix A.5 for details.

* If bit 56 is read as 1, software can use VM entry to deliver a hardware exception with or without an error code, regardless of vector (see Section 29.2.1.3).

* If bit 58 is read as 1, the processor provides VMX nested-exception support. With this support, software may indicate that an injected event is a nested exception (see Section 29.2.1.3 and Section 29.6.1.1), and the VM exits will indicate whether an event is an exception encountered during FRED event delivery (see Section 30.2.2 and Section 30.2.4). Any processor that supports FRED transitions will provide VMX nested-exception support.

* The values of bits 47:45, bit 57, and bits 63:59 are reserved and are read as 0.

## A.2 RESERVED CONTROLS AND DEFAULT SETTINGS

As noted in Chapter 29, “VM Entries,” certain VMX controls are reserved and must be set to a specific value (0 or 1) determined by the processor. The specific value to which a reserved control must be set is its **default setting**. Software can discover the default setting of a reserved control by consulting the appropriate VMX capability MSR (see Appendix A.3 through Appendix A.5).

Future processors may define new functionality for one or more reserved controls. Such processors would allow each newly defined control to be set either to 0 or to 1. Software that does not desire a control’s new functionality should set the control to its default setting. For that reason, it is useful for software to know the default settings of the reserved controls.

Default settings partition the various controls into the following classes:

* **Always-flexible.** These have never been reserved.

* **Default0.** These are (or have been) reserved with a default setting of 0.

* **Default1.** They are (or have been) reserved with a default setting of 1.

As noted in Appendix A.1, a logical processor uses bit 55 of the IA32_VMX_BASIC MSR to indicate whether any of the default1 controls may be 0:

* If bit 55 of the IA32_VMX_BASIC MSR is read as 0, all the default1 controls are reserved and must be 1. VM entry will fail if any of these controls are 0 (see Section 29.2.1).

* If bit 55 of the IA32_VMX_BASIC MSR is read as 1, not all the default1 controls are reserved, and some (but not necessarily all) may be 0. The CPU supports four (4) new VMX capability MSRs: IA32_VMX_TRUE_PINBASED_CTLS, IA32_VMX_TRUE_PROCBASED_CTLS, IA32_VMX_TRUE_EXIT_CTLS, and IA32_VMX_TRUE_ENTRY_CTLS. See Appendix A.3 through Appendix A.5 for details. (These MSRs are not supported if bit 55 of the IA32_VMX_BASIC MSR is read as 0.)

## A.3 VM-EXECUTION CONTROLS

There are separate capability MSRs for the pin-based VM-execution controls, the primary processor-based VM-execution controls, the secondary processor-based VM-execution controls, and the tertiary processor-based VM-execution controls. These are described in Appendix A.3.1, Appendix A.3.2, Appendix A.3.3, and Appendix A.3.4, respectively.

A-2 Vol. 3D
<page_number>A-2</page_number>

VMX CAPABILITY REPORTING FACILITY

## A.3.1 Pin-Based VM-Execution Controls

The IA32_VMX_PINBASED_CTLS MSR (index 481H) reports on the allowed settings of **most** of the pin-based VM-execution controls (see Section 27.6.1):

* Bits 31:0 indicate the **allowed 0-settings** of these controls. VM entry allows control X (bit X of the pin-based VM-execution controls) to be 0 if bit X in the MSR is cleared to 0; if bit X in the MSR is set to 1, VM entry fails if control X is 0.

Exceptions are made for the pin-based VM-execution controls in the default1 class (see Appendix A.2). These are bits 1, 2, and 4; the corresponding bits of the IA32_VMX_PINBASED_CTLS MSR are always read as 1. The treatment of these controls by VM entry is determined by bit 55 in the IA32_VMX_BASIC MSR:

— If bit 55 in the IA32_VMX_BASIC MSR is read as 0, VM entry fails if any pin-based VM-execution control in the default1 class is 0.

— If bit 55 in the IA32_VMX_BASIC MSR is read as 1, the IA32_VMX_TRUE_PINBASED_CTLS MSR (see below) reports which of the pin-based VM-execution controls in the default1 class can be 0 on VM entry.

* Bits 63:32 indicate the **allowed 1-settings** of these controls. VM entry allows control X to be 1 if bit 32+X in the MSR is set to 1; if bit 32+X in the MSR is cleared to 0, VM entry fails if control X is 1.

If bit 55 in the IA32_VMX_BASIC MSR is read as 1, the IA32_VMX_TRUE_PINBASED_CTLS MSR (index 48DH) reports on the allowed settings of **all** of the pin-based VM-execution controls:

* Bits 31:0 indicate the allowed 0-settings of these controls. VM entry allows control X to be 0 if bit X in the MSR is cleared to 0; if bit X in the MSR is set to 1, VM entry fails if control X is 0. There are no exceptions.

* Bits 63:32 indicate the allowed 1-settings of these controls. VM entry allows control X to be 1 if bit 32+X in the MSR is set to 1; if bit 32+X in the MSR is cleared to 0, VM entry fails if control X is 1.

It is necessary for software to consult only one of the capability MSRs to determine the allowed settings of the pin-based VM-execution controls:

* If bit 55 in the IA32_VMX_BASIC MSR is read as 0, all information about the allowed settings of the pin-based VM-execution controls is contained in the IA32_VMX_PINBASED_CTLS MSR. (The IA32_VMX_TRUE_PINBASED_CTLS MSR is not supported.)

* If bit 55 in the IA32_VMX_BASIC MSR is read as 1, all information about the allowed settings of the pin-based VM-execution controls is contained in the IA32_VMX_TRUE_PINBASED_CTLS MSR. Assuming that software knows that the default1 class of pin-based VM-execution controls contains bits 1, 2, and 4, there is no need for software to consult the IA32_VMX_PINBASED_CTLS MSR.

## A.3.2 Primary Processor-Based VM-Execution Controls

The IA32_VMX_PROCBASED_CTLS MSR (index 482H) reports on the allowed settings of **most** of the primary processor-based VM-execution controls (see Section 27.6.2):

* Bits 31:0 indicate the allowed 0-settings of these controls. VM entry allows control X (bit X of the primary processor-based VM-execution controls) to be 0 if bit X in the MSR is cleared to 0; if bit X in the MSR is set to 1, VM entry fails if control X is 0.

Exceptions are made for the primary processor-based VM-execution controls in the default1 class (see Appendix A.2). These are bits 1, 4–6, 8, 13–16, and 26; the corresponding bits of the IA32_VMX_PROCBASED_CTLS MSR are always read as 1. The treatment of these controls by VM entry is determined by bit 55 in the IA32_VMX_BASIC MSR:

— If bit 55 in the IA32_VMX_BASIC MSR is read as 0, VM entry fails if any of the primary processor-based VM-execution controls in the default1 class is 0.

— If bit 55 in the IA32_VMX_BASIC MSR is read as 1, the IA32_VMX_TRUE_PROCBASED_CTLS MSR (see below) reports which of the primary processor-based VM-execution controls in the default1 class can be 0 on VM entry.

* Bits 63:32 indicate the allowed 1-settings of these controls. VM entry allows control X to be 1 if bit 32+X in the MSR is set to 1; if bit 32+X in the MSR is cleared to 0, VM entry fails if control X is 1.

Vol. 3D A-3

VMX CAPABILITY REPORTING FACILITY

If bit 55 in the IA32_VMX_BASIC MSR is read as 1, the IA32_VMX_TRUE_PROCBASED_CTLS MSR (index 48EH) reports on the allowed settings of **all** of the primary processor-based VM-execution controls:

* Bits 31:0 indicate the allowed 0-settings of these controls. VM entry allows control X to be 0 if bit X in the MSR is cleared to 0; if bit X in the MSR is set to 1, VM entry fails if control X is 0. There are no exceptions.

* Bits 63:32 indicate the allowed 1-settings of these controls. VM entry allows control X to be 1 if bit 32+X in the MSR is set to 1; if bit 32+X in the MSR is cleared to 0, VM entry fails if control X is 1.

It is necessary for software to consult only one of the capability MSRs to determine the allowed settings of the primary processor-based VM-execution controls:

* If bit 55 in the IA32_VMX_BASIC MSR is read as 0, all information about the allowed settings of the primary processor-based VM-execution controls is contained in the IA32_VMX_PROCBASED_CTLS MSR. (The IA32_VMX_TRUE_PROCBASED_CTLS MSR is not supported.)

* If bit 55 in the IA32_VMX_BASIC MSR is read as 1, all information about the allowed settings of the primary processor-based VM-execution controls is contained in the IA32_VMX_TRUE_PROCBASED_CTLS MSR. Assuming that software knows that the default1 class of primary processor-based VM-execution controls contains bits 1, 4–6, 8, 13–16, and 26, there is no need for software to consult the IA32_VMX_PROCBASED_CTLS MSR.

## A.3.3 Secondary Processor-Based VM-Execution Controls

The IA32_VMX_PROCBASED_CTLS2 MSR (index 48BH) reports on the allowed settings of the secondary processor-based VM-execution controls (see Section 27.6.2). The following items provide details, including enforcement by VM entry:

* Bits 31:0 indicate the allowed 0-settings of these controls. These bits are always 0. This fact indicates that VM entry allows each bit of the secondary processor-based VM-execution controls to be 0 (reserved bits must be 0)

* Bits 63:32 indicate the allowed 1-settings of these controls; the 1-setting is not allowed for any reserved bit. VM entry allows control X (bit X of the secondary processor-based VM-execution controls) to be 1 if bit 32+X in the MSR is set to 1; if bit 32+X in the MSR is cleared to 0, VM entry fails if control X and the “activate secondary controls” primary processor-based VM-execution control are both 1.

The IA32_VMX_PROCBASED_CTLS2 MSR exists only on processors that support the 1-setting of the “activate secondary controls” VM-execution control (only if bit 63 of the IA32_VMX_PROCBASED_CTLS MSR is 1).

## A.3.4 Tertiary Processor-Based VM-Execution Controls

The IA32_VMX_PROCBASED_CTLS3 MSR (index 492H) reports on the allowed 1-settings of the tertiary processor-based VM-execution controls (see Section 27.6.2); the 1-setting is not allowed for any reserved bit.

VM entry allows control X (bit X of the tertiary processor-based VM-execution controls) to be 1 if bit X in the MSR is set to 1; if bit X in the MSR is cleared to 0, VM entry fails if control X and the “activate tertiary controls” primary processor-based VM-execution control are both 1.

The IA32_VMX_PROCBASED_CTLS3 MSR exists only on processors that support the 1-setting of the “activate tertiary controls” VM-execution control (only if bit 49 of the IA32_VMX_PROCBASED_CTLS MSR is 1).

Notice that the organization of this MSR differs from that of IA32_VMX_PROCBASED_CTLS2 (Appendix A.3.3). This is because there are 64 tertiary processor-based VM-execution controls, while there were only 32 secondary processor-based VM-execution controls.

## A.4 VM-EXIT CONTROLS

There are separate capability MSRs for the primary VM-exit controls and the secondary VM-exit controls. These are described in Appendix A.4.1 and Appendix A.4.2, respectively.

A-4 Vol. 3D

VMX CAPABILITY REPORTING FACILITY

## A.4.1 Primary VM-Exit Controls

The IA32_VMX_EXIT_CTLS MSR (index 483H) reports on the allowed settings of **most** of the primary VM-exit controls (see Section 27.7.1):

* Bits 31:0 indicate the allowed 0-settings of these controls. VM entry allows control X (bit X of the primary VM-exit controls) to be 0 if bit X in the MSR is cleared to 0; if bit X in the MSR is set to 1, VM entry fails if control X is 0.

Exceptions are made for the primary VM-exit controls in the default1 class (see Appendix A.2). These are bits 0–8, 10, 11, 13, 14, 16, and 17; the corresponding bits of the IA32_VMX_EXIT_CTLS MSR are always read as 1. The treatment of these controls by VM entry is determined by bit 55 in the IA32_VMX_BASIC MSR:

— If bit 55 in the IA32_VMX_BASIC MSR is read as 0, VM entry fails if any primary VM-exit control in the default1 class is 0.

— If bit 55 in the IA32_VMX_BASIC MSR is read as 1, the IA32_VMX_TRUE_EXIT_CTLS MSR (see below) reports which of the primary VM-exit controls in the default1 class can be 0 on VM entry.

* Bits 63:32 indicate the allowed 1-settings of these controls. VM entry allows control 32+X to be 1 if bit X in the MSR is set to 1; if bit 32+X in the MSR is cleared to 0, VM entry fails if control X is 1.

If bit 55 in the IA32_VMX_BASIC MSR is read as 1, the IA32_VMX_TRUE_EXIT_CTLS MSR (index 48FH) reports on the allowed settings of **all** of the primary VM-exit controls:

* Bits 31:0 indicate the allowed 0-settings of these controls. VM entry allows control X to be 0 if bit X in the MSR is cleared to 0; if bit X in the MSR is set to 1, VM entry fails if control X is 0. There are no exceptions.

* Bits 63:32 indicate the allowed 1-settings of these controls. VM entry allows control X to be 1 if bit 32+X in the MSR is set to 1; if bit 32+X in the MSR is cleared to 0, VM entry fails if control X is 1.

It is necessary for software to consult only one of the capability MSRs to determine the allowed settings of the primary VM-exit controls:

* If bit 55 in the IA32_VMX_BASIC MSR is read as 0, all information about the allowed settings of the primary VM-exit controls is contained in the IA32_VMX_EXIT_CTLS MSR. (The IA32_VMX_TRUE_EXIT_CTLS MSR is not supported.)

* If bit 55 in the IA32_VMX_BASIC MSR is read as 1, all information about the allowed settings of the primary VM-exit controls is contained in the IA32_VMX_TRUE_EXIT_CTLS MSR. Assuming that software knows that the default1 class of primary VM-exit controls contains bits 0–8, 10, 11, 13, 14, 16, and 17, there is no need for software to consult the IA32_VMX_EXIT_CTLS MSR.

## A.4.2 Secondary VM-Exit Controls

The IA32_VMX_EXIT_CTLS2 MSR (index 493H) reports on the allowed 1-settings of the secondary VM-exit controls (see Section 27.7.1); the 1-setting is not allowed for any reserved bit.

VM entry allows control X (bit X of the secondary VM-exit controls) to be 1 if bit X in the MSR is set to 1; if bit X in the MSR is cleared to 0, VM entry fails if control X and the "activate secondary controls" primary VM-exit control are both 1.

The IA32_VMX_EXIT_CTLS2 MSR exists only on processors that support the 1-setting of the "activate secondary controls" VM-exit control (only if bit 63 of the IA32_VMX_EXIT_CTLS MSR is 1).

Notice that the organization of this MSR differs from that of IA32_VMX_EXIT_CTLS (Appendix A.4.1). This is because there are 64 secondary VM-exit controls, while there were only 32 primary VM-exit controls.

## A.5 VM-ENTRY CONTROLS

The IA32_VMX_ENTRY_CTLS MSR (index 484H) reports on the allowed settings of **most** of the VM-entry controls (see Section 27.8.1):

* Bits 31:0 indicate the allowed 0-settings of these controls. VM entry allows control X (bit X of the VM-entry controls) to be 0 if bit X in the MSR is cleared to 0; if bit X in the MSR is set to 1, VM entry fails if control X is 0.

Vol. 3D A-5
<page_number>A-5</page_number>

VMX CAPABILITY REPORTING FACILITY

Exceptions are made for the VM-entry controls in the default1 class (see Appendix A.2). These are bits 0–8 and 12; the corresponding bits of the IA32_VMX_ENTRY_CTLS MSR are always read as 1. The treatment of these controls by VM entry is determined by bit 55 in the IA32_VMX_BASIC MSR:

— If bit 55 in the IA32_VMX_BASIC MSR is read as 0, VM entry fails if any VM-entry control in the default1 class is 0.

— If bit 55 in the IA32_VMX_BASIC MSR is read as 1, the IA32_VMX_TRUE_ENTRY_CTLS MSR (see below) reports which of the VM-entry controls in the default1 class can be 0 on VM entry.

* Bits 63:32 indicate the allowed 1-settings of these controls. VM entry fails if bit X is 1 in the VM-entry controls and bit 32+X is 0 in this MSR.

If bit 55 in the IA32_VMX_BASIC MSR is read as 1, the IA32_VMX_TRUE_ENTRY_CTLS MSR (index 490H) reports on the allowed settings of all of the VM-entry controls:

* Bits 31:0 indicate the allowed 0-settings of these controls. VM entry allows control X to be 0 if bit X in the MSR is cleared to 0; if bit X in the MSR is set to 1, VM entry fails if control X is 0. There are no exceptions.

* Bits 63:32 indicate the allowed 1-settings of these controls. VM entry allows control 32+X to be 1 if bit X in the MSR is set to 1; if bit 32+X in the MSR is cleared to 0, VM entry fails if control X is 1.

It is necessary for software to consult only one of the capability MSRs to determine the allowed settings of the VM-entry controls:

* If bit 55 in the IA32_VMX_BASIC MSR is read as 0, all information about the allowed settings of the VM-entry controls is contained in the IA32_VMX_ENTRY_CTLS MSR. (The IA32_VMX_TRUE_ENTRY_CTLS MSR is not supported.)

* If bit 55 in the IA32_VMX_BASIC MSR is read as 1, all information about the allowed settings of the VM-entry controls is contained in the IA32_VMX_TRUE_ENTRY_CTLS MSR. Assuming that software knows that the default1 class of VM-entry controls contains bits 0–8 and 12, there is no need for software to consult the IA32_VMX_ENTRY_CTLS MSR.

# A.6 MISCELLANEOUS DATA

The IA32_VMX_MISC MSR (index 485H) consists of the following fields:

* Bits 4:0 report a value X that specifies the relationship between the rate of the VMX-preemption timer and that of the timestamp counter (TSC). Specifically, the VMX-preemption timer (if it is active) counts down by 1 every time bit X in the TSC changes due to a TSC increment.

* If bit 5 is read as 1, VM exits store the value of IA32_EFER.LMA into the “IA-32e mode guest” VM-entry control; see Section 30.2 for more details. This bit is read as 1 on any logical processor that supports the 1-setting of the “unrestricted guest” VM-execution control.

* Bits 8:6 report, as a bitmap, the activity states supported by the implementation:

  — Bit 6 reports (if set) the support for activity state 1 (HLT).

  — Bit 7 reports (if set) the support for activity state 2 (shutdown).

  — Bit 8 reports (if set) the support for activity state 3 (wait-for-SIPI).

  If an activity state is not supported, the implementation causes a VM entry to fail if it attempts to establish that activity state. All implementations support VM entry to activity state 0 (active).

* If bit 14 is read as 1, Intel<sup>®</sup> Processor Trace (Intel PT) can be used in VMX operation. If the processor supports Intel PT but does not allow it to be used in VMX operation, execution of VMXON clears IA32_RTIT_CTL.TraceEn (see “VMXON—Enter VMX Operation” in Chapter 33); any attempt to write IA32_RTIT_CTL while in VMX operation (including VMX root operation) causes a general-protection exception.

* If bit 15 is read as 1, the RDMSR instruction can be used in system-management mode (SMM) to read the IA32_SMBASE MSR (MSR address 9EH). See Section 34.15.6.3.

* Bits 24:16 indicate the number of CR3-target values supported by the processor. This number is a value between 0 and 256, inclusive (bit 24 is set if and only if bits 23:16 are clear).

<page_number>A-6</page_number> Vol. 3D

VMX CAPABILITY REPORTING FACILITY

* Bits 27:25 is used to compute the recommended maximum number of MSRs that should appear in the VM-exit MSR-store list, the VM-exit MSR-load list, or the VM-entry MSR-load list. Specifically, if the value bits 27:25 of IA32_VMX_MISC is N, then 512 * (N + 1) is the recommended maximum number of MSRs to be included in each list. If the limit is exceeded, undefined processor behavior may result (including a machine check during the VMX transition).

* If bit 28 is read as 1, bit 2 of the IA32_SMM_MONITOR_CTL can be set to 1. VMXOFF unblocks SMIs unless IA32_SMM_MONITOR_CTL[bit 2] is 1 (see Section 34.14.4).

* If bit 29 is read as 1, software can use VMWRITE to write to any supported field in the VMCS; otherwise, VMWRITE cannot be used to modify VM-exit information fields.

* If bit 30 is read as 1, VM entry allows injection of a software interrupt, software exception, or privileged software exception with an instruction length of 0.

* Bits 63:32 report the 32-bit MSEG revision identifier used by the processor.

* Bits 13:9 and bit 31 are reserved and are read as 0.

# A.7 VMX-FIXED BITS IN CR0

The IA32_VMX_CR0_FIXED0 MSR (index 486H) and IA32_VMX_CR0_FIXED1 MSR (index 487H) indicate how bits in CR0 may be set in VMX operation. They report on bits in CR0 that are allowed to be 0 and to be 1, respectively, in VMX operation. If bit X is 1 in IA32_VMX_CR0_FIXED0, then that bit of CR0 is fixed to 1 in VMX operation. Similarly, if bit X is 0 in IA32_VMX_CR0_FIXED1, then that bit of CR0 is fixed to 0 in VMX operation. It is always the case that, if bit X is 1 in IA32_VMX_CR0_FIXED0, then that bit is also 1 in IA32_VMX_CR0_FIXED1; if bit X is 0 in IA32_VMX_CR0_FIXED1, then that bit is also 0 in IA32_VMX_CR0_FIXED0. Thus, each bit in CR0 is either fixed to 0 (with value 0 in both MSRs), fixed to 1 (1 in both MSRs), or flexible (0 in IA32_VMX_CR0_FIXED0 and 1 in IA32_VMX_CR0_FIXED1).

# A.8 VMX-FIXED BITS IN CR4

The IA32_VMX_CR4_FIXED0 MSR (index 488H) and IA32_VMX_CR4_FIXED1 MSR (index 489H) indicate how bits in CR4 may be set in VMX operation. They report on bits in CR4 that are allowed to be 0 and 1, respectively, in VMX operation. If bit X is 1 in IA32_VMX_CR4_FIXED0, then that bit of CR4 is fixed to 1 in VMX operation. Similarly, if bit X is 0 in IA32_VMX_CR4_FIXED1, then that bit of CR4 is fixed to 0 in VMX operation. It is always the case that, if bit X is 1 in IA32_VMX_CR4_FIXED0, then that bit is also 1 in IA32_VMX_CR4_FIXED1; if bit X is 0 in IA32_VMX_CR4_FIXED1, then that bit is also 0 in IA32_VMX_CR4_FIXED0. Thus, each bit in CR4 is either fixed to 0 (with value 0 in both MSRs), fixed to 1 (1 in both MSRs), or flexible (0 in IA32_VMX_CR4_FIXED0 and 1 in IA32_VMX_CR4_FIXED1).

# A.9 VMCS ENUMERATION

The IA32_VMX_VMCS_ENUM MSR (index 48AH) provides information to assist software in enumerating fields in the VMCS.

As noted in Section 27.11.2, each field in the VMCS is associated with a 32-bit encoding which is structured as follows:

* Bits 31:15 are reserved (must be 0).

* Bits 14:13 indicate the field's width.

* Bit 12 is reserved (must be 0).

* Bits 11:10 indicate the field's type.

* Bits 9:1 is an index field that distinguishes different fields with the same width and type.

* Bit 0 indicates access type.

Vol. 3D A-7
<page_number>A-7</page_number>

VMX CAPABILITY REPORTING FACILITY

IA32_VMX_VMCS_ENUM indicates to software the highest index value used in the encoding of any field supported by the processor:

* Bits 9:1 contain the highest index value used for any VMCS encoding.

* Bit 0 and bits 63:10 are reserved and are read as 0.

# A.10 VPID AND EPT CAPABILITIES

The IA32_VMX_EPT_VPID_CAP MSR (index 48CH) reports information about the capabilities of the logical processor with regard to virtual-processor identifiers (VPIDs, Section 31.1) and extended page tables (EPT, Section 31.3):

* If bit 0 is read as 1, the processor supports execute-only translations by EPT. This support allows software to configure EPT paging-structure entries in which bits 1:0 are clear (indicating that data accesses are not allowed) and bit 2 is set (indicating that instruction fetches are allowed).<sup>1</sup>

* Bit 6 indicates support for a page-walk length of 4.

* Bit 7 indicates support for a page-walk length of 5.

* If bit 8 is read as 1, the logical processor allows software to configure the EPT paging-structure memory type to be uncacheable (UC); see Section 27.6.11.

* If bit 14 is read as 1, the logical processor allows software to configure the EPT paging-structure memory type to be write-back (WB).

* If bit 16 is read as 1, the logical processor allows software to configure a EPT PDE to map a 2-Mbyte page (by setting bit 7 in the EPT PDE).

* If bit 17 is read as 1, the logical processor allows software to configure a EPT PDPTE to map a 1-Gbyte page (by setting bit 7 in the EPT PDPTE).

* Support for the INVEPT instruction (see Chapter 33 and Section 31.4.3.1):

  — If bit 20 is read as 1, the INVEPT instruction is supported.

  — If bit 25 is read as 1, the single-context INVEPT type is supported.

  — If bit 26 is read as 1, the all-context INVEPT type is supported.

* If bit 21 is read as 1, accessed and dirty flags for EPT are supported (see Section 31.3.5).

* If bit 22 is read as 1, the processor reports advanced VM-exit information for EPT violations (see Section 30.2.1). This reporting is done only if this bit is read as 1.

* If bit 23 is read as 1, supervisor shadow-stack control is supported (see Section 31.3.3.2).

* Support for the INVVPID instruction (see Chapter 33 and Section 31.4.3.1):

  — If bit 32 is read as 1, the INVVPID instruction is supported.

  — If bit 40 is read as 1, the individual-address INVVPID type is supported.

  — If bit 41 is read as 1, the single-context INVVPID type is supported.

  — If bit 42 is read as 1, the all-context INVVPID type is supported.

  — If bit 43 is read as 1, the single-context-retaining-globals INVVPID type is supported.

* Bits 53:48 enumerate the maximum HLAT prefix size. It is expected that any processor that supports the 1-setting of the "enable HLAT" VM-execution control will enumerate this value as 1. See Section 5.5.1.

* Bits 5:1, bits 13:9, bit 15, bits 19:18, bit 24, bits 31:27, bits 39:33, bits 47:44, and bits 63:54 are reserved and are read as 0.

The IA32_VMX_EPT_VPID_CAP MSR exists only on processors that support the 1-setting of the "activate secondary controls" VM-execution control (only if bit 63 of the IA32_VMX_PROCBASED_CTLS MSR is 1) and that support

<sup>1.</sup> If the "mode-based execute control for EPT" VM-execution control is 1, setting bit 0 indicates also that software may also configure EPT paging-structure entries in which bits 1:0 are both clear and in which bit 10 is set (indicating a translation that can be used to fetch instructions from a supervisor-mode linear address or a user-mode linear address).

A-8 Vol. 3D

VMX CAPABILITY REPORTING FACILITY

either the 1-setting of the “enable EPT” VM-execution control (only if bit 33 of the IA32_VMX_PROCBASED_CTLS2 MSR is 1) or the 1-setting of the “enable VPID” VM-execution control (only if bit 37 of the IA32_VMX_PROCBASED_CTLS2 MSR is 1).

# A.11 VM FUNCTIONS

The IA32_VMX_VMFUNC MSR (index 491H) reports on the allowed settings of the VM-function controls (see Section 27.6.14). VM entry allows bit X of the VM-function controls to be 1 if bit X in the MSR is set to 1; if bit X in the MSR is cleared to 0, VM entry fails if bit X of the VM-function controls, the “activate secondary controls” primary processor-based VM-execution control, and the “enable VM functions” secondary processor-based VM-execution control are all 1.

The IA32_VMX_VMFUNC MSR exists only on processors that support the 1-setting of the “activate secondary controls” VM-execution control (only if bit 63 of the IA32_VMX_PROCBASED_CTLS MSR is 1) and the 1-setting of the “enable VM functions” secondary processor-based VM-execution control (only if bit 45 of the IA32_VMX_PROCBASED_CTLS2 MSR is 1).

Vol. 3D A-9

VMX CAPABILITY REPORTING FACILITY

A-10 Vol. 3D

APPENDIX B
FIELD ENCODING IN VMCS

Every component of the VMCS is encoded by a 32-bit field that can be used by VMREAD and VMWRITE. Section 27.11.2 describes the structure of the encoding space (the meanings of the bits in each 32-bit encoding).

This appendix enumerates all fields in the VMCS and their encodings. Fields are grouped by width (16-bit, 32-bit, etc.) and type (guest-state, host-state, etc.).

# B.1 16-BIT FIELDS

A value of 0 in bits 14:13 of an encoding indicates a 16-bit field. Only guest-state areas and the host-state area contain 16-bit fields. As noted in Section 27.11.2, each 16-bit field allows only full access, meaning that bit 0 of its encoding is 0. Each such encoding is thus an even number.

## B.1.1 16-Bit Control Fields

A value of 0 in bits 11:10 of an encoding indicates a control field. These fields are distinguished by their index value in bits 9:1. Table B-1 enumerates the 16-bit control fields.

Table B-1. Encoding for 16-Bit Control Fields (0000_00xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Virtual-processor identifier (VPID)<sup>1</sup></td>
        <td>000000000B</td>
        <td>00000000H</td>
    </tr>
    <tr>
        <td>Posted-interrupt notification vector<sup>2</sup></td>
        <td>000000001B</td>
        <td>00000002H</td>
    </tr>
    <tr>
        <td>EPTP index<sup>3</sup></td>
        <td>000000010B</td>
        <td>00000004H</td>
    </tr>
    <tr>
        <td>HLAT prefix size<sup>4</sup></td>
        <td>000000011B</td>
        <td>00000006H</td>
    </tr>
    <tr>
        <td>Last PID-pointer index<sup>5</sup></td>
        <td>000000100B</td>
        <td>00000008H</td>
    </tr>
    <tr>
        <td>Virtual timer vector<sup>6</sup></td>
        <td>000000101B</td>
        <td>0000000AH</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. This field exists only on processors that support the 1-setting of the “enable VPID” VM-execution control.

2. This field exists only on processors that support the 1-setting of the “process posted interrupts” VM-execution control.

3. This field exists only on processors that support the 1-setting of the “EPT-violation #VE” VM-execution control.

4. This field exists only on processors that support the 1-setting of the “enable HLAT” VM-execution control.

5. This field exists only on processors that support the 1-setting of the “IPI virtualization” VM-execution control.

6. This field exists only on processors that support the 1-setting of the “APIC-timer virtualization” VM-execution control.

## B.1.2 16-Bit Guest-State Fields

A value of 2 in bits 11:10 of an encoding indicates a field in the guest-state area. These fields are distinguished by their index value in bits 9:1. Table B-2 enumerates 16-bit guest-state fields.

Table B-2. Encodings for 16-Bit Guest-State Fields (0000_10xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Guest ES selector</td>
        <td>000000000B</td>
        <td>00000800H</td>
    </tr>
    <tr>
        <td>Guest CS selector</td>
        <td>000000001B</td>
        <td>00000802H</td>
    </tr>
    <tr>
        <td>Guest SS selector</td>
        <td>000000010B</td>
        <td>00000804H</td>
    </tr>
  </tbody>
</table>

Vol. 3D <page_number>B-1</page_number>

FIELD ENCODING IN VMCS

Table B-2. Encodings for 16-Bit Guest-State Fields (0000_10xx_xxxx_xxx0B) (Contd.)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Guest DS selector</td>
        <td>000000011B</td>
        <td>00000806H</td>
    </tr>
    <tr>
        <td>Guest FS selector</td>
        <td>000000100B</td>
        <td>00000808H</td>
    </tr>
    <tr>
        <td>Guest GS selector</td>
        <td>000000101B</td>
        <td>0000080AH</td>
    </tr>
    <tr>
        <td>Guest LDTR selector</td>
        <td>000000110B</td>
        <td>0000080CH</td>
    </tr>
    <tr>
        <td>Guest TR selector</td>
        <td>000000111B</td>
        <td>0000080EH</td>
    </tr>
    <tr>
        <td>Guest interrupt status<sup>1</sup></td>
        <td>000001000B</td>
        <td>00000810H</td>
    </tr>
    <tr>
        <td>PML index<sup>2</sup></td>
        <td>000001001B</td>
        <td>00000812H</td>
    </tr>
    <tr>
        <td>Guest UINV<sup>3</sup></td>
        <td>000001010B</td>
        <td>00000814H</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. This field exists only on processors that support the 1-setting of the “virtual-interrupt delivery” VM-execution control.

2. This field exists only on processors that support the 1-setting of the “enable PML” VM-execution control.

3. This field exists only on processors that support the 1-setting of either the “clear UINV” VM-exit control or the “load UINV” VM-entry control.

## B.1.3 16-Bit Host-State Fields

A value of 3 in bits 11:10 of an encoding indicates a field in the host-state area. These fields are distinguished by their index value in bits 9:1. Table B-3 enumerates the 16-bit host-state fields.

Table B-3. Encodings for 16-Bit Host-State Fields (0000_11xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Host ES selector</td>
        <td>000000000B</td>
        <td>00000C00H</td>
    </tr>
    <tr>
        <td>Host CS selector</td>
        <td>000000001B</td>
        <td>00000C02H</td>
    </tr>
    <tr>
        <td>Host SS selector</td>
        <td>000000010B</td>
        <td>00000C04H</td>
    </tr>
    <tr>
        <td>Host DS selector</td>
        <td>000000011B</td>
        <td>00000C06H</td>
    </tr>
    <tr>
        <td>Host FS selector</td>
        <td>000000100B</td>
        <td>00000C08H</td>
    </tr>
    <tr>
        <td>Host GS selector</td>
        <td>000000101B</td>
        <td>00000C0AH</td>
    </tr>
    <tr>
        <td>Host TR selector</td>
        <td>000000110B</td>
        <td>00000C0CH</td>
    </tr>
  </tbody>
</table>

## B.2 64-BIT FIELDS

A value of 1 in bits 14:13 of an encoding indicates a 64-bit field. There are 64-bit fields only for controls and for guest state. As noted in Section 27.11.2, every 64-bit field has two encodings, which differ on bit 0, the access type. Thus, each such field has an even encoding for full access and an odd encoding for high access.

### B.2.1 64-Bit Control Fields

A value of 0 in bits 11:10 of an encoding indicates a control field. These fields are distinguished by their index value in bits 9:1. Table B-4 enumerates the 64-bit control fields.

Table B-4. Encodings for 64-Bit Control Fields (0010_00xx_xxxx_xxxAb)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Address of I/O bitmap A (full)</td>
        <td rowspan="2">000000000B</td>
        <td>00002000H</td>
    </tr>
    <tr>
        <td>Address of I/O bitmap A (high)</td>
        <td>00002001H</td>
    </tr>
  </tbody>
</table>

B-2 Vol. 3D

FIELD ENCODING IN VMCS

## Table B-4. Encodings for 64-Bit Control Fields (0010_00xx_xxxx_xxxAb) (Contd.)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Address of I/O bitmap B (full)</td>
        <td rowspan="2">000000001B</td>
        <td>00002002H</td>
    </tr>
    <tr>
        <td>Address of I/O bitmap B (high)</td>
        <td>00002003H</td>
    </tr>
    <tr>
        <td>Address of MSR bitmaps (full)<sup>1</sup></td>
        <td rowspan="2">000000010B</td>
        <td>00002004H</td>
    </tr>
    <tr>
        <td>Address of MSR bitmaps (high)<sup>1</sup></td>
        <td>00002005H</td>
    </tr>
    <tr>
        <td>VM-exit MSR-store address (full)</td>
        <td rowspan="2">000000011B</td>
        <td>00002006H</td>
    </tr>
    <tr>
        <td>VM-exit MSR-store address (high)</td>
        <td>00002007H</td>
    </tr>
    <tr>
        <td>VM-exit MSR-load address (full)</td>
        <td rowspan="2">000000100B</td>
        <td>00002008H</td>
    </tr>
    <tr>
        <td>VM-exit MSR-load address (high)</td>
        <td>00002009H</td>
    </tr>
    <tr>
        <td>VM-entry MSR-load address (full)</td>
        <td rowspan="2">000000101B</td>
        <td>0000200AH</td>
    </tr>
    <tr>
        <td>VM-entry MSR-load address (high)</td>
        <td>0000200BH</td>
    </tr>
    <tr>
        <td>Executive-VMCS pointer (full)</td>
        <td rowspan="2">000000110B</td>
        <td>0000200CH</td>
    </tr>
    <tr>
        <td>Executive-VMCS pointer (high)</td>
        <td>0000200DH</td>
    </tr>
    <tr>
        <td>PML address (full)<sup>2</sup></td>
        <td rowspan="2">000000111B</td>
        <td>0000200EH</td>
    </tr>
    <tr>
        <td>PML address (high)<sup>2</sup></td>
        <td>0000200FH</td>
    </tr>
    <tr>
        <td>TSC offset (full)</td>
        <td rowspan="2">000001000B</td>
        <td>00002010H</td>
    </tr>
    <tr>
        <td>TSC offset (high)</td>
        <td>00002011H</td>
    </tr>
    <tr>
        <td>Virtual-APIC address (full)<sup>3</sup></td>
        <td rowspan="2">000001001B</td>
        <td>00002012H</td>
    </tr>
    <tr>
        <td>Virtual-APIC address (high)<sup>3</sup></td>
        <td>00002013H</td>
    </tr>
    <tr>
        <td>APIC-access address (full)<sup>4</sup></td>
        <td rowspan="2">000001010B</td>
        <td>00002014H</td>
    </tr>
    <tr>
        <td>APIC-access address (high)<sup>4</sup></td>
        <td>00002015H</td>
    </tr>
    <tr>
        <td>Posted-interrupt descriptor address (full)<sup>5</sup></td>
        <td rowspan="2">000001011B</td>
        <td>00002016H</td>
    </tr>
    <tr>
        <td>Posted-interrupt descriptor address (high)<sup>5</sup></td>
        <td>00002017H</td>
    </tr>
    <tr>
        <td>VM-function controls (full)<sup>6</sup></td>
        <td rowspan="2">000001100B</td>
        <td>00002018H</td>
    </tr>
    <tr>
        <td>VM-function controls (high)<sup>6</sup></td>
        <td>00002019H</td>
    </tr>
    <tr>
        <td>EPT pointer (EPTP; full)<sup>7</sup></td>
        <td rowspan="2">000001101B</td>
        <td>0000201AH</td>
    </tr>
    <tr>
        <td>EPT pointer (EPTP; high)<sup>7</sup></td>
        <td>0000201BH</td>
    </tr>
    <tr>
        <td>EOI-exit bitmap 0 (EOI_EXIT0; full)<sup>8</sup></td>
        <td rowspan="2">000001110B</td>
        <td>0000201CH</td>
    </tr>
    <tr>
        <td>EOI-exit bitmap 0 (EOI_EXIT0; high)<sup>8</sup></td>
        <td>0000201DH</td>
    </tr>
    <tr>
        <td>EOI-exit bitmap 1 (EOI_EXIT1; full)<sup>8</sup></td>
        <td rowspan="2">000001111B</td>
        <td>0000201EH</td>
    </tr>
    <tr>
        <td>EOI-exit bitmap 1 (EOI_EXIT1; high)<sup>8</sup></td>
        <td>0000201FH</td>
    </tr>
    <tr>
        <td>EOI-exit bitmap 2 (EOI_EXIT2; full)<sup>8</sup></td>
        <td rowspan="2">000010000B</td>
        <td>00002020H</td>
    </tr>
    <tr>
        <td>EOI-exit bitmap 2 (EOI_EXIT2; high)<sup>8</sup></td>
        <td>00002021H</td>
    </tr>
    <tr>
        <td>EOI-exit bitmap 3 (EOI_EXIT3; full)<sup>8</sup></td>
        <td rowspan="2">000010001B</td>
        <td>00002022H</td>
    </tr>
    <tr>
        <td>EOI-exit bitmap 3 (EOI_EXIT3; high)<sup>8</sup></td>
        <td>00002023H</td>
    </tr>
    <tr>
        <td>EPTP-list address (full)<sup>9</sup></td>
        <td rowspan="2">000010010B</td>
        <td>00002024H</td>
    </tr>
    <tr>
        <td>EPTP-list address (high)<sup>9</sup></td>
        <td>00002025H</td>
    </tr>
    <tr>
        <td>VMREAD-bitmap address (full)<sup>10</sup></td>
        <td rowspan="2">000010011B</td>
        <td>00002026H</td>
    </tr>
    <tr>
        <td>VMREAD-bitmap address (high)<sup>10</sup></td>
        <td>00002027H</td>
    </tr>
  </tbody>
</table>

Vol. 3D B-3

FIELD ENCODING IN VMCS

Table B-4. Encodings for 64-Bit Control Fields (0010_00xx_xxxx_xxxAb) (Contd.)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>VMWRITE-bitmap address (full)<sup>10</sup></td>
        <td rowspan="2">000010100B</td>
        <td>00002028H</td>
    </tr>
    <tr>
        <td>VMWRITE-bitmap address (high)<sup>10</sup></td>
        <td>00002029H</td>
    </tr>
    <tr>
        <td>Virtualization-exception information address (full)<sup>11</sup></td>
        <td rowspan="2">000010101B</td>
        <td>0000202AH</td>
    </tr>
    <tr>
        <td>Virtualization-exception information address (high)<sup>11</sup></td>
        <td>0000202BH</td>
    </tr>
    <tr>
        <td>XSS-exiting bitmap (full)<sup>12</sup></td>
        <td rowspan="2">000010110B</td>
        <td>0000202CH</td>
    </tr>
    <tr>
        <td>XSS-exiting bitmap (high)<sup>12</sup></td>
        <td>0000202DH</td>
    </tr>
    <tr>
        <td>ENCLS-exiting bitmap (full)<sup>13</sup></td>
        <td rowspan="2">000010111B</td>
        <td>0000202EH</td>
    </tr>
    <tr>
        <td>ENCLS-exiting bitmap (high)<sup>13</sup></td>
        <td>0000202FH</td>
    </tr>
    <tr>
        <td>Sub-page-permission-table pointer (full)<sup>14</sup></td>
        <td rowspan="2">000011000B</td>
        <td>00002030H</td>
    </tr>
    <tr>
        <td>Sub-page-permission-table pointer (high)<sup>14</sup></td>
        <td>00002031H</td>
    </tr>
    <tr>
        <td>TSC multiplier (full)<sup>15</sup></td>
        <td rowspan="2">000011001B</td>
        <td>00002032H</td>
    </tr>
    <tr>
        <td>TSC multiplier (high)<sup>15</sup></td>
        <td>00002033H</td>
    </tr>
    <tr>
        <td>Tertiary processor-based VM-execution controls (full)<sup>16</sup></td>
        <td rowspan="2">000011010B</td>
        <td>00002034H</td>
    </tr>
    <tr>
        <td>Tertiary processor-based VM-execution controls (high)<sup>16</sup></td>
        <td>00002035H</td>
    </tr>
    <tr>
        <td>Low PASID directory address (full)<sup>17</sup></td>
        <td rowspan="2">000011100B</td>
        <td>00002038H</td>
    </tr>
    <tr>
        <td>Low PASID directory address (high)<sup>17</sup></td>
        <td>00002039H</td>
    </tr>
    <tr>
        <td>High PASID directory address (full)<sup>17</sup></td>
        <td rowspan="2">000011101B</td>
        <td>0000203AH</td>
    </tr>
    <tr>
        <td>High PASID directory address (high)<sup>17</sup></td>
        <td>0000203BH</td>
    </tr>
    <tr>
        <td>SEAM shared EPT pointer (full)<sup>18</sup></td>
        <td rowspan="2">000011110B</td>
        <td>0000203CH</td>
    </tr>
    <tr>
        <td>SEAM shared EPT pointer (high)<sup>18</sup></td>
        <td>0000203DH</td>
    </tr>
    <tr>
        <td>PCONFIG-exiting bitmap (full)<sup>19</sup></td>
        <td rowspan="2">000011111B</td>
        <td>0000203EH</td>
    </tr>
    <tr>
        <td>PCONFIG-exiting bitmap (high)<sup>19</sup></td>
        <td>0000203FH</td>
    </tr>
    <tr>
        <td>Hypervisor-managed linear-address translation pointer (HLATP; full)<sup>20</sup></td>
        <td rowspan="2">000100000B</td>
        <td>00002040H</td>
    </tr>
    <tr>
        <td>HLATP (high)<sup>20</sup></td>
        <td>00002041H</td>
    </tr>
    <tr>
        <td>PID-pointer table address (full)<sup>21</sup></td>
        <td rowspan="2">000100001B</td>
        <td>00002042H</td>
    </tr>
    <tr>
        <td>PID-pointer table address (high)<sup>21</sup></td>
        <td>00002043H</td>
    </tr>
    <tr>
        <td>Secondary VM-exit controls (full)<sup>22</sup></td>
        <td rowspan="2">000100010B</td>
        <td>00002044H</td>
    </tr>
    <tr>
        <td>Secondary VM-exit controls (high)<sup>22</sup></td>
        <td>00002045H</td>
    </tr>
    <tr>
        <td>IA32_SPEC_CTRL mask (full)<sup>23</sup></td>
        <td rowspan="2">000100101B</td>
        <td>0000204AH</td>
    </tr>
    <tr>
        <td>IA32_SPEC_CTRL mask (high)<sup>23</sup></td>
        <td>0000204BH</td>
    </tr>
    <tr>
        <td>IA32_SPEC_CTRL shadow (full)<sup>23</sup></td>
        <td rowspan="2">000100110B</td>
        <td>0000204CH</td>
    </tr>
    <tr>
        <td>IA32_SPEC_CTRL shadow (high)<sup>23</sup></td>
        <td>0000204DH</td>
    </tr>
    <tr>
        <td>Guest deadline shadow (full)<sup>24</sup></td>
        <td rowspan="2">000100111B</td>
        <td>0000204EH</td>
    </tr>
    <tr>
        <td>Guest deadline shadow (high)<sup>24</sup></td>
        <td>0000204FH</td>
    </tr>
    <tr>
        <td>Injected-event data (full)<sup>25</sup></td>
        <td rowspan="2">000101001B</td>
        <td>00002052H</td>
    </tr>
    <tr>
        <td>Injected-event data (high)<sup>25</sup></td>
        <td>00002053H</td>
    </tr>
  </tbody>
</table>

NOTES:

1. This field exists only on processors that support the 1-setting of the “use MSR bitmaps” VM-execution control.

2. This field exists only on processors that support the 1-setting of the “enable PML” VM-execution control.

<page_number>B-4</page_number> Vol. 3D

FIELD ENCODING IN VMCS

3. This field exists only on processors that support the 1-setting of the “use TPR shadow” VM-execution control.

4. This field exists only on processors that support the 1-setting of the “virtualize APIC accesses” VM-execution control.

5. This field exists only on processors that support the 1-setting of the “process posted interrupts” VM-execution control.

6. This field exists only on processors that support the 1-setting of the “enable VM functions” VM-execution control.

7. This field exists only on processors that support the 1-setting of the “enable EPT” VM-execution control.

8. This field exists only on processors that support the 1-setting of the “virtual-interrupt delivery” VM-execution control.

9. This field exists only on processors that support the 1-setting of the “EPTP switching” VM-function control.

10. This field exists only on processors that support the 1-setting of the “VMCS shadowing” VM-execution control.

11. This field exists only on processors that support the 1-setting of the “EPT-violation #VE” VM-execution control.

12. This field exists only on processors that support the 1-setting of the “enable XSAVES/XRSTORS” VM-execution control.

13. This field exists only on processors that support the 1-setting of the “enable ENCLS exiting” VM-execution control.

14. This field exists only on processors that support the 1-setting of the “sub-page write permissions for EPT” VM-execution control.

15. This field exists only on processors that support the 1-setting of the “use TSC scaling” VM-execution control.

16. This field exists only on processors that support the 1-setting of the “activate tertiary controls” VM-execution control.

17. This field exists only on processors that support the 1-setting of the “PASID translation” VM-execution control.

18. This field exists only on processors that support the 1-setting of the “SEAM guest-physical address width” VM-execution control.

19. This field exists only on processors that support the 1-setting of the “enable PCONFIG” VM-execution control.

20. This field exists only on processors that support the 1-setting of the “enable HLAT” VM-execution control.

21. This field exists only on processors that support the 1-setting of the “IPI virtualization” VM-execution control.

22. This field exists only on processors that support the 1-setting of the “activate secondary controls” VM-exit control.

23. This field exists only on processors that support the 1-setting of the “virtualize IA32_SPEC_CTRL” VM-execution control.

24. This field exists only on processors that support the 1-setting of the “APIC-timer virtualization” VM-execution control.

25. This field exists only on processors that support FRED transitions.

## B.2.2 64-Bit Read-Only Data Fields

A value of 1 in bits 11:10 of an encoding indicates a read-only data field. These fields are distinguished by their index value in bits 9:1. Table B-5 enumerates the 64-bit read-only data fields.

Table B-5. Encodings for 64-Bit Read-Only Data Fields (0010_01xx_xxxx_xxxAb)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Guest-physical address (full)<sup>1</sup></td>
        <td rowspan="2">000000000B</td>
        <td>00002400H</td>
    </tr>
    <tr>
        <td>Guest-physical address (high)<sup>1</sup></td>
        <td>00002401H</td>
    </tr>
    <tr>
        <td>MSR data (full)<sup>2</sup></td>
        <td rowspan="2">000000001B</td>
        <td>00002402H</td>
    </tr>
    <tr>
        <td>MSR data (high)<sup>2</sup></td>
        <td>00002403H</td>
    </tr>
    <tr>
        <td>Original-event data (full)<sup>3</sup></td>
        <td rowspan="2">000000010B</td>
        <td>00002404H</td>
    </tr>
    <tr>
        <td>Original-event data (high)<sup>3</sup></td>
        <td>00002405H</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. This field exists only on processors that support the 1-setting of the “enable EPT” VM-execution control.

2. This field exists only on processors that support the 1-setting of the “enable MSR-list instructions” VM-execution control.

3. This field exists only on processors that support FRED transitions.

Vol. 3D B-5
<page_number>B-5</page_number>

FIELD ENCODING IN VMCS

## B.2.3 64-Bit Guest-State Fields

A value of 2 in bits 11:10 of an encoding indicates a field in the guest-state area. These fields are distinguished by their index value in bits 9:1. Table B-6 enumerates the 64-bit guest-state fields.

Table B-6. Encodings for 64-Bit Guest-State Fields (0010_10xx_xxxx_xxxAb)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>VMCS link pointer (full)</td>
        <td rowspan="2">000000000B</td>
        <td>00002800H</td>
    </tr>
    <tr>
        <td>VMCS link pointer (high)</td>
        <td>00002801H</td>
    </tr>
    <tr>
        <td>Guest IA32_DEBUGCTL (full)</td>
        <td rowspan="2">000000001B</td>
        <td>00002802H</td>
    </tr>
    <tr>
        <td>Guest IA32_DEBUGCTL (high)</td>
        <td>00002803H</td>
    </tr>
    <tr>
        <td>Guest IA32_PAT (full)<sup>1</sup></td>
        <td rowspan="2">000000010B</td>
        <td>00002804H</td>
    </tr>
    <tr>
        <td>Guest IA32_PAT (high)<sup>1</sup></td>
        <td>00002805H</td>
    </tr>
    <tr>
        <td>Guest IA32_EFER (full)<sup>2</sup></td>
        <td rowspan="2">000000011B</td>
        <td>00002806H</td>
    </tr>
    <tr>
        <td>Guest IA32_EFER (high)<sup>2</sup></td>
        <td>00002807H</td>
    </tr>
    <tr>
        <td>Guest IA32_PERF_GLOBAL_CTRL (full)<sup>3</sup></td>
        <td rowspan="2">000000100B</td>
        <td>00002808H</td>
    </tr>
    <tr>
        <td>Guest IA32_PERF_GLOBAL_CTRL (high)<sup>3</sup></td>
        <td>00002809H</td>
    </tr>
    <tr>
        <td>Guest PDPTE0 (full)<sup>4</sup></td>
        <td rowspan="2">000000101B</td>
        <td>0000280AH</td>
    </tr>
    <tr>
        <td>Guest PDPTE0 (high)<sup>4</sup></td>
        <td>0000280BH</td>
    </tr>
    <tr>
        <td>Guest PDPTE1 (full)<sup>4</sup></td>
        <td rowspan="2">000000110B</td>
        <td>0000280CH</td>
    </tr>
    <tr>
        <td>Guest PDPTE1 (high)<sup>4</sup></td>
        <td>0000280DH</td>
    </tr>
    <tr>
        <td>Guest PDPTE2 (full)<sup>4</sup></td>
        <td rowspan="2">000000111B</td>
        <td>0000280EH</td>
    </tr>
    <tr>
        <td>Guest PDPTE2 (high)<sup>4</sup></td>
        <td>0000280FH</td>
    </tr>
    <tr>
        <td>Guest PDPTE3 (full)<sup>4</sup></td>
        <td rowspan="2">000001000B</td>
        <td>00002810H</td>
    </tr>
    <tr>
        <td>Guest PDPTE3 (high)<sup>4</sup></td>
        <td>00002811H</td>
    </tr>
    <tr>
        <td>Guest IA32_BNDCFGS (full)<sup>5</sup></td>
        <td rowspan="2">000001001B</td>
        <td>00002812H</td>
    </tr>
    <tr>
        <td>Guest IA32_BNDCFGS (high)<sup>5</sup></td>
        <td>00002813H</td>
    </tr>
    <tr>
        <td>Guest IA32_RTIT_CTL (full)<sup>6</sup></td>
        <td rowspan="2">000001010B</td>
        <td>00002814H</td>
    </tr>
    <tr>
        <td>Guest IA32_RTIT_CTL (high)<sup>6</sup></td>
        <td>00002815H</td>
    </tr>
    <tr>
        <td>Guest IA32_LBR_CTL (full)<sup>7</sup></td>
        <td rowspan="2">000001011B</td>
        <td>00002816H</td>
    </tr>
    <tr>
        <td>Guest IA32_LBR_CTL (high)<sup>7</sup></td>
        <td>00002817H</td>
    </tr>
    <tr>
        <td>Guest IA32_PKRS (full)<sup>8</sup></td>
        <td rowspan="2">000001100B</td>
        <td>00002818H</td>
    </tr>
    <tr>
        <td>Guest IA32_PKRS (high)<sup>8</sup></td>
        <td>00002819H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_CONFIG (full)<sup>9</sup></td>
        <td rowspan="2">000001101B</td>
        <td>0000281AH</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_CONFIG (high)<sup>9</sup></td>
        <td>0000281BH</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_RSP1 (full)<sup>9</sup></td>
        <td rowspan="2">000001110B</td>
        <td>0000281CH</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_RSP1 (high)<sup>9</sup></td>
        <td>0000281DH</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_RSP2 (full)<sup>9</sup></td>
        <td rowspan="2">000001111B</td>
        <td>0000281EH</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_RSP2 (high)<sup>9</sup></td>
        <td>0000281FH</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_RSP3 (full)<sup>9</sup></td>
        <td rowspan="2">000010000B</td>
        <td>00002820H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_RSP3 (high)<sup>9</sup></td>
        <td>00002821H</td>
    </tr>
  </tbody>
</table>

B-6 Vol. 3D

FIELD ENCODING IN VMCS

Table B-6. Encodings for 64-Bit Guest-State Fields (0010_10xx_xxxx_xxxAb) (Contd.)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Guest IA32_FRED_STKLVLS (full)<sup>9</sup></td>
        <td rowspan="2">000010001B</td>
        <td>00002822H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_STKLVLS (high)<sup>9</sup></td>
        <td>00002823H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_SSP1 (full)<sup>9</sup></td>
        <td rowspan="2">000010010B</td>
        <td>00002824H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_SSP1 (high)<sup>9</sup></td>
        <td>00002825H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_SSP2 (full)<sup>9</sup></td>
        <td rowspan="2">000010011B</td>
        <td>00002826H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_SSP2 (high)<sup>9</sup></td>
        <td>00002827H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_SSP3 (full)<sup>9</sup></td>
        <td rowspan="2">000010100B</td>
        <td>00002828H</td>
    </tr>
    <tr>
        <td>Guest IA32_FRED_SSP3 (high)<sup>9</sup></td>
        <td>00002829H</td>
    </tr>
    <tr>
        <td>Guest IA32_SPEC_CTRL (full)<sup>10</sup></td>
        <td rowspan="2">000010111B</td>
        <td>0000282EH</td>
    </tr>
    <tr>
        <td>Guest IA32_SPEC_CTRL (high)<sup>10</sup></td>
        <td>0000282FH</td>
    </tr>
    <tr>
        <td>Guest deadline (full)<sup>11</sup></td>
        <td rowspan="2">000011000B</td>
        <td>00002830H</td>
    </tr>
    <tr>
        <td>Guest deadline (high)<sup>11</sup></td>
        <td>00002831H</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. This field exists only on processors that support either the 1-setting of the “load IA32_PAT” VM-entry control or that of the “save IA32_PAT” VM-exit control.

2. This field exists only on processors that support either the 1-setting of the “load IA32_EFER” VM-entry control or that of the “save IA32_EFER” VM-exit control.

3. This field exists only on processors that support the 1-setting of the “load IA32_PERF_GLOBAL_CTRL” VM-entry control.

4. This field exists only on processors that support the 1-setting of the “enable EPT” VM-execution control.

5. This field exists only on processors that support either the 1-setting of the “load IA32_BNDCFGS” VM-entry control or that of the “clear IA32_BNDCFGS” VM-exit control.

6. This field exists only on processors that support either the 1-setting of the “load IA32_RTIT_CTL” VM-entry control or that of the “clear IA32_RTIT_CTL” VM-exit control.

7. This field exists only on processors that support either the 1-setting of the “load IA32_LBR_CTL” VM-entry control or that of the “clear IA32_LBR_CTL” VM-exit control.

8. This field exists only on processors that support the 1-setting of the “load PKRS” VM-entry control.

9. This field exists only on processors that support either the 1-setting of the “load FRED” VM-entry control or that of the “save FRED” VM-exit control.

10. This field exists only on processors that support the 1-setting of the “load IA32_SPEC_CTRL” VM-entry control.

11. This field exists only on processors that support the 1-setting of the “APIC-timer virtualization” VM-execution control.

## B.2.4 64-Bit Host-State Fields

A value of 3 in bits 11:10 of an encoding indicates a field in the host-state area. These fields are distinguished by their index value in bits 9:1. Table B-7 enumerates the 64-bit control fields.

Table B-7. Encodings for 64-Bit Host-State Fields (0010_11xx_xxxx_xxxAb)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Host IA32_PAT (full)<sup>1</sup></td>
        <td rowspan="2">000000000B</td>
        <td>00002C00H</td>
    </tr>
    <tr>
        <td>Host IA32_PAT (high)<sup>1</sup></td>
        <td>00002C01H</td>
    </tr>
    <tr>
        <td>Host IA32_EFER (full)<sup>2</sup></td>
        <td rowspan="2">000000001B</td>
        <td>00002C02H</td>
    </tr>
    <tr>
        <td>Host IA32_EFER (high)<sup>2</sup></td>
        <td>00002C03H</td>
    </tr>
    <tr>
        <td>Host IA32_PERF_GLOBAL_CTRL (full)<sup>3</sup></td>
        <td rowspan="2">000000010B</td>
        <td>00002C04H</td>
    </tr>
    <tr>
        <td>Host IA32_PERF_GLOBAL_CTRL (high)<sup>3</sup></td>
        <td>00002C05H</td>
    </tr>
  </tbody>
</table>

Vol. 3D <page_number>B-7</page_number>

FIELD ENCODING IN VMCS

Table B-7. Encodings for 64-Bit Host-State Fields (0010_11xx_xxxx_xxxAb) (Contd.)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Host IA32_PKRS (full)<sup>4</sup></td>
        <td rowspan="2">000000011B</td>
        <td>00002C06H</td>
    </tr>
    <tr>
        <td>Host IA32_PKRS (high)<sup>4</sup></td>
        <td>00002C07H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_CONFIG (full)<sup>5</sup></td>
        <td rowspan="2">000000100B</td>
        <td>00002C08H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_CONFIG (high)<sup>4</sup></td>
        <td>00002C09H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_RSP1 (full)<sup>4</sup></td>
        <td rowspan="2">000000101B</td>
        <td>00002C0AH</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_RSP1 (high)<sup>4</sup></td>
        <td>00002C0BH</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_RSP2 (full)<sup>4</sup></td>
        <td rowspan="2">000000110B</td>
        <td>00002C0CH</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_RSP2 (high)<sup>4</sup></td>
        <td>00002C0DH</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_RSP3 (full)<sup>4</sup></td>
        <td rowspan="2">000000111B</td>
        <td>00002C0EH</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_RSP3 (high)<sup>4</sup></td>
        <td>00002C0FH</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_STKLVLS (full)<sup>4</sup></td>
        <td rowspan="2">000001000B</td>
        <td>00002C10H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_STKLVLS (high)<sup>4</sup></td>
        <td>00002C11H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_SSP1 (full)<sup>4</sup></td>
        <td rowspan="2">000001001B</td>
        <td>00002C12H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_SSP1 (high)<sup>4</sup></td>
        <td>00002C13H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_SSP2 (full)<sup>4</sup></td>
        <td rowspan="2">000001010B</td>
        <td>00002C14H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_SSP2 (high)<sup>4</sup></td>
        <td>00002C15H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_SSP3 (full)<sup>4</sup></td>
        <td rowspan="2">000001011B</td>
        <td>00002C16H</td>
    </tr>
    <tr>
        <td>Host IA32_FRED_SSP3 (high)<sup>4</sup></td>
        <td>00002C17H</td>
    </tr>
    <tr>
        <td>IA32_SPEC_CTRL (full)<sup>6</sup></td>
        <td rowspan="2">000001101B</td>
        <td>00002C1AH</td>
    </tr>
    <tr>
        <td>IA32_SPEC_CTRL (high)<sup>6</sup></td>
        <td>00002C1BH</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. This field exists only on processors that support the 1-setting of the “load IA32_PAT” VM-exit control.

2. This field exists only on processors that support the 1-setting of the “load IA32_EFER” VM-exit control.

3. This field exists only on processors that support the 1-setting of the “load IA32_PERF_GLOBAL_CTRL” VM-exit control.

4. This field exists only on processors that support the 1-setting of the “load PKRS” VM-exit control.

5. This field exists only on processors that support the 1-setting of the “load FRED” VM-exit control.

6. This field exists only on processors that support the 1-setting of the “load IA32_SPEC_CTRL” VM-exit control.

## B.3 32-BIT FIELDS

A value of 2 in bits14:13 of an encoding indicates a 32-bit field. As noted in Section 27.11.2, each 32-bit field allows only full access, meaning that bit0 of its encoding is 0. Each such encoding is thus an even number.

### B.3.1 32-Bit Control Fields

A value of 0 in bits11:10 of an encoding indicates a control field. These fields are distinguished by their index value in bits9:1. Table B-8 enumerates the 32-bit control fields.

Table B-8. Encodings for 32-Bit Control Fields (0100_00xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Pin-based VM-execution controls</td>
        <td>000000000B</td>
        <td>00004000H</td>
    </tr>
  </tbody>
</table>

B-8 Vol. 3D
<page_number>B-8</page_number>

FIELD ENCODING IN VMCS

Table B-8. Encodings for 32-Bit Control Fields (0100_00xx_xxxx_xxx0B) (Contd.)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Primary processor-based VM-execution controls</td>
        <td>000000001B</td>
        <td>00004002H</td>
    </tr>
    <tr>
        <td>Exception bitmap</td>
        <td>000000010B</td>
        <td>00004004H</td>
    </tr>
    <tr>
        <td>Page-fault error-code mask</td>
        <td>000000011B</td>
        <td>00004006H</td>
    </tr>
    <tr>
        <td>Page-fault error-code match</td>
        <td>000000100B</td>
        <td>00004008H</td>
    </tr>
    <tr>
        <td>CR3-target count</td>
        <td>000000101B</td>
        <td>0000400AH</td>
    </tr>
    <tr>
        <td>Primary VM-exit controls</td>
        <td>000000110B</td>
        <td>0000400CH</td>
    </tr>
    <tr>
        <td>VM-exit MSR-store count</td>
        <td>000000111B</td>
        <td>0000400EH</td>
    </tr>
    <tr>
        <td>VM-exit MSR-load count</td>
        <td>000001000B</td>
        <td>00004010H</td>
    </tr>
    <tr>
        <td>VM-entry controls</td>
        <td>000001001B</td>
        <td>00004012H</td>
    </tr>
    <tr>
        <td>VM-entry MSR-load count</td>
        <td>000001010B</td>
        <td>00004014H</td>
    </tr>
    <tr>
        <td>Injected-event identification<sup>1</sup></td>
        <td>000001011B</td>
        <td>00004016H</td>
    </tr>
    <tr>
        <td>Injected-event error code<sup>2</sup></td>
        <td>000001100B</td>
        <td>00004018H</td>
    </tr>
    <tr>
        <td>VM-entry instruction length</td>
        <td>000001101B</td>
        <td>0000401AH</td>
    </tr>
    <tr>
        <td>TPR threshold<sup>3</sup></td>
        <td>000001110B</td>
        <td>0000401CH</td>
    </tr>
    <tr>
        <td>Secondary processor-based VM-execution controls<sup>4</sup></td>
        <td>000001111B</td>
        <td>0000401EH</td>
    </tr>
    <tr>
        <td>PLE_Gap<sup>5</sup></td>
        <td>000010000B</td>
        <td>00004020H</td>
    </tr>
    <tr>
        <td>PLE_Window<sup>5</sup></td>
        <td>000010001B</td>
        <td>00004022H</td>
    </tr>
    <tr>
        <td>Instruction-timeout control<sup>6</sup></td>
        <td>000010010B</td>
        <td>00004024H</td>
    </tr>
    <tr>
        <td>SEAM-guest KeyID<sup>7</sup></td>
        <td>000010011B</td>
        <td>00004026H</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. Older versions of this document called this field VM-entry interruption information.

2. Older versions of this document called this field VM-entry error code.

3. This field exists only on processors that support the 1-setting of the “use TPR shadow” VM-execution control.

4. This field exists only on processors that support the 1-setting of the “activate secondary controls” VM-execution control.

5. This field exists only on processors that support the 1-setting of the “PAUSE-loop exiting” VM-execution control.

6. This field exists only on processors that support the 1-setting of the “instruction timeout” VM-execution control.

7. This field exists only on processors that support the 1-setting of the “SEAM guest-physical address width” VM-execution control.

## B.3.2 32-Bit Read-Only Data Fields

A value of 1 in bits 11:10 of an encoding indicates a read-only data field. These fields are distinguished by their index value in bits 9:1. Table B-9 enumerates the 32-bit read-only data fields.

Table B-9. Encodings for 32-Bit Read-Only Data Fields (0100_01xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>VM-instruction error</td>
        <td>000000000B</td>
        <td>00004400H</td>
    </tr>
    <tr>
        <td>Exit reason</td>
        <td>000000001B</td>
        <td>00004402H</td>
    </tr>
    <tr>
        <td>Exiting-event identification<sup>1</sup></td>
        <td>000000010B</td>
        <td>00004404H</td>
    </tr>
    <tr>
        <td>Exiting-event error code<sup>2</sup></td>
        <td>000000011B</td>
        <td>00004406H</td>
    </tr>
    <tr>
        <td>Original-event identification<sup>3</sup></td>
        <td>000000100B</td>
        <td>00004408H</td>
    </tr>
    <tr>
        <td>Original-event error code<sup>4</sup></td>
        <td>000000101B</td>
        <td>0000440AH</td>
    </tr>
  </tbody>
</table>

Vol. 3D B-9

FIELD ENCODING IN VMCS

Table B-9. Encodings for 32-Bit Read-Only Data Fields (0100_01xx_xxxx_xxx0B) (Contd.)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>VM-exit instruction length</td>
        <td>000000110B</td>
        <td>0000440CH</td>
    </tr>
    <tr>
        <td>VM-exit instruction information</td>
        <td>000000111B</td>
        <td>0000440EH</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. Older versions of this document called this field VM-exit interruption information.

2. Older versions of this document called this field VM-exit interruption error code.

3. Older versions of this document called this field IDT-vectoring information.

4. Older versions of this document called this field IDT-vectoring error code.

## B.3.3 32-Bit Guest-State Fields

A value of 2 in bits 11:10 of an encoding indicates a field in the guest-state area. These fields are distinguished by their index value in bits 9:1. Table B-10 enumerates the 32-bit guest-state fields.

Table B-10. Encodings for 32-Bit Guest-State Fields (0100_10xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Guest ES limit</td>
        <td>000000000B</td>
        <td>00004800H</td>
    </tr>
    <tr>
        <td>Guest CS limit</td>
        <td>000000001B</td>
        <td>00004802H</td>
    </tr>
    <tr>
        <td>Guest SS limit</td>
        <td>000000010B</td>
        <td>00004804H</td>
    </tr>
    <tr>
        <td>Guest DS limit</td>
        <td>000000011B</td>
        <td>00004806H</td>
    </tr>
    <tr>
        <td>Guest FS limit</td>
        <td>000000100B</td>
        <td>00004808H</td>
    </tr>
    <tr>
        <td>Guest GS limit</td>
        <td>000000101B</td>
        <td>0000480AH</td>
    </tr>
    <tr>
        <td>Guest LDTR limit</td>
        <td>000000110B</td>
        <td>0000480CH</td>
    </tr>
    <tr>
        <td>Guest TR limit</td>
        <td>000000111B</td>
        <td>0000480EH</td>
    </tr>
    <tr>
        <td>Guest GDTR limit</td>
        <td>000001000B</td>
        <td>00004810H</td>
    </tr>
    <tr>
        <td>Guest IDTR limit</td>
        <td>000001001B</td>
        <td>00004812H</td>
    </tr>
    <tr>
        <td>Guest ES access rights</td>
        <td>000001010B</td>
        <td>00004814H</td>
    </tr>
    <tr>
        <td>Guest CS access rights</td>
        <td>000001011B</td>
        <td>00004816H</td>
    </tr>
    <tr>
        <td>Guest SS access rights</td>
        <td>000001100B</td>
        <td>00004818H</td>
    </tr>
    <tr>
        <td>Guest DS access rights</td>
        <td>000001101B</td>
        <td>0000481AH</td>
    </tr>
    <tr>
        <td>Guest FS access rights</td>
        <td>000001110B</td>
        <td>0000481CH</td>
    </tr>
    <tr>
        <td>Guest GS access rights</td>
        <td>000001111B</td>
        <td>0000481EH</td>
    </tr>
    <tr>
        <td>Guest LDTR access rights</td>
        <td>000010000B</td>
        <td>00004820H</td>
    </tr>
    <tr>
        <td>Guest TR access rights</td>
        <td>000010001B</td>
        <td>00004822H</td>
    </tr>
    <tr>
        <td>Guest interruptibility state</td>
        <td>000010010B</td>
        <td>00004824H</td>
    </tr>
    <tr>
        <td>Guest activity state</td>
        <td>000010011B</td>
        <td>00004826H</td>
    </tr>
    <tr>
        <td>Guest SMBASE</td>
        <td>000010100B</td>
        <td>00004828H</td>
    </tr>
    <tr>
        <td>Guest IA32_SYSENTER_CS</td>
        <td>000010101B</td>
        <td>0000482AH</td>
    </tr>
    <tr>
        <td>VMX-preemption timer value<sup>1</sup></td>
        <td>000010111B</td>
        <td>0000482EH</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. This field exists only on processors that support the 1-setting of the "activate VMX-preemption timer" VM-execution control.

B-10 Vol. 3D

FIELD ENCODING IN VMCS

The limit fields for GDTR and IDTR are defined to be 32 bits in width even though these fields are only 16-bits wide in the Intel 64 and IA-32 architectures. VM entry ensures that the high 16 bits of both these fields are cleared to 0.

## B.3.4 32-Bit Host-State Field

A value of 3 in bits 11:10 of an encoding indicates a field in the host-state area. There is only one such 32-bit field as given in Table B-11.

Table B-11. Encoding for 32-Bit Host-State Field (0100_11xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Host IA32_SYSENTER_CS</td>
        <td>000000000B</td>
        <td>00004C00H</td>
    </tr>
  </tbody>
</table>

## B.4 NATURAL-WIDTH FIELDS

A value of 3 in bits 14:13 of an encoding indicates a natural-width field. As noted in Section 27.11.2, each of these fields allows only full access, meaning that bit 0 of its encoding is 0. Each such encoding is thus an even number.

### B.4.1 Natural-Width Control Fields

A value of 0 in bits 11:10 of an encoding indicates a control field. These fields are distinguished by their index value in bits 9:1. Table B-12 enumerates the natural-width control fields.

Table B-12. Encodings for Natural-Width Control Fields (0110_00xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>CR0 guest/host mask</td>
        <td>000000000B</td>
        <td>00006000H</td>
    </tr>
    <tr>
        <td>CR4 guest/host mask</td>
        <td>000000001B</td>
        <td>00006002H</td>
    </tr>
    <tr>
        <td>CR0 read shadow</td>
        <td>000000010B</td>
        <td>00006004H</td>
    </tr>
    <tr>
        <td>CR4 read shadow</td>
        <td>000000011B</td>
        <td>00006006H</td>
    </tr>
    <tr>
        <td>CR3-target value 0</td>
        <td>000000100B</td>
        <td>00006008H</td>
    </tr>
    <tr>
        <td>CR3-target value 1</td>
        <td>000000101B</td>
        <td>0000600AH</td>
    </tr>
    <tr>
        <td>CR3-target value 2</td>
        <td>000000110B</td>
        <td>0000600CH</td>
    </tr>
    <tr>
        <td>CR3-target value 3<sup>1</sup></td>
        <td>000000111B</td>
        <td>0000600EH</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. If a future implementation supports more than 4 CR3-target values, they will be encoded consecutively following the 4 encodings given here.

### B.4.2 Natural-Width Read-Only Data Fields

A value of 1 in bits 11:10 of an encoding indicates a read-only data field. These fields are distinguished by their index value in bits 9:1. Table B-13 enumerates the natural-width read-only data fields.

Table B-13. Encodings for Natural-Width Read-Only Data Fields (0110_01xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Exit qualification</td>
        <td>000000000B</td>
        <td>00006400H</td>
    </tr>
    <tr>
        <td>I/O RCX</td>
        <td>000000001B</td>
        <td>00006402H</td>
    </tr>
    <tr>
        <td>I/O RSI</td>
        <td>000000010B</td>
        <td>00006404H</td>
    </tr>
  </tbody>
</table>

Vol. 3D B-11

FIELD ENCODING IN VMCS

Table B-13. Encodings for Natural-Width Read-Only Data Fields (0110_01xx_xxxx_xxx0B) (Contd.)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>I/O RDI</td>
        <td>000000011B</td>
        <td>00006406H</td>
    </tr>
    <tr>
        <td>I/O RIP</td>
        <td>000000100B</td>
        <td>00006408H</td>
    </tr>
    <tr>
        <td>Guest-linear address</td>
        <td>000000101B</td>
        <td>0000640AH</td>
    </tr>
  </tbody>
</table>

## B.4.3 Natural-Width Guest-State Fields

A value of 2 in bits 11:10 of an encoding indicates a field in the guest-state area. These fields are distinguished by their index value in bits 9:1. Table B-14 enumerates the natural-width guest-state fields.

Table B-14. Encodings for Natural-Width Guest-State Fields (0110_10xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Guest CR0</td>
        <td>000000000B</td>
        <td>00006800H</td>
    </tr>
    <tr>
        <td>Guest CR3</td>
        <td>000000001B</td>
        <td>00006802H</td>
    </tr>
    <tr>
        <td>Guest CR4</td>
        <td>000000010B</td>
        <td>00006804H</td>
    </tr>
    <tr>
        <td>Guest ES base</td>
        <td>000000011B</td>
        <td>00006806H</td>
    </tr>
    <tr>
        <td>Guest CS base</td>
        <td>000000100B</td>
        <td>00006808H</td>
    </tr>
    <tr>
        <td>Guest SS base</td>
        <td>000000101B</td>
        <td>0000680AH</td>
    </tr>
    <tr>
        <td>Guest DS base</td>
        <td>000000110B</td>
        <td>0000680CH</td>
    </tr>
    <tr>
        <td>Guest FS base</td>
        <td>000000111B</td>
        <td>0000680EH</td>
    </tr>
    <tr>
        <td>Guest GS base</td>
        <td>000001000B</td>
        <td>00006810H</td>
    </tr>
    <tr>
        <td>Guest LDTR base</td>
        <td>000001001B</td>
        <td>00006812H</td>
    </tr>
    <tr>
        <td>Guest TR base</td>
        <td>000001010B</td>
        <td>00006814H</td>
    </tr>
    <tr>
        <td>Guest GDTR base</td>
        <td>000001011B</td>
        <td>00006816H</td>
    </tr>
    <tr>
        <td>Guest IDTR base</td>
        <td>000001100B</td>
        <td>00006818H</td>
    </tr>
    <tr>
        <td>Guest DR7</td>
        <td>000001101B</td>
        <td>0000681AH</td>
    </tr>
    <tr>
        <td>Guest RSP</td>
        <td>000001110B</td>
        <td>0000681CH</td>
    </tr>
    <tr>
        <td>Guest RIP</td>
        <td>000001111B</td>
        <td>0000681EH</td>
    </tr>
    <tr>
        <td>Guest RFLAGS</td>
        <td>000010000B</td>
        <td>00006820H</td>
    </tr>
    <tr>
        <td>Guest pending debug exceptions</td>
        <td>000010001B</td>
        <td>00006822H</td>
    </tr>
    <tr>
        <td>Guest IA32_SYSENTER_ESP</td>
        <td>000010010B</td>
        <td>00006824H</td>
    </tr>
    <tr>
        <td>Guest IA32_SYSENTER_EIP</td>
        <td>000010011B</td>
        <td>00006826H</td>
    </tr>
    <tr>
        <td>Guest IA32_S_CET<sup>1</sup></td>
        <td>000010100B</td>
        <td>00006828H</td>
    </tr>
    <tr>
        <td>Guest SSP<sup>1</sup></td>
        <td>000010101B</td>
        <td>0000682AH</td>
    </tr>
    <tr>
        <td>Guest IA32_INTERRUPT_SSP_TABLE_ADDR<sup>1</sup></td>
        <td>000010110B</td>
        <td>0000682CH</td>
    </tr>
  </tbody>
</table>

**NOTES:**

<sup>1.</sup> This field is supported only on processors that support the 1-setting of the “load CET state” VM-entry control.

The base-address fields for ES, CS, SS, and DS in the guest-state area are defined to be natural-width (with 64 bits on processors supporting Intel 64 architecture) even though these fields are only 32-bits wide in the Intel 64 architecture. VM entry ensures that the high 32 bits of these fields are cleared to 0.

B-12 Vol. 3D

FIELD ENCODING IN VMCS

## B.4.4 Natural-Width Host-State Fields

A value of 3 in bits 11:10 of an encoding indicates a field in the host-state area. These fields are distinguished by their index value in bits 9:1. Table B-15 enumerates the natural-width host-state fields.

Table B-15. Encodings for Natural-Width Host-State Fields (0110_11xx_xxxx_xxx0B)

<table>
  <thead>
    <tr>
        <th>Field Name</th>
        <th>Index</th>
        <th>Encoding</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>Host CR0</td>
        <td>000000000B</td>
        <td>00006C00H</td>
    </tr>
    <tr>
        <td>Host CR3</td>
        <td>000000001B</td>
        <td>00006C02H</td>
    </tr>
    <tr>
        <td>Host CR4</td>
        <td>000000010B</td>
        <td>00006C04H</td>
    </tr>
    <tr>
        <td>Host FS base</td>
        <td>000000011B</td>
        <td>00006C06H</td>
    </tr>
    <tr>
        <td>Host GS base</td>
        <td>000000100B</td>
        <td>00006C08H</td>
    </tr>
    <tr>
        <td>Host TR base</td>
        <td>000000101B</td>
        <td>00006C0AH</td>
    </tr>
    <tr>
        <td>Host GDTR base</td>
        <td>000000110B</td>
        <td>00006C0CH</td>
    </tr>
    <tr>
        <td>Host IDTR base</td>
        <td>000000111B</td>
        <td>00006C0EH</td>
    </tr>
    <tr>
        <td>Host IA32_SYSENTER_ESP</td>
        <td>000001000B</td>
        <td>00006C10H</td>
    </tr>
    <tr>
        <td>Host IA32_SYSENTER_EIP</td>
        <td>000001001B</td>
        <td>00006C12H</td>
    </tr>
    <tr>
        <td>Host RSP</td>
        <td>000001010B</td>
        <td>00006C14H</td>
    </tr>
    <tr>
        <td>Host RIP</td>
        <td>000001011B</td>
        <td>00006C16H</td>
    </tr>
    <tr>
        <td>Host IA32_S_CET<sup>1</sup></td>
        <td>000001100B</td>
        <td>00006C18H</td>
    </tr>
    <tr>
        <td>Host SSP<sup>1</sup></td>
        <td>000001101B</td>
        <td>00006C1AH</td>
    </tr>
    <tr>
        <td>Host IA32_INTERRUPT_SSP_TABLE_ADDR<sup>1</sup></td>
        <td>000001110B</td>
        <td>00006C1CH</td>
    </tr>
  </tbody>
</table>

**NOTES:**

1. This field is supported only on processors that support the 1-setting of the “load CET state” VM-exit control.

Vol. 3D B-13

FIELD ENCODING IN VMCS

B-14 Vol. 3D

APPENDIX C
VMX BASIC EXIT REASONS

Every VM exit writes a 32-bit exit reason to the VMCS (see Section 27.9.1). Certain VM-entry failures also do this (see Section 29.8). The low 16 bits of the exit-reason field form the basic exit reason which provides basic information about the cause of the VM exit or VM-entry failure.

Table C-1 lists values for basic exit reasons and explains their meaning. Entries apply to VM exits, unless otherwise noted.

# Table C-1. Basic Exit Reasons

<table>
  <thead>
    <tr>
        <th>Basic Exit Reason</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>0</td>
        <td><strong>Exception or non-maskable interrupt (NMI).</strong> Either:<br/>1: Guest software caused an exception and the bit in the exception bitmap associated with exception’s vector was 1. This case includes executions of BOUND that cause #BR, executions of INT1 (they cause #DB), executions of INT3 (they cause #BP), executions of INTO that cause #OF, and executions of UD0, UD1, UD2, and UDB (they cause #UD).<br/>2: An NMI was delivered to the logical processor and the “NMI exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>1</td>
        <td><strong>External interrupt.</strong> An external interrupt arrived and the “external-interrupt exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>2</td>
        <td><strong>Triple fault.</strong> The logical processor encountered an exception while attempting to call the double-fault handler and that exception did not itself cause a VM exit due to the exception bitmap.</td>
    </tr>
    <tr>
        <td>3</td>
        <td><strong>INIT signal.</strong> An INIT signal arrived</td>
    </tr>
    <tr>
        <td>4</td>
        <td><strong>Start-up IPI (SIPI).</strong> A SIPI arrived while the logical processor was in the “wait-for-SIPI” state.</td>
    </tr>
    <tr>
        <td>5</td>
        <td><strong>I/O system-management interrupt (SMI).</strong> An SMI arrived immediately after retirement of an I/O instruction and caused an SMM VM exit (see Section 34.15.2).</td>
    </tr>
    <tr>
        <td>6</td>
        <td><strong>Other SMI.</strong> An SMI arrived and caused an SMM VM exit (see Section 34.15.2) but not immediately after retirement of an I/O instruction.</td>
    </tr>
    <tr>
        <td>7</td>
        <td><strong>Interrupt window.</strong> At the beginning of an instruction, RFLAGS.IF was 1; events were not blocked by STI or by MOV SS; and the “interrupt-window exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>8</td>
        <td><strong>NMI window.</strong> At the beginning of an instruction, there was no virtual-NMI blocking; events were not blocked by MOV SS; and the “NMI-window exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>9</td>
        <td><strong>Task switch.</strong> Guest software attempted a task switch.</td>
    </tr>
    <tr>
        <td>10</td>
        <td><strong>CPUID.</strong> Guest software attempted to execute CPUID.</td>
    </tr>
    <tr>
        <td>11</td>
        <td><strong>GETSEC.</strong> Guest software attempted to execute GETSEC.</td>
    </tr>
    <tr>
        <td>12</td>
        <td><strong>HLT.</strong> Guest software attempted to execute HLT and the “HLT exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>13</td>
        <td><strong>INVD.</strong> Guest software attempted to execute INVD.</td>
    </tr>
    <tr>
        <td>14</td>
        <td><strong>INVLPG.</strong> Guest software attempted to execute INVLPG and the “INVLPG exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>15</td>
        <td><strong>RDPMC.</strong> Guest software attempted to execute RDPMC and the “RDPMC exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>16</td>
        <td><strong>RDTSC.</strong> Guest software attempted to execute RDTSC and the “RDTSC exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>17</td>
        <td><strong>RSM.</strong> Guest software attempted to execute RSM in SMM.</td>
    </tr>
    <tr>
        <td>18</td>
        <td><strong>VMCALL.</strong> VMCALL was executed either by guest software (causing an ordinary VM exit) or by the executive monitor (causing an SMM VM exit; see Section 34.15.2).</td>
    </tr>
    <tr>
        <td>19</td>
        <td><strong>VMCLEAR.</strong> Guest software attempted to execute VMCLEAR.</td>
    </tr>
    <tr>
        <td>20</td>
        <td><strong>VMLAUNCH.</strong> Guest software attempted to execute VMLAUNCH.</td>
    </tr>
    <tr>
        <td>21</td>
        <td><strong>VMPTRLD.</strong> Guest software attempted to execute VMPTRLD.</td>
    </tr>
    <tr>
        <td>22</td>
        <td><strong>VMPTRST.</strong> Guest software attempted to execute VMPTRST.</td>
    </tr>
  </tbody>
</table>

Vol. 3D C-1

VMX BASIC EXIT REASONS

Table C-1. Basic Exit Reasons (Contd.)

<table>
  <thead>
    <tr>
        <th>Basic Exit Reason</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>23</td>
        <td><strong>VMREAD.</strong> Guest software attempted to execute VMREAD.</td>
    </tr>
    <tr>
        <td>24</td>
        <td><strong>VMRESUME.</strong> Guest software attempted to execute VMRESUME.</td>
    </tr>
    <tr>
        <td>25</td>
        <td><strong>VMWRITE.</strong> Guest software attempted to execute VMWRITE.</td>
    </tr>
    <tr>
        <td>26</td>
        <td><strong>VMXOFF.</strong> Guest software attempted to execute VMXOFF.</td>
    </tr>
    <tr>
        <td>27</td>
        <td><strong>VMXON.</strong> Guest software attempted to execute VMXON.</td>
    </tr>
    <tr>
        <td>28</td>
        <td><strong>Control-register accesses.</strong> Guest software attempted to access CR0, CR3, CR4, or CR8 using CLTS, LMSW, or MOV CR and the VM-execution control fields indicate that a VM exit should occur (see Section 28.1 for details). This basic exit reason is not used for trap-like VM exits following executions of the MOV to CR8 instruction when the “use TPR shadow” VM-execution control is 1. Such VM exits instead use basic exit reason 43.</td>
    </tr>
    <tr>
        <td>29</td>
        <td><strong>MOV DR.</strong> Guest software attempted a MOV to or from a debug register and the “MOV-DR exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>30</td>
        <td><strong>I/O instruction.</strong> Guest software attempted to execute an I/O instruction and either:<br/>1: The “use I/O bitmaps” VM-execution control was 0 and the “unconditional I/O exiting” VM-execution control was 1.<br/>2: The “use I/O bitmaps” VM-execution control was 1 and a bit in the I/O bitmap associated with one of the ports accessed by the I/O instruction was 1.</td>
    </tr>
    <tr>
        <td>31</td>
        <td><strong>RDMSR (implicit form).</strong> Guest software attempted to execute RDMSR and one of the following holds:<br/>\* The “use MSR bitmaps” VM-execution control was 0.<br/>\* The value of ECX is neither in the range 00000000H – 00001FFFH nor in the range C0000000H – C0001FFFH.<br/>\* The value of ECX is in the range 00000000H – 00001FFFH and the n<sup>th</sup> bit in read bitmap for low MSRs is 1, where n is the value of ECX.<br/>\* The value of ECX is in the range C0000000H – C0001FFFH and the n<sup>th</sup> bit in read bitmap for high MSRs is 1, where n is the value of ECX &amp; 00001FFFH.</td>
    </tr>
    <tr>
        <td>32</td>
        <td><strong>WRMSR (implicit form) or WRMSRNS.</strong> Guest software attempted to execute either WRMSR or WRMSRNS and either:<br/>1: The “use MSR bitmaps” VM-execution control was 0.<br/>2: The value of ECX is neither in the range 00000000H – 00001FFFH nor in the range C0000000H – C0001FFFH.<br/>3: The value of ECX is in the range 00000000H – 00001FFFH and the n<sup>th</sup> bit in write bitmap for low MSRs is 1, where n is the value of ECX.<br/>4: The value of ECX is in the range C0000000H – C0001FFFH and the n<sup>th</sup> bit in write bitmap for high MSRs is 1, where n is the value of ECX &amp; 00001FFFH.</td>
    </tr>
    <tr>
        <td>33</td>
        <td><strong>VM-entry failure due to invalid guest state.</strong> A VM entry failed one of the checks identified in Section 29.3.1.</td>
    </tr>
    <tr>
        <td>34</td>
        <td><strong>VM-entry failure due to MSR loading.</strong> A VM entry failed in an attempt to load MSRs. See Section 29.4.</td>
    </tr>
    <tr>
        <td>36</td>
        <td><strong>MWAIT.</strong> Guest software attempted to execute MWAIT and the “MWAIT exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>37</td>
        <td><strong>Monitor trap flag.</strong> A VM exit occurred due to the 1-setting of the “monitor trap flag” VM-execution control (see Section 28.5.2) or VM entry injected a pending MTF VM exit as part of VM entry (see Section 29.6.2).</td>
    </tr>
    <tr>
        <td>39</td>
        <td><strong>MONITOR.</strong> Guest software attempted to execute MONITOR and the “MONITOR exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>40</td>
        <td><strong>PAUSE.</strong> Either guest software attempted to execute PAUSE and the “PAUSE exiting” VM-execution control was 1 or the “PAUSE-loop exiting” VM-execution control was 1 and guest software executed a PAUSE loop with execution time exceeding PLE_Window (see Section 28.1.3).</td>
    </tr>
    <tr>
        <td>41</td>
        <td><strong>VM-entry failure due to machine-check event.</strong> A machine-check event occurred during VM entry (see Section 29.9).</td>
    </tr>
    <tr>
        <td>43</td>
        <td><strong>TPR below threshold.</strong> The logical processor determined that the value of bits 7:4 of the byte at offset 080H on the virtual-APIC page was below that of the TPR threshold VM-execution control field while the “use TPR shadow” VM-execution control was 1 either as part of TPR virtualization (Section 32.1.2) or VM entry (Section 29.7.7).</td>
    </tr>
    <tr>
        <td>44</td>
        <td><strong>APIC access.</strong> Guest software attempted to access memory at a physical address on the APIC-access page and the “virtualize APIC accesses” VM-execution control was 1 (see Section 32.4).</td>
    </tr>
    <tr>
        <td>45</td>
        <td><strong>Virtualized EOI.</strong> EOI virtualization was performed for a virtual interrupt whose vector indexed a bit set in the EOI-exit bitmap.</td>
    </tr>
  </tbody>
</table>

C-2 Vol. 3D

VMX BASIC EXIT REASONS

# Table C-1. Basic Exit Reasons (Contd.)

<table>
  <thead>
    <tr>
        <th>Basic Exit Reason</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>46</td>
        <td><strong>Access to GDTR or IDTR.</strong> Guest software attempted to execute LGDT, LIDT, SGDT, or SIDT and the “descriptor-table exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>47</td>
        <td><strong>Access to LDTR or TR.</strong> Guest software attempted to execute LLDT, LTR, SLDT, or STR and the “descriptor-table exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>48</td>
        <td><strong>EPT violation.</strong> An attempt to access memory with a guest-physical address was disallowed by the configuration of the EPT paging structures.</td>
    </tr>
    <tr>
        <td>49</td>
        <td><strong>EPT misconfiguration.</strong> An attempt to access memory with a guest-physical address encountered a misconfigured EPT paging-structure entry.</td>
    </tr>
    <tr>
        <td>50</td>
        <td><strong>INVEPT.</strong> Guest software attempted to execute INVEPT.</td>
    </tr>
    <tr>
        <td>51</td>
        <td><strong>RDTSCP.</strong> Guest software attempted to execute RDTSCP and the “enable RDTSCP” and “RDTSC exiting” VM-execution controls were both 1.</td>
    </tr>
    <tr>
        <td>52</td>
        <td><strong>VMX-preemption timer expired.</strong> The preemption timer counted down to zero.</td>
    </tr>
    <tr>
        <td>53</td>
        <td><strong>INVVPID.</strong> Guest software attempted to execute INVVPID.</td>
    </tr>
    <tr>
        <td>54</td>
        <td><strong>WBINVD or WBNOINVD.</strong> Guest software attempted to execute WBINVD or WBNOINVD and the “WBINVD exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>55</td>
        <td><strong>XSETBV.</strong> Guest software attempted to execute XSETBV.</td>
    </tr>
    <tr>
        <td>56</td>
        <td><strong>APIC write.</strong> Guest software completed a write to the virtual-APIC page that must be virtualized by VMM software (see Section 32.4.3.3).</td>
    </tr>
    <tr>
        <td>57</td>
        <td><strong>RDRAND.</strong> Guest software attempted to execute RDRAND and the “RDRAND exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>58</td>
        <td><strong>INVPCID.</strong> Guest software attempted to execute INVPCID and the “enable INVPCID” and “INVLPG exiting” VM-execution controls were both 1.</td>
    </tr>
    <tr>
        <td>59</td>
        <td><strong>VMFUNC.</strong> Guest software invoked a VM function with the VMFUNC instruction and the VM function either was not enabled or generated a function-specific condition causing a VM exit.</td>
    </tr>
    <tr>
        <td>60</td>
        <td><strong>ENCLS.</strong> Guest software attempted to execute ENCLS, “enable ENCLS exiting” VM-execution control was 1, and either (1) EAX &lt; 63 and the corresponding bit in the ENCLS-exiting bitmap is 1; or (2) EAX ≥ 63 and bit 63 in the ENCLS-exiting bitmap is 1.</td>
    </tr>
    <tr>
        <td>61</td>
        <td><strong>RDSEED.</strong> Guest software attempted to execute RDSEED and the “RDSEED exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>62</td>
        <td><strong>Page-modification log full.</strong> The processor attempted to create a page-modification log entry and the value of the PML index was not in the range 0–511.</td>
    </tr>
    <tr>
        <td>63</td>
        <td><strong>XSAVES.</strong> Guest software attempted to execute XSAVES, the “enable XSAVES/XRSTORS” was 1, and a bit was set in the logical-AND of the following three values: EDX:EAX, the IA32_XSS MSR, and the XSS-exiting bitmap.</td>
    </tr>
    <tr>
        <td>64</td>
        <td><strong>XRSTORS.</strong> Guest software attempted to execute XRSTORS, the “enable XSAVES/XRSTORS” was 1, and a bit was set in the logical-AND of the following three values: EDX:EAX, the IA32_XSS MSR, and the XSS-exiting bitmap.</td>
    </tr>
    <tr>
        <td>65</td>
        <td><strong>PCONFIG.</strong> Guest software attempted to execute PCONFIG, “enable PCONFIG” VM-execution control was 1, and either (1) EAX &lt; 63 and the corresponding bit in the PCONFIG-exiting bitmap is 1; or (2) EAX ≥ 63 and bit 63 in the PCONFIG-exiting bitmap is 1.</td>
    </tr>
    <tr>
        <td>66</td>
        <td><strong>SPP-related event.</strong> The processor attempted to determine an access’s sub-page write permission and encountered an SPP miss or an SPP misconfiguration. See Section 31.3.4.2.</td>
    </tr>
    <tr>
        <td>67</td>
        <td><strong>UMWAIT.</strong> Guest software attempted to execute UMWAIT and the “enable user wait and pause” and “RDTSC exiting” VM-execution controls were both 1.</td>
    </tr>
    <tr>
        <td>68</td>
        <td><strong>TPAUSE.</strong> Guest software attempted to execute TPAUSE and the “enable user wait and pause” and “RDTSC exiting” VM-execution controls were both 1.</td>
    </tr>
    <tr>
        <td>69</td>
        <td><strong>LOADIWKEY.</strong> Guest software attempted to execute LOADIWKEY and the “LOADIWKEY exiting” VM-execution control was 1.</td>
    </tr>
    <tr>
        <td>72</td>
        <td><strong>ENQCMD PASID translation failure.</strong> A VM exit occurred during PASID translation because the present bit was clear in a PASID-directory entry, the valid bit was clear in a PASID-table entry, or one of the entries set a reserved bit.</td>
    </tr>
  </tbody>
</table>

Vol. 3D <page_number>C-3</page_number>

VMX BASIC EXIT REASONS

Table C-1. Basic Exit Reasons (Contd.)

<table>
  <thead>
    <tr>
        <th>Basic Exit Reason</th>
        <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
        <td>73</td>
        <td><strong>ENQCMDS PASID translation failure.</strong> A VM exit occurred during PASID translation because the present bit was clear in a PASID-directory entry, the valid bit was clear in a PASID-table entry, or one of the entries set a reserved bit.</td>
    </tr>
    <tr>
        <td>74</td>
        <td><strong>Bus lock.</strong> The processor asserted a bus lock while the “bus-lock detection” VM-execution control was 1. (Such VM exits will also set bit 26 of the exit-reason field.)</td>
    </tr>
    <tr>
        <td>75</td>
        <td><strong>Instruction timeout.</strong> The “instruction timeout” VM-execution control was 1 and certain operations prevented the processor from reaching an instruction boundary within the amount of time specified by the instruction-timeout control.</td>
    </tr>
    <tr>
        <td>76</td>
        <td><strong>SEAMCALL.</strong> Guest software attempted to execute SEAMCALL.</td>
    </tr>
    <tr>
        <td>77</td>
        <td><strong>TDCALL.</strong> Guest software attempted to execute TDCALL.</td>
    </tr>
    <tr>
        <td>78</td>
        <td><strong>RDMSRLIST.</strong> Guest software attempted to execute RDMSRLIST and either the “use MSR bitmaps” VM-execution control was 0 or any of the following holds for the address of an MSR being accessed:<br/>\* The address is neither in the range 00000000H – 00001FFFH nor in the range C0000000H – C0001FFFH.<br/>\* The address is in the range 00000000H – 00001FFFH and the n<sup>th</sup> bit in read bitmap for low MSRs is 1, where n is the address.<br/>\* The address is in the range C0000000H – C0001FFFH and the n<sup>th</sup> bit in read bitmap for high MSRs is 1, where n is the logical AND of the address and the value 00001FFFH.</td>
    </tr>
    <tr>
        <td>79</td>
        <td><strong>WRMSRLIST.</strong> Guest software attempted to execute WRMSRLIST and either the “use MSR bitmaps” VM-execution control was 0 or any of the following holds for the address of an MSR being accessed:<br/>\* The address is neither in the range 00000000H – 00001FFFH nor in the range C0000000H – C0001FFFH.<br/>\* The address is in the range 00000000H – 00001FFFH and the n<sup>th</sup> bit in write bitmap for low MSRs is 1, where n is the address.<br/>\* The address is in the range C0000000H – C0001FFFH and the n<sup>th</sup> bit in write bitmap for high MSRs is 1, where n is the logical AND of the address and the value 00001FFFH.</td>
    </tr>
    <tr>
        <td>80</td>
        <td><strong>URDMSR.</strong> Guest software attempted to execute URDMSR and one of the following holds:<br/>\* The “use MSR bitmaps” VM-execution control is 0.<br/>\* The MSR address is in the range 0000H–1FFFH and bit n is 1 in the read bitmap for low MSRs (referenced by an address in the VMCS), where n is the MSR address.<br/>\* The MSR address is in the range 2000H–3FFFH.</td>
    </tr>
    <tr>
        <td>81</td>
        <td><strong>UWRMSR.</strong> Guest software attempted to execute UWRMSR and one of the following holds:<br/>\* The “use MSR bitmaps” VM-execution control is 0.<br/>\* The MSR address is in the range 0000H–1FFFH, and bit n is 1 in the write bitmap for low MSRs (referenced by an address in the VMCS), where n is the MSR address.<br/>\* The MSR address is in the range 2000H–3FFFH.</td>
    </tr>
    <tr>
        <td>84</td>
        <td><strong>RDMSR (immediate form).</strong> Guest software attempted to execute RDMSR and one of the following holds:<br/>\* The “use MSR bitmaps” VM-execution control was 0.<br/>\* The MSR address is neither in the range 00000000H – 00001FFFH nor in the range C0000000H – C0001FFFH.<br/>\* The MSR address is in the range 00000000H – 00001FFFH and the n<sup>th</sup> bit in read bitmap for low MSRs is 1, where n is the MSR address.<br/>\* The MSR address is in the range C0000000H – C0001FFFH and the n<sup>th</sup> bit in read bitmap for high MSRs is 1, where n is the logical AND of the MSR address and the value of 00001FFFH.</td>
    </tr>
    <tr>
        <td>85</td>
        <td><strong>WRMSRNS (immediate form).</strong> Guest software attempted to execute either WRMSR or WRMSRNS and either:<br/>1: The “use MSR bitmaps” VM-execution control was 0.<br/>2: The MSR address is neither in the range 00000000H – 00001FFFH nor in the range C0000000H – C0001FFFH.<br/>3: The MSR address is in the range 00000000H – 00001FFFH and the n<sup>th</sup> bit in write bitmap for low MSRs is 1, where n is the MSR address.<br/>4: The MSR address is in the range C0000000H – C0001FFFH and the n<sup>th</sup> bit in write bitmap for high MSRs is 1, where n is the logical AND of the MSR address and the value of 00001FFFH.</td>
    </tr>
  </tbody>
</table>

C-4 Vol. 3D

INDEX

# Numerics

16-bit code, mixing with 32-bit code, 24-1
32-bit code, mixing with 16-bit code, 24-1
32-bit physical addressing
* overview, 3-6
36-bit physical addressing
* overview, 3-6
64-bit mode
* call gates, 6-14
* code segment descriptors, 6-3, 12-12
* control registers, 2-13
* CR8 register, 2-13
* D flag, 6-4
* debug registers, 2-7
* descriptors, 6-3, 6-5
* DPL field, 6-4
* exception handling, 7-20
* external interrupts, 13-32
* fast system calls, 6-22
* GDTR register, 2-12, 2-13
* GP faults, causes of, 7-45
* IDTR register, 2-12
* initialization process, 2-8, 12-11
* interrupt and trap gates, 7-20
* interrupt controller, 13-32
* interrupt descriptors, 2-6
* interrupt handling, 7-20
* interrupt stack table, 7-23
* IRET instruction, 7-22
* L flag, 3-12, 6-4
* logical address translation, 3-7
* MOV CRn, 2-13, 13-32
* null segment checking, 6-6
* paging, 2-6
* registers and mode changes, 12-12
* RFLAGS register, 2-11
* segment descriptor tables, 3-16, 6-3
* segment loading instructions, 3-9
* segments, 3-5
* stack switching, 6-19, 7-22
* SYSCALL and SYSRET, 2-7, 6-22
* SYSENTER and SYSEXIT, 6-21
* system registers, 2-7
* task gate, 10-19
* task priority, 13-32
* task register, 2-13
* TSS
    - stack pointers, 10-19
* See also: IA-32e mode, compatibility mode
8086
* emulation, support for, 23-1
* processor, exceptions and interrupts, 23-6
8086/8088 processor, 25-7
8087 math coprocessor, 25-7
82489DX, 25-27, 25-28
* Local APIC and I/O APICs, 13-4

# A

A20M# signal, 23-2, 25-34, 26-4
AAA instruction, 35-7, 35-9

Aborts
* description of, 7-5
* restarting a program or task after, 7-5
AC (alignment check) flag, EFLAGS register, 2-11, 7-53, 25-6
Access rights
* checking, 2-26
* checking caller privileges, 6-26
* description of, 6-24
* invalid values, 25-19
ADC instruction, 11-4
ADD instruction, 11-4
Address
* size prefix, 24-1
* space, of task, 10-16
Address translation
* in real-address mode, 23-2
* logical to linear, 3-7
* overview, 3-6
Advanced power management
* C-state and Sub C-state, 17-35
* MWAIT extensions, 17-35
* See also: thermal monitoring
Advanced programmable interrupt controller (see I/O APIC or Local APIC)
Alignment
* check exception, 2-11, 7-53, 25-11, 25-21
* checking, 6-28
AM (alignment mask) flag
* CR0 control register, 2-16, 25-18
AND instruction, 11-4
APIC, 13-41, 13-42
APIC bus
* arbitration mechanism and protocol, 13-27, 13-34
* bus message format, 13-35, 13-48
* diagram of, 13-2, 13-3
* EOI message format, 13-15, 13-48
* nonfocused lowest priority message, 13-50
* short message format, 13-49
* SMI message, 34-2
* status cycles, 13-51
* structure of, 13-3
* See also
    - local APIC
APIC flag, CPUID instruction, 13-7
APIC ID, 13-41, 13-45, 13-47
APIC (see I/O APIC or Local APIC)
ARPL instruction, 2-26, 6-27
* not supported in 64-bit mode, 2-26
Atomic operations
* automatic bus locking, 11-3
* effects of a locked operation on internal processor caches, 11-6
* guaranteed, description of, 11-2
* overview of, 11-1, 11-3
* software-controlled bus locking, 11-4
At-retirement
* counting, 22-109, 22-125
* events, 22-109, 22-115, 22-116, 22-125, 22-129
Auto HALT restart
* field, SMM, 34-14
* SMM, 34-14
Automatic bus locking, 11-3

Vol. 3D INDEX-1

# INDEX

Automatic thermal monitoring mechanism, 17-36

# B
B (busy) flag
* TSS descriptor, 10-5, 10-11, 10-16
B (default stack size) flag
* segment descriptor, 24-1, 25-33
B0-B3 (BP condition detected) flags
* DR6 register, 20-4
Backlink (see Previous task link)
Base address fields, segment descriptor, 3-10
BD (debug register access detected) flag, DR6 register, 20-11
BINIT# signal, 2-28
BIOS role in microcode updates, 12-38
BOUND instruction, 2-5, 7-4, 7-31
BOUND range exceeded exception (#BR), 7-31
BP0#, BP1#, BP2#, and BP3# pins, 20-39, 20-41
Branch record
* branch trace message, 20-15
* IA-32e mode, 20-23
* saving, 20-17, 20-27, 20-28, 20-36
* saving as a branch trace message, 20-15
* structure, 20-37
* structure of in BTS buffer, 20-21
Branch trace message (see BTM)
Branch trace store (see BTS)
Breakpoint exception (#BP), 7-4, 7-29, 20-11
Breakpoints
* data breakpoint, 20-6
* data breakpoint exception conditions, 20-10
* description of, 20-1
* DR0-DR3 debug registers, 20-4
* example, 20-6
* exception, 7-29
* field recognition, 20-6, 20-7
* general-detect exception condition, 20-10
* instruction breakpoint, 20-6
* instruction breakpoint exception condition, 20-9
* I/O breakpoint exception conditions, 20-10
* LEN0 - LEN3 (Length) fields
  * DR7 register, 20-6
* R/W0-R/W3 (read/write) fields
  * DR7 register, 20-5
* single-step exception condition, 20-11
* task-switch exception condition, 20-11
BS (single step) flag, DR6 register, 20-4
BSP flag, IA32_APIC_BASE MSR, 13-8
BSWAP instruction, 25-4
BT (task switch) flag, DR6 register, 20-4, 20-11
BTC instruction, 11-4
BTF (single-step on branches) flag
* DEBUGCTLMSR MSR, 20-41
BTMs (branch trace messages)
* description of, 20-15
* enabling, 20-13, 20-25, 20-26, 20-36, 20-38, 20-39
* TR (trace message enable) flag
  * MSR_DEBUGCTLA MSR, 20-36
  * MSR_DEBUGCTLB MSR, 20-13, 20-38, 20-39
BTR instruction, 11-4
BTS buffer
* description of, 20-20
* introduction to, 20-12, 20-15
* records in, 20-21
* setting up, 20-25

* structure of, 20-21, 20-23, 22-27
BTS instruction, 11-4
BTS (branch trace store) facilities
* availability of, 20-35
* BTS_UNAVAILABLE flag,
  * IA32_MISC_ENABLE MSR, 20-20
* introduction to, 20-12
* setting up BTS buffer, 20-25
* writing an interrupt service routine for, 20-26
BTS_UNAVAILABLE, 20-20
Built-in self-test (BIST)
* description of, 12-1
* performing, 12-5
Bus
* errors detected with MCA, 18-28
* hold, 25-35
* locking, 11-3, 25-35

# C
C (conforming) flag, segment descriptor, 6-11
C1 flag, x87 FPU status word, 25-8, 25-14
C2 flag, x87 FPU status word, 25-8
Cache control, 14-20
* adaptive mode, L1 Data Cache, 14-18
* cache management instructions, 14-17, 14-18
* cache mechanisms in IA-32 processors, 25-30
* caching terminology, 14-5
* CD flag, CR0 control register, 14-10, 25-19
* choosing a memory type, 14-8
* CPUID feature flag, 14-18
* flags and fields, 14-10
* flushing TLBs, 14-19
* G (global) flag
  * page-directory entries, 14-13
  * page-table entries, 14-13
* internal caches, 14-1
* MemTypeGet() function, 14-29
* MemTypeSet() function, 14-31
* MESI protocol, 14-5, 14-9
* methods of caching available, 14-6
* MTRR initialization, 14-29
* MTRR precedences, 14-28
* MTRRs, description of, 14-20
* multiple-processor considerations, 14-32
* NW flag, CR0 control register, 14-13, 25-19
* operating modes, 14-12
* overview of, 14-1
* page attribute table (PAT), 14-33
* PCD flag
  * CR3 control register, 14-13
  * page-directory entries, 14-13, 14-33
  * page-table entries, 14-13, 14-33
* PGE (page global enable) flag, CR4 control register, 14-13
* precedence of controls, 14-13
* preventing caching, 14-16
* protocol, 14-9
* PWT flag
  * CR3 control register, 14-13
  * page-directory entries, 14-33
  * page-table entries, 14-33
* remapping memory types, 14-29
* setting up memory ranges with MTRRs, 14-22
* shared mode, L1 Data Cache, 14-18
* variable-range MTRRs, 14-23, 14-25
Caches, 2-7

INDEX-2 Vol. 3D

INDEX

cache hit, 14-5
cache line, 14-5
cache line fill, 14-5
cache write hit, 14-5
description of, 14-1
effects of a locked operation on internal processor caches, 11-6
enabling, 12-7
management, instructions, 2-27, 14-17
Caching
* cache control protocol, 14-9
* cache line, 14-5
* cache management instructions, 14-17
* cache mechanisms in IA-32 processors, 25-30
* caching terminology, 14-5
* choosing a memory type, 14-8
* flushing TLBs, 14-19
* implicit caching, 14-19
* internal caches, 14-1
* L1 (level 1) cache, 14-4
* L2 (level 2) cache, 14-4
* L3 (level 3) cache, 14-4
* methods of caching available, 14-6
* MTRRs, description of, 14-20
* operating modes, 14-12
* overview of, 14-1
* self-modifying code, effect on, 14-18, 25-30
* snooping, 14-6
* store buffer, 14-20
* TLBs, 14-5
* UC (strong uncacheable) memory type, 14-6
* UC- (uncacheable) memory type, 14-6
* WB (write back) memory type, 14-7
* WC (write combining) memory type, 14-7
* WP (write protected) memory type, 14-7
* write-back caching, 14-6
* WT (write through) memory type, 14-7
Call gates
* 16-bit, interlevel return from, 25-33
* accessing a code segment through, 6-15
* description of, 6-13
* for 16-bit and 32-bit code modules, 24-1
* IA-32e mode, 6-14
* introduction to, 2-4
* mechanism, 6-15
* privilege level checking rules, 6-16
CALL instruction, 2-5, 3-8, 6-10, 6-15, 6-20, 10-2, 10-9, 10-11, 24-5
Caller access privileges, checking, 6-26
Calls
* 16 and 32-bit code segments, 24-3
* controlling operand-size attribute, 24-5
* returning from, 6-20
Catastrophic shutdown detector
* Thermal monitoring
    * catastrophic shutdown detector, 17-37
catastrophic shutdown detector, 17-36
CC0 and CC1 (counter control) fields, CESR MSR (Pentium processor), 22-146
CD (cache disable) flag, CR0 control register, 2-16, 12-7, 14-10, 14-12, 14-13, 14-16, 14-32, 25-18, 25-19, 25-30
CESR (control and event select) MSR (Pentium processor), 22-145, 22-146
CLFLSH feature flag, CPUID instruction, 12-8
CLFLUSH instruction, 2-17, 12-8, 14-17
CLI instruction, 7-8
Clocks

counting processor clocks, 22-147
Hyper-Threading Technology, 22-147
nominal CPI, 22-147
non-halted clockticks, 22-147
non-halted CPI, 22-147
non-sleep Clockticks, 22-147
time stamp counter, 22-147
CLTS instruction, 2-25, 6-24, 28-2, 28-8
Cluster model, local APIC, 13-25
CMOVcc instructions, 25-4
CMPXCHG instruction, 11-4, 25-4
CMPXCHG8B instruction, 11-4, 25-5
Code modules
* 16 bit vs. 32 bit, 24-1
* mixing 16-bit and 32-bit code, 24-1
* sharing data, mixed-size code segs, 24-3
* transferring control, mixed-size code segs, 24-3
Code segments
* accessing data in, 6-9
* accessing through a call gate, 6-15
* description of, 3-12
* descriptor format, 6-2
* descriptor layout, 6-2
* direct calls or jumps to, 6-10
* paging of, 2-6
* pointer size, 24-4
* privilege level checks
    * transferring control between code segs, 6-10
Compatibility
* IA-32 architecture, 25-1
Compatibility mode
* code segment descriptor, 6-3
* code segment descriptors, 12-12
* control registers, 2-13
* CS.L and CS.D, 12-12
* debug registers, 2-27
* EFLAGS register, 2-11
* exception handling, 2-6
* gates, 2-4
* GDTR register, 2-12, 2-13
* global and local descriptor tables, 2-4
* IDTR register, 2-12
* interrupt handling, 2-6
* L flag, 3-12, 6-4
* memory management, 2-6
* operation, 12-12
* segment loading instructions, 3-9
* segments, 3-5
* switching to, 12-12
* SYSCALL and SYSRET, 6-22
* SYSENTER and SYSEXIT, 6-21
* system flags, 2-11
* system registers, 2-7
* task register, 2-13
* See also: 64-bit mode, IA-32e mode
Condition code flags, x87 FPU status word
* compatibility information, 25-8
Conforming code segments
* accessing, 6-12
* C (conforming) flag, 6-11
* description of, 3-13
Context, task (see Task state)
Control registers
* 64-bit mode, 2-13
* CR0, 2-13

Vol. 3D INDEX-3

# INDEX

* CR1 (reserved), 2-13
* CR2, 2-13
* CR3 (PDBR), 2-6, 2-13
* CR4, 2-13
* description of, 2-13
* introduction to, 2-6
* Coprocessor segment
    * overrun exception, 7-38, 25-12
* Counter mask field
    * PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family processors), 22-5, 22-144
* CPL
    * description of, 6-7
    * field, CS segment selector, 6-2
* CPUID instruction
    * availability, 25-5
    * control register flags, 2-21
    * detecting features, 25-2
    * feature information, 36-76
    * serializing instructions, 11-19
* CR0 control register, 25-8
    * description of, 2-13
    * introduction to, 2-6
    * state following processor reset, 12-2
* CR1 control register (reserved), 2-13
* CR2 control register
    * description of, 2-13
    * introduction to, 2-6
* CR3 control register (PDBR)
    * associated with a task, 10-1, 10-3
    * description of, 2-13
    * in TSS, 10-4, 10-17
    * introduction to, 2-6
    * loading during initialization, 12-10
    * memory management, 2-6
    * page directory base address, 2-6
    * page table base address, 2-5
* CR4 control register
    * description of, 2-13
    * enabling control functions, 25-2
    * inclusion in IA-32 architecture, 25-18
    * introduction to, 2-6
    * VMX usage of, 26-3
* CR8 register, 2-7
    * 64-bit mode, 2-13
    * compatibility mode, 2-13
    * description of, 2-13
    * when available, 2-13
* CS register, 25-11
    * state following initialization, 12-5
* C-state, 17-35
* CTR0 and CTR1 (performance counters) MSRs (Pentium processor), 22-145, 22-147
* Current privilege level (see CPL)

* privilege level checking when accessing, 6-8
* DE (debugging extensions) flag, CR4 control register, 2-21, 25-18, 25-20
* Debug exception (#DB), 7-8, 7-26, 10-5, 20-7, 20-14, 20-42
* Debug store (see DS)
* DEBUGCTLMSR MSR, 20-40, 20-42
* Debugging facilities
    * breakpoint exception (#BP), 20-1
    * debug exception (#DB), 20-1
    * DR6 debug status register, 20-1
    * DR7 debug control register, 20-1
    * exceptions, 20-7
    * INT3 instruction, 20-2
    * last branch, interrupt, and exception recording, 20-2, 20-12
    * masking debug exceptions, 7-8
    * overview of, 20-1
    * performance-monitoring counters, 22-1
    * registers
        * description of, 20-2
        * introduction to, 2-6
        * loading, 2-27
    * RF (resume) flag, EFLAGS, 20-1
    * see DS (debug store) mechanism
    * T (debug trap) flag, TSS, 20-1
    * TF (trap) flag, EFLAGS, 20-1
* DEC instruction, 11-4
* Denormal operand exception (#D), 25-10
* Denormalized operand, 25-12
* Device-not-available exception (#NM), 2-17, 2-26, 7-34, 12-7, 25-11, 25-12
* DFR
    * Destination Format Register, 13-39, 13-42, 13-47
* Digital readout bits, 17-43, 17-46
* DIV instruction, 7-25
* Divide configuration register, local APIC, 13-17
* Divide-error exception (#DE), 7-25, 25-21
* Double-fault exception (#DF), 7-36, 25-27
* DPL (descriptor privilege level) field, segment descriptor, 3-11, 6-2, 6-4, 6-7
* DR0-DR3 breakpoint-address registers, 20-1, 20-4, 20-39, 20-41, 20-42
* DR4-DR5 debug registers, 20-4, 25-20
* DR6 debug status register, 20-4
    * B0-B3 (BP detected) flags, 20-4
    * BD (debug register access detected) flag, 20-4
    * BS (single step) flag, 20-4
    * BT (task switch) flag, 20-4
    * debug exception (#DB), 7-26
    * reserved bits, 25-20
* DR7 debug control register, 20-4
    * G0-G3 (global breakpoint enable) flags, 20-5
    * GD (general detect enable) flag, 20-5
    * GE (global exact breakpoint enable) flag, 20-5
    * L0-L3 (local breakpoint enable) flags, 20-5
    * LE (local exact breakpoint enable) flag, 20-5
    * LEN0-LEN3 (Length) fields, 20-5
    * R/W0-R/W3 (read/write) fields, 20-5, 25-20
* DS feature flag, CPUID instruction, 20-19, 20-35, 20-38, 20-40
* DS save area, 20-21, 20-22, 20-23
* DS (debug store) mechanism
    * availability of, 22-119
    * description of, 22-119
    * DS feature flag, CPUID instruction, 22-119
    * DS save area, 20-19, 20-22
    * IA-32e mode, 20-22

# D

* D (default operation size) flag
    * segment descriptor, 24-1, 25-33
* Data breakpoint exception conditions, 20-10
* Data segments
    * description of, 3-12
    * descriptor layout, 6-2
    * expand-down type, 3-11
    * paging of, 2-6

INDEX-4 Vol. 3D

INDEX

interrupt service routine (DS ISR), 20-26
setting up, 20-24
Dual-core technology
architecture, 11-33
logical processors supported, 11-26
MTRR memory map, 11-34
multi-threading feature flag, 11-26
performance monitoring, 22-133
specific features, 25-4
Dual-monitor treatment, 34-19
D/B (default operation size/default stack pointer size and/or upper bound) flag, segment descriptor, 3-11, 6-4

# E

E (edge detect) flag
PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family), 22-4
E (edge detect) flag, PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family processors), 22-143
E (expansion direction) flag
segment descriptor, 6-2, 6-4
E (MTRRs enabled) flag
IA32_MTRR_DEF_TYPE MSR, 14-23
EFLAGS register
identifying 32-bit processors, 25-6
introduction to, 2-6
new flags, 25-6
saved in TSS, 10-5
system flags, 2-9
EIP register, 25-11
saved in TSS, 10-5
state following initialization, 12-5
EM (emulation) flag
CR0 control register, 2-17, 7-34, 12-6, 12-7, 15-1, 16-3
EMMS instruction, 15-3
Enhanced Intel SpeedStep Technology
ACPI 3.0 specification, 17-1
IA32_APERF MSR, 17-2
IA32_MPERF MSR, 17-2
IA32_PERF_CTL MSR, 17-1
IA32_PERF_STATUS MSR, 17-1
introduction, 17-1
multiple processor cores, 17-1
performance transitions, 17-1
P-state coordination, 17-1
See also: thermal monitoring
EOI
End Of Interrupt register, 13-39
Error code, 19-3, 19-7, 19-9, 19-12, 19-15
architectural MCA, 19-1, 19-3, 19-7, 19-9, 19-12, 19-15
decoding IA32_MCi_STATUS, 19-1, 19-3, 19-7, 19-9, 19-12, 19-15
exception, description of, 7-18
external bus, 19-1, 19-3, 19-7, 19-9, 19-12, 19-15
memory hierarchy, 19-3, 19-7, 19-9, 19-12, 19-15
pushing on stack, 25-32
watchdog timer, 19-1, 19-3, 19-7, 19-9, 19-12, 19-15
Error numbers
VM-instruction error field, 33-30
Error signals, 25-11
Error-reporting bank registers, 18-2
ERROR#
input, 25-16
output, 25-16

ES0 and ES1 (event select) fields, CESR MSR (Pentium processor), 22-146
ESR
Error Status Register, 13-40
ET (extension type) flag, CR0 control register, 2-16, 25-8
EUPDATESVN, 41-67
Event select field, PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family processors), 22-4, 22-107, 22-143
Events
at-retirement, 22-125
at-retirement (Pentium 4 processor), 22-115
non-retirement (Pentium 4 processor), 22-115
Exception handler
calling, 7-12
defined, 7-1, 8-1
flag usage by handler procedure, 7-18
machine-check exception handler, 18-28
machine-check exceptions (#MC), 18-28
machine-error logging utility, 18-28
procedures, 7-13
protection of handler procedures, 7-17
task, 7-18, 10-2
Exceptions
alignment check, 25-11
classifications, 7-4
compound error codes, 18-21
conditions checked during a task switch, 10-13
coprocessor segment overrun, 25-12
description of, 2-5, 7-1
device not available, 25-12
double fault, 7-36
error code, 7-18
execute-disable bit, 6-34
floating-point error, 25-12
general protection, 25-12
handler mechanism, 7-13
handler procedures, 7-13
handling, 7-12
handling in real-address mode, 23-4
handling in SMM, 34-11
handling in virtual-8086 mode, 23-11
handling through a task gate in virtual-8086 mode, 23-14
handling through a trap or interrupt gate in virtual-8086 mode, 23-12
IA-32e mode, 2-6
IDT, 7-10
initializing for protected-mode operation, 12-10
invalid-opcode, 25-5
masking debug exceptions, 7-8
masking when switching stack segments, 7-8
MCA error codes, 18-21
MMX instructions, 15-1
overview of, 7-1, 8-1
priority of, 25-22
priority of, x87 FPU exceptions, 25-10
reference information on all exceptions, 7-24
reference information, 64-bit mode, 7-20
restarting a task or program, 7-5
segment not present, 25-12
simple error codes, 18-21
sources of, 7-4
summary of, 7-2
vectors, 7-1
Executable, 3-11
Execute-disable bit capability

Vol. 3D INDEX-5
<page_number>INDEX-5</page_number>

# INDEX

conditions for, 6-30
CPUID flag, 6-31
detecting and enabling, 6-30
exception handling, 6-34
page-fault exceptions, 7-47
protection matrix for IA-32e mode, 6-32
protection matrix for legacy modes, 6-32
reserved bit checking, 6-32
Exit-reason numbers
VM entries & exits, C-1
Expand-down data segment type, 3-11
Extended signature table, 12-31
extended signature table, 12-31
External bus errors, detected with machine-check architecture, 18-28

## F

F2XM1 instruction, 25-13
Family 06H, 19-1
Family 0FH, 19-1
microcode update facilities, 12-28
Faults
description of, 7-5
restarting a program or task after, 7-5
FCMOVcc instructions, 25-4
FCOMI instruction, 25-4
FCOMIP instruction, 25-4
FCOS instruction, 25-13
FDIV instruction, 25-11, 25-12
FE (fixed MTRRs enabled) flag, IA32_MTRR_DEF_TYPE MSR, 14-23
Feature
determination, of processor, 25-2
information, processor, 25-2
FINIT/FNINIT instructions, 25-8, 25-16
FIX (fixed range registers supported) flag, IA32_MTRRCAPMSR, 14-22
Fixed-range MTRRs
description of, 14-23
Flat segmentation model, 3-3
FLD instruction, 25-14
FLDENV instruction, 25-12
FLDL2E instruction, 25-14
FLDL2T instruction, 25-14
FLDLG2 instruction, 25-14
FLDLN2 instruction, 25-14
FLDPI instruction, 25-14
Floating-point error exception (#MF), 25-12
Floating-point exceptions
denormal operand exception (#D), 25-10
invalid operation (#I), 25-14
numeric overflow (#O), 25-10
numeric underflow (#U), 25-10
saved CS and EIP values, 25-11
FLUSH# pin, 7-3
FNSAVE instruction, 15-4
Focus processor, local APIC, 13-26
FORCEPR# log, 17-43, 17-46
FORCPR# interrupt enable bit, 17-44
FPATAN instruction, 25-13
FPREM instruction, 25-8, 25-11, 25-12, 25-13
FPREM1 instruction, 25-8, 25-13
FPTAN instruction, 25-8, 25-13
FRSTOR instruction, 15-4, 25-11, 25-12
FSAVE instruction, 15-3, 15-4

FSAVE/FNSAVE instructions, 25-11, 25-14
FSCALE instruction, 25-12
FSIN instruction, 25-13
FSINCOS instruction, 25-13
FSQRT instruction, 25-11, 25-12
FSTENV instruction, 15-3
FSTENV/FNSTENV instructions, 25-14
FTAN instruction, 25-8
FUCOM instruction, 25-13
FUCOMI instruction, 25-4
FUCOMIP instruction, 25-4
FUCOMP instruction, 25-13
FUCOMPP instruction, 25-13
FWAIT instruction, 7-34
FXAM instruction, 25-14
FXRSTOR instruction, 2-19, 2-20, 12-8, 15-3, 15-4, 16-2, 16-6
FXSAVE instruction, 2-19, 2-20, 12-8, 15-3, 15-4, 16-2, 16-6
FXSR feature flag, CPUID instruction, 12-8
FXTRACT instruction, 25-10, 25-14

## G

G (global) flag
page-directory entries, 14-13
page-table entries, 14-13
G (granularity) flag
segment descriptor, 3-10, 3-11, 6-2, 6-4
G0-G3 (global breakpoint enable) flags
DR7 register, 20-5
Gate descriptors
call gates, 6-13
description of, 6-13
IA-32e mode, 6-14
Gates, 2-4
IA-32e mode, 2-4
GD (general detect enable) flag
DR7 register, 20-5, 20-10
GDT
description of, 2-3, 3-15
IA-32e mode, 2-4
index field of segment selector, 3-7
initializing, 12-10
paging of, 2-6
pointers to exception/interrupt handlers, 7-13
segment descriptors in, 3-9
selecting with TI flag of segment selector, 3-7
task switching, 10-9
task-gate descriptor, 10-8
TSS descriptors, 10-5
use in address translation, 3-6
GDTR register
description of, 2-3, 2-6, 2-12, 3-15
IA-32e mode, 2-4, 2-12
limit, 6-5
loading during initialization, 12-10
storing, 3-15
GE (global exact breakpoint enable) flag
DR7 register, 20-5, 20-10
General-detect exception condition, 20-10
General-protection exception (#GP), 3-12, 6-6, 6-7, 6-11, 6-12, 7-10, 7-17, 7-44, 10-5, 20-3, 25-12, 25-21, 25-34, 25-35
General-purpose registers, saved in TSS, 10-4
Global control MSRs, 18-2
Global descriptor table register (see GDTR)
Global descriptor table (see GDT)

INDEX-6 Vol. 3D

INDEX

# H

HALT state
* relationship to SMI interrupt, 34-4, 34-14

Hardware reset
* description of, 12-1
* processor state after reset, 12-2
* state of MTRRs following, 14-20
* value of SMBASE following, 34-4

high-temperature interrupt enable bit, 17-44, 17-47
HITM# line, 14-6
HLT instruction, 2-28, 6-24, 7-37, 28-2, 34-14, 34-15
Hyper-Threading Technology
* architectural state of a logical processor, 11-34
* architecture description, 11-28
* caches, 11-32
* debug registers, 11-31
* description of, 11-26, 25-3, 25-4
* detecting, 11-37, 11-38, 11-43, 11-44
* executing multiple threads, 11-28
* execution-based timing loops, 11-55
* external signal compatibility, 11-33
* halting logical processors, 11-54
* handling interrupts, 11-28
* HLT instruction, 11-49
* IA32_MISC_ENABLE MSR, 11-31, 11-34
* initializing IA-32 processors with, 11-27
* introduction of into the IA-32 architecture, 25-3, 25-4
* local a, 11-29
* local APIC
    - functionality in logical processor, 11-30
* logical processors, identifying, 11-40
* machine check architecture, 11-30
* managing idle and blocked conditions, 11-49
* mapping resources, 11-35
* memory ordering, 11-31
* microcode update resources, 11-31, 11-34, 12-35
* MP systems, 11-28
* MTRRs, 11-30, 11-34
* multi-threading feature flag, 11-26
* multi-threading support, 11-26
* PAT, 11-30
* PAUSE instruction, 11-49, 11-50
* performance monitoring, 22-129, 22-133
* performance monitoring counters, 11-31, 11-34
* placement of locks and semaphores, 11-55
* required operating system support, 11-52
* scheduling multiple threads, 11-55
* self modifying code, 11-32
* serializing instructions, 11-31
* spin-wait loops
    - PAUSE instructions in, 11-52, 11-54
* thermal monitor, 11-33
* TLBs, 11-32

# I

IA-32 Intel architecture
* compatibility, 25-1
* processors, 25-1

IA32e mode
* registers and mode changes, 12-12

IA-32e mode
* call gates, 6-14
* code segment descriptor, 6-3
* D flag, 6-4

* data structures and initialization, 12-11
* debug registers, 2-7
* debug store area
* descriptors, 2-4
* DPL field, 6-4
* exceptions during initialization, 12-12
* feature-enable register, 2-7
* gates, 2-4
* global and local descriptor tables, 2-4
* IA32_EFER MSR, 2-7, 6-31
* initialization process, 12-11
* interrupt stack table, 7-23
* interrupts and exceptions, 2-6
* IRET instruction, 7-22
* L flag, 3-12, 6-4
* logical address, 3-7
* MOV CRn, 12-11
* MTRR calculations, 14-27
* NXE bit, 6-31
* page level protection, 6-30
* paging, 2-6
* PDE tables, 6-32
* PDP tables, 6-32
* PML4 tables, 6-32
* PTE tables, 6-32
* registers and data structures, 2-1
* segment descriptor tables, 3-16, 6-3
* segment descriptors, 3-9
* segment loading instructions, 3-9
* segmentation, 3-5
* stack switching, 6-19, 7-22
* SYSCALL and SYSRET, 6-22
* SYSENTER and SYSEXIT, 6-21
* system descriptors, 3-14
* system registers, 2-7
* task switching, 10-19
* task-state segments, 2-5
* terminating mode operation, 12-12
* See also: 64-bit mode, compatibility mode

IA32_APERF MSR, 17-2
IA32_APIC_BASE MSR, 11-20, 11-21, 13-5, 13-7, 13-8
IA32_CLOCK_MODULATION MSR, 11-33, 17-7, 17-14, 17-15, 17-16, 17-17, 17-18, 17-21, 17-22, 17-23, 17-24, 17-40, 17-41, 17-43, 17-51, 17-52, 17-53, 17-54, 17-55
IA32_DEBUGCTL MSR, 30-30
IA32_DS_AREA MSR, 20-19, 20-20, 20-24, 22-112, 22-128
IA32_EFER MSR, 2-7, 2-8, 6-31, 30-30
IA32_FEATURE_CONTROL MSR, 26-3
IA32_KernelGSbase MSR, 2-7
IA32_LSTAR MSR, 2-7, 6-22
IA32_MCG_CAP MSR, 18-2, 18-29
IA32_MCG_CTL MSR, 18-2, 18-4
IA32_MCG_EAX MSR, 18-12
IA32_MCG_EBP MSR, 18-12
IA32_MCG_EBX MSR, 18-12
IA32_MCG_ECX MSR, 18-12
IA32_MCG_EDI MSR, 18-12
IA32_MCG_EDX MSR, 18-12
IA32_MCG_EFLAGS MSR, 18-12
IA32_MCG_EIP MSR, 18-12
IA32_MCG_ESI MSR, 18-12
IA32_MCG_ESP MSR, 18-12
IA32_MCG_MISC MSR, 18-12, 18-13
IA32_MCG_R10 MSR, 18-13
IA32_MCG_R11 MSR, 18-13

Vol. 3D <page_number>INDEX-7</page_number>

# INDEX

IA32_MCG_R12 MSR, 18-13
IA32_MCG_R13 MSR, 18-13
IA32_MCG_R14 MSR, 18-13
IA32_MCG_R15 MSR, 18-13
IA32_MCG_R8 MSR, 18-13
IA32_MCG_R9 MSR, 18-13
IA32_MCG_RAX MSR, 18-12
IA32_MCG_RBP MSR, 18-12
IA32_MCG_RBX MSR, 18-12
IA32_MCG_RCX MSR, 18-12
IA32_MCG_RDI MSR, 18-12
IA32_MCG_RDX MSR, 18-12
IA32_MCG_RESERVEDn MSR, 18-12
IA32_MCG_RFLAGS MSR, 18-12
IA32_MCG_RIP MSR, 18-12
IA32_MCG_RSI MSR, 18-12
IA32_MCG_RSP MSR, 18-12
IA32_MCG_STATUS MSR, 18-2, 18-4, 18-29, 18-31, 30-3
IA32_MCi_ADDR MSR, 18-9, 18-31
IA32_MCi_CTL, 18-6
IA32_MCi_CTL MSR, 18-6
IA32_MCi_MISC MSR, 18-9, 18-11, 18-12, 18-31
IA32_MCi_STATUS MSR, 18-6, 18-29, 18-31
- decoding for Family 06H, 19-1
- decoding for Family 0FH, 19-1, 19-3, 19-7, 19-9, 19-12, 19-15
IA32_MISC_ENABLE MSR, 17-1, 17-37, 20-20, 20-35, 22-112
IA32_MPERF MSR, 17-1, 17-2
IA32_MTRRCAP MSR, 14-21, 14-22
IA32_MTRR_DEF_TYPE MSR, 14-22
IA32_MTRR_FIXn, fixed ranger MTRRs, 14-23
IA32_PAT_CR MSR, 14-34
IA32_PEBS_ENABLE MSR, 22-110, 22-112, 22-127
IA32_PERF_CTL MSR, 17-1
IA32_PERF_STATUS MSR, 17-1
IA32_STAR MSR, 6-22
IA32_STAR_CS MSR, 2-7
IA32_SYSCALL_FLAG_MASK MSR, 2-7
IA32_SYSENTER_CS MSR, 6-21, 6-22, 30-24
IA32_SYSENTER_EIP MSR, 6-21
IA32_SYSENTER_ESP MSR, 6-21, 30-30, 30-31
IA32_THERM_INTERRUPT MSR, 17-39, 17-41, 17-42, 17-44
- FORCPR# interrupt enable bit, 17-44
- high-temperature interrupt enable bit, 17-44, 17-47
- low-temperature interrupt enable bit, 17-44, 17-47
- overheat interrupt enable bit, 17-44, 17-47
- THERMTRIP# interrupt enable bit, 17-44, 17-47
- threshold #1 interrupt enable bit, 17-44, 17-47
- threshold #1 value, 17-44, 17-47
- threshold #2 interrupt enable, 17-44, 17-47
- threshold #2 value, 17-44, 17-47
IA32_THERM_STATUS MSR, 17-41, 17-42
- digital readout bits, 17-43, 17-46
- out-of-spec status bit, 17-43, 17-46
- out-of-spec status log, 17-43, 17-46
- PROCHOT# or FORCEPR# event bit, 17-42, 17-46
- PROCHOT# or FORCEPR# log, 17-43, 17-46
- resolution in degrees, 17-43
- thermal status bit, 17-42, 17-45
- thermal status log, 17-42, 17-45
- thermal threshold #1 log, 17-43, 17-46
- thermal threshold #1 status, 17-43, 17-46
- thermal threshold #2 log, 17-43, 17-46
- thermal threshold #2 status, 17-43, 17-46
- validation bit, 17-43
IA32_VMX_BASIC MSR, 27-3, A-1, A-2
IA32_VMX_CR0_FIXED0 MSR, A-7
IA32_VMX_CR0_FIXED1 MSR, A-7
IA32_VMX_CR4_FIXED0 MSR, A-7
IA32_VMX_CR4_FIXED1 MSR, A-7
IA32_VMX_ENTRY_CTLS MSR, A-2, A-5, A-6
IA32_VMX_EXIT_CTLS MSR, A-2, A-5
IA32_VMX_MISC MSR, 27-6, 29-3, 29-13, 34-26, A-6
IA32_VMX_PINBASED_CTLS MSR, A-2, A-3
IA32_VMX_PROCBASED_CTLS MSR, 27-10, A-2, A-3, A-4, A-5, A-8, A-9
IA32_VMX_VMCS_ENUM MSR, A-8
ICR
- Interrupt Command Register, 13-39, 13-42, 13-48
ID (identification) flag
- EFLAGS register, 2-11, 25-6, 25-7
IDIV instruction, 7-25, 25-21
IDT
- 64-bit mode, 7-20
- call interrupt & exception-handlers from, 7-12
- change base & limit in real-address mode, 23-5
- description of, 7-10
- handling NMIs during initialization, 12-9
- initializing protected-mode operation, 12-10
- initializing real-address mode operation, 12-8
- introduction to, 2-5
- limit, 25-27
- paging of, 2-6
- structure in real-address mode, 23-5
- task switching, 10-10
- task-gate descriptor, 10-8
- types of descriptors allowed, 7-11
- use in real-address mode, 23-4
IDTR register
- description of, 2-12, 7-10
- IA-32e mode, 2-12
- introduction to, 2-5
- limit, 6-5
- loading in real-address mode, 23-5
- storing, 3-16
IE (invalid operation exception) flag
- x87 FPU status word, 25-8
IEEE Standard 754 for Binary Floating-Point Arithmetic, 25-9, 25-10, 25-12, 25-13, 25-14
IF (interrupt enable) flag
- EFLAGS register, 2-10, 2-11, 7-7, 7-11, 7-18, 23-4, 23-19, 34-11
IN instruction, 11-17, 25-35, 28-2
INC instruction, 11-4
Index field, segment selector, 3-7
INIT interrupt, 13-3
Initial-count register, local APIC, 13-16
Initialization
- built-in self-test (BIST), 12-1, 12-5
- CS register state following, 12-5
- EIP register state following, 12-5
- example, 12-14
- first instruction executed, 12-5
- hardware reset, 12-1
- IA-32e mode, 12-11
- IDT, protected mode, 12-10
- IDT, real-address mode, 12-8
- Intel486 SX processor and Intel 487 SX math coprocessor, 25-16
- location of software-initialization code, 12-5
- machine-check initialization, 18-19
- model and stepping information, 12-5

INDEX-8 Vol. 3D

INDEX

multitasking environment, 12-10, 12-11
overview, 12-1
paging, 12-10
processor state after reset, 12-2
protected mode, 12-9
real-address mode, 12-8
RESET# pin, 12-1
setting up exception- and interrupt-handling facilities, 12-10
x87 FPU, 12-5
INIT# pin, 7-3, 12-1
INIT# signal, 2-28, 26-4
INS instruction, 20-10
Instruction-breakpoint exception condition, 20-9
Instructions
* new instructions, 25-4
* obsolete instructions, 25-5
* privileged, 6-23
* serializing, 11-18, 11-31, 25-16
* supported in real-address mode, 23-3
* system, 2-7, 2-24
INS/INSB/INSW/INSD instruction, 28-2
INT 3 instruction, 2-5, 7-29, 20-7
INT instruction, 2-5, 6-10
INT n instruction, 3-8, 7-1, 7-4, 20-11
INT (APIC interrupt enable) flag, PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family processors), 22-5, 22-144
INT15 and microcode updates, 12-42
INT3 instruction, 3-8, 7-4
Intel 287 math coprocessor, 25-7
Intel 387 math coprocessor system, 25-7
Intel 487 SX math coprocessor, 25-7, 25-16
Intel 8086 processor, 25-7
Intel Core Solo and Intel Core Duo processors
* event mask (Umask), 22-104, 22-106
* last branch, interrupt, exception recording, 20-38
* notes on P-state transitions, 17-1
* performance monitoring, 22-104, 22-106
* sub-fields layouts, 22-104, 22-106
* time stamp counters, 20-42
Intel SpeedStep Technology
* See: Enhanced Intel SpeedStep Technology
Intel Xeon processor
* last branch, interrupt, and exception recording, 20-35
* time-stamp counter, 20-42
Intel Xeon processor MP
* with 8MB L3 cache, 22-133, 22-136
Intel286 processor, 25-7
Intel386 DX processor, 25-7
Intel386 SL processor, 2-8
Intel486 DX processor, 25-7
Intel486 SX processor, 25-7, 25-16
Interprivilege level calls
* call mechanism, 6-15
* stack switching, 6-17
Interprocessor interrupt (IPIs), 13-1
Interprocessor interrupt (IPI)
* in MP systems, 13-1
interrupt, 7-14
Interrupt Command Register, 13-39
Interrupt command register (ICR), local APIC, 13-19
Interrupt gates
* 16-bit, interlevel return from, 25-33
* clearing IF flag, 7-8, 7-18
* difference between interrupt and trap gates, 7-18
* for 16-bit and 32-bit code modules, 24-1

* handling a virtual-8086 mode interrupt or exception through, 23-12
* in IDT, 7-11
* introduction to, 2-4, 2-5
* layout of, 7-11
Interrupt handler
* calling, 7-12
* defined, 7-1, 8-1
* flag usage by handler procedure, 7-18
* procedures, 7-13
* protection of handler procedures, 7-17
* task, 7-18, 10-2
Interrupts
* automatic bus locking, 25-35
* control transfers between 16- and 32-bit code modules, 24-6
* description of, 2-5, 7-1, 8-2
* destination, 13-27
* distribution mechanism, local APIC, 13-26
* enabling and disabling, 7-7
* handling, 7-12
* handling in real-address mode, 23-4
* handling in SMM, 34-11
* handling in virtual-8086 mode, 23-11
* handling multiple NMIs, 7-6
* handling through a task gate in virtual-8086 mode, 23-14
* handling through a trap or interrupt gate in virtual-8086 mode, 23-12
* IA-32e mode, 2-6, 2-12
* IDT, 7-10
* IDTR, 2-12
* initializing for protected-mode operation, 12-10
* interrupt descriptor table register (see IDTR)
* interrupt descriptor table (see IDT)
* list of, 7-2, 23-6
* local APIC, 13-1
* maskable hardware interrupts, 2-10
* masking maskable hardware interrupts, 7-7
* masking when switching stack segments, 7-8
* message signalled interrupts, 13-35
* on-die sensors for, 17-36
* overview of, 7-1, 8-1
* priority, 13-29
* propagation delay, 25-27
* real-address mode, 23-6
* restarting a task or program, 7-5
* software, 7-61
* sources of, 13-1
* summary of, 7-2
* thermal monitoring, 17-36
* user defined, 7-1, 7-61
* valid APIC interrupts, 13-15
* vectors, 7-1
* virtual-8086 mode, 23-6
INTO instruction, 2-5, 3-8, 7-4, 7-30, 20-11
INTR# pin, 7-2, 7-7
Invalid opcode exception (#UD), 2-17, 7-32, 7-56, 15-1, 20-4, 25-5, 25-11, 25-20, 25-21, 34-3
Invalid TSS exception (#TS), 7-39, 10-6
Invalid-operation exception, x87 FPU, 25-11, 25-14
INVD instruction, 2-27, 6-24, 14-17, 25-4
INVLPG instruction, 2-27, 6-24, 25-4, 28-3
IOPL (I/O privilege level) field, EFLAGS register
* description of, 2-10
* on return from exception, interrupt handler, 7-14
* sensitive instructions in virtual-8086 mode, 23-10

Vol. 3D INDEX-9

INDEX

virtual interrupt, 2-11
IPI (see interprocessor interrupt)
IRET instruction, 3-8, 7-8, 7-14, 7-18, 7-22, 10-10, 10-11, 11-19, 23-5, 23-19, 28-9
IRETD instruction, 2-10, 11-19
IRR
* Interrupt Request Register, 13-40, 13-42, 13-48
IRR (interrupt request register), local APIC, 13-31
ISR
* In Service Register, 13-39, 13-42, 13-48
I/O
* breakpoint exception conditions, 20-10
* in virtual-8086 mode, 23-10
* instruction restart flag
  - SMM revision identifier field, 34-15
* instruction restart flag, SMM revision identifier field, 34-15
* IO_SMI bit, 34-12
* I/O permission bit map, TSS, 10-5
* map base address field, TSS, 10-5
* restarting following SMI interrupt, 34-15
* saving I/O state, 34-12
* SMM state save map, 34-12
I/O APIC, 13-27
* bus arbitration, 13-27
* description of, 13-1
* external interrupts, 7-3
* information about, 13-1
* interrupt sources, 13-2
* local APIC and I/O APIC, 13-2, 13-3
* overview of, 13-1
* valid interrupts, 13-15
* See also: local APIC

# J
JMP instruction, 2-5, 3-8, 6-10, 6-15, 10-2, 10-9, 10-11

# K
KEN# pin, 14-13, 25-36

# L
L0-L3 (local breakpoint enable) flags
* DR7 register, 20-5
L1 (level 1) cache
* caching methods, 14-6
* CPUID feature flag, 14-18
* description of, 14-4
* effect of using write-through memory, 14-9
* introduction of, 25-30
* invalidating and flushing, 14-17
* MESI cache protocol, 14-9
* shared and adaptive mode, 14-18
L2 (level 2) cache
* caching methods, 14-6
* description of, 14-4
* disabling, 14-17
* effect of using write-through memory, 14-9
* introduction of, 25-30
* invalidating and flushing, 14-17
* MESI cache protocol, 14-9
L3 (level 3) cache
* caching methods, 14-6
* description of, 14-4
* disabling and enabling, 14-13, 14-17

* effect of using write-through memory, 14-9
* introduction of, 25-31
* invalidating and flushing, 14-17
* MESI cache protocol, 14-9
LAM, 4-3
LAR instruction, 2-26, 6-25
Larger page sizes
* introduction of, 25-31
* support for, 25-19
LASS, 4-2
Last branch
* interrupt & exception recording
  - description of, 20-12, 20-27, 20-29, 20-31, 20-32, 20-33, 20-36, 20-38, 20-39, 20-40
  - record stack, 20-18, 20-19, 20-27, 20-28, 20-35, 20-36, 20-38, 20-40
  - record top-of-stack pointer, 20-18, 20-28, 20-35, 20-39, 20-40
LastBranchFromIP MSR, 20-41, 20-42
LastBranchToIP MSR, 20-41, 20-42
LastExceptionFromIP MSR, 20-37, 20-39, 20-41, 20-42
LastExceptionToIP MSR, 20-37, 20-39, 20-41, 20-42
LBR (last branch/interrupt/exception) flag, DEBUGCTLMSR MSR, 20-14, 20-35, 20-41, 20-42
LDR
* Logical Destination Register, 13-42, 13-46, 13-47
LDS instruction, 3-8, 6-8
LDT
* associated with a task, 10-3
* description of, 2-3, 2-5, 3-15
* index into with index field of segment selector, 3-7
* pointer to in TSS, 10-5
* pointers to exception and interrupt handlers, 7-13
* segment descriptors in, 3-9
* segment selector field, TSS, 10-16
* selecting with TI (table indicator) flag of segment selector, 3-7
* setting up during initialization, 12-10
* task switching, 10-9
* task-gate descriptor, 10-8
* use in address translation, 3-6
LDTR register
* description of, 2-3, 2-5, 2-6, 2-12, 3-15
* IA-32e mode, 2-12
* limit, 6-5
* storing, 3-16
LE (local exact breakpoint enable) flag, DR7 register, 20-5, 20-10
LEN0-LEN3 (Length) fields, DR7 register, 20-5, 20-6
LES instruction, 3-8, 6-8, 7-32
LFENCE instruction, 2-17, 11-7, 11-17, 11-18, 11-19
LFS instruction, 3-8, 6-8
LGDT instruction, 2-25, 6-24, 11-19, 12-10, 25-20
LGS instruction, 3-8, 6-8
LIDT instruction, 2-25, 6-24, 7-10, 11-19, 12-9, 23-5, 25-27
Limit checking
* description of, 6-4
* pointer offsets are within limits, 6-25
Limit field, segment descriptor, 6-2, 6-4
Linear, 4-2
Linear address
* description of, 3-6
* IA-32e mode, 3-7
* introduction to, 2-6
Linear address space, 3-6
* defined, 3-1
* of task, 10-17
Link (to previous task) field, TSS, 7-18

INDEX-10 Vol. 3D

INDEX

Linking tasks
* mechanism, 10-15
* modifying task linkages, 10-16
LINT pins
* function of, 7-2
LLDT instruction, 2-25, 6-24, 11-19
LMSW instruction, 2-25, 6-24, 28-3, 28-9
Local APIC, 13-39
* 64-bit mode, 13-33
* APIC_ID value, 11-35
* arbitration over the APIC bus, 13-27
* arbitration over the system bus, 13-27
* block diagram, 13-4
* cluster model, 13-25
* CR8 usage, 13-33
* current-count register, 13-16
* description of, 13-1
* detecting with CPUID, 13-7
* DFR (destination format register), 13-24
* divide configuration register, 13-17
* enabling and disabling, 13-7
* external interrupts, 7-2
* features
    - Pentium 4 and Intel Xeon, 25-28
    - Pentium and P6, 25-28
* focus processor, 13-26
* global enable flag, 13-8
* IA32_APIC_BASE MSR, 13-8
* initial-count register, 13-16
* internal error interrupts, 13-1
* interrupt command register (ICR), 13-19
* interrupt destination, 13-27
* interrupt distribution mechanism, 13-26
* interrupt sources, 13-2
* IRR (interrupt request register), 13-31
* I/O APIC, 13-1
* local APIC and 82489DX, 25-28
* local APIC and I/O APIC, 13-2, 13-3
* local vector table (LVT), 13-12
* logical destination mode, 13-24
* LVT (local-APIC version register), 13-11
* mapping of resources, 11-35
* MDA (message destination address), 13-24
* overview of, 13-1
* performance-monitoring counter, 22-145
* physical destination mode, 13-24
* receiving external interrupts, 7-2
* register address map, 13-6, 13-39
* shared resources, 11-35
* SMI interrupt, 34-2
* spurious interrupt, 13-33
* spurious-interrupt vector register, 13-8
* state after a software (INIT) reset, 13-10
* state after INIT-deassert message, 13-11
* state after power-up reset, 13-10
* state of, 13-34
* SVR (spurious-interrupt vector register), 13-8
* timer, 13-16
* timer generated interrupts, 13-1
* TMR (trigger mode register), 13-31
* valid interrupts, 13-15
* version register, 13-11
Local descriptor table register (see LDTR)
Local descriptor table (see LDT)
Local vector table (LVT)

* description of, 13-12
* thermal entry, 17-39
Local x2APIC, 13-32, 13-42, 13-47
Local xAPIC ID, 13-42
LOCK prefix, 2-28, 7-32, 11-1, 11-3, 11-4, 11-17, 25-35
Locked (atomic) operations
* automatic bus locking, 11-3
* bus locking, 11-3
* effects on caches, 11-6
* loading a segment descriptor, 25-20
* on IA-32 processors, 25-35
* overview of, 11-1
* software-controlled bus locking, 11-4
LOCK# signal, 2-28, 11-1, 11-3, 11-4, 11-6
Logical address
* description of, 3-6
* IA-32e mode, 3-7
Logical address space, of task, 10-17
Logical destination mode, local APIC, 13-24
Logical processors
* per physical package, 11-26
Logical x2APIC ID, 13-47
low-temperature interrupt enable bit, 17-44, 17-47
LSL instruction, 2-26, 6-25
LSS instruction, 3-8, 6-8
LTR instruction, 2-25, 6-24, 10-7, 11-19, 12-11
LVT (see Local vector table)

# M

Machine-check architecture
* availability of MCA and exception, 18-19
* compatibility with Pentium processor, 18-1
* compound error codes, 18-21
* CPUID flags, 18-19
* error codes, 18-21
* error-reporting bank registers, 18-2
* error-reporting MSRs, 18-5
* extended machine check state MSRs, 18-12
* external bus errors, 18-28
* first introduced, 25-22
* global MSRs, 18-2
* initialization of, 18-19
* introduction of in IA-32 processors, 25-36
* logging correctable errors, 18-30, 18-31, 18-36
* machine-check exception handler, 18-28
* machine-check exception (#MC), 18-1
* MSRs, 18-2
* overview of MCA, 18-1
* Pentium processor exception handling, 18-30
* Pentium processor style error reporting, 18-13
* simple error codes, 18-21
* writing machine-check software, 18-28
Machine-check exception (#MC), 7-55, 18-1, 18-19, 18-28, 25-21, 25-36
Mapping of shared resources, 11-35
Maskable hardware interrupts
* description of, 7-3
* handling with virtual interrupt mechanism, 23-15
* masking, 2-10, 7-7
MCA flag, CPUID instruction, 18-19
MCE flag, CPUID instruction, 18-19
MCE (machine-check enable) flag
* CR4 control register, 2-21, 25-18
MDA (message destination address)

Vol. 3D <page_number>INDEX-11</page_number>

# INDEX

local APIC, 13-24
Memory, 14-1
Memory management
* introduction to, 2-6
* overview, 3-1
* paging, 3-1, 3-2
* registers, 2-11
* segments, 3-1, 3-2, 3-7
Memory ordering
* in IA-32 processors, 25-34
* overview, 11-6
* processor ordering, 11-6
* strengthening or weakening, 11-17
* write ordering, 11-6
Memory type range registers (see MTRRs)
Memory types
* caching methods, defined, 14-6
* choosing, 14-8
* MTRR types, 14-21
* selecting for Pentium III and Pentium 4 processors, 14-15
* selecting for Pentium Pro and Pentium II processors, 14-14
* UC (strong uncacheable), 14-6
* UC- (uncacheable), 14-6
* WB (write back), 14-7
* WC (write combining), 14-7
* WP (write protected), 14-7
* writing values across pages with different memory types, 14-16
* WT (write through), 14-7
MemTypeGet() function, 14-29
MemTypeSet() function, 14-31
MESI cache protocol, 14-5, 14-9
Message address register, 13-35
Message data register format, 13-36
Message signalled interrupts
* message address register, 13-35
* message data register format, 13-35
MFENCE instruction, 2-17, 11-7, 11-17, 11-18, 11-19
Microcode update facilities
* authenticating an update, 12-37
* BIOS responsibilities, 12-38
* calling program responsibilities, 12-39
* checksum, 12-33
* extended signature table, 12-31
* family 0FH processors, 12-28
* field definitions, 12-28
* format of update, 12-28
* function 00H presence test, 12-42
* function 01H write microcode update data, 12-43
* function 02H microcode update control, 12-47
* function 03H read microcode update data, 12-48
* general description, 12-28
* HT Technology, 12-35
* INT 15H-based interface, 12-42
* overview, 12-27
* process description, 12-28
* processor identification, 12-32
* processor signature, 12-32
* return codes, 12-49
* update loader, 12-34
* update signature and verification, 12-36
* update specifications, 12-37
* VMX non-root operation, 28-14
Mixing 16-bit and 32-bit code
* in IA-32 processors, 25-33
* overview, 24-1
MMX technology
* debugging MMX code, 15-5
* effect of MMX instructions on pending x87 floating-point exceptions, 15-5
* emulation of the MMX instruction set, 15-1
* exceptions that can occur when executing MMX instructions, 15-1
* introduction of into the IA-32 architecture, 25-2
* register aliasing, 15-1
* state, 15-1
* state, saving and restoring, 15-3
* system programming, 15-1
* task or context switches, 15-4
* using TS flag to control saving of MMX state, 16-7
Mode switching
* example, 12-14
* real-address and protected mode, 12-13
* to SMM, 34-2
Model and stepping information, following processor initialization or reset, 12-5
Model-specific registers (see MSRs)
Modes of operation (see Operating modes)
MONITOR instruction, 28-3
MOV instruction, 3-8, 6-8
MOV (control registers) instructions, 2-25, 2-26, 6-24, 11-19, 12-13
MOV (debug registers) instructions, 2-27, 6-24, 11-19, 20-11
MOVNTDQ instruction, 11-7, 14-17
MOVNTI instruction, 2-17, 11-7, 14-17
MOVNTPD instruction, 11-7, 14-17
MOVNTPS instruction, 11-7, 14-17
MOVNTQ instruction, 11-7, 14-17
MP (monitor coprocessor) flag
* CR0 control register, 2-17, 2-18, 7-34, 12-6, 12-7, 15-1, 25-8
MSR
* Model Specific Register, 13-38, 13-39
MSRs
* description of, 12-7
* introduction of in IA-32 processors, 25-36
* introduction to, 2-6
* machine-check architecture, 18-2
* reading and writing, 2-21, 2-23, 2-29
MSR_DEBUBCTLB MSR, 20-13, 20-30, 20-38, 20-40
MSR_DEBUGCTLA MSR, 20-13, 20-19, 20-25, 20-26, 20-35, 22-7, 22-18, 22-43, 22-55, 22-84, 22-89, 22-95, 22-109, 22-110
MSR_DEBUGCTLB MSR, 20-13, 20-38, 20-39
MSR_IFSB_CNTR7 MSR, 22-135
MSR_IFSB_CTRL6 MSR, 22-135
MSR_IFSB_DRDY0 MSR, 22-135
MSR_IFSB_DRDY1 MSR, 22-135
MSR_IFSB_IBUSQ0 MSR, 22-134
MSR_IFSB_IBUSQ1 MSR, 22-134
MSR_IFSB_ISNPQ0 MSR, 22-134
MSR_IFSB_ISNPQ1 MSR, 22-134
MSR_LASTBRANCH_n MSR, 20-19, 20-36, 20-37
MSR_LASTBRANCH_n_FROM_IP MSR, 20-18, 20-19, 20-36, 20-37
MSR_LASTBRANCH_n_TO_IP MSR, 20-18, 20-19, 20-36, 20-37
MSR_LASTBRANCH_TOS MSR, 20-36, 20-37
MSR_LER_FROM_LIP MSR, 20-37, 20-39
MSR_LER_TO_LIP MSR, 20-37, 20-39
MTRR feature flag, CPUID instruction, 14-21
MTRRcap MSR, 14-21
MTRRfix MSR, 14-23
MTRRs, 11-17
* base & mask calculations, 14-26, 14-27

INDEX-12 Vol. 3D

INDEX

cache control, 14-13
description of, 12-8, 14-20
dual-core processors, 11-34
enabling caching, 12-7
feature identification, 14-21
fixed-range registers, 14-23
IA32_MTRRCAP MSR, 14-21
IA32_MTRR_DEF_TYPE MSR, 14-22
initialization of, 14-29
introduction of in IA-32 processors, 25-36
introduction to, 2-6
large page size considerations, 14-33
logical processors, 11-34
mapping physical memory with, 14-21
memory types and their properties, 14-21
MemTypeGet() function, 14-29
MemTypeSet() function, 14-31
multiple-processor considerations, 14-32
precedence of cache controls, 14-13
precedences, 14-28
programming interface, 14-29
remapping memory types, 14-29
state of following a hardware reset, 14-20
variable-range registers, 14-23, 14-25
Multi-core technology
See multi-threading support
Multiple-processor management
bus locking, 11-3
guaranteed atomic operations, 11-2
initialization
- MP protocol, 11-20
- procedure, 11-56
local APIC, 13-1
memory ordering, 11-6
MP protocol, 11-20
overview of, 11-1
SMM considerations, 34-16
Multiple-processor system
local APIC and I/O APICs, Pentium 4, 13-3
local APIC and I/O APIC, P6 family, 13-3
Multisegment model, 3-4
Multitasking
initialization for, 12-10, 12-11
initializing IA-32e mode, 12-11
linking tasks, 10-15
mechanism, description of, 10-2
overview, 10-1
setting up TSS, 12-10
setting up TSS descriptor, 12-10
Multi-threading support
executing multiple threads, 11-28
handling interrupts, 11-28
logical processors per package, 11-26
mapping resources, 11-35
microcode updates, 11-34
performance monitoring counters, 11-34
programming considerations, 11-35
See also: Hyper-Threading Technology and dual-core technology
MWAIT instruction, 28-3
power management extensions, 17-35
MXCSR register, 7-56, 12-8, 16-6

# N
NaN, compatibility, IA-32 processors, 25-9
NE (numeric error) flag
CR0 control register, 2-16, 7-51, 12-6, 12-7, 25-8, 25-18
NEG instruction, 11-4
NetBurst microarchitecture (see Intel NetBurst microarchitecture)
NMI interrupt, 2-28, 13-3
description of, 7-2
handling during initialization, 12-9
handling in SMM, 34-11
handling multiple NMIs, 7-6
masking, 25-27
receiving when processor is shutdown, 7-37
reference information, 7-28
vector, 7-2
NMI# pin, 7-2, 7-28
Nominal CPI method, 22-148
Nonconforming code segments
accessing, 6-11
C (conforming) flag, 6-11
description of, 3-13
Non-halted clockticks, 22-148
setting up counters, 22-148
Non-Halted CPI method, 22-148
Nonmaskable interrupt (see NMI)
Non-precise event-based sampling
defined, 22-115
used for at-retirement counting, 22-126
writing an interrupt service routine for, 20-26
Non-retirement events, 22-115
Non-sleep clockticks, 22-148
NOT instruction, 11-4
NT (nested task) flag
EFLAGS register, 2-10, 10-10, 10-11, 10-15
Null segment selector, checking for, 6-6
Numeric overflow exception (#O), 25-10
Numeric underflow exception (#U), 25-10
NV (invert) flag, PerfEvtSel0 MSR
(P6 family processors), 22-5, 22-144
NW (not write-through) flag
CR0 control register, 2-16, 12-7, 14-12, 14-13, 14-16, 14-32, 25-18, 25-19, 25-30
NXE bit, 6-31

# O
Obsolete instructions, 25-5, 25-15
OF flag, EFLAGS register, 7-30
On die digital thermal sensor, 17-42
relevant MSRs, 17-42
sensor enumeration, 17-42
On-Demand
clock modulation enable bits, 17-40
On-demand
clock modulation duty cycle bits, 17-40
On-die sensors, 17-36
Opcodes
undefined, 25-5
Operands
operand-size prefix, 24-1
Operating modes
64-bit mode, 2-7
compatibility mode, 2-7
IA-32e mode, 2-7, 2-8
introduction to, 2-7

Vol. 3D INDEX-13

# INDEX

protected mode, 2-7
SMM (system management mode), 2-7
transitions between, 2-8
virtual-8086 mode, 2-8
VMX operation
* enabling and entering, 26-3
OR instruction, 11-4
OS (operating system mode) flag
* PerfEvtSel0 and PerfEvtSel1 MSRs (P6 only), 22-4, 22-143
OSFXSR (FXSAVE/FXRSTOR support) flag
* CR4 control register, 2-20, 12-8, 16-2
OSXMMEXCPT (SIMD floating-point exception support) flag, CR4 control register, 2-21, 7-56, 12-8, 16-3
OUT instruction, 11-17, 28-2
Out-of-spec status bit, 17-43, 17-46
Out-of-spec status log, 17-43, 17-46
OUTS/OUTSB/OUTSW/OUTSD instruction, 20-10, 28-2
Overflow exception (#OF), 7-30
Overheat interrupt enable bit, 17-44, 17-47

# P

P (present) flag
* page-directory entry, 7-47
* page-table entry, 7-47
* segment descriptor, 3-11
P5_MC_ADDR MSR, 18-13, 18-30
P5_MC_TYPE MSR, 18-13, 18-30
P6 family processors
* compatibility with FP software, 25-7
* last branch, interrupt, and exception recording, 20-40
PAE paging
* feature flag, CR4 register, 2-20, 2-21
* flag, CR4 control register, 3-6, 25-18, 25-19
Page attribute table (PAT)
* compatibility with earlier IA-32 processors, 14-36
* detecting support for, 14-34
* IA32_PAT MSR, 14-34
* introduction to, 14-33
* memory types that can be encoded with, 14-34
* MSR, 14-13
* precedence of cache controls, 14-14
* programming, 14-35
* selecting a memory type with, 14-35
Page directories, 2-6
Page directory
* base address (PDBR), 10-5
* introduction to, 2-6
* overview, 3-2
* setting up during initialization, 12-10
Page directory pointers, 2-6
Page frame (see Page)
Page tables, 2-6
* introduction to, 2-6
* overview, 3-2
* setting up during initialization, 12-10
Page-directory entries, 14-5
Page-fault exception (#PF), 5-54, 7-47, 25-21
Pages
* disabling protection of, 6-1
* enabling protection of, 6-1
* introduction to, 2-6
* overview, 3-2
* PG flag, CR0 control register, 6-1
* split, 25-15

Page-table entries, 14-5, 14-19
Paging
* combining segment and page-level protection, 6-29
* combining with segmentation, 3-5
* defined, 3-1
* IA-32e mode, 2-6
* initializing, 12-10
* introduction to, 2-6
* large page size MTRR considerations, 14-33
* mapping segments to pages, 5-54
* page-fault exception, 7-47, 7-58, 7-59
* page-level protection, 6-2, 6-3, 6-28
* page-level protection flags, 6-28
* virtual-8086 tasks, 23-7
Parameter
* passing, between 16- and 32-bit call gates, 24-6
* translation, between 16- and 32-bit code segments, 24-6
PAUSE instruction, 2-17, 28-3
PBi (performance monitoring/breakpoint pins) flags, DEBUGCTLMSR MSR, 20-39, 20-41
PC (pin control) flag, PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family processors), 22-4, 22-144
PC0 and PC1 (pin control) fields, CESR MSR (Pentium processor), 22-146
PCD pin (Pentium processor), 14-13
PCD (page-level cache disable) flag
* CR3 control register, 2-18, 14-13, 25-18, 25-30
* page-directory entries, 12-7, 14-13, 14-33
* page-table entries, 12-7, 14-13, 14-33, 25-31
PCE (performance monitoring counter enable) flag, CR4 control register, 2-20, 6-24, 22-117, 22-144
PCE (performance-monitoring counter enable) flag, CR4 control register, 25-18
PDBR (see CR3 control register)
PE (protection enable) flag, CR0 control register, 2-18, 6-1, 12-10, 12-13, 34-10
PEBS records, 20-23
PEBS (precise event-based sampling) facilities
* availability of, 22-127
* description of, 22-115, 22-127
* DS save area, 20-19
* IA-32e mode, 20-23
* PEBS buffer, 20-20, 22-128
* PEBS records, 20-19, 20-20, 20-22
* writing a PEBS interrupt service routine, 22-128
* writing interrupt service routine, 20-26
PEBS_UNAVAILABLE flag
* IA32_MISC_ENABLE MSR, 20-20
Pentium 4 processor
* compatibility with FP software, 25-7
* last branch, interrupt, and exception recording, 20-35
* time-stamp counter, 20-42
Pentium M processor
* last branch, interrupt, and exception recording, 20-39
* time-stamp counter, 20-42
Pentium processor, 25-7
* compatibility with MCA, 18-1
* performance-monitoring counters, 22-145
PerfCtr0 and PerfCtr1 MSRs (P6 family processors), 22-143, 22-144
PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family processors), 22-143
PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family processors), 22-143
Performance events
* architectural, 22-1

INDEX-14 Vol. 3D

INDEX

Intel Core Solo and Intel Core Duo processors, 22-1
non-architectural, 22-1
Pentium 4 and Intel Xeon processors, 20-35
Pentium M processors, 20-39
Performance state, 17-1
Performance-monitoring counters
* counted events (Pentium processors), 22-147
* description of, 22-1, 22-2
* interrupt, 13-1
* introduction of in IA-32 processors, 25-37
* monitoring counter overflow (P6 family processors), 22-145
* overflow, monitoring (P6 family processors), 22-145
* overview of, 2-7
* P6 family processors, 22-142
* Pentium II processor, 22-142
* Pentium Pro processor, 22-142
* Pentium processor, 22-145
* reading, 22-144
* setting up (P6 family processors), 22-143
* software drivers for, 22-144
* starting and stopping, 22-144
PG (paging) flag
* CR0 control register, 2-16, 6-1
PG (paging) flag, CR0 control register, 12-10, 12-13, 25-32, 34-10
PGE (page global enable) flag, CR4 control register, 2-20, 14-13, 25-18, 25-19
PhysBase field, IA32_MTRR_PHYSBASEn MTRR, 14-24, 14-26
Physical address extension
* introduction to, 3-6
Physical address space
* 4 GBytes, 3-6
* 64 GBytes, 3-6
* addressing, 2-6
* defined, 3-1
* description of, 3-6
* IA-32e mode, 3-6
* mapped to a task, 10-17
* mapping with variable-range MTRRs, 14-23, 14-25
Physical destination mode, local APIC, 13-24
PhysMask
* IA32_MTRR_PHYSMASKn MTRR, 14-24, 14-26
PM0/BP0 and PM1/BP1 (performance-monitor) pins (Pentium processor), 22-145, 22-146, 22-147
PML4 tables, 2-6
Pointers
* code-segment pointer size, 24-4
* limit checking, 6-25
* validation, 6-24
POP instruction, 3-8
POPF instruction, 7-8, 20-11
Power consumption
* software controlled clock, 17-36, 17-40
Precise event-based sampling (see PEBS)
PREFETCHh instruction, 2-17, 14-17
Previous task link field, TSS, 10-5, 10-15, 10-16
Privilege levels
* checking when accessing data segments, 6-8
* checking, for call gates, 6-15
* checking, when transferring program control between code segments, 6-10
* description of, 6-6
* protection rings, 6-8
Privileged instructions, 6-23
Processor families
* 06H, 19-1

0FH, 19-1
Processor management
* initialization, 12-1
* local APIC, 13-1
* microcode update facilities, 12-27
* overview of, 11-1
* See also: multiple-processor management
Processor ordering, description of, 11-6
PROCHOT# log, 17-43, 17-46
PROCHOT# or FORCEPR# event bit, 17-42, 17-46
Protected mode
* IDT initialization, 12-10
* initialization for, 12-9
* mixing 16-bit and 32-bit code modules, 24-1
* mode switching, 12-13
* PE flag, CR0 register, 6-1
* switching to, 6-1, 12-13
* system data structures required during initialization, 12-9
Protection
* combining segment & page-level, 6-29
* disabling, 6-1
* enabling, 6-1
* flags used for page-level protection, 6-2, 6-3
* flags used for segment-level protection, 6-2
* IA-32e mode, 6-3
* of exception, interrupt-handler procedures, 7-17
* overview of, 6-1
* page level, 6-1, 6-28, 6-29, 6-30
* page level, overriding, 6-29
* page-level protection flags, 6-28
* read/write, page level, 6-29
* segment level, 6-1
* user/supervisor type, 6-28
Protection rings, 6-8
PSE (page size extension) flag
* CR4 control register, 2-21, 14-20, 25-18, 25-19
PSE-36 page size extension, 3-6
Pseudo-functions
* VMfail, 33-2
* VMfailInvalid, 33-2
* VMfailValid, 33-2
* VMsucceed, 33-2
Pseudo-infinity, 25-9
Pseudo-NaN, 25-9
Pseudo-zero, 25-9
P-state, 17-1
PUSH instruction, 25-7
PUSHF instruction, 7-8, 25-7
PVI (protected-mode virtual interrupts) flag
* CR4 control register, 2-11, 2-21, 25-18
PWT pin (Pentium processor), 14-13
PWT (page-level write-through) flag
* CR3 control register, 2-18, 14-13, 25-18, 25-30
* page-directory entries, 12-7, 14-13, 14-33
* page-table entries, 12-7, 14-33, 25-31

# Q
QNaN, compatibility, IA-32 processors, 25-9

# R
RDMSR instruction, 2-21, 2-23, 2-29, 6-24, 20-37, 20-41, 20-43, 22-117, 22-143, 22-144, 22-145, 25-5, 25-36, 28-4

Vol. 3D INDEX-15
<page_number>INDEX-15</page_number>

# INDEX

RDPMC instruction, 2-28, 6-24, 22-117, 22-143, 22-144, 25-4, 25-18, 25-37, 28-4, 28-6, 28-11, 28-14
RDTSC instruction, 6-24, 20-43, 25-5, 28-4, 28-12
reading sensors, 17-42
Read/write
* protection, page level, 6-29
* rights, checking, 6-25
Real-address mode
* 8086 emulation, 23-1
* address translation in, 23-2
* description of, 23-1
* exceptions and interrupts, 23-6
* IDT initialization, 12-8
* IDT, changing base and limit of, 23-5
* IDT, structure of, 23-5
* IDT, use of, 23-4
* initialization, 12-8
* instructions supported, 23-3
* interrupt and exception handling, 23-4
* interrupts, 23-6
* introduction to, 2-8
* mode switching, 12-13
* native 16-bit mode, 24-1
* overview of, 23-1
* registers supported, 23-3
* switching to, 12-14
Recursive task switching, 10-16
Requested privilege level (see RPL)
Reserved bits, 25-2
RESET# pin, 7-3, 25-16
RESET# signal, 2-28
Resolution in degrees, 17-43
Restarting program or task, following an exception or interrupt, 7-5
Restricting addressable domain, 6-28
RET instruction, 6-10, 6-20, 24-6
Returning
* from a called procedure, 6-20
* from an interrupt or exception handler, 7-14
RF (resume) flag
* EFLAGS register, 2-10, 7-8
RPL
* description of, 3-8, 6-8
* field, segment selector, 6-2
RSM instruction, 2-28, 11-19, 25-5, 28-4, 34-1, 34-2, 34-3, 34-13, 34-16, 34-19
RsvdZ, 13-41
R/S# pin, 7-3
R/W (read/write) flag
* page-directory entry, 6-1, 6-2, 6-29
* page-table entry, 6-1, 6-2, 6-29
R/W0-R/W3 (read/write) fields
* DR7 register, 20-5, 25-20

# S

S (descriptor type) flag
* segment descriptor, 3-11, 3-12, 6-2, 6-5
SBB instruction, 11-4
Segment descriptors
* access rights, 6-24
* access rights, invalid values, 25-19
* base address fields, 3-10
* code type, 6-2
* data type, 6-2

* description of, 2-4, 3-9
* DPL (descriptor privilege level) field, 3-11, 6-2
* D/B (default operation size/default stack pointer size and/or upper bound) flag, 3-11, 6-4
* E (expansion direction) flag, 6-2, 6-4
* G (granularity) flag, 3-11, 6-2, 6-4
* limit field, 6-2, 6-4
* loading, 25-20
* P (segment-present) flag, 3-11
* S (descriptor type) flag, 3-11, 3-12, 6-2, 6-5
* segment limit field, 3-10
* system type, 6-2
* tables, 3-14
* TSS descriptor, 10-5, 10-6
* type field, 3-10, 3-12, 6-2, 6-5
* type field, encoding, 3-14
* when P (segment-present) flag is clear, 3-11
Segment limit
* checking, 2-26
* field, segment descriptor, 3-10
Segment not present exception (#NP), 3-11
Segment registers
* description of, 3-8
* IA-32e mode, 3-9
* saved in TSS, 10-4
Segment selectors
* description of, 3-7
* index field, 3-7
* null, 6-6
* null in 64-bit mode, 6-6
* RPL field, 3-8, 6-2
* TI (table indicator) flag, 3-7
Segment-not-present exception (#NP), 7-41
Segments
* 64-bit mode, 3-5
* basic flat model, 3-3
* code type, 3-12
* combining segment, page-level protection, 6-29
* combining with paging, 3-5
* compatibility mode, 3-5
* data type, 3-12
* defined, 3-1
* disabling protection of, 6-1
* enabling protection of, 6-1
* mapping to pages, 5-54
* multisegment usage model, 3-4
* protected flat model, 3-3
* segment-level protection, 6-2, 6-3
* segment-not-present exception, 7-41
* system, 2-4
* types, checking access rights, 6-24
* typing, 6-5
* using, 3-2
* wraparound, 25-34
SELF IPI register, 13-39
Self-modifying code, effect on caches, 14-18
Serializing, 11-18
Serializing instructions
* CPUID, 11-18
* HT technology, 11-31
* non-privileged, 11-18
* privileged, 11-18
SF (stack fault) flag, x87 FPU status word, 25-8
SFENCE instruction, 2-17, 11-7, 11-17, 11-18, 11-19
SGDT instruction, 2-25, 3-15

INDEX-16 Vol. 3D

INDEX

Shared resources
mapping of, 11-35
Shutdown
resulting from double fault, 7-37
resulting from out of IDT limit condition, 7-37
SIDT instruction, 2-25, 3-16, 7-10
SIMD floating-point exception (#XM), 2-20, 7-56, 12-8
SIMD floating-point exceptions
description of, 7-56, 16-5
handler, 16-3
support for, 2-20
Single-stepping
breakpoint exception condition, 20-11
on branches, 20-14
on exceptions, 20-14
on interrupts, 20-14
TF (trap) flag, EFLAGS register, 20-11
SLDT instruction, 2-25
SLTR instruction, 3-16
SMBASE
default value, 34-4
relocation of, 34-15
SMI handler
description of, 34-1
execution environment for, 34-9
exiting from, 34-3
VMX treatment of, 34-17
SMI interrupt, 2-28, 13-3
description of, 34-1, 34-2
IO\_SMI bit, 34-12
priority, 34-3
switching to SMM, 34-2
synchronous and asynchronous, 34-12
VMX treatment of, 34-17
SMI# pin, 7-3, 34-2, 34-15
SMM
asynchronous SMI, 34-12
auto halt restart, 34-14
executing the HLT instruction in, 34-15
exiting from, 34-3
handling exceptions and interrupts, 34-11
introduction to, 2-8
I/O instruction restart, 34-15
I/O state implementation, 34-12
native 16-bit mode, 24-1
overview of, 34-1
revision identifier, 34-13
revision identifier field, 34-13
switching to, 34-2
switching to from other operating modes, 34-2
synchronous SMI, 34-12
VMX operation
default RSM treatment, 34-18
default SMI delivery, 34-17
dual-monitor treatment, 34-19
overview, 34-2
protecting CR4.VMXE, 34-19
RSM instruction, 34-19
SMM monitor, 34-2
SMM VM exits, 30-1, 34-19
SMM-transfer VMCS, 34-20
SMM-transfer VMCS pointer, 34-20
VMCS pointer preservation, 34-17
VMX-critical state, 34-17
SMRAM
caching, 34-8

state save map, 34-4
structure of, 34-4
SMSW instruction, 2-25, 28-12
SNaN, compatibility, IA-32 processors, 25-9, 25-14
Snooping mechanism, 14-6
Software controlled clock
modulation control bits, 17-40
power consumption, 17-36, 17-40
Software interrupts, 7-4
Software-controlled bus locking, 11-4
Split pages, 25-15
Spurious interrupt, local APIC, 13-33
SSE extensions
checking for with CPUID, 16-2
checking support for FXSAVE/FXRSTOR, 16-2
CPUID feature flag, 12-8
EM flag, 2-17
emulation of, 16-6
facilities for automatic saving of state, 16-6, 16-7
initialization, 12-8
introduction of into the IA-32 architecture, 25-3
providing exception handlers for, 16-4, 16-5
providing operating system support for, 16-1
saving and restoring state, 16-6
saving state on task, context switches, 16-6
SIMD Floating-point exception (#XM), 7-56
using TS flag to control saving of state, 16-7
SSE feature flag
CPUID instruction, 16-2
SSE2 extensions
checking for with CPUID, 16-2
checking support for FXSAVE/FXRSTOR, 16-2
CPUID feature flag, 12-8
EM flag, 2-17
emulation of, 16-6
facilities for automatic saving of state, 16-6, 16-7
initialization, 12-8
introduction of into the IA-32 architecture, 25-3
providing exception handlers for, 16-4, 16-5
providing operating system support for, 16-1
saving and restoring state, 16-6
saving state on task, context switches, 16-6
SIMD Floating-point exception (#XM), 7-56
using TS flag to control saving state, 16-7
SSE2 feature flag
CPUID instruction, 16-2
SSE3 extensions
checking for with CPUID, 16-2
CPUID feature flag, 12-8
EM flag, 2-17
emulation of, 16-6
example verifying SS3 support, 11-47, 11-50, 17-2
facilities for automatic saving of state, 16-6, 16-7
initialization, 12-8
introduction of into the IA-32 architecture, 25-3
providing exception handlers for, 16-4, 16-5
providing operating system support for, 16-1
saving and restoring state, 16-6
saving state on task, context switches, 16-6
using TS flag to control saving of state, 16-7
SSE3 feature flag
CPUID instruction, 16-2
Stack fault exception (#SS), 7-43
Stack fault, x87 FPU, 25-8, 25-13
Stack pointers

Vol. 3D INDEX-17

# INDEX

privilege level 0, 1, and 2 stacks, 10-5
size of, 3-11
Stack segments
paging of, 2-6
privilege level check when loading SS register, 6-10
size of stack pointer, 3-11
Stack switching
exceptions/interrupts when switching stacks, 7-8
IA-32e mode, 7-22
inter-privilege level calls, 6-17
Stack-fault exception (#SS), 25-34
Stacks
error code pushes, 25-32
faults, 7-43
for privilege levels 0, 1, and 2, 6-17
interlevel RET/IRET
from a 16-bit interrupt or call gate, 25-33
interrupt stack table, 64-bit mode, 7-23
management of control transfers for
16- and 32-bit procedure calls, 24-4
operation on pushes and pops, 25-32
pointers to in TSS, 10-5
stack switching, 6-17, 7-22
usage on call to exception
or interrupt handler, 25-33
Stepping information, following processor initialization or reset, 12-5
STI instruction, 7-8
Store buffer
caching terminology, 14-5
characteristics of, 14-4
description of, 14-5, 14-20
in IA-32 processors, 25-34
location of, 14-1
operation of, 14-20
STPCLK# pin, 7-3
STR instruction, 2-25, 3-16, 10-7
Strong uncached (UC) memory type
description of, 14-6
effect on memory ordering, 11-18
use of, 12-8, 14-8
Sub C-state, 17-35
SUB instruction, 11-4
Supervisor mode
description of, 6-28
U/S (user/supervisor) flag, 6-28
SVR (spurious-interrupt vector register), local APIC, 13-8, 25-28
SWAPGS instruction, 2-7
SYSCALL instruction, 2-7, 6-22
SYSENTER instruction, 3-8, 6-10, 6-20, 6-21
SYSENTER_CS_MSR, 6-21
SYSENTER_EIP_MSR, 6-21
SYSENTER_ESP_MSR, 6-21
SYSEXIT instruction, 3-8, 6-10, 6-20, 6-21
SYSRET instruction, 2-7, 6-22
System
architecture, 2-1, 2-2
data structures, 2-2
instructions, 2-7, 2-24
registers in IA-32e mode, 2-7
registers, introduction to, 2-6
segment descriptor, layout of, 6-2
segments, paging of, 2-6
System programming
MMX technology, 15-1

System-management mode (see SMM)

# T
T (debug trap) flag, TSS, 10-5
Task gates
descriptor, 10-8
executing a task, 10-2
handling a virtual-8086 mode interrupt or exception through, 23-14
IA-32e mode, 2-5
in IDT, 7-11
introduction for IA-32e, 2-4
introduction to, 2-4, 2-5
layout of, 7-11
referencing of TSS descriptor, 7-18
Task management, 10-1
data structures, 10-3
mechanism, description of, 10-2
Task register, 3-16
description of, 2-13, 10-1, 10-7
IA-32e mode, 2-13
initializing, 12-11
introduction to, 2-6
Task switching
description of, 10-3
exception condition, 20-11
operation, 10-10
preventing recursive task switching, 10-16
saving MMX state on, 15-4
saving SSE/SSE2/SSE3 state
on task or context switches, 16-6
T (debug trap) flag, 10-5
Tasks
address space, 10-16
description of, 10-1
exception-handler task, 7-12
executing, 10-2
Intel 286 processor tasks, 25-37
interrupt-handler task, 7-12
interrupts and exceptions, 7-18
linking, 10-15
logical address space, 10-17
management, 10-1
mapping linear and physical address space, 10-17
restart following an exception or interrupt, 7-5
state (context), 10-2, 10-3
structure, 10-1
switching, 10-3
task management data structures, 10-3
TF (trap) flag, EFLAGS register, 2-10, 7-18, 20-11, 20-13, 20-36, 20-38, 20-39, 20-41, 23-4, 23-19, 34-11
Thermal monitoring
advanced power management, 17-35
automatic, 17-37
automatic thermal monitoring, 17-36
catastrophic shutdown detector, 17-36, 17-37
clock-modulation bits, 17-40
C-state, 17-35
detection of facilities, 17-41
Enhanced Intel SpeedStep Technology, 17-1
IA32_APERF MSR, 17-2
IA32_MPERF MSR, 17-1
IA32_THERM_INTERRUPT MSR, 17-42
IA32_THERM_STATUS MSR, 17-42

INDEX-18 Vol. 3D

INDEX

interrupt enable/disable flags, 17-39
interrupt mechanisms, 17-36
MWAIT extensions for, 17-35
on die sensors, 17-36, 17-42
overview of, 17-1, 17-36
performance state transitions, 17-38
sensor interrupt, 13-1
setting thermal thresholds, 17-42
software controlled clock modulation, 17-36, 17-40
status flags, 17-38
status information, 17-38, 17-39
stop clock mechanism, 17-36
thermal monitor 1 (TM1), 17-37
thermal monitor 2 (TM2), 17-37
TM flag, CPUID instruction, 17-41
Thermal status bit, 17-42, 17-45
Thermal status log bit, 17-42, 17-45
Thermal threshold #1 log, 17-43, 17-46
Thermal threshold #1 status, 17-43, 17-46
Thermal threshold #2 log, 17-43, 17-46
Thermal threshold #2 status, 17-43, 17-46
THERMTRIP# interrupt enable bit, 17-44, 17-47
thread timeout indicator, 19-3, 19-7, 19-9, 19-12, 19-15
Threshold #1 interrupt enable bit, 17-44, 17-47
Threshold #1 value, 17-44, 17-47
Threshold #2 interrupt enable, 17-44, 17-47
Threshold #2 value, 17-44, 17-47
TI (table indicator) flag, segment selector, 3-7
Timer, local APIC, 13-16
Time-stamp counter
counting clockticks, 22-148
description of, 20-42
IA32_TIME_STAMP_COUNTER MSR, 20-42
RDTSC instruction, 20-42
software drivers for, 22-144
TSC flag, 20-42
TSD flag, 20-42
TLBs
description of, 14-1, 14-5
flushing, 14-19
invalidating (flushing), 2-27
relationship to PGE flag, 25-19
relationship to PSE flag, 14-20
TM1 and TM2
See: thermal monitoring, 17-37
TMR
Trigger Mode Register, 13-32, 13-40, 13-42, 13-48
TMR (Trigger Mode Register), local APIC, 13-31
TPR
Task Priority Register, 13-39, 13-42
TR (trace message enable) flag
DEBUGCTLMSR MSR, 20-13, 20-36, 20-38, 20-39, 20-41
Trace cache, 14-4, 14-5
Transcendental instruction accuracy, 25-8, 25-14
Translation lookaside buffer (see TLB)
Trap gates
difference between interrupt and trap gates, 7-18
for 16-bit and 32-bit code modules, 24-1
handling a virtual-8086 mode interrupt or exception through, 23-12
in IDT, 7-11
introduction for IA-32e, 2-4
introduction to, 2-4, 2-5
layout of, 7-11
Traps

description of, 7-5
restarting a program or task after, 7-5
TS (task switched) flag
CR0 control register, 2-16, 2-26, 7-34, 15-1, 16-3, 16-7
TSD (time-stamp counter disable) flag
CR4 control register, 2-21, 6-24, 20-43, 25-18
TSS
16-bit TSS, structure of, 10-18
32-bit TSS, structure of, 10-3
64-bit mode, 10-19
CR3 control register (PDBR), 10-4, 10-17
description of, 2-4, 2-5, 10-1, 10-3
EFLAGS register, 10-5
EFLAGS.NT, 10-15
EIP, 10-5
executing a task, 10-2
floating-point save area, 25-12
format in 64-bit mode, 10-19
general-purpose registers, 10-4
IA-32e mode, 2-5
initialization for multitasking, 12-10
interrupt stack table, 10-19
invalid TSS exception, 7-39
IRET instruction, 10-15
I/O map base address field, 10-5, 25-29
I/O permission bit map, 10-5, 10-19
LDT segment selector field, 10-5, 10-16
link field, 7-18
order of reads/writes to, 25-29
pointed to by task-gate descriptor, 10-8
previous task link field, 10-5, 10-15, 10-16
privilege-level 0, 1, and 2 stacks, 6-17
referenced by task gate, 7-18
segment registers, 10-4
T (debug trap) flag, 10-5
task register, 10-7
using 16-bit TSSs in a 32-bit environment, 25-29
virtual-mode extensions, 25-29
TSS descriptor
B (busy) flag, 10-5
busy flag, 10-16
initialization for multitasking, 12-10
structure of, 10-5, 10-6
TSS segment selector
field, task-gate descriptor, 10-8
writes, 25-29
Type
checking, 6-5
field, IA32_MTRR_DEF_TYPE MSR, 14-22
field, IA32_MTRR_PHYSBASEn MTRR, 14-24, 14-26
field, segment descriptor, 3-10, 3-12, 3-14, 6-2, 6-5
of segment, 6-5

# U
UC- (uncacheable) memory type, 14-6
UD2 instruction, 25-4
Uncached (UC-) memory type, 14-8
Uncached (UC) memory type (see Strong uncached (UC) memory type)
Undefined opcodes, 25-5

Vol. 3D <page_number>INDEX-19</page_number>

INDEX

Unit mask field, PerfEvtSel0 and PerfEvtSel1 MSRs (P6 family
processors), 22-4, 22-6, 22-7, 22-8, 22-9, 22-10, 22-11,
22-13, 22-30, 22-32, 22-39, 22-40, 22-41, 22-59, 22-61,
22-107, 22-108, 22-109, 22-143, 22-152, 22-153, 22-154,
22-155, 22-159, 22-160
Un-normal number, 25-9
User mode
description of, 6-28
U/S (user/supervisor) flag, 6-28
User-defined interrupts, 7-1, 7-61
USR (user mode) flag, PerfEvtSel0 and PerfEvtSel1 MSRs (P6
family processors), 22-4, 22-6, 22-7, 22-8, 22-9, 22-10,
22-11, 22-30, 22-32, 22-39, 22-40, 22-41, 22-59, 22-61,
22-107, 22-108, 22-109, 22-143, 22-152, 22-153, 22-154,
22-155, 22-159, 22-160
U/S (user/supervisor) flag
page-directory entry, 6-1, 6-2, 6-28
page-table entries, 23-8
page-table entry, 6-1, 6-2, 6-28

# V

V (valid) flag
IA32_MTRR_PHYSMASKn MTRR, 14-25, 14-26
Variable-range MTRRs, description of, 14-23, 14-25
VCNT (variable range registers count) field, IA32_MTRRCAP MSR,
14-22
Vectors
exceptions, 7-1
interrupts, 7-1
VERR instruction, 2-27, 6-25
VERW instruction, 2-27, 6-25
VIF (virtual interrupt) flag
EFLAGS register, 2-11, 25-6, 25-7
VIP (virtual interrupt pending) flag
EFLAGS register, 2-11, 25-6, 25-7
Virtual memory, 2-6, 3-1, 3-2
Virtual-8086 mode
8086 emulation, 23-1
description of, 23-5
emulating 8086 operating system calls, 23-18
enabling, 23-6
entering, 23-8
exception and interrupt handling overview, 23-11
exceptions and interrupts, handling through a task gate, 23-14
exceptions and interrupts, handling through a trap or interrupt
gate, 23-12
handling exceptions and interrupts through a task gate, 23-14
interrupts, 23-6
introduction to, 2-8
IOPL sensitive instructions, 23-10
I/O-port-mapped I/O, 23-11
leaving, 23-9
memory mapped I/O, 23-11
native 16-bit mode, 24-1
overview of, 23-1
paging of virtual-8086 tasks, 23-7
protection within a virtual-8086 task, 23-8
special I/O buffers, 23-11
structure of a virtual-8086 task, 23-7
virtual I/O, 23-10
VM flag, EFLAGS register, 2-11
Virtual-8086 tasks
paging of, 23-7
protection within, 23-8
structure of, 23-7
VM entries
basic VM-entry checks, 29-2
checking guest state
control registers, 29-9
debug registers, 29-9
descriptor-table registers, 29-13
MSRs, 29-9
non-register state, 29-13
RIP and RFLAGS, 29-13
segment registers, 29-10
checks on controls, host-state area, 29-2
registers and MSRs, 29-7
segment and descriptor-table registers, 29-8
VMX control checks, 29-2
exit-reason numbers, C-1
loading guest state, 29-16
control and debug registers, MSRs, 29-16
RIP, RSP, RFLAGS, 29-18
segment & descriptor-table registers, 29-17
loading MSRs, 29-19
failure cases, 29-19
VM-entry MSR-load area, 29-19
overview of failure conditions, 29-1
overview of steps, 29-1
VMLAUNCH and VMRESUME, 29-1
See also: VMCS, VMM, VM exits
VM exits
architectural state
existing before exit, 30-1
updating state before exit, 30-1
basic VM-exit information fields, 30-4
basic exit reasons, 30-4
exit qualification, 30-4
exception bitmap, 30-1
exceptions (faults, traps, and aborts), 28-6
exit-reason numbers, C-1
external interrupts, 28-7
IA-32 faults and VM exits, 28-1
INITs, 28-7
instructions that cause:
conditional exits, 28-2
unconditional exits, 28-2
interrupt-window exiting, 28-7
non-maskable interrupts (NMIs), 28-7
page faults, 28-6
start-up IPIs (SIPIs), 28-7
task switches, 28-7
See also: VMCS, VMM, VM entries
VM (virtual-8086 mode) flag
EFLAGS register, 2-8, 2-11
VMCALL instruction, 33-1
VMCLEAR instruction, 33-1
VMCS
error numbers, 33-30
field encodings, 1-3, B-1
16-bit guest-state fields, B-1
16-bit host-state fields, B-2
32-bit control fields, B-1, B-8
32-bit guest-state fields, B-10
32-bit read-only data fields, B-9
64-bit control fields, B-2
64-bit guest-state fields, B-6, B-7
natural-width control fields, B-11
natural-width guest-state fields, B-12
natural-width host-state fields, B-13
natural-width read-only data fields, B-11
format of VMCS region, 27-2

INDEX-20 Vol. 3D

INDEX

guest-state area, 27-3
* guest non-register state, 27-6
* guest register state, 27-4
host-state area, 27-3, 27-9
introduction, 27-1
migrating between processors, 27-31
software access to, 27-31
VMCS data, 27-2, 28-23
VMCS pointer, 27-1
VMCS region, 27-1
VMCS revision identifier, 27-2, 28-23
VM-entry control fields, 27-3, 27-24
* entry controls, 27-24
* entry controls for event injection, 27-26
* entry controls for MSRs, 27-25
VM-execution control fields, 27-3, 27-10
* controls for CR8 accesses, 27-15
* CR3-target controls, 27-15
* exception bitmap, 27-14
* I/O bitmaps, 27-14
* masks & read shadows CR0 & CR4, 27-15
* pin-based controls, 27-10
* processor-based controls, 27-10, 27-22
* time-stamp counter offset, 27-15
VM-exit control fields, 27-3, 27-22
* exit controls for MSRs, 27-24
VM-exit information fields, 27-3, 27-27
* basic exit information, 27-27, C-1
* basic VM-exit information, 27-27
* exits due to instruction execution, 27-30
* exits due to vectored events, 27-28
* exits occurring during event delivery, 27-29
* VM-instruction error field, 27-30
VM-instruction error field, 29-1, 33-30
VMREAD instruction
* field encodings, 1-3, B-1
VMWRITE instruction
* field encodings, 1-3, B-1
VMX-abort indicator, 27-2, 28-23
See also: VM entries, VM exits, VMM, VMX
VME (virtual-8086 mode extensions) flag, CR4 control register, 2-11, 2-18, 25-18
VMLAUNCH instruction, 33-1
VMM
* VM exits, 30-1
* See also: VMCS, VM entries, VM exits, VMX
VMPTRLD instruction, 33-1
VMPTRST instruction, 33-1
VMREAD instruction, 33-1
* field encodings, B-1
VMRESUME instruction, 33-1
VMWRITE instruction, 33-1
* field encodings, B-1
VMX
* A20M# signal, 26-4
* capability MSRs
    - overview, 26-2, A-1
    - IA32_VMX_BASIC MSR, 27-3, A-1, A-2
    - IA32_VMX_CR0_FIXED0 MSR, A-7
    - IA32_VMX_CR0_FIXED1 MSR, A-7
    - IA32_VMX_ENTRY_CTLS MSR, A-2, A-5, A-6
    - IA32_VMX_EXIT_CTLS MSR, A-2, A-5
    - IA32_VMX_MISC MSR, 27-6, 29-3, 29-13, 34-26, A-6
    - IA32_VMX_PINBASED_CTLS MSR, A-2, A-3
    - IA32_VMX_PROCBASED_CTLS MSR, 27-10, A-2, A-3, A-4, A-5, A-8, A-9
* CPUID instruction, 26-2, A-1
* CR4 control register, 26-3

CR4 fixed bits, A-7
entering operation, 26-3
guest software, 26-1
IA32_FEATURE_CONTROL MSR, 26-3
INIT# signal, 26-4
instruction set, 26-2, 35-2
introduction, 26-1
microcode update facilities, 28-14
non-root operation, 26-1
* event blocking, 28-15
* instruction changes, 28-8
* overview, 28-1
* task switches not allowed, 28-15
* see VM exits
operation restrictions, 26-3
root operation, 26-1
SMM
* CR4.VMXE reserved, 34-19
* overview, 34-2
* RSM instruction, 34-19
* VMCS pointer, 34-17
* VMX-critical state, 34-17
testing for support, 26-2
virtual-machine control structure (VMCS), 26-2
virtual-machine monitor (VMM), 26-1
VM entries and exits, 26-1
VM exits, 30-1
VMCS pointer, 26-2
VMM life cycle, 26-2
VMXOFF instruction, 26-3
VMXON instruction, 26-3
VMXON pointer, 26-3
VMXON region, 26-3
See also: VMM, VMCS, VM entries, VM exits
VMXOFF instruction, 26-3, 33-1
VMXON instruction, 26-3, 33-1

# W

WAIT/FWAIT instructions, 7-34, 25-8, 25-15, 25-16
WB (write back) memory type, 11-18, 14-7, 14-8
WB (write-back) pin (Pentium processor), 14-13
WBINVD instruction, 2-27, 6-24, 14-16, 14-17, 25-4
WB/WT# pins, 14-13
WC buffer (see Write combining (WC) buffer)
WC (write combining)
* flag, IA32_MTRRCAP MSR, 14-22
* memory type, 14-7, 14-8
WP (write protected) memory type, 14-7
WP (write protect) flag
* CR0 control register, 2-16, 6-29, 25-18
Write
* hit, 14-5
Write combining (WC) buffer, 14-4, 14-8
Write-back caching, 14-6
WRMSR instruction, 2-21, 2-23, 2-28, 2-29, 6-24, 11-19, 20-35, 20-40, 20-43, 22-117, 22-143, 22-144, 22-145, 25-5, 25-36
WT (write through) memory type, 14-7, 14-8
WT# (write-through) pin (Pentium processor), 14-13

# X

x2APIC ID, 13-41, 13-42, 13-45, 13-47
x2APIC Mode, 13-32, 13-38, 13-39, 13-41, 13-42, 13-45, 13-46, 13-47
x87 FPU
* compatibility with IA-32 x87 FPUs and math coprocessors, 25-7

Vol. 3D INDEX-21

INDEX

configuring the x87 FPU environment, 12-6
device-not-available exception, 7-34
effect of MMX instructions on pending x87 floating-point
exceptions, 15-5
effects of MMX instructions on x87 FPU state, 15-3
effects of MMX, x87 FPU, FXSAVE, and FXRSTOR instructions
on x87 FPU tag word, 15-3
error signals, 25-11
initialization, 12-5
instruction synchronization, 25-15
register stack, aliasing with MMX registers, 15-2
setting up for software emulation of x87 FPU functions, 12-6
using TS flag to control saving of x87 FPU state, 16-7
x87 floating-point error exception (#MF), 7-51
x87 FPU control word
compatibility, IA-32 processors, 25-9
x87 FPU floating-point error exception (#MF), 7-51
x87 FPU status word
condition code flags, 25-8
x87 FPU tag word, 25-9
XADD instruction, 11-4, 25-4
xAPIC, 13-39, 13-41
determining lowest priority processor, 13-26
interrupt control register, 13-22
introduction to, 13-4
message passing protocol on system bus, 13-34
new features, 25-28
spurious vector, 13-33
using system bus, 13-4
xAPIC Mode, 13-32, 13-38, 13-42, 13-45, 13-47
XCHG instruction, 11-3, 11-4, 11-17
XCR0, 2-19
XGETBV, 2-19, 2-25
XMM registers, saving, 16-6
XOR instruction, 11-4
XSAVE, 2-19, 16-7, 16-8, 16-9, 16-10
XSETBV, 2-19, 2-22, 2-25, 2-29

# Z

ZF flag, EFLAGS register, 6-25

INDEX-22 Vol. 3D